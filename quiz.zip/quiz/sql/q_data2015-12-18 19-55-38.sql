CREATE TABLE `q_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_text` varchar(500) NOT NULL,
  `answer_option1` varchar(30) NOT NULL,
  `answer_option2` varchar(30) NOT NULL,
  `answer_option3` varchar(30) NOT NULL,
  `answer_option4` varchar(30) NOT NULL,
  `correct_answer` varchar(30) NOT NULL,
  `image_location` varchar(100) DEFAULT NULL,
  `category` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;


