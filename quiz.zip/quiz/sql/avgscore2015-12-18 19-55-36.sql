CREATE TABLE `avgscore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `correct_answers` int(11) NOT NULL,
  `attempted_questions` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;



insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (41,3,3,30,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (45,2,3,20,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (46,1,3,10,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (47,2,3,20,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (48,2,3,1,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (49,1,3,0,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (50,1,3,10,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (51,3,3,30,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (52,2,3,20,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (53,3,3,30,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (54,2,3,20,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (55,3,3,30,1);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (56,4,5,40,2);
insert into `avgscore`(`id`,`correct_answers`,`attempted_questions`,`score`,`category`) values (57,3,3,30,5);
