
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(20) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;



insert into `category`(`id`,`category`,`category_id`) values (2,'Cricket',1);
insert into `category`(`id`,`category`,`category_id`) values (3,'Football',2);
insert into `category`(`id`,`category`,`category_id`) values (4,'Rugby',3);
insert into `category`(`id`,`category`,`category_id`) values (5,'Tennis',4);
insert into `category`(`id`,`category`,`category_id`) values (6,'Level2',5);
