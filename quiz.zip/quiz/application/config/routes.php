<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
*/

// by default it routes to home page. In this case it will be routed to index.php via Controller Home.
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = TRUE;

/*
URL: /fetch_question
Type: POST
Description: Gets a question from database for the category selected one by one and displayed to user (pagination concept)
Parameter: id
*/ 
$route['fetch_question'] = 'restapi/fetch_question'; 
/*
URL: /validate_answer
Type: POST
Description: Validates the answer submitted by the user for the question. If the answer is correct '0' is sent in response and '1'/'2' for invalid answer
Parameter: questionid
*/

$route['validate_answer'] = 'restapi/validateanswer'; 
/*
URL: /submit_results
Type: POST
Description: Find the average score and total number of plays, inserts the user score into database
Parameter: correct_answer, number_questions, score, category
*/
$route['submit_results'] = 'restapi/submitresults'; 

/*
URL: getquestionsbycategory/(:num)
Type: GET
Description: Gets all questions from the database for the question selected
Parameter: category - category selected by the admin in the admin page
*/

$route['getquestionsbycategory/(:num)'] = 'restapi/get_allquestionsbycategory/category/$1'; 
/*
URL: deletequestion/(:num)
Type: delete
Description: delete a row item from the database for the specified quiz id
Parameter: id- quiz id to be deleted
*/
$route['deletequestion/(:num)'] = 'restapi/delete_question/id/$1';
/*
URL: /savequestion
Type: POST
Description: Edit / Save the question data to database. If quizid is available data is updated in database, if no quizid is available the data will be newly inserted into database
Parameter: question_data, question_option,question_option1_text,question_option2_text,question_option3_text,question_option4_text,selectcategory, image_name, quizid
*/
$route['savequestion'] = 'restapi/save_question';
/*
URL: /uploadfile
Type: POST
Description: Upload the file selected by Administrator
Parameter: imageToUpload
*/
$route['uploadfile'] = 'restapi/upload_file';
/*
URL: /viewquestion/(:num)
Type: GET
Description: Gets the question data from the database for the given question id
Parameter: id - question id
*/
$route['viewquestion/(:num)'] = 'restapi/fetch_question_db/id/$1';
/*
Route to admin home page
*/
$route['adminhome'] = 'loginvalidation/home';


