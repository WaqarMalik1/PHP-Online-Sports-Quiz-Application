<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-01 22:08:28 --> Config Class Initialized
INFO - 2016-01-01 22:08:28 --> Hooks Class Initialized
DEBUG - 2016-01-01 22:08:28 --> UTF-8 Support Enabled
INFO - 2016-01-01 22:08:28 --> Utf8 Class Initialized
INFO - 2016-01-01 22:08:28 --> URI Class Initialized
DEBUG - 2016-01-01 22:08:28 --> No URI present. Default controller set.
INFO - 2016-01-01 22:08:28 --> Router Class Initialized
INFO - 2016-01-01 22:08:28 --> Output Class Initialized
INFO - 2016-01-01 22:08:28 --> Security Class Initialized
DEBUG - 2016-01-01 22:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-01 22:08:28 --> Input Class Initialized
INFO - 2016-01-01 22:08:28 --> Language Class Initialized
INFO - 2016-01-01 22:08:28 --> Loader Class Initialized
INFO - 2016-01-01 22:08:28 --> Helper loaded: url_helper
INFO - 2016-01-01 22:08:28 --> Database Driver Class Initialized
INFO - 2016-01-01 22:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-01 22:08:28 --> Controller Class Initialized
INFO - 2016-01-01 22:08:28 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-01 22:08:28 --> Final output sent to browser
DEBUG - 2016-01-01 22:08:28 --> Total execution time: 0.5297
INFO - 2016-01-01 22:08:59 --> Config Class Initialized
INFO - 2016-01-01 22:08:59 --> Hooks Class Initialized
DEBUG - 2016-01-01 22:08:59 --> UTF-8 Support Enabled
INFO - 2016-01-01 22:08:59 --> Utf8 Class Initialized
INFO - 2016-01-01 22:08:59 --> URI Class Initialized
INFO - 2016-01-01 22:08:59 --> Router Class Initialized
INFO - 2016-01-01 22:08:59 --> Output Class Initialized
INFO - 2016-01-01 22:08:59 --> Security Class Initialized
DEBUG - 2016-01-01 22:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-01 22:08:59 --> Input Class Initialized
INFO - 2016-01-01 22:08:59 --> Language Class Initialized
INFO - 2016-01-01 22:08:59 --> Loader Class Initialized
INFO - 2016-01-01 22:08:59 --> Helper loaded: url_helper
INFO - 2016-01-01 22:08:59 --> Database Driver Class Initialized
INFO - 2016-01-01 22:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-01 22:08:59 --> Controller Class Initialized
INFO - 2016-01-01 22:08:59 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-01 22:08:59 --> Final output sent to browser
DEBUG - 2016-01-01 22:08:59 --> Total execution time: 0.1882
INFO - 2016-01-01 22:08:59 --> Config Class Initialized
INFO - 2016-01-01 22:08:59 --> Hooks Class Initialized
DEBUG - 2016-01-01 22:08:59 --> UTF-8 Support Enabled
INFO - 2016-01-01 22:08:59 --> Utf8 Class Initialized
INFO - 2016-01-01 22:08:59 --> URI Class Initialized
INFO - 2016-01-01 22:08:59 --> Router Class Initialized
INFO - 2016-01-01 22:08:59 --> Output Class Initialized
INFO - 2016-01-01 22:08:59 --> Security Class Initialized
DEBUG - 2016-01-01 22:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-01 22:08:59 --> Input Class Initialized
INFO - 2016-01-01 22:08:59 --> Language Class Initialized
INFO - 2016-01-01 22:08:59 --> Loader Class Initialized
INFO - 2016-01-01 22:08:59 --> Helper loaded: url_helper
INFO - 2016-01-01 22:08:59 --> Database Driver Class Initialized
INFO - 2016-01-01 22:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-01 22:08:59 --> Controller Class Initialized
DEBUG - 2016-01-01 22:08:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-01 22:08:59 --> Helper loaded: inflector_helper
INFO - 2016-01-01 22:08:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-01 22:08:59 --> Model Class Initialized
INFO - 2016-01-01 22:08:59 --> Model Class Initialized
INFO - 2016-01-01 22:08:59 --> Final output sent to browser
DEBUG - 2016-01-01 22:08:59 --> Total execution time: 0.1891
INFO - 2016-01-01 22:10:01 --> Config Class Initialized
INFO - 2016-01-01 22:10:01 --> Hooks Class Initialized
DEBUG - 2016-01-01 22:10:01 --> UTF-8 Support Enabled
INFO - 2016-01-01 22:10:01 --> Utf8 Class Initialized
INFO - 2016-01-01 22:10:01 --> URI Class Initialized
INFO - 2016-01-01 22:10:01 --> Router Class Initialized
INFO - 2016-01-01 22:10:01 --> Output Class Initialized
INFO - 2016-01-01 22:10:01 --> Security Class Initialized
DEBUG - 2016-01-01 22:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-01 22:10:01 --> Input Class Initialized
INFO - 2016-01-01 22:10:01 --> Language Class Initialized
INFO - 2016-01-01 22:10:01 --> Loader Class Initialized
INFO - 2016-01-01 22:10:01 --> Helper loaded: url_helper
INFO - 2016-01-01 22:10:01 --> Database Driver Class Initialized
INFO - 2016-01-01 22:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-01 22:10:01 --> Controller Class Initialized
DEBUG - 2016-01-01 22:10:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-01 22:10:01 --> Helper loaded: inflector_helper
INFO - 2016-01-01 22:10:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-01 22:10:01 --> Model Class Initialized
INFO - 2016-01-01 22:10:01 --> Model Class Initialized
INFO - 2016-01-01 22:10:01 --> Final output sent to browser
DEBUG - 2016-01-01 22:10:01 --> Total execution time: 0.4779
INFO - 2016-01-01 22:10:03 --> Config Class Initialized
INFO - 2016-01-01 22:10:03 --> Hooks Class Initialized
DEBUG - 2016-01-01 22:10:03 --> UTF-8 Support Enabled
INFO - 2016-01-01 22:10:03 --> Utf8 Class Initialized
INFO - 2016-01-01 22:10:04 --> URI Class Initialized
INFO - 2016-01-01 22:10:04 --> Router Class Initialized
INFO - 2016-01-01 22:10:04 --> Output Class Initialized
INFO - 2016-01-01 22:10:04 --> Security Class Initialized
DEBUG - 2016-01-01 22:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-01 22:10:04 --> Input Class Initialized
INFO - 2016-01-01 22:10:04 --> Language Class Initialized
INFO - 2016-01-01 22:10:04 --> Loader Class Initialized
INFO - 2016-01-01 22:10:04 --> Helper loaded: url_helper
INFO - 2016-01-01 22:10:04 --> Database Driver Class Initialized
INFO - 2016-01-01 22:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-01 22:10:04 --> Controller Class Initialized
DEBUG - 2016-01-01 22:10:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-01 22:10:04 --> Helper loaded: inflector_helper
INFO - 2016-01-01 22:10:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-01 22:10:04 --> Model Class Initialized
INFO - 2016-01-01 22:10:04 --> Model Class Initialized
INFO - 2016-01-01 22:10:04 --> Final output sent to browser
DEBUG - 2016-01-01 22:10:04 --> Total execution time: 0.1557
INFO - 2016-01-01 22:10:40 --> Config Class Initialized
INFO - 2016-01-01 22:10:40 --> Hooks Class Initialized
DEBUG - 2016-01-01 22:10:40 --> UTF-8 Support Enabled
INFO - 2016-01-01 22:10:40 --> Utf8 Class Initialized
INFO - 2016-01-01 22:10:40 --> URI Class Initialized
DEBUG - 2016-01-01 22:10:40 --> No URI present. Default controller set.
INFO - 2016-01-01 22:10:40 --> Router Class Initialized
INFO - 2016-01-01 22:10:40 --> Output Class Initialized
INFO - 2016-01-01 22:10:40 --> Security Class Initialized
DEBUG - 2016-01-01 22:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-01 22:10:40 --> Input Class Initialized
INFO - 2016-01-01 22:10:40 --> Language Class Initialized
INFO - 2016-01-01 22:10:40 --> Loader Class Initialized
INFO - 2016-01-01 22:10:40 --> Helper loaded: url_helper
INFO - 2016-01-01 22:10:40 --> Database Driver Class Initialized
INFO - 2016-01-01 22:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-01 22:10:40 --> Controller Class Initialized
INFO - 2016-01-01 22:10:40 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-01 22:10:40 --> Final output sent to browser
DEBUG - 2016-01-01 22:10:40 --> Total execution time: 0.1776
INFO - 2016-01-01 22:10:47 --> Config Class Initialized
INFO - 2016-01-01 22:10:47 --> Hooks Class Initialized
DEBUG - 2016-01-01 22:10:47 --> UTF-8 Support Enabled
INFO - 2016-01-01 22:10:47 --> Utf8 Class Initialized
INFO - 2016-01-01 22:10:47 --> URI Class Initialized
INFO - 2016-01-01 22:10:47 --> Router Class Initialized
INFO - 2016-01-01 22:10:47 --> Output Class Initialized
INFO - 2016-01-01 22:10:47 --> Security Class Initialized
DEBUG - 2016-01-01 22:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-01 22:10:47 --> Input Class Initialized
INFO - 2016-01-01 22:10:47 --> Language Class Initialized
INFO - 2016-01-01 22:10:47 --> Loader Class Initialized
INFO - 2016-01-01 22:10:47 --> Helper loaded: url_helper
INFO - 2016-01-01 22:10:47 --> Database Driver Class Initialized
INFO - 2016-01-01 22:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-01 22:10:47 --> Controller Class Initialized
INFO - 2016-01-01 22:10:47 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-01 22:10:47 --> Final output sent to browser
DEBUG - 2016-01-01 22:10:47 --> Total execution time: 0.0901
INFO - 2016-01-01 22:10:47 --> Config Class Initialized
INFO - 2016-01-01 22:10:47 --> Hooks Class Initialized
DEBUG - 2016-01-01 22:10:47 --> UTF-8 Support Enabled
INFO - 2016-01-01 22:10:47 --> Utf8 Class Initialized
INFO - 2016-01-01 22:10:47 --> URI Class Initialized
INFO - 2016-01-01 22:10:47 --> Router Class Initialized
INFO - 2016-01-01 22:10:47 --> Output Class Initialized
INFO - 2016-01-01 22:10:47 --> Security Class Initialized
DEBUG - 2016-01-01 22:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-01 22:10:47 --> Input Class Initialized
INFO - 2016-01-01 22:10:47 --> Language Class Initialized
INFO - 2016-01-01 22:10:47 --> Loader Class Initialized
INFO - 2016-01-01 22:10:47 --> Helper loaded: url_helper
INFO - 2016-01-01 22:10:47 --> Database Driver Class Initialized
INFO - 2016-01-01 22:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-01 22:10:47 --> Controller Class Initialized
DEBUG - 2016-01-01 22:10:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-01 22:10:47 --> Helper loaded: inflector_helper
INFO - 2016-01-01 22:10:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-01 22:10:47 --> Model Class Initialized
INFO - 2016-01-01 22:10:47 --> Model Class Initialized
INFO - 2016-01-01 22:10:47 --> Final output sent to browser
DEBUG - 2016-01-01 22:10:47 --> Total execution time: 0.1158
INFO - 2016-01-01 22:11:48 --> Config Class Initialized
INFO - 2016-01-01 22:11:48 --> Hooks Class Initialized
DEBUG - 2016-01-01 22:11:48 --> UTF-8 Support Enabled
INFO - 2016-01-01 22:11:48 --> Utf8 Class Initialized
INFO - 2016-01-01 22:11:48 --> URI Class Initialized
INFO - 2016-01-01 22:11:48 --> Router Class Initialized
INFO - 2016-01-01 22:11:48 --> Output Class Initialized
INFO - 2016-01-01 22:11:48 --> Security Class Initialized
DEBUG - 2016-01-01 22:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-01 22:11:48 --> Input Class Initialized
INFO - 2016-01-01 22:11:48 --> Language Class Initialized
INFO - 2016-01-01 22:11:48 --> Loader Class Initialized
INFO - 2016-01-01 22:11:48 --> Helper loaded: url_helper
INFO - 2016-01-01 22:11:48 --> Database Driver Class Initialized
INFO - 2016-01-01 22:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-01 22:11:48 --> Controller Class Initialized
DEBUG - 2016-01-01 22:11:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-01 22:11:48 --> Helper loaded: inflector_helper
INFO - 2016-01-01 22:11:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-01 22:11:48 --> Model Class Initialized
INFO - 2016-01-01 22:11:48 --> Model Class Initialized
INFO - 2016-01-01 22:11:48 --> Final output sent to browser
DEBUG - 2016-01-01 22:11:48 --> Total execution time: 0.4160
INFO - 2016-01-01 23:02:30 --> Config Class Initialized
INFO - 2016-01-01 23:02:30 --> Hooks Class Initialized
DEBUG - 2016-01-01 23:02:30 --> UTF-8 Support Enabled
INFO - 2016-01-01 23:02:30 --> Utf8 Class Initialized
INFO - 2016-01-01 23:02:30 --> URI Class Initialized
DEBUG - 2016-01-01 23:02:30 --> No URI present. Default controller set.
INFO - 2016-01-01 23:02:30 --> Router Class Initialized
INFO - 2016-01-01 23:02:30 --> Output Class Initialized
INFO - 2016-01-01 23:02:30 --> Security Class Initialized
DEBUG - 2016-01-01 23:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-01 23:02:30 --> Input Class Initialized
INFO - 2016-01-01 23:02:30 --> Language Class Initialized
INFO - 2016-01-01 23:02:30 --> Loader Class Initialized
INFO - 2016-01-01 23:02:30 --> Helper loaded: url_helper
INFO - 2016-01-01 23:02:30 --> Database Driver Class Initialized
INFO - 2016-01-01 23:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-01 23:02:30 --> Controller Class Initialized
INFO - 2016-01-01 23:02:30 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-01 23:02:30 --> Final output sent to browser
DEBUG - 2016-01-01 23:02:30 --> Total execution time: 0.2043
