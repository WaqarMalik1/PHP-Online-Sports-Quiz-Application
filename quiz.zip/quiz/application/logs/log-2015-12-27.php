<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2015-12-27 05:29:39 --> Config Class Initialized
INFO - 2015-12-27 05:29:39 --> Hooks Class Initialized
DEBUG - 2015-12-27 05:29:39 --> UTF-8 Support Enabled
INFO - 2015-12-27 05:29:39 --> Utf8 Class Initialized
INFO - 2015-12-27 05:29:39 --> URI Class Initialized
INFO - 2015-12-27 05:29:39 --> Router Class Initialized
INFO - 2015-12-27 05:29:39 --> Output Class Initialized
INFO - 2015-12-27 05:29:39 --> Security Class Initialized
DEBUG - 2015-12-27 05:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 05:29:39 --> Input Class Initialized
INFO - 2015-12-27 05:29:39 --> Language Class Initialized
INFO - 2015-12-27 05:29:39 --> Loader Class Initialized
INFO - 2015-12-27 05:29:39 --> Helper loaded: url_helper
INFO - 2015-12-27 05:29:39 --> Database Driver Class Initialized
INFO - 2015-12-27 05:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 05:29:39 --> Controller Class Initialized
INFO - 2015-12-27 05:29:39 --> Helper loaded: form_helper
INFO - 2015-12-27 05:29:39 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-27 05:29:39 --> Final output sent to browser
DEBUG - 2015-12-27 05:29:39 --> Total execution time: 0.5084
INFO - 2015-12-27 05:31:00 --> Config Class Initialized
INFO - 2015-12-27 05:31:00 --> Hooks Class Initialized
DEBUG - 2015-12-27 05:31:00 --> UTF-8 Support Enabled
INFO - 2015-12-27 05:31:00 --> Utf8 Class Initialized
INFO - 2015-12-27 05:31:00 --> URI Class Initialized
INFO - 2015-12-27 05:31:00 --> Router Class Initialized
INFO - 2015-12-27 05:31:00 --> Output Class Initialized
INFO - 2015-12-27 05:31:00 --> Security Class Initialized
DEBUG - 2015-12-27 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 05:31:00 --> Input Class Initialized
INFO - 2015-12-27 05:31:00 --> Language Class Initialized
INFO - 2015-12-27 05:31:00 --> Loader Class Initialized
INFO - 2015-12-27 05:31:00 --> Helper loaded: url_helper
INFO - 2015-12-27 05:31:01 --> Database Driver Class Initialized
INFO - 2015-12-27 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 05:31:01 --> Controller Class Initialized
INFO - 2015-12-27 05:31:01 --> Model Class Initialized
INFO - 2015-12-27 05:31:01 --> Model Class Initialized
INFO - 2015-12-27 05:31:01 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 05:31:01 --> Final output sent to browser
DEBUG - 2015-12-27 05:31:01 --> Total execution time: 0.4296
INFO - 2015-12-27 05:31:01 --> Config Class Initialized
INFO - 2015-12-27 05:31:01 --> Hooks Class Initialized
DEBUG - 2015-12-27 05:31:01 --> UTF-8 Support Enabled
INFO - 2015-12-27 05:31:01 --> Utf8 Class Initialized
INFO - 2015-12-27 05:31:01 --> Config Class Initialized
INFO - 2015-12-27 05:31:01 --> URI Class Initialized
INFO - 2015-12-27 05:31:01 --> Hooks Class Initialized
INFO - 2015-12-27 05:31:01 --> Router Class Initialized
INFO - 2015-12-27 05:31:01 --> Output Class Initialized
DEBUG - 2015-12-27 05:31:01 --> UTF-8 Support Enabled
INFO - 2015-12-27 05:31:01 --> Security Class Initialized
INFO - 2015-12-27 05:31:01 --> Utf8 Class Initialized
INFO - 2015-12-27 05:31:01 --> URI Class Initialized
DEBUG - 2015-12-27 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 05:31:01 --> Input Class Initialized
INFO - 2015-12-27 05:31:01 --> Router Class Initialized
INFO - 2015-12-27 05:31:01 --> Language Class Initialized
INFO - 2015-12-27 05:31:01 --> Output Class Initialized
INFO - 2015-12-27 05:31:01 --> Loader Class Initialized
INFO - 2015-12-27 05:31:01 --> Security Class Initialized
INFO - 2015-12-27 05:31:01 --> Helper loaded: url_helper
DEBUG - 2015-12-27 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 05:31:01 --> Input Class Initialized
INFO - 2015-12-27 05:31:01 --> Language Class Initialized
INFO - 2015-12-27 05:31:01 --> Database Driver Class Initialized
INFO - 2015-12-27 05:31:01 --> Loader Class Initialized
INFO - 2015-12-27 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 05:31:01 --> Helper loaded: url_helper
INFO - 2015-12-27 05:31:01 --> Controller Class Initialized
INFO - 2015-12-27 05:31:01 --> Model Class Initialized
INFO - 2015-12-27 05:31:01 --> Model Class Initialized
INFO - 2015-12-27 05:31:01 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-27 05:31:01 --> Final output sent to browser
INFO - 2015-12-27 05:31:01 --> Database Driver Class Initialized
DEBUG - 2015-12-27 05:31:01 --> Total execution time: 0.1893
INFO - 2015-12-27 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 05:31:01 --> Controller Class Initialized
DEBUG - 2015-12-27 05:31:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 05:31:01 --> Helper loaded: inflector_helper
INFO - 2015-12-27 05:31:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 05:31:01 --> Model Class Initialized
INFO - 2015-12-27 05:31:01 --> Model Class Initialized
INFO - 2015-12-27 05:31:01 --> Final output sent to browser
DEBUG - 2015-12-27 05:31:01 --> Total execution time: 0.2595
INFO - 2015-12-27 05:31:06 --> Config Class Initialized
INFO - 2015-12-27 05:31:06 --> Hooks Class Initialized
DEBUG - 2015-12-27 05:31:06 --> UTF-8 Support Enabled
INFO - 2015-12-27 05:31:06 --> Utf8 Class Initialized
INFO - 2015-12-27 05:31:06 --> URI Class Initialized
INFO - 2015-12-27 05:31:06 --> Router Class Initialized
INFO - 2015-12-27 05:31:06 --> Output Class Initialized
INFO - 2015-12-27 05:31:06 --> Security Class Initialized
DEBUG - 2015-12-27 05:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 05:31:06 --> Input Class Initialized
INFO - 2015-12-27 05:31:06 --> Language Class Initialized
INFO - 2015-12-27 05:31:06 --> Loader Class Initialized
INFO - 2015-12-27 05:31:06 --> Helper loaded: url_helper
INFO - 2015-12-27 05:31:06 --> Database Driver Class Initialized
INFO - 2015-12-27 05:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 05:31:06 --> Controller Class Initialized
INFO - 2015-12-27 05:31:06 --> Config Class Initialized
INFO - 2015-12-27 05:31:06 --> Hooks Class Initialized
DEBUG - 2015-12-27 05:31:07 --> UTF-8 Support Enabled
INFO - 2015-12-27 05:31:07 --> Utf8 Class Initialized
INFO - 2015-12-27 05:31:07 --> URI Class Initialized
INFO - 2015-12-27 05:31:07 --> Router Class Initialized
INFO - 2015-12-27 05:31:07 --> Output Class Initialized
INFO - 2015-12-27 05:31:07 --> Security Class Initialized
DEBUG - 2015-12-27 05:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 05:31:07 --> Input Class Initialized
INFO - 2015-12-27 05:31:07 --> Language Class Initialized
INFO - 2015-12-27 05:31:07 --> Loader Class Initialized
INFO - 2015-12-27 05:31:07 --> Helper loaded: url_helper
INFO - 2015-12-27 05:31:07 --> Database Driver Class Initialized
INFO - 2015-12-27 05:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 05:31:07 --> Controller Class Initialized
INFO - 2015-12-27 05:31:07 --> Helper loaded: form_helper
INFO - 2015-12-27 05:31:07 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-27 05:31:07 --> Final output sent to browser
DEBUG - 2015-12-27 05:31:07 --> Total execution time: 0.1252
INFO - 2015-12-27 05:31:10 --> Config Class Initialized
INFO - 2015-12-27 05:31:10 --> Hooks Class Initialized
DEBUG - 2015-12-27 05:31:10 --> UTF-8 Support Enabled
INFO - 2015-12-27 05:31:10 --> Utf8 Class Initialized
INFO - 2015-12-27 05:31:10 --> URI Class Initialized
INFO - 2015-12-27 05:31:10 --> Router Class Initialized
INFO - 2015-12-27 05:31:10 --> Output Class Initialized
INFO - 2015-12-27 05:31:10 --> Security Class Initialized
DEBUG - 2015-12-27 05:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 05:31:10 --> Input Class Initialized
INFO - 2015-12-27 05:31:10 --> Language Class Initialized
INFO - 2015-12-27 05:31:10 --> Loader Class Initialized
INFO - 2015-12-27 05:31:10 --> Helper loaded: url_helper
INFO - 2015-12-27 05:31:10 --> Database Driver Class Initialized
INFO - 2015-12-27 05:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 05:31:10 --> Controller Class Initialized
INFO - 2015-12-27 05:31:10 --> Model Class Initialized
INFO - 2015-12-27 05:31:10 --> Model Class Initialized
INFO - 2015-12-27 05:31:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 05:31:10 --> Final output sent to browser
DEBUG - 2015-12-27 05:31:10 --> Total execution time: 0.1578
INFO - 2015-12-27 05:31:10 --> Config Class Initialized
INFO - 2015-12-27 05:31:10 --> Hooks Class Initialized
DEBUG - 2015-12-27 05:31:10 --> UTF-8 Support Enabled
INFO - 2015-12-27 05:31:10 --> Utf8 Class Initialized
INFO - 2015-12-27 05:31:10 --> URI Class Initialized
INFO - 2015-12-27 05:31:10 --> Router Class Initialized
INFO - 2015-12-27 05:31:10 --> Output Class Initialized
INFO - 2015-12-27 05:31:10 --> Security Class Initialized
DEBUG - 2015-12-27 05:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 05:31:10 --> Input Class Initialized
INFO - 2015-12-27 05:31:10 --> Language Class Initialized
INFO - 2015-12-27 05:31:10 --> Loader Class Initialized
INFO - 2015-12-27 05:31:10 --> Helper loaded: url_helper
INFO - 2015-12-27 05:31:10 --> Config Class Initialized
INFO - 2015-12-27 05:31:10 --> Hooks Class Initialized
INFO - 2015-12-27 05:31:10 --> Database Driver Class Initialized
DEBUG - 2015-12-27 05:31:10 --> UTF-8 Support Enabled
INFO - 2015-12-27 05:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 05:31:10 --> Utf8 Class Initialized
INFO - 2015-12-27 05:31:10 --> Controller Class Initialized
INFO - 2015-12-27 05:31:10 --> URI Class Initialized
INFO - 2015-12-27 05:31:10 --> Model Class Initialized
INFO - 2015-12-27 05:31:10 --> Model Class Initialized
INFO - 2015-12-27 05:31:10 --> Router Class Initialized
INFO - 2015-12-27 05:31:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-27 05:31:10 --> Output Class Initialized
INFO - 2015-12-27 05:31:10 --> Final output sent to browser
DEBUG - 2015-12-27 05:31:10 --> Total execution time: 0.1632
INFO - 2015-12-27 05:31:10 --> Security Class Initialized
DEBUG - 2015-12-27 05:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 05:31:10 --> Input Class Initialized
INFO - 2015-12-27 05:31:10 --> Language Class Initialized
INFO - 2015-12-27 05:31:10 --> Loader Class Initialized
INFO - 2015-12-27 05:31:10 --> Helper loaded: url_helper
INFO - 2015-12-27 05:31:10 --> Database Driver Class Initialized
INFO - 2015-12-27 05:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 05:31:10 --> Controller Class Initialized
DEBUG - 2015-12-27 05:31:10 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 05:31:10 --> Helper loaded: inflector_helper
INFO - 2015-12-27 05:31:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 05:31:10 --> Model Class Initialized
INFO - 2015-12-27 05:31:10 --> Model Class Initialized
INFO - 2015-12-27 05:31:10 --> Final output sent to browser
DEBUG - 2015-12-27 05:31:10 --> Total execution time: 0.2153
INFO - 2015-12-27 06:16:45 --> Config Class Initialized
INFO - 2015-12-27 06:16:45 --> Hooks Class Initialized
DEBUG - 2015-12-27 06:16:45 --> UTF-8 Support Enabled
INFO - 2015-12-27 06:16:45 --> Utf8 Class Initialized
INFO - 2015-12-27 06:16:45 --> URI Class Initialized
INFO - 2015-12-27 06:16:45 --> Router Class Initialized
INFO - 2015-12-27 06:16:45 --> Output Class Initialized
INFO - 2015-12-27 06:16:45 --> Security Class Initialized
DEBUG - 2015-12-27 06:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 06:16:45 --> Input Class Initialized
INFO - 2015-12-27 06:16:45 --> Language Class Initialized
INFO - 2015-12-27 06:16:45 --> Loader Class Initialized
INFO - 2015-12-27 06:16:45 --> Helper loaded: url_helper
INFO - 2015-12-27 06:16:45 --> Database Driver Class Initialized
INFO - 2015-12-27 06:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 06:16:45 --> Controller Class Initialized
DEBUG - 2015-12-27 06:16:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 06:16:45 --> Helper loaded: inflector_helper
INFO - 2015-12-27 06:16:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 06:16:45 --> Model Class Initialized
INFO - 2015-12-27 06:16:45 --> Model Class Initialized
INFO - 2015-12-27 06:16:45 --> Final output sent to browser
DEBUG - 2015-12-27 06:16:45 --> Total execution time: 0.4905
INFO - 2015-12-27 06:16:49 --> Config Class Initialized
INFO - 2015-12-27 06:16:49 --> Hooks Class Initialized
DEBUG - 2015-12-27 06:16:49 --> UTF-8 Support Enabled
INFO - 2015-12-27 06:16:49 --> Utf8 Class Initialized
INFO - 2015-12-27 06:16:49 --> URI Class Initialized
INFO - 2015-12-27 06:16:49 --> Router Class Initialized
INFO - 2015-12-27 06:16:49 --> Output Class Initialized
INFO - 2015-12-27 06:16:49 --> Security Class Initialized
DEBUG - 2015-12-27 06:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 06:16:49 --> Input Class Initialized
INFO - 2015-12-27 06:16:49 --> Language Class Initialized
INFO - 2015-12-27 06:16:49 --> Loader Class Initialized
INFO - 2015-12-27 06:16:49 --> Helper loaded: url_helper
INFO - 2015-12-27 06:16:49 --> Database Driver Class Initialized
INFO - 2015-12-27 06:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 06:16:49 --> Controller Class Initialized
DEBUG - 2015-12-27 06:16:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 06:16:49 --> Helper loaded: inflector_helper
INFO - 2015-12-27 06:16:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 06:16:49 --> Model Class Initialized
INFO - 2015-12-27 06:16:49 --> Model Class Initialized
INFO - 2015-12-27 06:16:49 --> Final output sent to browser
DEBUG - 2015-12-27 06:16:49 --> Total execution time: 0.1164
INFO - 2015-12-27 08:17:30 --> Config Class Initialized
INFO - 2015-12-27 08:17:31 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:17:31 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:17:31 --> Utf8 Class Initialized
INFO - 2015-12-27 08:17:31 --> URI Class Initialized
INFO - 2015-12-27 08:17:31 --> Router Class Initialized
INFO - 2015-12-27 08:17:31 --> Output Class Initialized
INFO - 2015-12-27 08:17:31 --> Security Class Initialized
DEBUG - 2015-12-27 08:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:17:31 --> Input Class Initialized
INFO - 2015-12-27 08:17:31 --> Language Class Initialized
INFO - 2015-12-27 08:17:31 --> Loader Class Initialized
INFO - 2015-12-27 08:17:31 --> Helper loaded: url_helper
INFO - 2015-12-27 08:17:31 --> Database Driver Class Initialized
INFO - 2015-12-27 08:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:17:31 --> Controller Class Initialized
INFO - 2015-12-27 08:17:31 --> Helper loaded: form_helper
INFO - 2015-12-27 08:17:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-27 08:17:31 --> Final output sent to browser
DEBUG - 2015-12-27 08:17:31 --> Total execution time: 0.4465
INFO - 2015-12-27 08:22:49 --> Config Class Initialized
INFO - 2015-12-27 08:22:49 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:22:49 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:22:49 --> Utf8 Class Initialized
INFO - 2015-12-27 08:22:49 --> URI Class Initialized
INFO - 2015-12-27 08:22:49 --> Router Class Initialized
INFO - 2015-12-27 08:22:49 --> Output Class Initialized
INFO - 2015-12-27 08:22:49 --> Security Class Initialized
DEBUG - 2015-12-27 08:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:22:49 --> Input Class Initialized
INFO - 2015-12-27 08:22:49 --> Language Class Initialized
INFO - 2015-12-27 08:22:49 --> Loader Class Initialized
INFO - 2015-12-27 08:22:49 --> Helper loaded: url_helper
INFO - 2015-12-27 08:22:49 --> Database Driver Class Initialized
INFO - 2015-12-27 08:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:22:49 --> Controller Class Initialized
INFO - 2015-12-27 08:22:49 --> Model Class Initialized
INFO - 2015-12-27 08:22:49 --> Model Class Initialized
INFO - 2015-12-27 08:22:49 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:22:49 --> Final output sent to browser
DEBUG - 2015-12-27 08:22:49 --> Total execution time: 0.4174
INFO - 2015-12-27 08:22:50 --> Config Class Initialized
INFO - 2015-12-27 08:22:50 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:22:50 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:22:50 --> Utf8 Class Initialized
INFO - 2015-12-27 08:22:50 --> URI Class Initialized
INFO - 2015-12-27 08:22:50 --> Router Class Initialized
INFO - 2015-12-27 08:22:50 --> Output Class Initialized
INFO - 2015-12-27 08:22:50 --> Security Class Initialized
DEBUG - 2015-12-27 08:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:22:50 --> Input Class Initialized
INFO - 2015-12-27 08:22:50 --> Language Class Initialized
INFO - 2015-12-27 08:22:50 --> Loader Class Initialized
INFO - 2015-12-27 08:22:50 --> Helper loaded: url_helper
INFO - 2015-12-27 08:22:50 --> Database Driver Class Initialized
INFO - 2015-12-27 08:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:22:50 --> Controller Class Initialized
INFO - 2015-12-27 08:22:50 --> Model Class Initialized
INFO - 2015-12-27 08:22:50 --> Model Class Initialized
INFO - 2015-12-27 08:22:50 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-27 08:22:50 --> Final output sent to browser
DEBUG - 2015-12-27 08:22:50 --> Total execution time: 0.0932
INFO - 2015-12-27 08:22:50 --> Config Class Initialized
INFO - 2015-12-27 08:22:50 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:22:50 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:22:50 --> Utf8 Class Initialized
INFO - 2015-12-27 08:22:50 --> URI Class Initialized
INFO - 2015-12-27 08:22:50 --> Router Class Initialized
INFO - 2015-12-27 08:22:50 --> Output Class Initialized
INFO - 2015-12-27 08:22:50 --> Security Class Initialized
DEBUG - 2015-12-27 08:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:22:50 --> Input Class Initialized
INFO - 2015-12-27 08:22:50 --> Language Class Initialized
INFO - 2015-12-27 08:22:50 --> Loader Class Initialized
INFO - 2015-12-27 08:22:50 --> Helper loaded: url_helper
INFO - 2015-12-27 08:22:50 --> Database Driver Class Initialized
INFO - 2015-12-27 08:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:22:50 --> Controller Class Initialized
DEBUG - 2015-12-27 08:22:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:22:50 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:22:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:22:50 --> Model Class Initialized
INFO - 2015-12-27 08:22:50 --> Model Class Initialized
INFO - 2015-12-27 08:22:50 --> Final output sent to browser
DEBUG - 2015-12-27 08:22:50 --> Total execution time: 0.1364
INFO - 2015-12-27 08:22:55 --> Config Class Initialized
INFO - 2015-12-27 08:22:55 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:22:55 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:22:55 --> Utf8 Class Initialized
INFO - 2015-12-27 08:22:55 --> URI Class Initialized
INFO - 2015-12-27 08:22:55 --> Router Class Initialized
INFO - 2015-12-27 08:22:55 --> Output Class Initialized
INFO - 2015-12-27 08:22:55 --> Security Class Initialized
DEBUG - 2015-12-27 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:22:55 --> Input Class Initialized
INFO - 2015-12-27 08:22:55 --> Language Class Initialized
INFO - 2015-12-27 08:22:55 --> Loader Class Initialized
INFO - 2015-12-27 08:22:55 --> Helper loaded: url_helper
INFO - 2015-12-27 08:22:55 --> Database Driver Class Initialized
INFO - 2015-12-27 08:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:22:55 --> Controller Class Initialized
INFO - 2015-12-27 08:22:55 --> Model Class Initialized
INFO - 2015-12-27 08:22:55 --> Model Class Initialized
INFO - 2015-12-27 08:22:55 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:22:55 --> Final output sent to browser
DEBUG - 2015-12-27 08:22:55 --> Total execution time: 0.1172
INFO - 2015-12-27 08:22:56 --> Config Class Initialized
INFO - 2015-12-27 08:22:56 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:22:56 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:22:56 --> Utf8 Class Initialized
INFO - 2015-12-27 08:22:56 --> URI Class Initialized
INFO - 2015-12-27 08:22:56 --> Router Class Initialized
INFO - 2015-12-27 08:22:56 --> Output Class Initialized
INFO - 2015-12-27 08:22:56 --> Security Class Initialized
DEBUG - 2015-12-27 08:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:22:56 --> Input Class Initialized
INFO - 2015-12-27 08:22:56 --> Language Class Initialized
INFO - 2015-12-27 08:22:56 --> Loader Class Initialized
INFO - 2015-12-27 08:22:56 --> Helper loaded: url_helper
INFO - 2015-12-27 08:22:56 --> Database Driver Class Initialized
INFO - 2015-12-27 08:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:22:56 --> Config Class Initialized
INFO - 2015-12-27 08:22:56 --> Controller Class Initialized
INFO - 2015-12-27 08:22:56 --> Hooks Class Initialized
INFO - 2015-12-27 08:22:56 --> Model Class Initialized
INFO - 2015-12-27 08:22:56 --> Model Class Initialized
DEBUG - 2015-12-27 08:22:56 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:22:56 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:22:56 --> Utf8 Class Initialized
INFO - 2015-12-27 08:22:56 --> Final output sent to browser
INFO - 2015-12-27 08:22:56 --> URI Class Initialized
DEBUG - 2015-12-27 08:22:56 --> Total execution time: 0.0930
INFO - 2015-12-27 08:22:56 --> Router Class Initialized
INFO - 2015-12-27 08:22:56 --> Output Class Initialized
INFO - 2015-12-27 08:22:56 --> Security Class Initialized
DEBUG - 2015-12-27 08:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:22:56 --> Input Class Initialized
INFO - 2015-12-27 08:22:56 --> Language Class Initialized
INFO - 2015-12-27 08:22:56 --> Loader Class Initialized
INFO - 2015-12-27 08:22:56 --> Helper loaded: url_helper
INFO - 2015-12-27 08:22:56 --> Database Driver Class Initialized
INFO - 2015-12-27 08:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:22:56 --> Controller Class Initialized
DEBUG - 2015-12-27 08:22:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:22:56 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:22:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:22:56 --> Model Class Initialized
INFO - 2015-12-27 08:22:56 --> Model Class Initialized
INFO - 2015-12-27 08:22:56 --> Final output sent to browser
DEBUG - 2015-12-27 08:22:56 --> Total execution time: 0.1146
INFO - 2015-12-27 08:22:59 --> Config Class Initialized
INFO - 2015-12-27 08:22:59 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:22:59 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:22:59 --> Utf8 Class Initialized
INFO - 2015-12-27 08:22:59 --> URI Class Initialized
INFO - 2015-12-27 08:22:59 --> Router Class Initialized
INFO - 2015-12-27 08:22:59 --> Output Class Initialized
INFO - 2015-12-27 08:22:59 --> Security Class Initialized
DEBUG - 2015-12-27 08:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:22:59 --> Input Class Initialized
INFO - 2015-12-27 08:22:59 --> Language Class Initialized
INFO - 2015-12-27 08:22:59 --> Loader Class Initialized
INFO - 2015-12-27 08:22:59 --> Helper loaded: url_helper
INFO - 2015-12-27 08:22:59 --> Database Driver Class Initialized
INFO - 2015-12-27 08:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:22:59 --> Controller Class Initialized
INFO - 2015-12-27 08:22:59 --> Model Class Initialized
INFO - 2015-12-27 08:22:59 --> Model Class Initialized
INFO - 2015-12-27 08:22:59 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:22:59 --> Final output sent to browser
DEBUG - 2015-12-27 08:22:59 --> Total execution time: 0.1004
INFO - 2015-12-27 08:22:59 --> Config Class Initialized
INFO - 2015-12-27 08:22:59 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:22:59 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:22:59 --> Utf8 Class Initialized
INFO - 2015-12-27 08:22:59 --> URI Class Initialized
INFO - 2015-12-27 08:22:59 --> Router Class Initialized
INFO - 2015-12-27 08:22:59 --> Output Class Initialized
INFO - 2015-12-27 08:22:59 --> Security Class Initialized
DEBUG - 2015-12-27 08:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:22:59 --> Input Class Initialized
INFO - 2015-12-27 08:22:59 --> Language Class Initialized
INFO - 2015-12-27 08:22:59 --> Loader Class Initialized
INFO - 2015-12-27 08:22:59 --> Helper loaded: url_helper
INFO - 2015-12-27 08:22:59 --> Database Driver Class Initialized
INFO - 2015-12-27 08:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:22:59 --> Controller Class Initialized
INFO - 2015-12-27 08:22:59 --> Model Class Initialized
INFO - 2015-12-27 08:22:59 --> Model Class Initialized
INFO - 2015-12-27 08:22:59 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:22:59 --> Final output sent to browser
DEBUG - 2015-12-27 08:22:59 --> Total execution time: 0.0971
INFO - 2015-12-27 08:22:59 --> Config Class Initialized
INFO - 2015-12-27 08:22:59 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:22:59 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:22:59 --> Utf8 Class Initialized
INFO - 2015-12-27 08:22:59 --> URI Class Initialized
INFO - 2015-12-27 08:22:59 --> Router Class Initialized
INFO - 2015-12-27 08:22:59 --> Output Class Initialized
INFO - 2015-12-27 08:22:59 --> Security Class Initialized
DEBUG - 2015-12-27 08:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:22:59 --> Input Class Initialized
INFO - 2015-12-27 08:22:59 --> Language Class Initialized
INFO - 2015-12-27 08:22:59 --> Loader Class Initialized
INFO - 2015-12-27 08:22:59 --> Helper loaded: url_helper
INFO - 2015-12-27 08:22:59 --> Database Driver Class Initialized
INFO - 2015-12-27 08:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:22:59 --> Controller Class Initialized
DEBUG - 2015-12-27 08:22:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:22:59 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:22:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:22:59 --> Model Class Initialized
INFO - 2015-12-27 08:22:59 --> Model Class Initialized
INFO - 2015-12-27 08:22:59 --> Final output sent to browser
DEBUG - 2015-12-27 08:22:59 --> Total execution time: 0.1224
INFO - 2015-12-27 08:23:01 --> Config Class Initialized
INFO - 2015-12-27 08:23:01 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:01 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:01 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:01 --> URI Class Initialized
INFO - 2015-12-27 08:23:01 --> Router Class Initialized
INFO - 2015-12-27 08:23:01 --> Output Class Initialized
INFO - 2015-12-27 08:23:01 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:01 --> Input Class Initialized
INFO - 2015-12-27 08:23:01 --> Language Class Initialized
INFO - 2015-12-27 08:23:01 --> Loader Class Initialized
INFO - 2015-12-27 08:23:01 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:01 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:01 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:01 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:01 --> Model Class Initialized
INFO - 2015-12-27 08:23:01 --> Model Class Initialized
INFO - 2015-12-27 08:23:01 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:01 --> Total execution time: 0.1454
INFO - 2015-12-27 08:23:06 --> Config Class Initialized
INFO - 2015-12-27 08:23:06 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:06 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:06 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:06 --> URI Class Initialized
INFO - 2015-12-27 08:23:06 --> Router Class Initialized
INFO - 2015-12-27 08:23:06 --> Output Class Initialized
INFO - 2015-12-27 08:23:06 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:06 --> Input Class Initialized
INFO - 2015-12-27 08:23:06 --> Language Class Initialized
INFO - 2015-12-27 08:23:06 --> Loader Class Initialized
INFO - 2015-12-27 08:23:06 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:06 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:06 --> Controller Class Initialized
INFO - 2015-12-27 08:23:06 --> Model Class Initialized
INFO - 2015-12-27 08:23:06 --> Model Class Initialized
INFO - 2015-12-27 08:23:06 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:06 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:06 --> Total execution time: 0.1188
INFO - 2015-12-27 08:23:07 --> Config Class Initialized
INFO - 2015-12-27 08:23:07 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:07 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:07 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:07 --> Config Class Initialized
INFO - 2015-12-27 08:23:07 --> URI Class Initialized
INFO - 2015-12-27 08:23:07 --> Hooks Class Initialized
INFO - 2015-12-27 08:23:07 --> Router Class Initialized
DEBUG - 2015-12-27 08:23:07 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:07 --> Output Class Initialized
INFO - 2015-12-27 08:23:07 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:07 --> Security Class Initialized
INFO - 2015-12-27 08:23:07 --> URI Class Initialized
DEBUG - 2015-12-27 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:07 --> Input Class Initialized
INFO - 2015-12-27 08:23:07 --> Router Class Initialized
INFO - 2015-12-27 08:23:07 --> Language Class Initialized
INFO - 2015-12-27 08:23:07 --> Output Class Initialized
INFO - 2015-12-27 08:23:07 --> Security Class Initialized
INFO - 2015-12-27 08:23:07 --> Loader Class Initialized
DEBUG - 2015-12-27 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:07 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:07 --> Input Class Initialized
INFO - 2015-12-27 08:23:07 --> Language Class Initialized
INFO - 2015-12-27 08:23:07 --> Loader Class Initialized
INFO - 2015-12-27 08:23:07 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:07 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:07 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:07 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:07 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:07 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:07 --> Model Class Initialized
INFO - 2015-12-27 08:23:07 --> Model Class Initialized
INFO - 2015-12-27 08:23:07 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:07 --> Total execution time: 0.2152
INFO - 2015-12-27 08:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:07 --> Controller Class Initialized
INFO - 2015-12-27 08:23:07 --> Model Class Initialized
INFO - 2015-12-27 08:23:07 --> Model Class Initialized
INFO - 2015-12-27 08:23:07 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:07 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:07 --> Total execution time: 0.2196
INFO - 2015-12-27 08:23:11 --> Config Class Initialized
INFO - 2015-12-27 08:23:11 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:11 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:11 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:11 --> URI Class Initialized
INFO - 2015-12-27 08:23:11 --> Router Class Initialized
INFO - 2015-12-27 08:23:11 --> Output Class Initialized
INFO - 2015-12-27 08:23:11 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:11 --> Input Class Initialized
INFO - 2015-12-27 08:23:11 --> Language Class Initialized
INFO - 2015-12-27 08:23:11 --> Loader Class Initialized
INFO - 2015-12-27 08:23:11 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:11 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:12 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:12 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:12 --> Model Class Initialized
INFO - 2015-12-27 08:23:12 --> Model Class Initialized
INFO - 2015-12-27 08:23:12 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:12 --> Total execution time: 0.1311
INFO - 2015-12-27 08:23:15 --> Config Class Initialized
INFO - 2015-12-27 08:23:15 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:15 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:15 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:15 --> URI Class Initialized
INFO - 2015-12-27 08:23:15 --> Router Class Initialized
INFO - 2015-12-27 08:23:15 --> Output Class Initialized
INFO - 2015-12-27 08:23:15 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:15 --> Input Class Initialized
INFO - 2015-12-27 08:23:15 --> Language Class Initialized
INFO - 2015-12-27 08:23:15 --> Loader Class Initialized
INFO - 2015-12-27 08:23:15 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:15 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:15 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:15 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:15 --> Model Class Initialized
INFO - 2015-12-27 08:23:15 --> Model Class Initialized
INFO - 2015-12-27 08:23:15 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:15 --> Total execution time: 0.1416
INFO - 2015-12-27 08:23:16 --> Config Class Initialized
INFO - 2015-12-27 08:23:16 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:16 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:16 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:16 --> URI Class Initialized
INFO - 2015-12-27 08:23:16 --> Router Class Initialized
INFO - 2015-12-27 08:23:16 --> Output Class Initialized
INFO - 2015-12-27 08:23:16 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:16 --> Input Class Initialized
INFO - 2015-12-27 08:23:16 --> Language Class Initialized
INFO - 2015-12-27 08:23:16 --> Loader Class Initialized
INFO - 2015-12-27 08:23:16 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:16 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:16 --> Controller Class Initialized
INFO - 2015-12-27 08:23:16 --> Model Class Initialized
INFO - 2015-12-27 08:23:16 --> Model Class Initialized
INFO - 2015-12-27 08:23:16 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:16 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:16 --> Total execution time: 0.1223
INFO - 2015-12-27 08:23:16 --> Config Class Initialized
INFO - 2015-12-27 08:23:16 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:16 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:16 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:16 --> URI Class Initialized
INFO - 2015-12-27 08:23:16 --> Router Class Initialized
INFO - 2015-12-27 08:23:16 --> Output Class Initialized
INFO - 2015-12-27 08:23:16 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:16 --> Input Class Initialized
INFO - 2015-12-27 08:23:16 --> Language Class Initialized
INFO - 2015-12-27 08:23:16 --> Loader Class Initialized
INFO - 2015-12-27 08:23:16 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:16 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:16 --> Config Class Initialized
INFO - 2015-12-27 08:23:16 --> Hooks Class Initialized
INFO - 2015-12-27 08:23:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2015-12-27 08:23:16 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:16 --> Controller Class Initialized
INFO - 2015-12-27 08:23:16 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:16 --> Model Class Initialized
INFO - 2015-12-27 08:23:16 --> URI Class Initialized
INFO - 2015-12-27 08:23:16 --> Model Class Initialized
INFO - 2015-12-27 08:23:16 --> Router Class Initialized
INFO - 2015-12-27 08:23:16 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:16 --> Final output sent to browser
INFO - 2015-12-27 08:23:16 --> Output Class Initialized
DEBUG - 2015-12-27 08:23:16 --> Total execution time: 0.1291
INFO - 2015-12-27 08:23:16 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:17 --> Input Class Initialized
INFO - 2015-12-27 08:23:17 --> Language Class Initialized
INFO - 2015-12-27 08:23:17 --> Loader Class Initialized
INFO - 2015-12-27 08:23:17 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:17 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:17 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:17 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:17 --> Model Class Initialized
INFO - 2015-12-27 08:23:17 --> Model Class Initialized
INFO - 2015-12-27 08:23:17 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:17 --> Total execution time: 0.1237
INFO - 2015-12-27 08:23:17 --> Config Class Initialized
INFO - 2015-12-27 08:23:17 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:17 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:17 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:17 --> URI Class Initialized
INFO - 2015-12-27 08:23:17 --> Router Class Initialized
INFO - 2015-12-27 08:23:17 --> Output Class Initialized
INFO - 2015-12-27 08:23:17 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:17 --> Input Class Initialized
INFO - 2015-12-27 08:23:17 --> Language Class Initialized
INFO - 2015-12-27 08:23:17 --> Loader Class Initialized
INFO - 2015-12-27 08:23:17 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:17 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:17 --> Controller Class Initialized
INFO - 2015-12-27 08:23:17 --> Config Class Initialized
INFO - 2015-12-27 08:23:17 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:17 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:17 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:17 --> URI Class Initialized
INFO - 2015-12-27 08:23:17 --> Router Class Initialized
INFO - 2015-12-27 08:23:17 --> Output Class Initialized
INFO - 2015-12-27 08:23:17 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:17 --> Input Class Initialized
INFO - 2015-12-27 08:23:17 --> Language Class Initialized
INFO - 2015-12-27 08:23:17 --> Loader Class Initialized
INFO - 2015-12-27 08:23:17 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:17 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:17 --> Controller Class Initialized
INFO - 2015-12-27 08:23:17 --> Helper loaded: form_helper
INFO - 2015-12-27 08:23:17 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-27 08:23:17 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:17 --> Total execution time: 0.0882
INFO - 2015-12-27 08:23:21 --> Config Class Initialized
INFO - 2015-12-27 08:23:21 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:21 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:21 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:21 --> URI Class Initialized
INFO - 2015-12-27 08:23:21 --> Router Class Initialized
INFO - 2015-12-27 08:23:21 --> Output Class Initialized
INFO - 2015-12-27 08:23:21 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:21 --> Input Class Initialized
INFO - 2015-12-27 08:23:21 --> Language Class Initialized
INFO - 2015-12-27 08:23:21 --> Loader Class Initialized
INFO - 2015-12-27 08:23:21 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:21 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:21 --> Controller Class Initialized
INFO - 2015-12-27 08:23:21 --> Model Class Initialized
INFO - 2015-12-27 08:23:21 --> Model Class Initialized
INFO - 2015-12-27 08:23:22 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:22 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:22 --> Total execution time: 0.1356
INFO - 2015-12-27 08:23:22 --> Config Class Initialized
INFO - 2015-12-27 08:23:22 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:22 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:22 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:22 --> URI Class Initialized
INFO - 2015-12-27 08:23:22 --> Router Class Initialized
INFO - 2015-12-27 08:23:22 --> Output Class Initialized
INFO - 2015-12-27 08:23:22 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:22 --> Input Class Initialized
INFO - 2015-12-27 08:23:22 --> Language Class Initialized
INFO - 2015-12-27 08:23:22 --> Loader Class Initialized
INFO - 2015-12-27 08:23:22 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:22 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:22 --> Controller Class Initialized
INFO - 2015-12-27 08:23:22 --> Model Class Initialized
INFO - 2015-12-27 08:23:22 --> Model Class Initialized
INFO - 2015-12-27 08:23:22 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-27 08:23:22 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:22 --> Total execution time: 0.1304
INFO - 2015-12-27 08:23:22 --> Config Class Initialized
INFO - 2015-12-27 08:23:22 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:22 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:22 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:22 --> URI Class Initialized
INFO - 2015-12-27 08:23:22 --> Router Class Initialized
INFO - 2015-12-27 08:23:22 --> Output Class Initialized
INFO - 2015-12-27 08:23:22 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:22 --> Input Class Initialized
INFO - 2015-12-27 08:23:22 --> Language Class Initialized
INFO - 2015-12-27 08:23:22 --> Loader Class Initialized
INFO - 2015-12-27 08:23:22 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:22 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:22 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:22 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:22 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:22 --> Model Class Initialized
INFO - 2015-12-27 08:23:22 --> Model Class Initialized
INFO - 2015-12-27 08:23:22 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:22 --> Total execution time: 0.1578
INFO - 2015-12-27 08:23:24 --> Config Class Initialized
INFO - 2015-12-27 08:23:24 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:24 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:24 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:24 --> URI Class Initialized
INFO - 2015-12-27 08:23:24 --> Router Class Initialized
INFO - 2015-12-27 08:23:24 --> Output Class Initialized
INFO - 2015-12-27 08:23:24 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:24 --> Input Class Initialized
INFO - 2015-12-27 08:23:24 --> Language Class Initialized
INFO - 2015-12-27 08:23:24 --> Loader Class Initialized
INFO - 2015-12-27 08:23:24 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:24 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:24 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:24 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:24 --> Model Class Initialized
INFO - 2015-12-27 08:23:24 --> Model Class Initialized
INFO - 2015-12-27 08:23:24 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:24 --> Total execution time: 0.1457
INFO - 2015-12-27 08:23:30 --> Config Class Initialized
INFO - 2015-12-27 08:23:30 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:30 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:30 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:30 --> URI Class Initialized
INFO - 2015-12-27 08:23:30 --> Router Class Initialized
INFO - 2015-12-27 08:23:30 --> Output Class Initialized
INFO - 2015-12-27 08:23:30 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:30 --> Input Class Initialized
INFO - 2015-12-27 08:23:30 --> Language Class Initialized
INFO - 2015-12-27 08:23:30 --> Loader Class Initialized
INFO - 2015-12-27 08:23:30 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:30 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:31 --> Controller Class Initialized
INFO - 2015-12-27 08:23:31 --> Model Class Initialized
INFO - 2015-12-27 08:23:31 --> Model Class Initialized
INFO - 2015-12-27 08:23:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:31 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:31 --> Total execution time: 0.1578
INFO - 2015-12-27 08:23:31 --> Config Class Initialized
INFO - 2015-12-27 08:23:31 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:31 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:31 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:31 --> URI Class Initialized
INFO - 2015-12-27 08:23:31 --> Router Class Initialized
INFO - 2015-12-27 08:23:31 --> Output Class Initialized
INFO - 2015-12-27 08:23:31 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:31 --> Input Class Initialized
INFO - 2015-12-27 08:23:31 --> Language Class Initialized
INFO - 2015-12-27 08:23:31 --> Loader Class Initialized
INFO - 2015-12-27 08:23:31 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:31 --> Database Driver Class Initialized
ERROR - 2015-12-27 08:23:31 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2015-12-27 08:23:31 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
INFO - 2015-12-27 08:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:31 --> Controller Class Initialized
INFO - 2015-12-27 08:23:31 --> Model Class Initialized
INFO - 2015-12-27 08:23:31 --> Model Class Initialized
INFO - 2015-12-27 08:23:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:31 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:31 --> Total execution time: 0.1396
INFO - 2015-12-27 08:23:31 --> Config Class Initialized
INFO - 2015-12-27 08:23:31 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:31 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:31 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:31 --> URI Class Initialized
INFO - 2015-12-27 08:23:31 --> Router Class Initialized
INFO - 2015-12-27 08:23:31 --> Output Class Initialized
INFO - 2015-12-27 08:23:31 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:31 --> Input Class Initialized
INFO - 2015-12-27 08:23:31 --> Language Class Initialized
INFO - 2015-12-27 08:23:31 --> Loader Class Initialized
INFO - 2015-12-27 08:23:31 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:31 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:31 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:31 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:31 --> Model Class Initialized
INFO - 2015-12-27 08:23:31 --> Model Class Initialized
INFO - 2015-12-27 08:23:31 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:31 --> Total execution time: 0.1579
INFO - 2015-12-27 08:23:33 --> Config Class Initialized
INFO - 2015-12-27 08:23:33 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:33 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:33 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:33 --> URI Class Initialized
INFO - 2015-12-27 08:23:33 --> Router Class Initialized
INFO - 2015-12-27 08:23:33 --> Output Class Initialized
INFO - 2015-12-27 08:23:33 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:33 --> Input Class Initialized
INFO - 2015-12-27 08:23:33 --> Language Class Initialized
INFO - 2015-12-27 08:23:33 --> Loader Class Initialized
INFO - 2015-12-27 08:23:33 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:33 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:33 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:33 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:33 --> Model Class Initialized
INFO - 2015-12-27 08:23:33 --> Model Class Initialized
INFO - 2015-12-27 08:23:33 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:33 --> Total execution time: 0.1153
INFO - 2015-12-27 08:23:48 --> Config Class Initialized
INFO - 2015-12-27 08:23:48 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:48 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:48 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:48 --> URI Class Initialized
INFO - 2015-12-27 08:23:48 --> Router Class Initialized
INFO - 2015-12-27 08:23:48 --> Output Class Initialized
INFO - 2015-12-27 08:23:48 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:48 --> Input Class Initialized
INFO - 2015-12-27 08:23:48 --> Language Class Initialized
INFO - 2015-12-27 08:23:48 --> Loader Class Initialized
INFO - 2015-12-27 08:23:48 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:48 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:48 --> Controller Class Initialized
INFO - 2015-12-27 08:23:48 --> Model Class Initialized
INFO - 2015-12-27 08:23:48 --> Model Class Initialized
INFO - 2015-12-27 08:23:48 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:48 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:48 --> Total execution time: 0.1282
INFO - 2015-12-27 08:23:48 --> Config Class Initialized
INFO - 2015-12-27 08:23:48 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:48 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:48 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:48 --> URI Class Initialized
INFO - 2015-12-27 08:23:48 --> Router Class Initialized
INFO - 2015-12-27 08:23:48 --> Output Class Initialized
INFO - 2015-12-27 08:23:48 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:48 --> Input Class Initialized
INFO - 2015-12-27 08:23:48 --> Language Class Initialized
INFO - 2015-12-27 08:23:48 --> Loader Class Initialized
INFO - 2015-12-27 08:23:48 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:48 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:48 --> Controller Class Initialized
INFO - 2015-12-27 08:23:48 --> Model Class Initialized
INFO - 2015-12-27 08:23:48 --> Model Class Initialized
INFO - 2015-12-27 08:23:48 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:48 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:48 --> Total execution time: 0.1320
INFO - 2015-12-27 08:23:48 --> Config Class Initialized
INFO - 2015-12-27 08:23:48 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:48 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:48 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:48 --> URI Class Initialized
INFO - 2015-12-27 08:23:48 --> Router Class Initialized
INFO - 2015-12-27 08:23:48 --> Output Class Initialized
INFO - 2015-12-27 08:23:48 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:48 --> Input Class Initialized
INFO - 2015-12-27 08:23:48 --> Language Class Initialized
INFO - 2015-12-27 08:23:48 --> Loader Class Initialized
INFO - 2015-12-27 08:23:48 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:48 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:48 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:48 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:48 --> Model Class Initialized
INFO - 2015-12-27 08:23:48 --> Model Class Initialized
INFO - 2015-12-27 08:23:48 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:48 --> Total execution time: 0.1262
INFO - 2015-12-27 08:23:50 --> Config Class Initialized
INFO - 2015-12-27 08:23:50 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:50 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:50 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:50 --> URI Class Initialized
INFO - 2015-12-27 08:23:50 --> Router Class Initialized
INFO - 2015-12-27 08:23:50 --> Output Class Initialized
INFO - 2015-12-27 08:23:50 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:50 --> Input Class Initialized
INFO - 2015-12-27 08:23:50 --> Language Class Initialized
INFO - 2015-12-27 08:23:50 --> Loader Class Initialized
INFO - 2015-12-27 08:23:50 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:50 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:50 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:50 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:50 --> Model Class Initialized
INFO - 2015-12-27 08:23:50 --> Model Class Initialized
INFO - 2015-12-27 08:23:50 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:50 --> Total execution time: 0.1017
INFO - 2015-12-27 08:23:53 --> Config Class Initialized
INFO - 2015-12-27 08:23:53 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:53 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:53 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:53 --> URI Class Initialized
INFO - 2015-12-27 08:23:53 --> Router Class Initialized
INFO - 2015-12-27 08:23:53 --> Output Class Initialized
INFO - 2015-12-27 08:23:53 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:53 --> Input Class Initialized
INFO - 2015-12-27 08:23:53 --> Language Class Initialized
INFO - 2015-12-27 08:23:53 --> Loader Class Initialized
INFO - 2015-12-27 08:23:53 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:53 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:53 --> Controller Class Initialized
INFO - 2015-12-27 08:23:53 --> Model Class Initialized
INFO - 2015-12-27 08:23:53 --> Model Class Initialized
INFO - 2015-12-27 08:23:53 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:53 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:53 --> Total execution time: 0.1282
INFO - 2015-12-27 08:23:54 --> Config Class Initialized
INFO - 2015-12-27 08:23:54 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:54 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:54 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:54 --> URI Class Initialized
INFO - 2015-12-27 08:23:54 --> Router Class Initialized
INFO - 2015-12-27 08:23:54 --> Output Class Initialized
INFO - 2015-12-27 08:23:54 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:54 --> Input Class Initialized
INFO - 2015-12-27 08:23:54 --> Language Class Initialized
INFO - 2015-12-27 08:23:54 --> Loader Class Initialized
INFO - 2015-12-27 08:23:54 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:54 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:54 --> Controller Class Initialized
INFO - 2015-12-27 08:23:54 --> Model Class Initialized
INFO - 2015-12-27 08:23:54 --> Model Class Initialized
INFO - 2015-12-27 08:23:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:54 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:54 --> Total execution time: 0.1294
INFO - 2015-12-27 08:23:54 --> Config Class Initialized
INFO - 2015-12-27 08:23:54 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:54 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:54 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:54 --> URI Class Initialized
INFO - 2015-12-27 08:23:54 --> Router Class Initialized
INFO - 2015-12-27 08:23:54 --> Output Class Initialized
INFO - 2015-12-27 08:23:54 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:54 --> Input Class Initialized
INFO - 2015-12-27 08:23:54 --> Language Class Initialized
INFO - 2015-12-27 08:23:54 --> Loader Class Initialized
INFO - 2015-12-27 08:23:54 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:54 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:54 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:54 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:54 --> Model Class Initialized
INFO - 2015-12-27 08:23:54 --> Model Class Initialized
INFO - 2015-12-27 08:23:54 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:54 --> Total execution time: 0.1590
INFO - 2015-12-27 08:23:56 --> Config Class Initialized
INFO - 2015-12-27 08:23:56 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:56 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:56 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:56 --> URI Class Initialized
INFO - 2015-12-27 08:23:56 --> Router Class Initialized
INFO - 2015-12-27 08:23:56 --> Output Class Initialized
INFO - 2015-12-27 08:23:56 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:56 --> Input Class Initialized
INFO - 2015-12-27 08:23:56 --> Language Class Initialized
INFO - 2015-12-27 08:23:56 --> Loader Class Initialized
INFO - 2015-12-27 08:23:56 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:56 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:56 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:56 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:56 --> Model Class Initialized
INFO - 2015-12-27 08:23:56 --> Model Class Initialized
INFO - 2015-12-27 08:23:56 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:56 --> Total execution time: 0.1007
INFO - 2015-12-27 08:23:58 --> Config Class Initialized
INFO - 2015-12-27 08:23:58 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:58 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:58 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:58 --> URI Class Initialized
INFO - 2015-12-27 08:23:58 --> Router Class Initialized
INFO - 2015-12-27 08:23:58 --> Output Class Initialized
INFO - 2015-12-27 08:23:58 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:58 --> Input Class Initialized
INFO - 2015-12-27 08:23:58 --> Language Class Initialized
INFO - 2015-12-27 08:23:58 --> Loader Class Initialized
INFO - 2015-12-27 08:23:58 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:58 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:58 --> Controller Class Initialized
INFO - 2015-12-27 08:23:58 --> Model Class Initialized
INFO - 2015-12-27 08:23:58 --> Model Class Initialized
INFO - 2015-12-27 08:23:58 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:58 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:58 --> Total execution time: 0.0889
INFO - 2015-12-27 08:23:58 --> Config Class Initialized
INFO - 2015-12-27 08:23:58 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:23:58 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:58 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:58 --> URI Class Initialized
INFO - 2015-12-27 08:23:58 --> Router Class Initialized
INFO - 2015-12-27 08:23:58 --> Output Class Initialized
INFO - 2015-12-27 08:23:58 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:58 --> Input Class Initialized
INFO - 2015-12-27 08:23:58 --> Language Class Initialized
INFO - 2015-12-27 08:23:58 --> Loader Class Initialized
INFO - 2015-12-27 08:23:58 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:58 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:58 --> Config Class Initialized
INFO - 2015-12-27 08:23:58 --> Controller Class Initialized
INFO - 2015-12-27 08:23:58 --> Hooks Class Initialized
INFO - 2015-12-27 08:23:58 --> Model Class Initialized
INFO - 2015-12-27 08:23:58 --> Model Class Initialized
DEBUG - 2015-12-27 08:23:58 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:23:58 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:23:58 --> Utf8 Class Initialized
INFO - 2015-12-27 08:23:58 --> Final output sent to browser
INFO - 2015-12-27 08:23:58 --> URI Class Initialized
DEBUG - 2015-12-27 08:23:58 --> Total execution time: 0.1318
INFO - 2015-12-27 08:23:58 --> Router Class Initialized
INFO - 2015-12-27 08:23:58 --> Output Class Initialized
INFO - 2015-12-27 08:23:58 --> Security Class Initialized
DEBUG - 2015-12-27 08:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:23:58 --> Input Class Initialized
INFO - 2015-12-27 08:23:58 --> Language Class Initialized
INFO - 2015-12-27 08:23:58 --> Loader Class Initialized
INFO - 2015-12-27 08:23:58 --> Helper loaded: url_helper
INFO - 2015-12-27 08:23:58 --> Database Driver Class Initialized
INFO - 2015-12-27 08:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:23:58 --> Controller Class Initialized
DEBUG - 2015-12-27 08:23:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:23:58 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:23:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:23:58 --> Model Class Initialized
INFO - 2015-12-27 08:23:58 --> Model Class Initialized
INFO - 2015-12-27 08:23:58 --> Final output sent to browser
DEBUG - 2015-12-27 08:23:58 --> Total execution time: 0.1588
INFO - 2015-12-27 08:24:01 --> Config Class Initialized
INFO - 2015-12-27 08:24:01 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:24:01 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:24:01 --> Utf8 Class Initialized
INFO - 2015-12-27 08:24:01 --> URI Class Initialized
INFO - 2015-12-27 08:24:01 --> Router Class Initialized
INFO - 2015-12-27 08:24:01 --> Output Class Initialized
INFO - 2015-12-27 08:24:01 --> Security Class Initialized
DEBUG - 2015-12-27 08:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:24:01 --> Input Class Initialized
INFO - 2015-12-27 08:24:01 --> Language Class Initialized
INFO - 2015-12-27 08:24:01 --> Loader Class Initialized
INFO - 2015-12-27 08:24:01 --> Helper loaded: url_helper
INFO - 2015-12-27 08:24:01 --> Database Driver Class Initialized
INFO - 2015-12-27 08:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:24:01 --> Controller Class Initialized
DEBUG - 2015-12-27 08:24:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:24:01 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:24:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:24:01 --> Model Class Initialized
INFO - 2015-12-27 08:24:01 --> Model Class Initialized
INFO - 2015-12-27 08:24:01 --> Final output sent to browser
DEBUG - 2015-12-27 08:24:01 --> Total execution time: 0.1683
INFO - 2015-12-27 08:24:11 --> Config Class Initialized
INFO - 2015-12-27 08:24:11 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:24:11 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:24:11 --> Utf8 Class Initialized
INFO - 2015-12-27 08:24:11 --> URI Class Initialized
INFO - 2015-12-27 08:24:11 --> Router Class Initialized
INFO - 2015-12-27 08:24:11 --> Output Class Initialized
INFO - 2015-12-27 08:24:11 --> Security Class Initialized
DEBUG - 2015-12-27 08:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:24:11 --> Input Class Initialized
INFO - 2015-12-27 08:24:11 --> Language Class Initialized
INFO - 2015-12-27 08:24:11 --> Loader Class Initialized
INFO - 2015-12-27 08:24:11 --> Helper loaded: url_helper
INFO - 2015-12-27 08:24:11 --> Database Driver Class Initialized
INFO - 2015-12-27 08:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:24:11 --> Controller Class Initialized
DEBUG - 2015-12-27 08:24:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:24:11 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:24:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:24:11 --> Model Class Initialized
INFO - 2015-12-27 08:24:11 --> Model Class Initialized
INFO - 2015-12-27 08:24:11 --> Final output sent to browser
DEBUG - 2015-12-27 08:24:11 --> Total execution time: 0.1130
INFO - 2015-12-27 08:24:29 --> Config Class Initialized
INFO - 2015-12-27 08:24:29 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:24:29 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:24:29 --> Utf8 Class Initialized
INFO - 2015-12-27 08:24:29 --> URI Class Initialized
INFO - 2015-12-27 08:24:29 --> Router Class Initialized
INFO - 2015-12-27 08:24:29 --> Output Class Initialized
INFO - 2015-12-27 08:24:29 --> Security Class Initialized
DEBUG - 2015-12-27 08:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:24:29 --> Input Class Initialized
INFO - 2015-12-27 08:24:29 --> Language Class Initialized
INFO - 2015-12-27 08:24:29 --> Loader Class Initialized
INFO - 2015-12-27 08:24:29 --> Helper loaded: url_helper
INFO - 2015-12-27 08:24:30 --> Database Driver Class Initialized
INFO - 2015-12-27 08:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:24:30 --> Controller Class Initialized
INFO - 2015-12-27 08:24:30 --> Model Class Initialized
INFO - 2015-12-27 08:24:30 --> Model Class Initialized
INFO - 2015-12-27 08:24:30 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:24:30 --> Final output sent to browser
DEBUG - 2015-12-27 08:24:30 --> Total execution time: 0.1434
INFO - 2015-12-27 08:24:30 --> Config Class Initialized
INFO - 2015-12-27 08:24:30 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:24:30 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:24:30 --> Utf8 Class Initialized
INFO - 2015-12-27 08:24:30 --> URI Class Initialized
INFO - 2015-12-27 08:24:30 --> Router Class Initialized
INFO - 2015-12-27 08:24:30 --> Output Class Initialized
INFO - 2015-12-27 08:24:30 --> Security Class Initialized
DEBUG - 2015-12-27 08:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:24:30 --> Input Class Initialized
INFO - 2015-12-27 08:24:30 --> Language Class Initialized
INFO - 2015-12-27 08:24:30 --> Loader Class Initialized
INFO - 2015-12-27 08:24:30 --> Helper loaded: url_helper
INFO - 2015-12-27 08:24:30 --> Database Driver Class Initialized
INFO - 2015-12-27 08:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:24:30 --> Controller Class Initialized
INFO - 2015-12-27 08:24:30 --> Model Class Initialized
INFO - 2015-12-27 08:24:30 --> Model Class Initialized
INFO - 2015-12-27 08:24:30 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-27 08:24:30 --> Final output sent to browser
DEBUG - 2015-12-27 08:24:30 --> Total execution time: 0.1311
INFO - 2015-12-27 08:24:30 --> Config Class Initialized
INFO - 2015-12-27 08:24:30 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:24:30 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:24:30 --> Utf8 Class Initialized
INFO - 2015-12-27 08:24:30 --> URI Class Initialized
INFO - 2015-12-27 08:24:30 --> Router Class Initialized
INFO - 2015-12-27 08:24:30 --> Output Class Initialized
INFO - 2015-12-27 08:24:30 --> Security Class Initialized
DEBUG - 2015-12-27 08:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:24:30 --> Input Class Initialized
INFO - 2015-12-27 08:24:30 --> Language Class Initialized
INFO - 2015-12-27 08:24:30 --> Loader Class Initialized
INFO - 2015-12-27 08:24:30 --> Helper loaded: url_helper
INFO - 2015-12-27 08:24:30 --> Database Driver Class Initialized
INFO - 2015-12-27 08:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:24:30 --> Controller Class Initialized
DEBUG - 2015-12-27 08:24:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-27 08:24:30 --> Helper loaded: inflector_helper
INFO - 2015-12-27 08:24:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-27 08:24:30 --> Model Class Initialized
INFO - 2015-12-27 08:24:30 --> Model Class Initialized
INFO - 2015-12-27 08:24:30 --> Final output sent to browser
DEBUG - 2015-12-27 08:24:30 --> Total execution time: 0.1655
INFO - 2015-12-27 08:24:39 --> Config Class Initialized
INFO - 2015-12-27 08:24:39 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:24:39 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:24:39 --> Utf8 Class Initialized
INFO - 2015-12-27 08:24:39 --> URI Class Initialized
INFO - 2015-12-27 08:24:39 --> Router Class Initialized
INFO - 2015-12-27 08:24:39 --> Output Class Initialized
INFO - 2015-12-27 08:24:39 --> Security Class Initialized
DEBUG - 2015-12-27 08:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:24:39 --> Input Class Initialized
INFO - 2015-12-27 08:24:39 --> Language Class Initialized
INFO - 2015-12-27 08:24:39 --> Loader Class Initialized
INFO - 2015-12-27 08:24:39 --> Helper loaded: url_helper
INFO - 2015-12-27 08:24:39 --> Database Driver Class Initialized
INFO - 2015-12-27 08:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:24:39 --> Controller Class Initialized
INFO - 2015-12-27 08:24:39 --> Config Class Initialized
INFO - 2015-12-27 08:24:39 --> Hooks Class Initialized
DEBUG - 2015-12-27 08:24:39 --> UTF-8 Support Enabled
INFO - 2015-12-27 08:24:39 --> Utf8 Class Initialized
INFO - 2015-12-27 08:24:39 --> URI Class Initialized
INFO - 2015-12-27 08:24:39 --> Router Class Initialized
INFO - 2015-12-27 08:24:39 --> Output Class Initialized
INFO - 2015-12-27 08:24:39 --> Security Class Initialized
DEBUG - 2015-12-27 08:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-27 08:24:39 --> Input Class Initialized
INFO - 2015-12-27 08:24:39 --> Language Class Initialized
INFO - 2015-12-27 08:24:39 --> Loader Class Initialized
INFO - 2015-12-27 08:24:39 --> Helper loaded: url_helper
INFO - 2015-12-27 08:24:39 --> Database Driver Class Initialized
INFO - 2015-12-27 08:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-27 08:24:39 --> Controller Class Initialized
INFO - 2015-12-27 08:24:39 --> Helper loaded: form_helper
INFO - 2015-12-27 08:24:39 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-27 08:24:39 --> Final output sent to browser
DEBUG - 2015-12-27 08:24:39 --> Total execution time: 0.1467
