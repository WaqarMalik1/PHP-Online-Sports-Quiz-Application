<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2015-12-26 00:27:16 --> Config Class Initialized
INFO - 2015-12-26 00:27:16 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:16 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:16 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:16 --> URI Class Initialized
DEBUG - 2015-12-26 00:27:16 --> No URI present. Default controller set.
INFO - 2015-12-26 00:27:16 --> Router Class Initialized
INFO - 2015-12-26 00:27:16 --> Output Class Initialized
INFO - 2015-12-26 00:27:16 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:16 --> Input Class Initialized
INFO - 2015-12-26 00:27:16 --> Language Class Initialized
INFO - 2015-12-26 00:27:16 --> Loader Class Initialized
INFO - 2015-12-26 00:27:16 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:16 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:16 --> Controller Class Initialized
INFO - 2015-12-26 00:27:16 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 00:27:16 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:16 --> Total execution time: 0.4206
INFO - 2015-12-26 00:27:21 --> Config Class Initialized
INFO - 2015-12-26 00:27:21 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:21 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:21 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:21 --> URI Class Initialized
INFO - 2015-12-26 00:27:21 --> Router Class Initialized
INFO - 2015-12-26 00:27:21 --> Output Class Initialized
INFO - 2015-12-26 00:27:21 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:21 --> Input Class Initialized
INFO - 2015-12-26 00:27:21 --> Language Class Initialized
INFO - 2015-12-26 00:27:21 --> Loader Class Initialized
INFO - 2015-12-26 00:27:21 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:21 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:21 --> Controller Class Initialized
INFO - 2015-12-26 00:27:21 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 00:27:21 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:21 --> Total execution time: 0.1029
INFO - 2015-12-26 00:27:22 --> Config Class Initialized
INFO - 2015-12-26 00:27:22 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:22 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:22 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:22 --> URI Class Initialized
INFO - 2015-12-26 00:27:22 --> Router Class Initialized
INFO - 2015-12-26 00:27:22 --> Output Class Initialized
INFO - 2015-12-26 00:27:22 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:22 --> Input Class Initialized
INFO - 2015-12-26 00:27:22 --> Language Class Initialized
INFO - 2015-12-26 00:27:22 --> Loader Class Initialized
INFO - 2015-12-26 00:27:22 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:22 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:22 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:22 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:22 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:22 --> Model Class Initialized
INFO - 2015-12-26 00:27:22 --> Model Class Initialized
INFO - 2015-12-26 00:27:22 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:22 --> Total execution time: 0.1366
INFO - 2015-12-26 00:27:24 --> Config Class Initialized
INFO - 2015-12-26 00:27:24 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:24 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:24 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:24 --> URI Class Initialized
INFO - 2015-12-26 00:27:24 --> Router Class Initialized
INFO - 2015-12-26 00:27:24 --> Output Class Initialized
INFO - 2015-12-26 00:27:24 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:24 --> Input Class Initialized
INFO - 2015-12-26 00:27:24 --> Language Class Initialized
INFO - 2015-12-26 00:27:24 --> Loader Class Initialized
INFO - 2015-12-26 00:27:24 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:24 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:24 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:24 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:24 --> Model Class Initialized
INFO - 2015-12-26 00:27:24 --> Model Class Initialized
INFO - 2015-12-26 00:27:24 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:24 --> Total execution time: 0.1127
INFO - 2015-12-26 00:27:24 --> Config Class Initialized
INFO - 2015-12-26 00:27:24 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:24 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:24 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:24 --> URI Class Initialized
INFO - 2015-12-26 00:27:24 --> Router Class Initialized
INFO - 2015-12-26 00:27:24 --> Output Class Initialized
INFO - 2015-12-26 00:27:24 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:24 --> Input Class Initialized
INFO - 2015-12-26 00:27:24 --> Language Class Initialized
INFO - 2015-12-26 00:27:24 --> Loader Class Initialized
INFO - 2015-12-26 00:27:24 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:24 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:24 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:24 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:24 --> Model Class Initialized
INFO - 2015-12-26 00:27:24 --> Model Class Initialized
INFO - 2015-12-26 00:27:24 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:24 --> Total execution time: 0.1012
INFO - 2015-12-26 00:27:27 --> Config Class Initialized
INFO - 2015-12-26 00:27:27 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:27 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:27 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:27 --> URI Class Initialized
INFO - 2015-12-26 00:27:27 --> Router Class Initialized
INFO - 2015-12-26 00:27:27 --> Output Class Initialized
INFO - 2015-12-26 00:27:27 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:27 --> Input Class Initialized
INFO - 2015-12-26 00:27:27 --> Language Class Initialized
INFO - 2015-12-26 00:27:27 --> Loader Class Initialized
INFO - 2015-12-26 00:27:27 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:27 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:27 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:27 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:27 --> Model Class Initialized
INFO - 2015-12-26 00:27:27 --> Model Class Initialized
INFO - 2015-12-26 00:27:27 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:27 --> Total execution time: 0.1049
INFO - 2015-12-26 00:27:28 --> Config Class Initialized
INFO - 2015-12-26 00:27:28 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:28 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:28 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:28 --> URI Class Initialized
INFO - 2015-12-26 00:27:28 --> Router Class Initialized
INFO - 2015-12-26 00:27:28 --> Output Class Initialized
INFO - 2015-12-26 00:27:28 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:28 --> Input Class Initialized
INFO - 2015-12-26 00:27:28 --> Language Class Initialized
INFO - 2015-12-26 00:27:28 --> Loader Class Initialized
INFO - 2015-12-26 00:27:28 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:28 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:28 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:28 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:28 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:28 --> Model Class Initialized
INFO - 2015-12-26 00:27:28 --> Model Class Initialized
INFO - 2015-12-26 00:27:28 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:28 --> Total execution time: 0.0983
INFO - 2015-12-26 00:27:30 --> Config Class Initialized
INFO - 2015-12-26 00:27:30 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:30 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:30 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:30 --> URI Class Initialized
INFO - 2015-12-26 00:27:30 --> Router Class Initialized
INFO - 2015-12-26 00:27:30 --> Output Class Initialized
INFO - 2015-12-26 00:27:30 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:30 --> Input Class Initialized
INFO - 2015-12-26 00:27:30 --> Language Class Initialized
INFO - 2015-12-26 00:27:30 --> Loader Class Initialized
INFO - 2015-12-26 00:27:30 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:30 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:30 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:30 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:30 --> Model Class Initialized
INFO - 2015-12-26 00:27:30 --> Model Class Initialized
INFO - 2015-12-26 00:27:30 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:30 --> Total execution time: 0.1090
INFO - 2015-12-26 00:27:30 --> Config Class Initialized
INFO - 2015-12-26 00:27:30 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:30 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:30 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:30 --> URI Class Initialized
INFO - 2015-12-26 00:27:30 --> Router Class Initialized
INFO - 2015-12-26 00:27:30 --> Output Class Initialized
INFO - 2015-12-26 00:27:30 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:30 --> Input Class Initialized
INFO - 2015-12-26 00:27:30 --> Language Class Initialized
INFO - 2015-12-26 00:27:30 --> Loader Class Initialized
INFO - 2015-12-26 00:27:30 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:30 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:30 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:30 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:30 --> Model Class Initialized
INFO - 2015-12-26 00:27:30 --> Model Class Initialized
INFO - 2015-12-26 00:27:30 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:30 --> Total execution time: 0.1028
INFO - 2015-12-26 00:27:33 --> Config Class Initialized
INFO - 2015-12-26 00:27:33 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:33 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:33 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:33 --> URI Class Initialized
INFO - 2015-12-26 00:27:33 --> Router Class Initialized
INFO - 2015-12-26 00:27:34 --> Output Class Initialized
INFO - 2015-12-26 00:27:34 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:34 --> Input Class Initialized
INFO - 2015-12-26 00:27:34 --> Language Class Initialized
INFO - 2015-12-26 00:27:34 --> Loader Class Initialized
INFO - 2015-12-26 00:27:34 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:34 --> Database Driver Class Initialized
ERROR - 2015-12-26 00:27:34 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2015-12-26 00:27:34 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
ERROR - 2015-12-26 00:27:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/libraries/Session/Session.php 168
INFO - 2015-12-26 00:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:34 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:34 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:34 --> Model Class Initialized
INFO - 2015-12-26 00:27:34 --> Model Class Initialized
ERROR - 2015-12-26 00:27:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/core/Common.php 573
INFO - 2015-12-26 00:27:34 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:34 --> Total execution time: 0.1845
INFO - 2015-12-26 00:27:37 --> Config Class Initialized
INFO - 2015-12-26 00:27:37 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:37 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:37 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:37 --> URI Class Initialized
DEBUG - 2015-12-26 00:27:37 --> No URI present. Default controller set.
INFO - 2015-12-26 00:27:37 --> Router Class Initialized
INFO - 2015-12-26 00:27:37 --> Output Class Initialized
INFO - 2015-12-26 00:27:37 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:37 --> Input Class Initialized
INFO - 2015-12-26 00:27:37 --> Language Class Initialized
INFO - 2015-12-26 00:27:37 --> Loader Class Initialized
INFO - 2015-12-26 00:27:37 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:37 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:37 --> Controller Class Initialized
INFO - 2015-12-26 00:27:37 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 00:27:37 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:37 --> Total execution time: 0.1252
INFO - 2015-12-26 00:27:39 --> Config Class Initialized
INFO - 2015-12-26 00:27:39 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:39 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:39 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:39 --> URI Class Initialized
INFO - 2015-12-26 00:27:39 --> Router Class Initialized
INFO - 2015-12-26 00:27:39 --> Output Class Initialized
INFO - 2015-12-26 00:27:39 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:39 --> Input Class Initialized
INFO - 2015-12-26 00:27:39 --> Language Class Initialized
INFO - 2015-12-26 00:27:39 --> Loader Class Initialized
INFO - 2015-12-26 00:27:39 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:39 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:39 --> Controller Class Initialized
INFO - 2015-12-26 00:27:39 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 00:27:39 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:39 --> Total execution time: 0.0833
INFO - 2015-12-26 00:27:39 --> Config Class Initialized
INFO - 2015-12-26 00:27:39 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:39 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:39 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:39 --> URI Class Initialized
INFO - 2015-12-26 00:27:39 --> Router Class Initialized
INFO - 2015-12-26 00:27:39 --> Output Class Initialized
INFO - 2015-12-26 00:27:39 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:39 --> Input Class Initialized
INFO - 2015-12-26 00:27:39 --> Language Class Initialized
INFO - 2015-12-26 00:27:39 --> Loader Class Initialized
INFO - 2015-12-26 00:27:39 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:39 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:39 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:39 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:39 --> Model Class Initialized
INFO - 2015-12-26 00:27:39 --> Model Class Initialized
INFO - 2015-12-26 00:27:39 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:39 --> Total execution time: 0.0995
INFO - 2015-12-26 00:27:40 --> Config Class Initialized
INFO - 2015-12-26 00:27:40 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:40 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:40 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:40 --> URI Class Initialized
INFO - 2015-12-26 00:27:40 --> Router Class Initialized
INFO - 2015-12-26 00:27:40 --> Output Class Initialized
INFO - 2015-12-26 00:27:40 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:40 --> Input Class Initialized
INFO - 2015-12-26 00:27:40 --> Language Class Initialized
INFO - 2015-12-26 00:27:40 --> Loader Class Initialized
INFO - 2015-12-26 00:27:40 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:40 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:40 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:40 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:40 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:40 --> Model Class Initialized
INFO - 2015-12-26 00:27:40 --> Model Class Initialized
INFO - 2015-12-26 00:27:40 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:40 --> Total execution time: 0.0999
INFO - 2015-12-26 00:27:40 --> Config Class Initialized
INFO - 2015-12-26 00:27:40 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:40 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:40 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:40 --> URI Class Initialized
INFO - 2015-12-26 00:27:40 --> Router Class Initialized
INFO - 2015-12-26 00:27:40 --> Output Class Initialized
INFO - 2015-12-26 00:27:41 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:41 --> Input Class Initialized
INFO - 2015-12-26 00:27:41 --> Language Class Initialized
INFO - 2015-12-26 00:27:41 --> Loader Class Initialized
INFO - 2015-12-26 00:27:41 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:41 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:41 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:41 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:41 --> Model Class Initialized
INFO - 2015-12-26 00:27:41 --> Model Class Initialized
INFO - 2015-12-26 00:27:41 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:41 --> Total execution time: 0.1496
INFO - 2015-12-26 00:27:44 --> Config Class Initialized
INFO - 2015-12-26 00:27:44 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:44 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:44 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:44 --> URI Class Initialized
INFO - 2015-12-26 00:27:44 --> Router Class Initialized
INFO - 2015-12-26 00:27:44 --> Output Class Initialized
INFO - 2015-12-26 00:27:44 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:44 --> Input Class Initialized
INFO - 2015-12-26 00:27:44 --> Language Class Initialized
INFO - 2015-12-26 00:27:44 --> Loader Class Initialized
INFO - 2015-12-26 00:27:44 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:44 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:44 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:44 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:44 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:44 --> Model Class Initialized
INFO - 2015-12-26 00:27:44 --> Model Class Initialized
INFO - 2015-12-26 00:27:44 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:44 --> Total execution time: 0.1063
INFO - 2015-12-26 00:27:45 --> Config Class Initialized
INFO - 2015-12-26 00:27:45 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:45 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:45 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:45 --> URI Class Initialized
INFO - 2015-12-26 00:27:45 --> Router Class Initialized
INFO - 2015-12-26 00:27:45 --> Output Class Initialized
INFO - 2015-12-26 00:27:45 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:45 --> Input Class Initialized
INFO - 2015-12-26 00:27:45 --> Language Class Initialized
INFO - 2015-12-26 00:27:45 --> Loader Class Initialized
INFO - 2015-12-26 00:27:45 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:45 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:45 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:45 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:45 --> Model Class Initialized
INFO - 2015-12-26 00:27:45 --> Model Class Initialized
INFO - 2015-12-26 00:27:45 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:45 --> Total execution time: 0.1041
INFO - 2015-12-26 00:27:47 --> Config Class Initialized
INFO - 2015-12-26 00:27:47 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:47 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:47 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:47 --> URI Class Initialized
INFO - 2015-12-26 00:27:47 --> Router Class Initialized
INFO - 2015-12-26 00:27:47 --> Output Class Initialized
INFO - 2015-12-26 00:27:47 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:47 --> Input Class Initialized
INFO - 2015-12-26 00:27:47 --> Language Class Initialized
INFO - 2015-12-26 00:27:47 --> Loader Class Initialized
INFO - 2015-12-26 00:27:47 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:47 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:47 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:47 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:47 --> Model Class Initialized
INFO - 2015-12-26 00:27:47 --> Model Class Initialized
INFO - 2015-12-26 00:27:47 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:47 --> Total execution time: 0.1034
INFO - 2015-12-26 00:27:48 --> Config Class Initialized
INFO - 2015-12-26 00:27:48 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:48 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:48 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:48 --> URI Class Initialized
INFO - 2015-12-26 00:27:48 --> Router Class Initialized
INFO - 2015-12-26 00:27:48 --> Output Class Initialized
INFO - 2015-12-26 00:27:48 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:48 --> Input Class Initialized
INFO - 2015-12-26 00:27:48 --> Language Class Initialized
INFO - 2015-12-26 00:27:48 --> Loader Class Initialized
INFO - 2015-12-26 00:27:48 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:48 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:48 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:48 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:48 --> Model Class Initialized
INFO - 2015-12-26 00:27:48 --> Model Class Initialized
INFO - 2015-12-26 00:27:48 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:48 --> Total execution time: 0.0999
INFO - 2015-12-26 00:27:50 --> Config Class Initialized
INFO - 2015-12-26 00:27:50 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:50 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:50 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:50 --> URI Class Initialized
INFO - 2015-12-26 00:27:50 --> Router Class Initialized
INFO - 2015-12-26 00:27:50 --> Output Class Initialized
INFO - 2015-12-26 00:27:50 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:50 --> Input Class Initialized
INFO - 2015-12-26 00:27:50 --> Language Class Initialized
INFO - 2015-12-26 00:27:50 --> Loader Class Initialized
INFO - 2015-12-26 00:27:50 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:50 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:50 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:50 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:50 --> Model Class Initialized
INFO - 2015-12-26 00:27:50 --> Model Class Initialized
INFO - 2015-12-26 00:27:50 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:50 --> Total execution time: 0.1057
INFO - 2015-12-26 00:27:51 --> Config Class Initialized
INFO - 2015-12-26 00:27:51 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:51 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:51 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:51 --> URI Class Initialized
INFO - 2015-12-26 00:27:51 --> Router Class Initialized
INFO - 2015-12-26 00:27:51 --> Output Class Initialized
INFO - 2015-12-26 00:27:51 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:51 --> Input Class Initialized
INFO - 2015-12-26 00:27:51 --> Language Class Initialized
INFO - 2015-12-26 00:27:51 --> Loader Class Initialized
INFO - 2015-12-26 00:27:51 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:51 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:51 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:51 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:51 --> Model Class Initialized
INFO - 2015-12-26 00:27:51 --> Model Class Initialized
INFO - 2015-12-26 00:27:51 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:51 --> Total execution time: 0.1019
INFO - 2015-12-26 00:27:54 --> Config Class Initialized
INFO - 2015-12-26 00:27:54 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:54 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:54 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:54 --> URI Class Initialized
DEBUG - 2015-12-26 00:27:54 --> No URI present. Default controller set.
INFO - 2015-12-26 00:27:54 --> Router Class Initialized
INFO - 2015-12-26 00:27:54 --> Output Class Initialized
INFO - 2015-12-26 00:27:54 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:54 --> Input Class Initialized
INFO - 2015-12-26 00:27:54 --> Language Class Initialized
INFO - 2015-12-26 00:27:54 --> Loader Class Initialized
INFO - 2015-12-26 00:27:54 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:54 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:54 --> Controller Class Initialized
INFO - 2015-12-26 00:27:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 00:27:54 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:54 --> Total execution time: 0.0828
INFO - 2015-12-26 00:27:55 --> Config Class Initialized
INFO - 2015-12-26 00:27:55 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:55 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:55 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:56 --> URI Class Initialized
INFO - 2015-12-26 00:27:56 --> Router Class Initialized
INFO - 2015-12-26 00:27:56 --> Output Class Initialized
INFO - 2015-12-26 00:27:56 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:56 --> Input Class Initialized
INFO - 2015-12-26 00:27:56 --> Language Class Initialized
INFO - 2015-12-26 00:27:56 --> Loader Class Initialized
INFO - 2015-12-26 00:27:56 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:56 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:56 --> Controller Class Initialized
INFO - 2015-12-26 00:27:56 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 00:27:56 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:56 --> Total execution time: 0.0803
INFO - 2015-12-26 00:27:56 --> Config Class Initialized
INFO - 2015-12-26 00:27:56 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:56 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:56 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:56 --> URI Class Initialized
INFO - 2015-12-26 00:27:56 --> Router Class Initialized
INFO - 2015-12-26 00:27:56 --> Output Class Initialized
INFO - 2015-12-26 00:27:56 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:56 --> Input Class Initialized
INFO - 2015-12-26 00:27:56 --> Language Class Initialized
INFO - 2015-12-26 00:27:56 --> Loader Class Initialized
INFO - 2015-12-26 00:27:56 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:56 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:56 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:56 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:56 --> Model Class Initialized
INFO - 2015-12-26 00:27:56 --> Model Class Initialized
INFO - 2015-12-26 00:27:56 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:56 --> Total execution time: 0.1037
INFO - 2015-12-26 00:27:59 --> Config Class Initialized
INFO - 2015-12-26 00:27:59 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:59 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:59 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:59 --> URI Class Initialized
INFO - 2015-12-26 00:27:59 --> Router Class Initialized
INFO - 2015-12-26 00:27:59 --> Output Class Initialized
INFO - 2015-12-26 00:27:59 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:59 --> Input Class Initialized
INFO - 2015-12-26 00:27:59 --> Language Class Initialized
INFO - 2015-12-26 00:27:59 --> Loader Class Initialized
INFO - 2015-12-26 00:27:59 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:59 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:59 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:59 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:59 --> Model Class Initialized
INFO - 2015-12-26 00:27:59 --> Model Class Initialized
INFO - 2015-12-26 00:27:59 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:59 --> Total execution time: 0.1183
INFO - 2015-12-26 00:27:59 --> Config Class Initialized
INFO - 2015-12-26 00:27:59 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:27:59 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:27:59 --> Utf8 Class Initialized
INFO - 2015-12-26 00:27:59 --> URI Class Initialized
INFO - 2015-12-26 00:27:59 --> Router Class Initialized
INFO - 2015-12-26 00:27:59 --> Output Class Initialized
INFO - 2015-12-26 00:27:59 --> Security Class Initialized
DEBUG - 2015-12-26 00:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:27:59 --> Input Class Initialized
INFO - 2015-12-26 00:27:59 --> Language Class Initialized
INFO - 2015-12-26 00:27:59 --> Loader Class Initialized
INFO - 2015-12-26 00:27:59 --> Helper loaded: url_helper
INFO - 2015-12-26 00:27:59 --> Database Driver Class Initialized
INFO - 2015-12-26 00:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:27:59 --> Controller Class Initialized
DEBUG - 2015-12-26 00:27:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:27:59 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:27:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:27:59 --> Model Class Initialized
INFO - 2015-12-26 00:27:59 --> Model Class Initialized
INFO - 2015-12-26 00:27:59 --> Final output sent to browser
DEBUG - 2015-12-26 00:27:59 --> Total execution time: 0.1010
INFO - 2015-12-26 00:28:03 --> Config Class Initialized
INFO - 2015-12-26 00:28:03 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:03 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:03 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:03 --> URI Class Initialized
INFO - 2015-12-26 00:28:03 --> Router Class Initialized
INFO - 2015-12-26 00:28:03 --> Output Class Initialized
INFO - 2015-12-26 00:28:03 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:03 --> Input Class Initialized
INFO - 2015-12-26 00:28:03 --> Language Class Initialized
INFO - 2015-12-26 00:28:03 --> Loader Class Initialized
INFO - 2015-12-26 00:28:03 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:03 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:03 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:03 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:03 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:03 --> Model Class Initialized
INFO - 2015-12-26 00:28:03 --> Model Class Initialized
INFO - 2015-12-26 00:28:03 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:03 --> Total execution time: 0.1779
INFO - 2015-12-26 00:28:04 --> Config Class Initialized
INFO - 2015-12-26 00:28:04 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:04 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:04 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:04 --> URI Class Initialized
INFO - 2015-12-26 00:28:04 --> Router Class Initialized
INFO - 2015-12-26 00:28:04 --> Output Class Initialized
INFO - 2015-12-26 00:28:04 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:04 --> Input Class Initialized
INFO - 2015-12-26 00:28:04 --> Language Class Initialized
INFO - 2015-12-26 00:28:04 --> Loader Class Initialized
INFO - 2015-12-26 00:28:04 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:04 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:04 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:04 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:04 --> Model Class Initialized
INFO - 2015-12-26 00:28:04 --> Model Class Initialized
INFO - 2015-12-26 00:28:04 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:04 --> Total execution time: 0.1041
INFO - 2015-12-26 00:28:06 --> Config Class Initialized
INFO - 2015-12-26 00:28:06 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:06 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:06 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:06 --> URI Class Initialized
INFO - 2015-12-26 00:28:06 --> Router Class Initialized
INFO - 2015-12-26 00:28:06 --> Output Class Initialized
INFO - 2015-12-26 00:28:06 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:06 --> Input Class Initialized
INFO - 2015-12-26 00:28:06 --> Language Class Initialized
INFO - 2015-12-26 00:28:06 --> Loader Class Initialized
INFO - 2015-12-26 00:28:06 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:06 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:06 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:06 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:06 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:06 --> Model Class Initialized
INFO - 2015-12-26 00:28:06 --> Model Class Initialized
INFO - 2015-12-26 00:28:06 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:06 --> Total execution time: 0.0990
INFO - 2015-12-26 00:28:06 --> Config Class Initialized
INFO - 2015-12-26 00:28:06 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:06 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:06 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:06 --> URI Class Initialized
INFO - 2015-12-26 00:28:06 --> Router Class Initialized
INFO - 2015-12-26 00:28:06 --> Output Class Initialized
INFO - 2015-12-26 00:28:06 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:06 --> Input Class Initialized
INFO - 2015-12-26 00:28:06 --> Language Class Initialized
INFO - 2015-12-26 00:28:06 --> Loader Class Initialized
INFO - 2015-12-26 00:28:06 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:06 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:06 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:06 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:06 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:06 --> Model Class Initialized
INFO - 2015-12-26 00:28:06 --> Model Class Initialized
INFO - 2015-12-26 00:28:06 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:06 --> Total execution time: 0.1160
INFO - 2015-12-26 00:28:09 --> Config Class Initialized
INFO - 2015-12-26 00:28:09 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:09 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:09 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:09 --> URI Class Initialized
INFO - 2015-12-26 00:28:09 --> Router Class Initialized
INFO - 2015-12-26 00:28:09 --> Output Class Initialized
INFO - 2015-12-26 00:28:09 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:09 --> Input Class Initialized
INFO - 2015-12-26 00:28:09 --> Language Class Initialized
INFO - 2015-12-26 00:28:09 --> Loader Class Initialized
INFO - 2015-12-26 00:28:09 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:09 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:09 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:09 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:09 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:09 --> Model Class Initialized
INFO - 2015-12-26 00:28:09 --> Model Class Initialized
INFO - 2015-12-26 00:28:09 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:09 --> Total execution time: 0.1078
INFO - 2015-12-26 00:28:09 --> Config Class Initialized
INFO - 2015-12-26 00:28:09 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:09 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:09 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:09 --> URI Class Initialized
INFO - 2015-12-26 00:28:09 --> Router Class Initialized
INFO - 2015-12-26 00:28:09 --> Output Class Initialized
INFO - 2015-12-26 00:28:09 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:09 --> Input Class Initialized
INFO - 2015-12-26 00:28:09 --> Language Class Initialized
INFO - 2015-12-26 00:28:10 --> Loader Class Initialized
INFO - 2015-12-26 00:28:10 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:10 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:10 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:10 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:10 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:10 --> Model Class Initialized
INFO - 2015-12-26 00:28:10 --> Model Class Initialized
INFO - 2015-12-26 00:28:10 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:10 --> Total execution time: 0.1057
INFO - 2015-12-26 00:28:11 --> Config Class Initialized
INFO - 2015-12-26 00:28:11 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:11 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:11 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:11 --> URI Class Initialized
INFO - 2015-12-26 00:28:11 --> Router Class Initialized
INFO - 2015-12-26 00:28:11 --> Output Class Initialized
INFO - 2015-12-26 00:28:11 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:11 --> Input Class Initialized
INFO - 2015-12-26 00:28:11 --> Language Class Initialized
INFO - 2015-12-26 00:28:11 --> Loader Class Initialized
INFO - 2015-12-26 00:28:11 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:11 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:11 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:11 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:11 --> Model Class Initialized
INFO - 2015-12-26 00:28:11 --> Model Class Initialized
INFO - 2015-12-26 00:28:11 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:11 --> Total execution time: 0.1007
INFO - 2015-12-26 00:28:11 --> Config Class Initialized
INFO - 2015-12-26 00:28:11 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:11 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:12 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:12 --> URI Class Initialized
INFO - 2015-12-26 00:28:12 --> Router Class Initialized
INFO - 2015-12-26 00:28:12 --> Output Class Initialized
INFO - 2015-12-26 00:28:12 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:12 --> Input Class Initialized
INFO - 2015-12-26 00:28:12 --> Language Class Initialized
INFO - 2015-12-26 00:28:12 --> Loader Class Initialized
INFO - 2015-12-26 00:28:12 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:12 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:12 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:12 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:12 --> Model Class Initialized
INFO - 2015-12-26 00:28:12 --> Model Class Initialized
INFO - 2015-12-26 00:28:12 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:12 --> Total execution time: 0.1053
INFO - 2015-12-26 00:28:15 --> Config Class Initialized
INFO - 2015-12-26 00:28:15 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:15 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:15 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:15 --> URI Class Initialized
INFO - 2015-12-26 00:28:15 --> Router Class Initialized
INFO - 2015-12-26 00:28:15 --> Output Class Initialized
INFO - 2015-12-26 00:28:15 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:15 --> Input Class Initialized
INFO - 2015-12-26 00:28:15 --> Language Class Initialized
INFO - 2015-12-26 00:28:15 --> Loader Class Initialized
INFO - 2015-12-26 00:28:15 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:15 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:15 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:15 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:15 --> Model Class Initialized
INFO - 2015-12-26 00:28:15 --> Model Class Initialized
INFO - 2015-12-26 00:28:15 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:15 --> Total execution time: 0.1134
INFO - 2015-12-26 00:28:16 --> Config Class Initialized
INFO - 2015-12-26 00:28:16 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:16 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:16 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:16 --> URI Class Initialized
INFO - 2015-12-26 00:28:16 --> Router Class Initialized
INFO - 2015-12-26 00:28:16 --> Output Class Initialized
INFO - 2015-12-26 00:28:16 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:16 --> Input Class Initialized
INFO - 2015-12-26 00:28:16 --> Language Class Initialized
INFO - 2015-12-26 00:28:16 --> Loader Class Initialized
INFO - 2015-12-26 00:28:16 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:16 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:16 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:16 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:16 --> Model Class Initialized
INFO - 2015-12-26 00:28:16 --> Model Class Initialized
INFO - 2015-12-26 00:28:16 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:16 --> Total execution time: 0.1290
INFO - 2015-12-26 00:28:19 --> Config Class Initialized
INFO - 2015-12-26 00:28:19 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:19 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:19 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:19 --> URI Class Initialized
INFO - 2015-12-26 00:28:19 --> Router Class Initialized
INFO - 2015-12-26 00:28:19 --> Output Class Initialized
INFO - 2015-12-26 00:28:19 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:19 --> Input Class Initialized
INFO - 2015-12-26 00:28:19 --> Language Class Initialized
INFO - 2015-12-26 00:28:19 --> Loader Class Initialized
INFO - 2015-12-26 00:28:19 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:19 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:19 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:19 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:19 --> Model Class Initialized
INFO - 2015-12-26 00:28:19 --> Model Class Initialized
INFO - 2015-12-26 00:28:19 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:19 --> Total execution time: 0.1063
INFO - 2015-12-26 00:28:20 --> Config Class Initialized
INFO - 2015-12-26 00:28:20 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:20 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:20 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:20 --> URI Class Initialized
INFO - 2015-12-26 00:28:20 --> Router Class Initialized
INFO - 2015-12-26 00:28:20 --> Output Class Initialized
INFO - 2015-12-26 00:28:20 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:20 --> Input Class Initialized
INFO - 2015-12-26 00:28:20 --> Language Class Initialized
INFO - 2015-12-26 00:28:20 --> Loader Class Initialized
INFO - 2015-12-26 00:28:20 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:20 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:20 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:20 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:20 --> Model Class Initialized
INFO - 2015-12-26 00:28:20 --> Model Class Initialized
INFO - 2015-12-26 00:28:20 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:20 --> Total execution time: 0.1046
INFO - 2015-12-26 00:28:26 --> Config Class Initialized
INFO - 2015-12-26 00:28:26 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:26 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:26 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:26 --> URI Class Initialized
INFO - 2015-12-26 00:28:26 --> Router Class Initialized
INFO - 2015-12-26 00:28:26 --> Output Class Initialized
INFO - 2015-12-26 00:28:26 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:26 --> Input Class Initialized
INFO - 2015-12-26 00:28:26 --> Language Class Initialized
INFO - 2015-12-26 00:28:26 --> Loader Class Initialized
INFO - 2015-12-26 00:28:26 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:26 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:26 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:26 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:26 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:26 --> Model Class Initialized
INFO - 2015-12-26 00:28:26 --> Model Class Initialized
INFO - 2015-12-26 00:28:26 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:26 --> Total execution time: 0.1143
INFO - 2015-12-26 00:28:26 --> Config Class Initialized
INFO - 2015-12-26 00:28:26 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:26 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:26 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:26 --> URI Class Initialized
INFO - 2015-12-26 00:28:26 --> Router Class Initialized
INFO - 2015-12-26 00:28:26 --> Output Class Initialized
INFO - 2015-12-26 00:28:26 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:27 --> Input Class Initialized
INFO - 2015-12-26 00:28:27 --> Language Class Initialized
INFO - 2015-12-26 00:28:27 --> Loader Class Initialized
INFO - 2015-12-26 00:28:27 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:27 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:27 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:27 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:27 --> Model Class Initialized
INFO - 2015-12-26 00:28:27 --> Model Class Initialized
INFO - 2015-12-26 00:28:27 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:27 --> Total execution time: 0.1189
INFO - 2015-12-26 00:28:29 --> Config Class Initialized
INFO - 2015-12-26 00:28:29 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:29 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:29 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:29 --> URI Class Initialized
DEBUG - 2015-12-26 00:28:29 --> No URI present. Default controller set.
INFO - 2015-12-26 00:28:29 --> Router Class Initialized
INFO - 2015-12-26 00:28:29 --> Output Class Initialized
INFO - 2015-12-26 00:28:29 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:29 --> Input Class Initialized
INFO - 2015-12-26 00:28:29 --> Language Class Initialized
INFO - 2015-12-26 00:28:29 --> Loader Class Initialized
INFO - 2015-12-26 00:28:29 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:29 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:29 --> Controller Class Initialized
INFO - 2015-12-26 00:28:29 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 00:28:29 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:29 --> Total execution time: 0.0843
INFO - 2015-12-26 00:28:31 --> Config Class Initialized
INFO - 2015-12-26 00:28:31 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:31 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:31 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:31 --> URI Class Initialized
INFO - 2015-12-26 00:28:31 --> Router Class Initialized
INFO - 2015-12-26 00:28:31 --> Output Class Initialized
INFO - 2015-12-26 00:28:31 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:31 --> Input Class Initialized
INFO - 2015-12-26 00:28:31 --> Language Class Initialized
INFO - 2015-12-26 00:28:31 --> Loader Class Initialized
INFO - 2015-12-26 00:28:31 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:31 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:31 --> Controller Class Initialized
INFO - 2015-12-26 00:28:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 00:28:31 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:31 --> Total execution time: 0.0968
INFO - 2015-12-26 00:28:31 --> Config Class Initialized
INFO - 2015-12-26 00:28:31 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:31 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:31 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:31 --> URI Class Initialized
INFO - 2015-12-26 00:28:31 --> Router Class Initialized
INFO - 2015-12-26 00:28:31 --> Output Class Initialized
INFO - 2015-12-26 00:28:31 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:31 --> Input Class Initialized
INFO - 2015-12-26 00:28:31 --> Language Class Initialized
INFO - 2015-12-26 00:28:31 --> Loader Class Initialized
INFO - 2015-12-26 00:28:31 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:31 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:31 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:31 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:31 --> Model Class Initialized
INFO - 2015-12-26 00:28:31 --> Model Class Initialized
INFO - 2015-12-26 00:28:31 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:31 --> Total execution time: 0.0993
INFO - 2015-12-26 00:28:33 --> Config Class Initialized
INFO - 2015-12-26 00:28:33 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:33 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:33 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:33 --> URI Class Initialized
INFO - 2015-12-26 00:28:33 --> Router Class Initialized
INFO - 2015-12-26 00:28:33 --> Output Class Initialized
INFO - 2015-12-26 00:28:33 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:33 --> Input Class Initialized
INFO - 2015-12-26 00:28:33 --> Language Class Initialized
INFO - 2015-12-26 00:28:33 --> Loader Class Initialized
INFO - 2015-12-26 00:28:33 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:33 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:33 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:33 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:33 --> Model Class Initialized
INFO - 2015-12-26 00:28:33 --> Model Class Initialized
INFO - 2015-12-26 00:28:33 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:33 --> Total execution time: 0.1089
INFO - 2015-12-26 00:28:33 --> Config Class Initialized
INFO - 2015-12-26 00:28:33 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:33 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:33 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:33 --> URI Class Initialized
INFO - 2015-12-26 00:28:33 --> Router Class Initialized
INFO - 2015-12-26 00:28:33 --> Output Class Initialized
INFO - 2015-12-26 00:28:33 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:33 --> Input Class Initialized
INFO - 2015-12-26 00:28:33 --> Language Class Initialized
INFO - 2015-12-26 00:28:33 --> Loader Class Initialized
INFO - 2015-12-26 00:28:33 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:33 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:33 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:33 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:33 --> Model Class Initialized
INFO - 2015-12-26 00:28:33 --> Model Class Initialized
INFO - 2015-12-26 00:28:33 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:33 --> Total execution time: 0.1041
INFO - 2015-12-26 00:28:36 --> Config Class Initialized
INFO - 2015-12-26 00:28:36 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:36 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:36 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:36 --> URI Class Initialized
INFO - 2015-12-26 00:28:36 --> Router Class Initialized
INFO - 2015-12-26 00:28:36 --> Output Class Initialized
INFO - 2015-12-26 00:28:36 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:36 --> Input Class Initialized
INFO - 2015-12-26 00:28:36 --> Language Class Initialized
INFO - 2015-12-26 00:28:36 --> Loader Class Initialized
INFO - 2015-12-26 00:28:36 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:36 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:36 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:36 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:36 --> Model Class Initialized
INFO - 2015-12-26 00:28:36 --> Model Class Initialized
INFO - 2015-12-26 00:28:36 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:36 --> Total execution time: 0.1035
INFO - 2015-12-26 00:28:36 --> Config Class Initialized
INFO - 2015-12-26 00:28:36 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:36 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:36 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:36 --> URI Class Initialized
INFO - 2015-12-26 00:28:36 --> Router Class Initialized
INFO - 2015-12-26 00:28:36 --> Output Class Initialized
INFO - 2015-12-26 00:28:36 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:36 --> Input Class Initialized
INFO - 2015-12-26 00:28:36 --> Language Class Initialized
INFO - 2015-12-26 00:28:36 --> Loader Class Initialized
INFO - 2015-12-26 00:28:36 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:36 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:36 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:36 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:36 --> Model Class Initialized
INFO - 2015-12-26 00:28:36 --> Model Class Initialized
INFO - 2015-12-26 00:28:36 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:36 --> Total execution time: 0.1018
INFO - 2015-12-26 00:28:37 --> Config Class Initialized
INFO - 2015-12-26 00:28:37 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:37 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:37 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:37 --> URI Class Initialized
INFO - 2015-12-26 00:28:37 --> Router Class Initialized
INFO - 2015-12-26 00:28:37 --> Output Class Initialized
INFO - 2015-12-26 00:28:37 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:37 --> Input Class Initialized
INFO - 2015-12-26 00:28:37 --> Language Class Initialized
INFO - 2015-12-26 00:28:37 --> Loader Class Initialized
INFO - 2015-12-26 00:28:37 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:37 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:38 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:38 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:38 --> Model Class Initialized
INFO - 2015-12-26 00:28:38 --> Model Class Initialized
INFO - 2015-12-26 00:28:38 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:38 --> Total execution time: 0.1180
INFO - 2015-12-26 00:28:38 --> Config Class Initialized
INFO - 2015-12-26 00:28:38 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:38 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:38 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:38 --> URI Class Initialized
INFO - 2015-12-26 00:28:38 --> Router Class Initialized
INFO - 2015-12-26 00:28:38 --> Output Class Initialized
INFO - 2015-12-26 00:28:38 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:38 --> Input Class Initialized
INFO - 2015-12-26 00:28:38 --> Language Class Initialized
INFO - 2015-12-26 00:28:38 --> Loader Class Initialized
INFO - 2015-12-26 00:28:38 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:38 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:38 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:38 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:38 --> Model Class Initialized
INFO - 2015-12-26 00:28:38 --> Model Class Initialized
INFO - 2015-12-26 00:28:38 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:38 --> Total execution time: 0.1354
INFO - 2015-12-26 00:28:40 --> Config Class Initialized
INFO - 2015-12-26 00:28:40 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:40 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:40 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:40 --> URI Class Initialized
INFO - 2015-12-26 00:28:40 --> Router Class Initialized
INFO - 2015-12-26 00:28:40 --> Output Class Initialized
INFO - 2015-12-26 00:28:40 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:40 --> Input Class Initialized
INFO - 2015-12-26 00:28:40 --> Language Class Initialized
INFO - 2015-12-26 00:28:40 --> Loader Class Initialized
INFO - 2015-12-26 00:28:40 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:40 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:40 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:40 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:40 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:40 --> Model Class Initialized
INFO - 2015-12-26 00:28:40 --> Model Class Initialized
INFO - 2015-12-26 00:28:40 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:40 --> Total execution time: 0.1016
INFO - 2015-12-26 00:28:40 --> Config Class Initialized
INFO - 2015-12-26 00:28:40 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:40 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:40 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:40 --> URI Class Initialized
INFO - 2015-12-26 00:28:40 --> Router Class Initialized
INFO - 2015-12-26 00:28:40 --> Output Class Initialized
INFO - 2015-12-26 00:28:40 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:40 --> Input Class Initialized
INFO - 2015-12-26 00:28:40 --> Language Class Initialized
INFO - 2015-12-26 00:28:40 --> Loader Class Initialized
INFO - 2015-12-26 00:28:40 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:40 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:40 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:40 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:40 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:40 --> Model Class Initialized
INFO - 2015-12-26 00:28:40 --> Model Class Initialized
INFO - 2015-12-26 00:28:40 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:40 --> Total execution time: 0.1055
INFO - 2015-12-26 00:28:42 --> Config Class Initialized
INFO - 2015-12-26 00:28:42 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:42 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:42 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:42 --> URI Class Initialized
INFO - 2015-12-26 00:28:42 --> Router Class Initialized
INFO - 2015-12-26 00:28:42 --> Output Class Initialized
INFO - 2015-12-26 00:28:42 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:42 --> Input Class Initialized
INFO - 2015-12-26 00:28:42 --> Language Class Initialized
INFO - 2015-12-26 00:28:42 --> Loader Class Initialized
INFO - 2015-12-26 00:28:42 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:42 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:42 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:42 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:42 --> Model Class Initialized
INFO - 2015-12-26 00:28:42 --> Model Class Initialized
INFO - 2015-12-26 00:28:42 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:42 --> Total execution time: 0.1135
INFO - 2015-12-26 00:28:43 --> Config Class Initialized
INFO - 2015-12-26 00:28:43 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:43 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:43 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:43 --> URI Class Initialized
INFO - 2015-12-26 00:28:43 --> Router Class Initialized
INFO - 2015-12-26 00:28:43 --> Output Class Initialized
INFO - 2015-12-26 00:28:43 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:43 --> Input Class Initialized
INFO - 2015-12-26 00:28:43 --> Language Class Initialized
INFO - 2015-12-26 00:28:43 --> Loader Class Initialized
INFO - 2015-12-26 00:28:43 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:43 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:43 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:43 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:43 --> Model Class Initialized
INFO - 2015-12-26 00:28:43 --> Model Class Initialized
INFO - 2015-12-26 00:28:43 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:43 --> Total execution time: 0.1008
INFO - 2015-12-26 00:28:46 --> Config Class Initialized
INFO - 2015-12-26 00:28:46 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:46 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:46 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:46 --> URI Class Initialized
INFO - 2015-12-26 00:28:46 --> Router Class Initialized
INFO - 2015-12-26 00:28:46 --> Output Class Initialized
INFO - 2015-12-26 00:28:46 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:46 --> Input Class Initialized
INFO - 2015-12-26 00:28:46 --> Language Class Initialized
INFO - 2015-12-26 00:28:46 --> Loader Class Initialized
INFO - 2015-12-26 00:28:46 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:46 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:46 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:46 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:46 --> Model Class Initialized
INFO - 2015-12-26 00:28:46 --> Model Class Initialized
INFO - 2015-12-26 00:28:46 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:46 --> Total execution time: 0.1495
INFO - 2015-12-26 00:28:47 --> Config Class Initialized
INFO - 2015-12-26 00:28:47 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:47 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:47 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:47 --> URI Class Initialized
INFO - 2015-12-26 00:28:47 --> Router Class Initialized
INFO - 2015-12-26 00:28:47 --> Output Class Initialized
INFO - 2015-12-26 00:28:47 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:47 --> Input Class Initialized
INFO - 2015-12-26 00:28:47 --> Language Class Initialized
INFO - 2015-12-26 00:28:47 --> Loader Class Initialized
INFO - 2015-12-26 00:28:47 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:47 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:47 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:47 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:47 --> Model Class Initialized
INFO - 2015-12-26 00:28:47 --> Model Class Initialized
INFO - 2015-12-26 00:28:47 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:47 --> Total execution time: 0.2651
INFO - 2015-12-26 00:28:48 --> Config Class Initialized
INFO - 2015-12-26 00:28:48 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:48 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:48 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:48 --> URI Class Initialized
INFO - 2015-12-26 00:28:48 --> Router Class Initialized
INFO - 2015-12-26 00:28:48 --> Output Class Initialized
INFO - 2015-12-26 00:28:48 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:48 --> Input Class Initialized
INFO - 2015-12-26 00:28:48 --> Language Class Initialized
INFO - 2015-12-26 00:28:48 --> Loader Class Initialized
INFO - 2015-12-26 00:28:48 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:48 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:48 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:48 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:48 --> Model Class Initialized
INFO - 2015-12-26 00:28:48 --> Model Class Initialized
INFO - 2015-12-26 00:28:49 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:49 --> Total execution time: 0.1202
INFO - 2015-12-26 00:28:49 --> Config Class Initialized
INFO - 2015-12-26 00:28:49 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:49 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:49 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:49 --> URI Class Initialized
INFO - 2015-12-26 00:28:49 --> Router Class Initialized
INFO - 2015-12-26 00:28:49 --> Output Class Initialized
INFO - 2015-12-26 00:28:49 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:49 --> Input Class Initialized
INFO - 2015-12-26 00:28:49 --> Language Class Initialized
INFO - 2015-12-26 00:28:49 --> Loader Class Initialized
INFO - 2015-12-26 00:28:49 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:49 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:49 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:49 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:49 --> Model Class Initialized
INFO - 2015-12-26 00:28:49 --> Model Class Initialized
INFO - 2015-12-26 00:28:49 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:49 --> Total execution time: 0.1135
INFO - 2015-12-26 00:28:51 --> Config Class Initialized
INFO - 2015-12-26 00:28:51 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:51 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:51 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:51 --> URI Class Initialized
INFO - 2015-12-26 00:28:51 --> Router Class Initialized
INFO - 2015-12-26 00:28:51 --> Output Class Initialized
INFO - 2015-12-26 00:28:51 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:51 --> Input Class Initialized
INFO - 2015-12-26 00:28:51 --> Language Class Initialized
INFO - 2015-12-26 00:28:51 --> Loader Class Initialized
INFO - 2015-12-26 00:28:51 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:51 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:51 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:51 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:51 --> Model Class Initialized
INFO - 2015-12-26 00:28:51 --> Model Class Initialized
INFO - 2015-12-26 00:28:51 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:51 --> Total execution time: 0.1019
INFO - 2015-12-26 00:28:51 --> Config Class Initialized
INFO - 2015-12-26 00:28:51 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:51 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:51 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:51 --> URI Class Initialized
INFO - 2015-12-26 00:28:51 --> Router Class Initialized
INFO - 2015-12-26 00:28:51 --> Output Class Initialized
INFO - 2015-12-26 00:28:51 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:51 --> Input Class Initialized
INFO - 2015-12-26 00:28:51 --> Language Class Initialized
INFO - 2015-12-26 00:28:51 --> Loader Class Initialized
INFO - 2015-12-26 00:28:51 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:51 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:51 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:51 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:51 --> Model Class Initialized
INFO - 2015-12-26 00:28:51 --> Model Class Initialized
INFO - 2015-12-26 00:28:51 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:51 --> Total execution time: 0.1435
INFO - 2015-12-26 00:28:53 --> Config Class Initialized
INFO - 2015-12-26 00:28:53 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:53 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:53 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:53 --> URI Class Initialized
INFO - 2015-12-26 00:28:53 --> Router Class Initialized
INFO - 2015-12-26 00:28:53 --> Output Class Initialized
INFO - 2015-12-26 00:28:53 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:53 --> Input Class Initialized
INFO - 2015-12-26 00:28:53 --> Language Class Initialized
INFO - 2015-12-26 00:28:53 --> Loader Class Initialized
INFO - 2015-12-26 00:28:53 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:53 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:53 --> Controller Class Initialized
INFO - 2015-12-26 00:28:53 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 00:28:53 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:53 --> Total execution time: 0.1174
INFO - 2015-12-26 00:28:54 --> Config Class Initialized
INFO - 2015-12-26 00:28:54 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:54 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:54 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:54 --> URI Class Initialized
INFO - 2015-12-26 00:28:54 --> Router Class Initialized
INFO - 2015-12-26 00:28:54 --> Output Class Initialized
INFO - 2015-12-26 00:28:54 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:54 --> Input Class Initialized
INFO - 2015-12-26 00:28:54 --> Language Class Initialized
INFO - 2015-12-26 00:28:54 --> Loader Class Initialized
INFO - 2015-12-26 00:28:54 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:54 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:54 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:54 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:54 --> Model Class Initialized
INFO - 2015-12-26 00:28:54 --> Model Class Initialized
INFO - 2015-12-26 00:28:54 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:54 --> Total execution time: 0.1478
INFO - 2015-12-26 00:28:55 --> Config Class Initialized
INFO - 2015-12-26 00:28:55 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:55 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:55 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:55 --> URI Class Initialized
INFO - 2015-12-26 00:28:55 --> Router Class Initialized
INFO - 2015-12-26 00:28:55 --> Output Class Initialized
INFO - 2015-12-26 00:28:55 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:55 --> Input Class Initialized
INFO - 2015-12-26 00:28:55 --> Language Class Initialized
INFO - 2015-12-26 00:28:55 --> Loader Class Initialized
INFO - 2015-12-26 00:28:55 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:55 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:55 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:55 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:55 --> Model Class Initialized
INFO - 2015-12-26 00:28:55 --> Model Class Initialized
INFO - 2015-12-26 00:28:55 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:55 --> Total execution time: 0.1526
INFO - 2015-12-26 00:28:56 --> Config Class Initialized
INFO - 2015-12-26 00:28:56 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:56 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:56 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:56 --> URI Class Initialized
INFO - 2015-12-26 00:28:56 --> Router Class Initialized
INFO - 2015-12-26 00:28:56 --> Output Class Initialized
INFO - 2015-12-26 00:28:56 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:56 --> Input Class Initialized
INFO - 2015-12-26 00:28:56 --> Language Class Initialized
INFO - 2015-12-26 00:28:56 --> Loader Class Initialized
INFO - 2015-12-26 00:28:56 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:56 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:56 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:56 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:56 --> Model Class Initialized
INFO - 2015-12-26 00:28:56 --> Model Class Initialized
INFO - 2015-12-26 00:28:56 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:56 --> Total execution time: 0.1716
INFO - 2015-12-26 00:28:57 --> Config Class Initialized
INFO - 2015-12-26 00:28:57 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:57 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:57 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:57 --> URI Class Initialized
INFO - 2015-12-26 00:28:57 --> Router Class Initialized
INFO - 2015-12-26 00:28:57 --> Output Class Initialized
INFO - 2015-12-26 00:28:57 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:57 --> Input Class Initialized
INFO - 2015-12-26 00:28:57 --> Language Class Initialized
INFO - 2015-12-26 00:28:57 --> Loader Class Initialized
INFO - 2015-12-26 00:28:57 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:57 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:57 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:57 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:57 --> Model Class Initialized
INFO - 2015-12-26 00:28:57 --> Model Class Initialized
INFO - 2015-12-26 00:28:57 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:57 --> Total execution time: 0.1054
INFO - 2015-12-26 00:28:58 --> Config Class Initialized
INFO - 2015-12-26 00:28:58 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:28:58 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:28:58 --> Utf8 Class Initialized
INFO - 2015-12-26 00:28:58 --> URI Class Initialized
INFO - 2015-12-26 00:28:58 --> Router Class Initialized
INFO - 2015-12-26 00:28:58 --> Output Class Initialized
INFO - 2015-12-26 00:28:58 --> Security Class Initialized
DEBUG - 2015-12-26 00:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:28:58 --> Input Class Initialized
INFO - 2015-12-26 00:28:58 --> Language Class Initialized
INFO - 2015-12-26 00:28:58 --> Loader Class Initialized
INFO - 2015-12-26 00:28:58 --> Helper loaded: url_helper
INFO - 2015-12-26 00:28:58 --> Database Driver Class Initialized
INFO - 2015-12-26 00:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:28:58 --> Controller Class Initialized
DEBUG - 2015-12-26 00:28:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:28:58 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:28:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:28:58 --> Model Class Initialized
INFO - 2015-12-26 00:28:58 --> Model Class Initialized
INFO - 2015-12-26 00:28:58 --> Final output sent to browser
DEBUG - 2015-12-26 00:28:58 --> Total execution time: 0.1032
INFO - 2015-12-26 00:29:01 --> Config Class Initialized
INFO - 2015-12-26 00:29:01 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:01 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:01 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:01 --> URI Class Initialized
INFO - 2015-12-26 00:29:01 --> Router Class Initialized
INFO - 2015-12-26 00:29:01 --> Output Class Initialized
INFO - 2015-12-26 00:29:01 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:01 --> Input Class Initialized
INFO - 2015-12-26 00:29:01 --> Language Class Initialized
INFO - 2015-12-26 00:29:01 --> Loader Class Initialized
INFO - 2015-12-26 00:29:01 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:01 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:01 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:01 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:01 --> Model Class Initialized
INFO - 2015-12-26 00:29:01 --> Model Class Initialized
INFO - 2015-12-26 00:29:01 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:01 --> Total execution time: 0.1027
INFO - 2015-12-26 00:29:02 --> Config Class Initialized
INFO - 2015-12-26 00:29:02 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:02 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:02 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:02 --> URI Class Initialized
INFO - 2015-12-26 00:29:02 --> Router Class Initialized
INFO - 2015-12-26 00:29:02 --> Output Class Initialized
INFO - 2015-12-26 00:29:02 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:02 --> Input Class Initialized
INFO - 2015-12-26 00:29:02 --> Language Class Initialized
INFO - 2015-12-26 00:29:02 --> Loader Class Initialized
INFO - 2015-12-26 00:29:02 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:02 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:02 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:02 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:02 --> Model Class Initialized
INFO - 2015-12-26 00:29:02 --> Model Class Initialized
INFO - 2015-12-26 00:29:02 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:02 --> Total execution time: 0.1010
INFO - 2015-12-26 00:29:06 --> Config Class Initialized
INFO - 2015-12-26 00:29:06 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:06 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:06 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:06 --> URI Class Initialized
INFO - 2015-12-26 00:29:06 --> Router Class Initialized
INFO - 2015-12-26 00:29:06 --> Output Class Initialized
INFO - 2015-12-26 00:29:06 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:06 --> Input Class Initialized
INFO - 2015-12-26 00:29:06 --> Language Class Initialized
INFO - 2015-12-26 00:29:06 --> Loader Class Initialized
INFO - 2015-12-26 00:29:06 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:06 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:06 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:06 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:06 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:06 --> Model Class Initialized
INFO - 2015-12-26 00:29:06 --> Model Class Initialized
INFO - 2015-12-26 00:29:06 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:06 --> Total execution time: 0.0983
INFO - 2015-12-26 00:29:07 --> Config Class Initialized
INFO - 2015-12-26 00:29:07 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:07 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:07 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:07 --> URI Class Initialized
INFO - 2015-12-26 00:29:07 --> Router Class Initialized
INFO - 2015-12-26 00:29:07 --> Output Class Initialized
INFO - 2015-12-26 00:29:07 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:07 --> Input Class Initialized
INFO - 2015-12-26 00:29:07 --> Language Class Initialized
INFO - 2015-12-26 00:29:07 --> Loader Class Initialized
INFO - 2015-12-26 00:29:07 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:07 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:07 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:07 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:07 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:07 --> Model Class Initialized
INFO - 2015-12-26 00:29:07 --> Model Class Initialized
INFO - 2015-12-26 00:29:07 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:07 --> Total execution time: 0.1948
INFO - 2015-12-26 00:29:12 --> Config Class Initialized
INFO - 2015-12-26 00:29:12 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:12 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:12 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:12 --> URI Class Initialized
INFO - 2015-12-26 00:29:12 --> Router Class Initialized
INFO - 2015-12-26 00:29:12 --> Output Class Initialized
INFO - 2015-12-26 00:29:12 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:12 --> Input Class Initialized
INFO - 2015-12-26 00:29:12 --> Language Class Initialized
INFO - 2015-12-26 00:29:13 --> Loader Class Initialized
INFO - 2015-12-26 00:29:13 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:13 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:13 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:13 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:13 --> Model Class Initialized
INFO - 2015-12-26 00:29:13 --> Model Class Initialized
INFO - 2015-12-26 00:29:13 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:13 --> Total execution time: 0.1081
INFO - 2015-12-26 00:29:13 --> Config Class Initialized
INFO - 2015-12-26 00:29:13 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:13 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:13 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:13 --> URI Class Initialized
INFO - 2015-12-26 00:29:13 --> Router Class Initialized
INFO - 2015-12-26 00:29:13 --> Output Class Initialized
INFO - 2015-12-26 00:29:13 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:13 --> Input Class Initialized
INFO - 2015-12-26 00:29:13 --> Language Class Initialized
INFO - 2015-12-26 00:29:13 --> Loader Class Initialized
INFO - 2015-12-26 00:29:13 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:13 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:13 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:13 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:13 --> Model Class Initialized
INFO - 2015-12-26 00:29:13 --> Model Class Initialized
INFO - 2015-12-26 00:29:13 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:13 --> Total execution time: 0.1022
INFO - 2015-12-26 00:29:15 --> Config Class Initialized
INFO - 2015-12-26 00:29:15 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:15 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:15 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:15 --> URI Class Initialized
INFO - 2015-12-26 00:29:15 --> Router Class Initialized
INFO - 2015-12-26 00:29:15 --> Output Class Initialized
INFO - 2015-12-26 00:29:15 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:15 --> Input Class Initialized
INFO - 2015-12-26 00:29:15 --> Language Class Initialized
INFO - 2015-12-26 00:29:15 --> Loader Class Initialized
INFO - 2015-12-26 00:29:15 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:15 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:15 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:15 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:15 --> Model Class Initialized
INFO - 2015-12-26 00:29:15 --> Model Class Initialized
INFO - 2015-12-26 00:29:15 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:15 --> Total execution time: 0.1008
INFO - 2015-12-26 00:29:16 --> Config Class Initialized
INFO - 2015-12-26 00:29:16 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:16 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:16 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:16 --> URI Class Initialized
INFO - 2015-12-26 00:29:16 --> Router Class Initialized
INFO - 2015-12-26 00:29:16 --> Output Class Initialized
INFO - 2015-12-26 00:29:16 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:16 --> Input Class Initialized
INFO - 2015-12-26 00:29:16 --> Language Class Initialized
INFO - 2015-12-26 00:29:16 --> Loader Class Initialized
INFO - 2015-12-26 00:29:16 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:16 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:16 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:16 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:16 --> Model Class Initialized
INFO - 2015-12-26 00:29:16 --> Model Class Initialized
INFO - 2015-12-26 00:29:16 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:16 --> Total execution time: 0.0994
INFO - 2015-12-26 00:29:17 --> Config Class Initialized
INFO - 2015-12-26 00:29:17 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:17 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:17 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:17 --> URI Class Initialized
INFO - 2015-12-26 00:29:17 --> Router Class Initialized
INFO - 2015-12-26 00:29:17 --> Output Class Initialized
INFO - 2015-12-26 00:29:17 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:17 --> Input Class Initialized
INFO - 2015-12-26 00:29:17 --> Language Class Initialized
INFO - 2015-12-26 00:29:18 --> Loader Class Initialized
INFO - 2015-12-26 00:29:18 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:18 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:18 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:18 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:18 --> Model Class Initialized
INFO - 2015-12-26 00:29:18 --> Model Class Initialized
INFO - 2015-12-26 00:29:18 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:18 --> Total execution time: 0.1043
INFO - 2015-12-26 00:29:18 --> Config Class Initialized
INFO - 2015-12-26 00:29:18 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:18 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:18 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:18 --> URI Class Initialized
INFO - 2015-12-26 00:29:18 --> Router Class Initialized
INFO - 2015-12-26 00:29:18 --> Output Class Initialized
INFO - 2015-12-26 00:29:18 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:18 --> Input Class Initialized
INFO - 2015-12-26 00:29:18 --> Language Class Initialized
INFO - 2015-12-26 00:29:18 --> Loader Class Initialized
INFO - 2015-12-26 00:29:18 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:18 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:18 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:18 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:18 --> Model Class Initialized
INFO - 2015-12-26 00:29:18 --> Model Class Initialized
INFO - 2015-12-26 00:29:18 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:18 --> Total execution time: 0.1027
INFO - 2015-12-26 00:29:20 --> Config Class Initialized
INFO - 2015-12-26 00:29:20 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:20 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:20 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:20 --> URI Class Initialized
INFO - 2015-12-26 00:29:20 --> Router Class Initialized
INFO - 2015-12-26 00:29:20 --> Output Class Initialized
INFO - 2015-12-26 00:29:20 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:20 --> Input Class Initialized
INFO - 2015-12-26 00:29:20 --> Language Class Initialized
INFO - 2015-12-26 00:29:20 --> Loader Class Initialized
INFO - 2015-12-26 00:29:20 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:20 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:20 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:20 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:20 --> Model Class Initialized
INFO - 2015-12-26 00:29:20 --> Model Class Initialized
INFO - 2015-12-26 00:29:20 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:20 --> Total execution time: 0.1032
INFO - 2015-12-26 00:29:20 --> Config Class Initialized
INFO - 2015-12-26 00:29:20 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:20 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:20 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:20 --> URI Class Initialized
INFO - 2015-12-26 00:29:20 --> Router Class Initialized
INFO - 2015-12-26 00:29:20 --> Output Class Initialized
INFO - 2015-12-26 00:29:20 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:20 --> Input Class Initialized
INFO - 2015-12-26 00:29:20 --> Language Class Initialized
INFO - 2015-12-26 00:29:20 --> Loader Class Initialized
INFO - 2015-12-26 00:29:20 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:20 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:20 --> Controller Class Initialized
DEBUG - 2015-12-26 00:29:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:29:20 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:29:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:29:20 --> Model Class Initialized
INFO - 2015-12-26 00:29:20 --> Model Class Initialized
INFO - 2015-12-26 00:29:20 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:20 --> Total execution time: 0.1156
INFO - 2015-12-26 00:29:24 --> Config Class Initialized
INFO - 2015-12-26 00:29:24 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:29:24 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:29:24 --> Utf8 Class Initialized
INFO - 2015-12-26 00:29:24 --> URI Class Initialized
DEBUG - 2015-12-26 00:29:24 --> No URI present. Default controller set.
INFO - 2015-12-26 00:29:24 --> Router Class Initialized
INFO - 2015-12-26 00:29:24 --> Output Class Initialized
INFO - 2015-12-26 00:29:24 --> Security Class Initialized
DEBUG - 2015-12-26 00:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:29:24 --> Input Class Initialized
INFO - 2015-12-26 00:29:24 --> Language Class Initialized
INFO - 2015-12-26 00:29:24 --> Loader Class Initialized
INFO - 2015-12-26 00:29:24 --> Helper loaded: url_helper
INFO - 2015-12-26 00:29:24 --> Database Driver Class Initialized
INFO - 2015-12-26 00:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:29:24 --> Controller Class Initialized
INFO - 2015-12-26 00:29:24 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 00:29:24 --> Final output sent to browser
DEBUG - 2015-12-26 00:29:24 --> Total execution time: 0.1377
INFO - 2015-12-26 00:30:10 --> Config Class Initialized
INFO - 2015-12-26 00:30:10 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:30:10 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:30:10 --> Utf8 Class Initialized
INFO - 2015-12-26 00:30:10 --> URI Class Initialized
INFO - 2015-12-26 00:30:10 --> Router Class Initialized
INFO - 2015-12-26 00:30:10 --> Output Class Initialized
INFO - 2015-12-26 00:30:10 --> Security Class Initialized
DEBUG - 2015-12-26 00:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:30:10 --> Input Class Initialized
INFO - 2015-12-26 00:30:10 --> Language Class Initialized
INFO - 2015-12-26 00:30:10 --> Loader Class Initialized
INFO - 2015-12-26 00:30:10 --> Helper loaded: url_helper
INFO - 2015-12-26 00:30:10 --> Database Driver Class Initialized
INFO - 2015-12-26 00:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:30:10 --> Controller Class Initialized
INFO - 2015-12-26 00:30:10 --> Helper loaded: form_helper
INFO - 2015-12-26 00:30:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 00:30:10 --> Final output sent to browser
DEBUG - 2015-12-26 00:30:10 --> Total execution time: 0.1598
INFO - 2015-12-26 00:30:21 --> Config Class Initialized
INFO - 2015-12-26 00:30:21 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:30:21 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:30:21 --> Utf8 Class Initialized
INFO - 2015-12-26 00:30:21 --> URI Class Initialized
INFO - 2015-12-26 00:30:21 --> Router Class Initialized
INFO - 2015-12-26 00:30:21 --> Output Class Initialized
INFO - 2015-12-26 00:30:21 --> Security Class Initialized
DEBUG - 2015-12-26 00:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:30:21 --> Input Class Initialized
INFO - 2015-12-26 00:30:21 --> Language Class Initialized
INFO - 2015-12-26 00:30:21 --> Loader Class Initialized
INFO - 2015-12-26 00:30:21 --> Helper loaded: url_helper
INFO - 2015-12-26 00:30:21 --> Database Driver Class Initialized
INFO - 2015-12-26 00:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:30:21 --> Controller Class Initialized
INFO - 2015-12-26 00:30:21 --> Model Class Initialized
INFO - 2015-12-26 00:30:21 --> Model Class Initialized
INFO - 2015-12-26 00:30:21 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 00:30:21 --> Final output sent to browser
DEBUG - 2015-12-26 00:30:21 --> Total execution time: 0.1117
INFO - 2015-12-26 00:30:26 --> Config Class Initialized
INFO - 2015-12-26 00:30:26 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:30:26 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:30:27 --> Utf8 Class Initialized
INFO - 2015-12-26 00:30:27 --> URI Class Initialized
INFO - 2015-12-26 00:30:27 --> Router Class Initialized
INFO - 2015-12-26 00:30:27 --> Output Class Initialized
INFO - 2015-12-26 00:30:27 --> Security Class Initialized
DEBUG - 2015-12-26 00:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:30:27 --> Input Class Initialized
INFO - 2015-12-26 00:30:27 --> Language Class Initialized
INFO - 2015-12-26 00:30:27 --> Loader Class Initialized
INFO - 2015-12-26 00:30:27 --> Helper loaded: url_helper
INFO - 2015-12-26 00:30:27 --> Database Driver Class Initialized
INFO - 2015-12-26 00:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:30:27 --> Controller Class Initialized
INFO - 2015-12-26 00:30:27 --> Model Class Initialized
INFO - 2015-12-26 00:30:27 --> Model Class Initialized
INFO - 2015-12-26 00:30:27 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 00:30:27 --> Final output sent to browser
DEBUG - 2015-12-26 00:30:27 --> Total execution time: 0.1008
INFO - 2015-12-26 00:30:27 --> Config Class Initialized
INFO - 2015-12-26 00:30:27 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:30:27 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:30:27 --> Utf8 Class Initialized
INFO - 2015-12-26 00:30:27 --> URI Class Initialized
INFO - 2015-12-26 00:30:27 --> Router Class Initialized
INFO - 2015-12-26 00:30:27 --> Output Class Initialized
INFO - 2015-12-26 00:30:27 --> Security Class Initialized
DEBUG - 2015-12-26 00:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:30:27 --> Input Class Initialized
INFO - 2015-12-26 00:30:27 --> Language Class Initialized
INFO - 2015-12-26 00:30:27 --> Loader Class Initialized
INFO - 2015-12-26 00:30:27 --> Helper loaded: url_helper
INFO - 2015-12-26 00:30:27 --> Database Driver Class Initialized
INFO - 2015-12-26 00:30:27 --> Config Class Initialized
INFO - 2015-12-26 00:30:27 --> Hooks Class Initialized
INFO - 2015-12-26 00:30:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2015-12-26 00:30:27 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:30:27 --> Controller Class Initialized
INFO - 2015-12-26 00:30:27 --> Utf8 Class Initialized
INFO - 2015-12-26 00:30:27 --> Model Class Initialized
INFO - 2015-12-26 00:30:27 --> URI Class Initialized
INFO - 2015-12-26 00:30:27 --> Model Class Initialized
INFO - 2015-12-26 00:30:27 --> Router Class Initialized
INFO - 2015-12-26 00:30:27 --> Output Class Initialized
INFO - 2015-12-26 00:30:27 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 00:30:27 --> Security Class Initialized
INFO - 2015-12-26 00:30:27 --> Final output sent to browser
DEBUG - 2015-12-26 00:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-12-26 00:30:27 --> Total execution time: 0.1183
INFO - 2015-12-26 00:30:27 --> Input Class Initialized
INFO - 2015-12-26 00:30:27 --> Language Class Initialized
INFO - 2015-12-26 00:30:27 --> Loader Class Initialized
INFO - 2015-12-26 00:30:27 --> Helper loaded: url_helper
INFO - 2015-12-26 00:30:27 --> Database Driver Class Initialized
INFO - 2015-12-26 00:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:30:27 --> Controller Class Initialized
DEBUG - 2015-12-26 00:30:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:30:27 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:30:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:30:27 --> Model Class Initialized
INFO - 2015-12-26 00:30:27 --> Model Class Initialized
INFO - 2015-12-26 00:30:27 --> Final output sent to browser
DEBUG - 2015-12-26 00:30:27 --> Total execution time: 0.1390
INFO - 2015-12-26 00:30:31 --> Config Class Initialized
INFO - 2015-12-26 00:30:31 --> Hooks Class Initialized
DEBUG - 2015-12-26 00:30:31 --> UTF-8 Support Enabled
INFO - 2015-12-26 00:30:31 --> Utf8 Class Initialized
INFO - 2015-12-26 00:30:31 --> URI Class Initialized
INFO - 2015-12-26 00:30:31 --> Router Class Initialized
INFO - 2015-12-26 00:30:31 --> Output Class Initialized
INFO - 2015-12-26 00:30:31 --> Security Class Initialized
DEBUG - 2015-12-26 00:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 00:30:31 --> Input Class Initialized
INFO - 2015-12-26 00:30:31 --> Language Class Initialized
INFO - 2015-12-26 00:30:31 --> Loader Class Initialized
INFO - 2015-12-26 00:30:31 --> Helper loaded: url_helper
INFO - 2015-12-26 00:30:31 --> Database Driver Class Initialized
INFO - 2015-12-26 00:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 00:30:31 --> Controller Class Initialized
DEBUG - 2015-12-26 00:30:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 00:30:31 --> Helper loaded: inflector_helper
INFO - 2015-12-26 00:30:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 00:30:31 --> Model Class Initialized
INFO - 2015-12-26 00:30:31 --> Model Class Initialized
INFO - 2015-12-26 00:30:31 --> Final output sent to browser
DEBUG - 2015-12-26 00:30:31 --> Total execution time: 0.1530
INFO - 2015-12-26 01:00:09 --> Config Class Initialized
INFO - 2015-12-26 01:00:09 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:00:09 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:00:09 --> Utf8 Class Initialized
INFO - 2015-12-26 01:00:09 --> URI Class Initialized
INFO - 2015-12-26 01:00:09 --> Router Class Initialized
INFO - 2015-12-26 01:00:09 --> Output Class Initialized
INFO - 2015-12-26 01:00:09 --> Security Class Initialized
DEBUG - 2015-12-26 01:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:00:09 --> Input Class Initialized
INFO - 2015-12-26 01:00:09 --> Language Class Initialized
INFO - 2015-12-26 01:00:10 --> Loader Class Initialized
INFO - 2015-12-26 01:00:10 --> Helper loaded: url_helper
INFO - 2015-12-26 01:00:10 --> Database Driver Class Initialized
INFO - 2015-12-26 01:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:00:10 --> Controller Class Initialized
INFO - 2015-12-26 01:00:10 --> Model Class Initialized
INFO - 2015-12-26 01:00:10 --> Model Class Initialized
INFO - 2015-12-26 01:00:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:00:10 --> Final output sent to browser
DEBUG - 2015-12-26 01:00:10 --> Total execution time: 0.2145
INFO - 2015-12-26 01:00:10 --> Config Class Initialized
INFO - 2015-12-26 01:00:10 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:00:10 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:00:10 --> Utf8 Class Initialized
INFO - 2015-12-26 01:00:10 --> URI Class Initialized
INFO - 2015-12-26 01:00:10 --> Router Class Initialized
INFO - 2015-12-26 01:00:10 --> Output Class Initialized
INFO - 2015-12-26 01:00:10 --> Security Class Initialized
DEBUG - 2015-12-26 01:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:00:10 --> Input Class Initialized
INFO - 2015-12-26 01:00:10 --> Language Class Initialized
INFO - 2015-12-26 01:00:10 --> Loader Class Initialized
INFO - 2015-12-26 01:00:10 --> Helper loaded: url_helper
INFO - 2015-12-26 01:00:10 --> Database Driver Class Initialized
INFO - 2015-12-26 01:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:00:10 --> Controller Class Initialized
INFO - 2015-12-26 01:00:10 --> Model Class Initialized
INFO - 2015-12-26 01:00:10 --> Model Class Initialized
INFO - 2015-12-26 01:00:10 --> Config Class Initialized
INFO - 2015-12-26 01:00:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:00:10 --> Hooks Class Initialized
INFO - 2015-12-26 01:00:10 --> Final output sent to browser
DEBUG - 2015-12-26 01:00:10 --> Total execution time: 0.1168
DEBUG - 2015-12-26 01:00:10 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:00:10 --> Utf8 Class Initialized
INFO - 2015-12-26 01:00:10 --> URI Class Initialized
INFO - 2015-12-26 01:00:10 --> Router Class Initialized
INFO - 2015-12-26 01:00:10 --> Output Class Initialized
INFO - 2015-12-26 01:00:10 --> Security Class Initialized
DEBUG - 2015-12-26 01:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:00:10 --> Input Class Initialized
INFO - 2015-12-26 01:00:10 --> Language Class Initialized
INFO - 2015-12-26 01:00:10 --> Loader Class Initialized
INFO - 2015-12-26 01:00:10 --> Helper loaded: url_helper
INFO - 2015-12-26 01:00:10 --> Database Driver Class Initialized
INFO - 2015-12-26 01:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:00:10 --> Controller Class Initialized
DEBUG - 2015-12-26 01:00:10 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 01:00:10 --> Helper loaded: inflector_helper
INFO - 2015-12-26 01:00:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 01:00:10 --> Model Class Initialized
INFO - 2015-12-26 01:00:10 --> Model Class Initialized
INFO - 2015-12-26 01:00:10 --> Final output sent to browser
DEBUG - 2015-12-26 01:00:10 --> Total execution time: 0.1578
INFO - 2015-12-26 01:00:21 --> Config Class Initialized
INFO - 2015-12-26 01:00:21 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:00:21 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:00:21 --> Utf8 Class Initialized
INFO - 2015-12-26 01:00:21 --> URI Class Initialized
INFO - 2015-12-26 01:00:21 --> Router Class Initialized
INFO - 2015-12-26 01:00:21 --> Output Class Initialized
INFO - 2015-12-26 01:00:21 --> Security Class Initialized
DEBUG - 2015-12-26 01:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:00:21 --> Input Class Initialized
INFO - 2015-12-26 01:00:21 --> Language Class Initialized
INFO - 2015-12-26 01:00:21 --> Loader Class Initialized
INFO - 2015-12-26 01:00:21 --> Helper loaded: url_helper
INFO - 2015-12-26 01:00:21 --> Database Driver Class Initialized
INFO - 2015-12-26 01:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:00:21 --> Controller Class Initialized
INFO - 2015-12-26 01:00:21 --> Config Class Initialized
INFO - 2015-12-26 01:00:21 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:00:21 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:00:22 --> Utf8 Class Initialized
INFO - 2015-12-26 01:00:22 --> URI Class Initialized
INFO - 2015-12-26 01:00:22 --> Router Class Initialized
INFO - 2015-12-26 01:00:22 --> Output Class Initialized
INFO - 2015-12-26 01:00:22 --> Security Class Initialized
DEBUG - 2015-12-26 01:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:00:22 --> Input Class Initialized
INFO - 2015-12-26 01:00:22 --> Language Class Initialized
INFO - 2015-12-26 01:00:22 --> Loader Class Initialized
INFO - 2015-12-26 01:00:22 --> Helper loaded: url_helper
INFO - 2015-12-26 01:00:22 --> Database Driver Class Initialized
INFO - 2015-12-26 01:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:00:22 --> Controller Class Initialized
INFO - 2015-12-26 01:00:22 --> Helper loaded: form_helper
INFO - 2015-12-26 01:00:22 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 01:00:22 --> Final output sent to browser
DEBUG - 2015-12-26 01:00:22 --> Total execution time: 0.0870
INFO - 2015-12-26 01:00:41 --> Config Class Initialized
INFO - 2015-12-26 01:00:41 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:00:41 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:00:41 --> Utf8 Class Initialized
INFO - 2015-12-26 01:00:41 --> URI Class Initialized
INFO - 2015-12-26 01:00:41 --> Router Class Initialized
INFO - 2015-12-26 01:00:41 --> Output Class Initialized
INFO - 2015-12-26 01:00:41 --> Security Class Initialized
DEBUG - 2015-12-26 01:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:00:41 --> Input Class Initialized
INFO - 2015-12-26 01:00:41 --> Language Class Initialized
INFO - 2015-12-26 01:00:41 --> Loader Class Initialized
INFO - 2015-12-26 01:00:41 --> Helper loaded: url_helper
INFO - 2015-12-26 01:00:41 --> Database Driver Class Initialized
INFO - 2015-12-26 01:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:00:41 --> Controller Class Initialized
INFO - 2015-12-26 01:00:41 --> Helper loaded: form_helper
INFO - 2015-12-26 01:00:41 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 01:00:41 --> Final output sent to browser
DEBUG - 2015-12-26 01:00:41 --> Total execution time: 0.1766
INFO - 2015-12-26 01:00:46 --> Config Class Initialized
INFO - 2015-12-26 01:00:46 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:00:46 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:00:46 --> Utf8 Class Initialized
INFO - 2015-12-26 01:00:46 --> URI Class Initialized
INFO - 2015-12-26 01:00:46 --> Router Class Initialized
INFO - 2015-12-26 01:00:46 --> Output Class Initialized
INFO - 2015-12-26 01:00:46 --> Security Class Initialized
DEBUG - 2015-12-26 01:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:00:46 --> Input Class Initialized
INFO - 2015-12-26 01:00:46 --> Language Class Initialized
INFO - 2015-12-26 01:00:46 --> Loader Class Initialized
INFO - 2015-12-26 01:00:46 --> Helper loaded: url_helper
INFO - 2015-12-26 01:00:46 --> Database Driver Class Initialized
INFO - 2015-12-26 01:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:00:46 --> Controller Class Initialized
INFO - 2015-12-26 01:00:46 --> Model Class Initialized
INFO - 2015-12-26 01:00:46 --> Model Class Initialized
INFO - 2015-12-26 01:00:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:00:46 --> Final output sent to browser
DEBUG - 2015-12-26 01:00:46 --> Total execution time: 0.1270
INFO - 2015-12-26 01:00:46 --> Config Class Initialized
INFO - 2015-12-26 01:00:46 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:00:46 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:00:46 --> Utf8 Class Initialized
INFO - 2015-12-26 01:00:46 --> URI Class Initialized
INFO - 2015-12-26 01:00:46 --> Router Class Initialized
INFO - 2015-12-26 01:00:46 --> Output Class Initialized
INFO - 2015-12-26 01:00:46 --> Security Class Initialized
DEBUG - 2015-12-26 01:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:00:46 --> Input Class Initialized
INFO - 2015-12-26 01:00:46 --> Language Class Initialized
INFO - 2015-12-26 01:00:46 --> Loader Class Initialized
INFO - 2015-12-26 01:00:46 --> Helper loaded: url_helper
INFO - 2015-12-26 01:00:46 --> Database Driver Class Initialized
INFO - 2015-12-26 01:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:00:46 --> Config Class Initialized
INFO - 2015-12-26 01:00:46 --> Controller Class Initialized
INFO - 2015-12-26 01:00:46 --> Hooks Class Initialized
INFO - 2015-12-26 01:00:46 --> Model Class Initialized
INFO - 2015-12-26 01:00:46 --> Model Class Initialized
DEBUG - 2015-12-26 01:00:46 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:00:46 --> Utf8 Class Initialized
INFO - 2015-12-26 01:00:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 01:00:46 --> URI Class Initialized
INFO - 2015-12-26 01:00:46 --> Final output sent to browser
DEBUG - 2015-12-26 01:00:46 --> Total execution time: 0.1179
INFO - 2015-12-26 01:00:46 --> Router Class Initialized
INFO - 2015-12-26 01:00:46 --> Output Class Initialized
INFO - 2015-12-26 01:00:46 --> Security Class Initialized
DEBUG - 2015-12-26 01:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:00:46 --> Input Class Initialized
INFO - 2015-12-26 01:00:46 --> Language Class Initialized
INFO - 2015-12-26 01:00:46 --> Loader Class Initialized
INFO - 2015-12-26 01:00:46 --> Helper loaded: url_helper
INFO - 2015-12-26 01:00:46 --> Database Driver Class Initialized
INFO - 2015-12-26 01:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:00:46 --> Controller Class Initialized
DEBUG - 2015-12-26 01:00:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 01:00:46 --> Helper loaded: inflector_helper
INFO - 2015-12-26 01:00:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 01:00:46 --> Model Class Initialized
INFO - 2015-12-26 01:00:46 --> Model Class Initialized
INFO - 2015-12-26 01:00:46 --> Final output sent to browser
DEBUG - 2015-12-26 01:00:46 --> Total execution time: 0.1743
INFO - 2015-12-26 01:01:23 --> Config Class Initialized
INFO - 2015-12-26 01:01:23 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:23 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:23 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:23 --> URI Class Initialized
INFO - 2015-12-26 01:01:23 --> Router Class Initialized
INFO - 2015-12-26 01:01:23 --> Output Class Initialized
INFO - 2015-12-26 01:01:23 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:23 --> Input Class Initialized
INFO - 2015-12-26 01:01:23 --> Language Class Initialized
INFO - 2015-12-26 01:01:23 --> Loader Class Initialized
INFO - 2015-12-26 01:01:23 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:23 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:23 --> Controller Class Initialized
INFO - 2015-12-26 01:01:23 --> Model Class Initialized
INFO - 2015-12-26 01:01:23 --> Model Class Initialized
INFO - 2015-12-26 01:01:23 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:23 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:23 --> Total execution time: 0.1614
INFO - 2015-12-26 01:01:23 --> Config Class Initialized
INFO - 2015-12-26 01:01:23 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:23 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:23 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:23 --> URI Class Initialized
INFO - 2015-12-26 01:01:23 --> Router Class Initialized
INFO - 2015-12-26 01:01:23 --> Output Class Initialized
INFO - 2015-12-26 01:01:23 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:23 --> Input Class Initialized
INFO - 2015-12-26 01:01:23 --> Language Class Initialized
INFO - 2015-12-26 01:01:23 --> Loader Class Initialized
INFO - 2015-12-26 01:01:23 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:23 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:23 --> Controller Class Initialized
INFO - 2015-12-26 01:01:23 --> Model Class Initialized
INFO - 2015-12-26 01:01:23 --> Model Class Initialized
INFO - 2015-12-26 01:01:23 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:23 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:23 --> Total execution time: 0.0886
INFO - 2015-12-26 01:01:23 --> Config Class Initialized
INFO - 2015-12-26 01:01:23 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:23 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:23 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:23 --> URI Class Initialized
INFO - 2015-12-26 01:01:23 --> Router Class Initialized
INFO - 2015-12-26 01:01:23 --> Output Class Initialized
INFO - 2015-12-26 01:01:23 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:23 --> Input Class Initialized
INFO - 2015-12-26 01:01:23 --> Language Class Initialized
INFO - 2015-12-26 01:01:23 --> Loader Class Initialized
INFO - 2015-12-26 01:01:23 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:23 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:23 --> Controller Class Initialized
DEBUG - 2015-12-26 01:01:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 01:01:23 --> Helper loaded: inflector_helper
INFO - 2015-12-26 01:01:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 01:01:23 --> Model Class Initialized
INFO - 2015-12-26 01:01:23 --> Model Class Initialized
INFO - 2015-12-26 01:01:23 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:23 --> Total execution time: 0.1176
INFO - 2015-12-26 01:01:25 --> Config Class Initialized
INFO - 2015-12-26 01:01:25 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:25 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:25 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:25 --> URI Class Initialized
INFO - 2015-12-26 01:01:25 --> Router Class Initialized
INFO - 2015-12-26 01:01:25 --> Output Class Initialized
INFO - 2015-12-26 01:01:25 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:25 --> Input Class Initialized
INFO - 2015-12-26 01:01:25 --> Language Class Initialized
INFO - 2015-12-26 01:01:25 --> Loader Class Initialized
INFO - 2015-12-26 01:01:25 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:25 --> Database Driver Class Initialized
ERROR - 2015-12-26 01:01:25 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2015-12-26 01:01:25 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
INFO - 2015-12-26 01:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:25 --> Controller Class Initialized
INFO - 2015-12-26 01:01:25 --> Model Class Initialized
INFO - 2015-12-26 01:01:25 --> Model Class Initialized
INFO - 2015-12-26 01:01:25 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:25 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:25 --> Total execution time: 0.0968
INFO - 2015-12-26 01:01:25 --> Config Class Initialized
INFO - 2015-12-26 01:01:25 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:25 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:25 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:25 --> URI Class Initialized
INFO - 2015-12-26 01:01:25 --> Router Class Initialized
INFO - 2015-12-26 01:01:25 --> Output Class Initialized
INFO - 2015-12-26 01:01:25 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:25 --> Input Class Initialized
INFO - 2015-12-26 01:01:25 --> Language Class Initialized
INFO - 2015-12-26 01:01:25 --> Loader Class Initialized
INFO - 2015-12-26 01:01:25 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:25 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:25 --> Config Class Initialized
INFO - 2015-12-26 01:01:25 --> Controller Class Initialized
INFO - 2015-12-26 01:01:25 --> Hooks Class Initialized
INFO - 2015-12-26 01:01:25 --> Model Class Initialized
INFO - 2015-12-26 01:01:25 --> Model Class Initialized
DEBUG - 2015-12-26 01:01:25 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:25 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:25 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:25 --> Final output sent to browser
INFO - 2015-12-26 01:01:25 --> URI Class Initialized
DEBUG - 2015-12-26 01:01:25 --> Total execution time: 0.1189
INFO - 2015-12-26 01:01:25 --> Router Class Initialized
INFO - 2015-12-26 01:01:25 --> Output Class Initialized
INFO - 2015-12-26 01:01:25 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:25 --> Input Class Initialized
INFO - 2015-12-26 01:01:25 --> Language Class Initialized
INFO - 2015-12-26 01:01:25 --> Loader Class Initialized
INFO - 2015-12-26 01:01:25 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:26 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:26 --> Controller Class Initialized
DEBUG - 2015-12-26 01:01:26 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 01:01:26 --> Helper loaded: inflector_helper
INFO - 2015-12-26 01:01:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 01:01:26 --> Model Class Initialized
INFO - 2015-12-26 01:01:26 --> Model Class Initialized
INFO - 2015-12-26 01:01:26 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:26 --> Total execution time: 0.1650
INFO - 2015-12-26 01:01:28 --> Config Class Initialized
INFO - 2015-12-26 01:01:28 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:28 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:28 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:28 --> URI Class Initialized
INFO - 2015-12-26 01:01:28 --> Router Class Initialized
INFO - 2015-12-26 01:01:28 --> Output Class Initialized
INFO - 2015-12-26 01:01:28 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:28 --> Input Class Initialized
INFO - 2015-12-26 01:01:28 --> Language Class Initialized
INFO - 2015-12-26 01:01:28 --> Loader Class Initialized
INFO - 2015-12-26 01:01:28 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:28 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:28 --> Controller Class Initialized
INFO - 2015-12-26 01:01:28 --> Model Class Initialized
INFO - 2015-12-26 01:01:28 --> Model Class Initialized
INFO - 2015-12-26 01:01:28 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:28 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:28 --> Total execution time: 0.1280
INFO - 2015-12-26 01:01:28 --> Config Class Initialized
INFO - 2015-12-26 01:01:28 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:28 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:28 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:28 --> URI Class Initialized
INFO - 2015-12-26 01:01:28 --> Router Class Initialized
INFO - 2015-12-26 01:01:28 --> Output Class Initialized
INFO - 2015-12-26 01:01:28 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:28 --> Input Class Initialized
INFO - 2015-12-26 01:01:28 --> Language Class Initialized
INFO - 2015-12-26 01:01:28 --> Loader Class Initialized
INFO - 2015-12-26 01:01:28 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:28 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:28 --> Controller Class Initialized
INFO - 2015-12-26 01:01:28 --> Model Class Initialized
INFO - 2015-12-26 01:01:28 --> Model Class Initialized
INFO - 2015-12-26 01:01:28 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:28 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:28 --> Total execution time: 0.1222
INFO - 2015-12-26 01:01:28 --> Config Class Initialized
INFO - 2015-12-26 01:01:28 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:28 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:28 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:28 --> URI Class Initialized
INFO - 2015-12-26 01:01:28 --> Router Class Initialized
INFO - 2015-12-26 01:01:28 --> Output Class Initialized
INFO - 2015-12-26 01:01:28 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:28 --> Input Class Initialized
INFO - 2015-12-26 01:01:29 --> Language Class Initialized
INFO - 2015-12-26 01:01:29 --> Loader Class Initialized
INFO - 2015-12-26 01:01:29 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:29 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:29 --> Controller Class Initialized
INFO - 2015-12-26 01:01:29 --> Model Class Initialized
INFO - 2015-12-26 01:01:29 --> Model Class Initialized
INFO - 2015-12-26 01:01:29 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:29 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:29 --> Total execution time: 0.1329
INFO - 2015-12-26 01:01:29 --> Config Class Initialized
INFO - 2015-12-26 01:01:29 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:29 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:29 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:29 --> URI Class Initialized
INFO - 2015-12-26 01:01:29 --> Router Class Initialized
INFO - 2015-12-26 01:01:29 --> Output Class Initialized
INFO - 2015-12-26 01:01:29 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:29 --> Input Class Initialized
INFO - 2015-12-26 01:01:29 --> Language Class Initialized
INFO - 2015-12-26 01:01:29 --> Loader Class Initialized
INFO - 2015-12-26 01:01:29 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:29 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:29 --> Controller Class Initialized
INFO - 2015-12-26 01:01:29 --> Model Class Initialized
INFO - 2015-12-26 01:01:29 --> Model Class Initialized
INFO - 2015-12-26 01:01:29 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:29 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:29 --> Total execution time: 0.1323
INFO - 2015-12-26 01:01:29 --> Config Class Initialized
INFO - 2015-12-26 01:01:29 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:29 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:29 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:29 --> URI Class Initialized
INFO - 2015-12-26 01:01:29 --> Router Class Initialized
INFO - 2015-12-26 01:01:29 --> Output Class Initialized
INFO - 2015-12-26 01:01:29 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:29 --> Input Class Initialized
INFO - 2015-12-26 01:01:29 --> Language Class Initialized
INFO - 2015-12-26 01:01:29 --> Loader Class Initialized
INFO - 2015-12-26 01:01:29 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:29 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:29 --> Config Class Initialized
INFO - 2015-12-26 01:01:29 --> Hooks Class Initialized
INFO - 2015-12-26 01:01:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2015-12-26 01:01:29 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:29 --> Controller Class Initialized
INFO - 2015-12-26 01:01:29 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:29 --> Model Class Initialized
INFO - 2015-12-26 01:01:29 --> URI Class Initialized
INFO - 2015-12-26 01:01:29 --> Model Class Initialized
INFO - 2015-12-26 01:01:29 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:29 --> Router Class Initialized
INFO - 2015-12-26 01:01:29 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:29 --> Total execution time: 0.1405
INFO - 2015-12-26 01:01:29 --> Output Class Initialized
INFO - 2015-12-26 01:01:29 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:29 --> Input Class Initialized
INFO - 2015-12-26 01:01:29 --> Language Class Initialized
INFO - 2015-12-26 01:01:29 --> Loader Class Initialized
INFO - 2015-12-26 01:01:29 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:29 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:29 --> Controller Class Initialized
DEBUG - 2015-12-26 01:01:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 01:01:29 --> Helper loaded: inflector_helper
INFO - 2015-12-26 01:01:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 01:01:29 --> Model Class Initialized
INFO - 2015-12-26 01:01:29 --> Model Class Initialized
INFO - 2015-12-26 01:01:29 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:29 --> Total execution time: 0.2501
INFO - 2015-12-26 01:01:30 --> Config Class Initialized
INFO - 2015-12-26 01:01:30 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:30 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:30 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:30 --> URI Class Initialized
INFO - 2015-12-26 01:01:30 --> Router Class Initialized
INFO - 2015-12-26 01:01:30 --> Output Class Initialized
INFO - 2015-12-26 01:01:30 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:30 --> Input Class Initialized
INFO - 2015-12-26 01:01:30 --> Language Class Initialized
INFO - 2015-12-26 01:01:30 --> Loader Class Initialized
INFO - 2015-12-26 01:01:30 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:30 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:30 --> Controller Class Initialized
INFO - 2015-12-26 01:01:30 --> Model Class Initialized
INFO - 2015-12-26 01:01:30 --> Model Class Initialized
INFO - 2015-12-26 01:01:30 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:30 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:30 --> Total execution time: 0.0857
INFO - 2015-12-26 01:01:30 --> Config Class Initialized
INFO - 2015-12-26 01:01:30 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:30 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:30 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:30 --> URI Class Initialized
INFO - 2015-12-26 01:01:30 --> Router Class Initialized
INFO - 2015-12-26 01:01:30 --> Output Class Initialized
INFO - 2015-12-26 01:01:30 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:30 --> Input Class Initialized
INFO - 2015-12-26 01:01:30 --> Language Class Initialized
INFO - 2015-12-26 01:01:30 --> Loader Class Initialized
INFO - 2015-12-26 01:01:30 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:30 --> Config Class Initialized
INFO - 2015-12-26 01:01:30 --> Hooks Class Initialized
INFO - 2015-12-26 01:01:30 --> Database Driver Class Initialized
DEBUG - 2015-12-26 01:01:30 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:30 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:30 --> URI Class Initialized
INFO - 2015-12-26 01:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:30 --> Router Class Initialized
INFO - 2015-12-26 01:01:30 --> Controller Class Initialized
INFO - 2015-12-26 01:01:30 --> Output Class Initialized
INFO - 2015-12-26 01:01:30 --> Model Class Initialized
INFO - 2015-12-26 01:01:30 --> Security Class Initialized
INFO - 2015-12-26 01:01:30 --> Model Class Initialized
DEBUG - 2015-12-26 01:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:30 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:30 --> Input Class Initialized
INFO - 2015-12-26 01:01:30 --> Final output sent to browser
INFO - 2015-12-26 01:01:30 --> Language Class Initialized
DEBUG - 2015-12-26 01:01:30 --> Total execution time: 0.1336
INFO - 2015-12-26 01:01:30 --> Loader Class Initialized
INFO - 2015-12-26 01:01:30 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:30 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:30 --> Controller Class Initialized
DEBUG - 2015-12-26 01:01:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 01:01:30 --> Helper loaded: inflector_helper
INFO - 2015-12-26 01:01:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 01:01:30 --> Model Class Initialized
INFO - 2015-12-26 01:01:30 --> Model Class Initialized
INFO - 2015-12-26 01:01:30 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:30 --> Total execution time: 0.1552
INFO - 2015-12-26 01:01:31 --> Config Class Initialized
INFO - 2015-12-26 01:01:31 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:31 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:31 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:31 --> URI Class Initialized
INFO - 2015-12-26 01:01:31 --> Router Class Initialized
INFO - 2015-12-26 01:01:31 --> Output Class Initialized
INFO - 2015-12-26 01:01:31 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:31 --> Input Class Initialized
INFO - 2015-12-26 01:01:31 --> Language Class Initialized
INFO - 2015-12-26 01:01:31 --> Loader Class Initialized
INFO - 2015-12-26 01:01:31 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:31 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:31 --> Controller Class Initialized
INFO - 2015-12-26 01:01:31 --> Model Class Initialized
INFO - 2015-12-26 01:01:31 --> Model Class Initialized
INFO - 2015-12-26 01:01:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:31 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:31 --> Total execution time: 0.0886
INFO - 2015-12-26 01:01:31 --> Config Class Initialized
INFO - 2015-12-26 01:01:31 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:31 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:31 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:31 --> URI Class Initialized
INFO - 2015-12-26 01:01:31 --> Router Class Initialized
INFO - 2015-12-26 01:01:31 --> Output Class Initialized
INFO - 2015-12-26 01:01:31 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:31 --> Input Class Initialized
INFO - 2015-12-26 01:01:31 --> Language Class Initialized
INFO - 2015-12-26 01:01:31 --> Loader Class Initialized
INFO - 2015-12-26 01:01:31 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:31 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:31 --> Config Class Initialized
INFO - 2015-12-26 01:01:31 --> Hooks Class Initialized
INFO - 2015-12-26 01:01:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2015-12-26 01:01:31 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:31 --> Controller Class Initialized
INFO - 2015-12-26 01:01:31 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:31 --> Model Class Initialized
INFO - 2015-12-26 01:01:31 --> URI Class Initialized
INFO - 2015-12-26 01:01:31 --> Model Class Initialized
INFO - 2015-12-26 01:01:31 --> Router Class Initialized
INFO - 2015-12-26 01:01:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:31 --> Output Class Initialized
INFO - 2015-12-26 01:01:31 --> Final output sent to browser
INFO - 2015-12-26 01:01:31 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:31 --> Total execution time: 0.1129
DEBUG - 2015-12-26 01:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:31 --> Input Class Initialized
INFO - 2015-12-26 01:01:31 --> Language Class Initialized
INFO - 2015-12-26 01:01:31 --> Loader Class Initialized
INFO - 2015-12-26 01:01:31 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:31 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:31 --> Controller Class Initialized
DEBUG - 2015-12-26 01:01:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 01:01:31 --> Helper loaded: inflector_helper
INFO - 2015-12-26 01:01:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 01:01:31 --> Model Class Initialized
INFO - 2015-12-26 01:01:31 --> Model Class Initialized
INFO - 2015-12-26 01:01:31 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:31 --> Total execution time: 0.1713
INFO - 2015-12-26 01:01:32 --> Config Class Initialized
INFO - 2015-12-26 01:01:32 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:32 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:32 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:32 --> URI Class Initialized
INFO - 2015-12-26 01:01:32 --> Router Class Initialized
INFO - 2015-12-26 01:01:32 --> Output Class Initialized
INFO - 2015-12-26 01:01:32 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:32 --> Input Class Initialized
INFO - 2015-12-26 01:01:32 --> Language Class Initialized
INFO - 2015-12-26 01:01:32 --> Loader Class Initialized
INFO - 2015-12-26 01:01:32 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:32 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:32 --> Controller Class Initialized
INFO - 2015-12-26 01:01:32 --> Model Class Initialized
INFO - 2015-12-26 01:01:32 --> Model Class Initialized
INFO - 2015-12-26 01:01:32 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:32 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:32 --> Total execution time: 0.1261
INFO - 2015-12-26 01:01:32 --> Config Class Initialized
INFO - 2015-12-26 01:01:32 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:32 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:32 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:32 --> URI Class Initialized
INFO - 2015-12-26 01:01:32 --> Router Class Initialized
INFO - 2015-12-26 01:01:32 --> Output Class Initialized
INFO - 2015-12-26 01:01:32 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:32 --> Input Class Initialized
INFO - 2015-12-26 01:01:32 --> Language Class Initialized
INFO - 2015-12-26 01:01:32 --> Loader Class Initialized
INFO - 2015-12-26 01:01:32 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:32 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:32 --> Controller Class Initialized
INFO - 2015-12-26 01:01:32 --> Model Class Initialized
INFO - 2015-12-26 01:01:32 --> Model Class Initialized
INFO - 2015-12-26 01:01:32 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:32 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:32 --> Total execution time: 0.1284
INFO - 2015-12-26 01:01:32 --> Config Class Initialized
INFO - 2015-12-26 01:01:32 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:32 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:32 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:32 --> URI Class Initialized
INFO - 2015-12-26 01:01:32 --> Router Class Initialized
INFO - 2015-12-26 01:01:32 --> Output Class Initialized
INFO - 2015-12-26 01:01:32 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:32 --> Input Class Initialized
INFO - 2015-12-26 01:01:32 --> Language Class Initialized
INFO - 2015-12-26 01:01:32 --> Loader Class Initialized
INFO - 2015-12-26 01:01:32 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:32 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:32 --> Controller Class Initialized
INFO - 2015-12-26 01:01:32 --> Model Class Initialized
INFO - 2015-12-26 01:01:32 --> Model Class Initialized
INFO - 2015-12-26 01:01:32 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:32 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:32 --> Total execution time: 0.1114
INFO - 2015-12-26 01:01:33 --> Config Class Initialized
INFO - 2015-12-26 01:01:33 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:33 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:33 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:33 --> URI Class Initialized
INFO - 2015-12-26 01:01:33 --> Router Class Initialized
INFO - 2015-12-26 01:01:33 --> Output Class Initialized
INFO - 2015-12-26 01:01:33 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:33 --> Input Class Initialized
INFO - 2015-12-26 01:01:33 --> Language Class Initialized
INFO - 2015-12-26 01:01:33 --> Loader Class Initialized
INFO - 2015-12-26 01:01:33 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:33 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:33 --> Controller Class Initialized
INFO - 2015-12-26 01:01:33 --> Model Class Initialized
INFO - 2015-12-26 01:01:33 --> Model Class Initialized
INFO - 2015-12-26 01:01:33 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:33 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:33 --> Total execution time: 0.0994
INFO - 2015-12-26 01:01:33 --> Config Class Initialized
INFO - 2015-12-26 01:01:33 --> Hooks Class Initialized
DEBUG - 2015-12-26 01:01:33 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:33 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:33 --> URI Class Initialized
INFO - 2015-12-26 01:01:33 --> Router Class Initialized
INFO - 2015-12-26 01:01:33 --> Output Class Initialized
INFO - 2015-12-26 01:01:33 --> Security Class Initialized
DEBUG - 2015-12-26 01:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:33 --> Input Class Initialized
INFO - 2015-12-26 01:01:33 --> Language Class Initialized
INFO - 2015-12-26 01:01:33 --> Loader Class Initialized
INFO - 2015-12-26 01:01:33 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:33 --> Config Class Initialized
INFO - 2015-12-26 01:01:33 --> Hooks Class Initialized
INFO - 2015-12-26 01:01:33 --> Database Driver Class Initialized
DEBUG - 2015-12-26 01:01:33 --> UTF-8 Support Enabled
INFO - 2015-12-26 01:01:33 --> Utf8 Class Initialized
INFO - 2015-12-26 01:01:33 --> URI Class Initialized
INFO - 2015-12-26 01:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:33 --> Router Class Initialized
INFO - 2015-12-26 01:01:33 --> Controller Class Initialized
INFO - 2015-12-26 01:01:33 --> Output Class Initialized
INFO - 2015-12-26 01:01:33 --> Model Class Initialized
INFO - 2015-12-26 01:01:33 --> Security Class Initialized
INFO - 2015-12-26 01:01:33 --> Model Class Initialized
DEBUG - 2015-12-26 01:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 01:01:33 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 01:01:33 --> Input Class Initialized
INFO - 2015-12-26 01:01:33 --> Final output sent to browser
INFO - 2015-12-26 01:01:33 --> Language Class Initialized
DEBUG - 2015-12-26 01:01:33 --> Total execution time: 0.1612
INFO - 2015-12-26 01:01:33 --> Loader Class Initialized
INFO - 2015-12-26 01:01:33 --> Helper loaded: url_helper
INFO - 2015-12-26 01:01:33 --> Database Driver Class Initialized
INFO - 2015-12-26 01:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 01:01:33 --> Controller Class Initialized
DEBUG - 2015-12-26 01:01:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 01:01:33 --> Helper loaded: inflector_helper
INFO - 2015-12-26 01:01:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 01:01:33 --> Model Class Initialized
INFO - 2015-12-26 01:01:33 --> Model Class Initialized
INFO - 2015-12-26 01:01:33 --> Final output sent to browser
DEBUG - 2015-12-26 01:01:33 --> Total execution time: 0.1861
INFO - 2015-12-26 02:04:28 --> Config Class Initialized
INFO - 2015-12-26 02:04:28 --> Hooks Class Initialized
DEBUG - 2015-12-26 02:04:28 --> UTF-8 Support Enabled
INFO - 2015-12-26 02:04:28 --> Utf8 Class Initialized
INFO - 2015-12-26 02:04:28 --> URI Class Initialized
INFO - 2015-12-26 02:04:28 --> Router Class Initialized
INFO - 2015-12-26 02:04:28 --> Output Class Initialized
INFO - 2015-12-26 02:04:28 --> Security Class Initialized
DEBUG - 2015-12-26 02:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 02:04:28 --> Input Class Initialized
INFO - 2015-12-26 02:04:28 --> Language Class Initialized
INFO - 2015-12-26 02:04:28 --> Loader Class Initialized
INFO - 2015-12-26 02:04:28 --> Helper loaded: url_helper
INFO - 2015-12-26 02:04:28 --> Database Driver Class Initialized
INFO - 2015-12-26 02:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 02:04:28 --> Controller Class Initialized
INFO - 2015-12-26 02:04:28 --> Helper loaded: form_helper
INFO - 2015-12-26 02:04:28 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 02:04:28 --> Final output sent to browser
DEBUG - 2015-12-26 02:04:28 --> Total execution time: 0.2240
INFO - 2015-12-26 02:04:34 --> Config Class Initialized
INFO - 2015-12-26 02:04:34 --> Hooks Class Initialized
DEBUG - 2015-12-26 02:04:34 --> UTF-8 Support Enabled
INFO - 2015-12-26 02:04:34 --> Utf8 Class Initialized
INFO - 2015-12-26 02:04:34 --> URI Class Initialized
INFO - 2015-12-26 02:04:34 --> Router Class Initialized
INFO - 2015-12-26 02:04:35 --> Output Class Initialized
INFO - 2015-12-26 02:04:35 --> Security Class Initialized
DEBUG - 2015-12-26 02:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 02:04:35 --> Input Class Initialized
INFO - 2015-12-26 02:04:35 --> Language Class Initialized
INFO - 2015-12-26 02:04:35 --> Loader Class Initialized
INFO - 2015-12-26 02:04:35 --> Helper loaded: url_helper
INFO - 2015-12-26 02:04:35 --> Database Driver Class Initialized
INFO - 2015-12-26 02:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 02:04:35 --> Controller Class Initialized
INFO - 2015-12-26 02:04:35 --> Model Class Initialized
INFO - 2015-12-26 02:04:35 --> Model Class Initialized
INFO - 2015-12-26 02:04:35 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 02:04:35 --> Final output sent to browser
DEBUG - 2015-12-26 02:04:35 --> Total execution time: 0.1264
INFO - 2015-12-26 02:04:35 --> Config Class Initialized
INFO - 2015-12-26 02:04:35 --> Hooks Class Initialized
DEBUG - 2015-12-26 02:04:35 --> UTF-8 Support Enabled
INFO - 2015-12-26 02:04:35 --> Utf8 Class Initialized
INFO - 2015-12-26 02:04:35 --> URI Class Initialized
INFO - 2015-12-26 02:04:35 --> Router Class Initialized
INFO - 2015-12-26 02:04:35 --> Output Class Initialized
INFO - 2015-12-26 02:04:35 --> Security Class Initialized
DEBUG - 2015-12-26 02:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 02:04:35 --> Input Class Initialized
INFO - 2015-12-26 02:04:35 --> Language Class Initialized
INFO - 2015-12-26 02:04:35 --> Loader Class Initialized
INFO - 2015-12-26 02:04:35 --> Helper loaded: url_helper
INFO - 2015-12-26 02:04:35 --> Config Class Initialized
INFO - 2015-12-26 02:04:35 --> Hooks Class Initialized
INFO - 2015-12-26 02:04:35 --> Database Driver Class Initialized
DEBUG - 2015-12-26 02:04:35 --> UTF-8 Support Enabled
INFO - 2015-12-26 02:04:35 --> Utf8 Class Initialized
INFO - 2015-12-26 02:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 02:04:35 --> URI Class Initialized
INFO - 2015-12-26 02:04:35 --> Controller Class Initialized
INFO - 2015-12-26 02:04:35 --> Router Class Initialized
INFO - 2015-12-26 02:04:35 --> Model Class Initialized
INFO - 2015-12-26 02:04:35 --> Output Class Initialized
INFO - 2015-12-26 02:04:35 --> Model Class Initialized
INFO - 2015-12-26 02:04:35 --> Security Class Initialized
INFO - 2015-12-26 02:04:35 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
DEBUG - 2015-12-26 02:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 02:04:35 --> Final output sent to browser
INFO - 2015-12-26 02:04:35 --> Input Class Initialized
DEBUG - 2015-12-26 02:04:35 --> Total execution time: 0.1213
INFO - 2015-12-26 02:04:35 --> Language Class Initialized
INFO - 2015-12-26 02:04:35 --> Loader Class Initialized
INFO - 2015-12-26 02:04:35 --> Helper loaded: url_helper
INFO - 2015-12-26 02:04:35 --> Database Driver Class Initialized
INFO - 2015-12-26 02:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 02:04:35 --> Controller Class Initialized
DEBUG - 2015-12-26 02:04:35 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 02:04:35 --> Helper loaded: inflector_helper
INFO - 2015-12-26 02:04:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 02:04:35 --> Model Class Initialized
INFO - 2015-12-26 02:04:35 --> Model Class Initialized
INFO - 2015-12-26 02:04:35 --> Final output sent to browser
DEBUG - 2015-12-26 02:04:35 --> Total execution time: 0.1691
INFO - 2015-12-26 02:19:21 --> Config Class Initialized
INFO - 2015-12-26 02:19:21 --> Hooks Class Initialized
DEBUG - 2015-12-26 02:19:21 --> UTF-8 Support Enabled
INFO - 2015-12-26 02:19:21 --> Utf8 Class Initialized
INFO - 2015-12-26 02:19:21 --> URI Class Initialized
INFO - 2015-12-26 02:19:21 --> Router Class Initialized
INFO - 2015-12-26 02:19:21 --> Output Class Initialized
INFO - 2015-12-26 02:19:21 --> Security Class Initialized
DEBUG - 2015-12-26 02:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 02:19:21 --> Input Class Initialized
INFO - 2015-12-26 02:19:21 --> Language Class Initialized
INFO - 2015-12-26 02:19:21 --> Loader Class Initialized
INFO - 2015-12-26 02:19:21 --> Helper loaded: url_helper
INFO - 2015-12-26 02:19:21 --> Database Driver Class Initialized
INFO - 2015-12-26 02:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 02:19:21 --> Controller Class Initialized
INFO - 2015-12-26 02:19:21 --> Config Class Initialized
INFO - 2015-12-26 02:19:21 --> Hooks Class Initialized
DEBUG - 2015-12-26 02:19:21 --> UTF-8 Support Enabled
INFO - 2015-12-26 02:19:21 --> Utf8 Class Initialized
INFO - 2015-12-26 02:19:21 --> URI Class Initialized
INFO - 2015-12-26 02:19:21 --> Router Class Initialized
INFO - 2015-12-26 02:19:21 --> Output Class Initialized
INFO - 2015-12-26 02:19:21 --> Security Class Initialized
DEBUG - 2015-12-26 02:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 02:19:21 --> Input Class Initialized
INFO - 2015-12-26 02:19:21 --> Language Class Initialized
INFO - 2015-12-26 02:19:21 --> Loader Class Initialized
INFO - 2015-12-26 02:19:21 --> Helper loaded: url_helper
INFO - 2015-12-26 02:19:21 --> Database Driver Class Initialized
INFO - 2015-12-26 02:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 02:19:21 --> Controller Class Initialized
INFO - 2015-12-26 02:19:21 --> Helper loaded: form_helper
INFO - 2015-12-26 02:19:21 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 02:19:21 --> Final output sent to browser
DEBUG - 2015-12-26 02:19:21 --> Total execution time: 0.1041
INFO - 2015-12-26 03:11:58 --> Config Class Initialized
INFO - 2015-12-26 03:11:58 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:11:58 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:11:58 --> Utf8 Class Initialized
INFO - 2015-12-26 03:11:58 --> URI Class Initialized
INFO - 2015-12-26 03:11:58 --> Router Class Initialized
INFO - 2015-12-26 03:11:58 --> Output Class Initialized
INFO - 2015-12-26 03:11:58 --> Security Class Initialized
DEBUG - 2015-12-26 03:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:11:58 --> Input Class Initialized
INFO - 2015-12-26 03:11:58 --> Language Class Initialized
INFO - 2015-12-26 03:11:58 --> Loader Class Initialized
INFO - 2015-12-26 03:11:58 --> Helper loaded: url_helper
INFO - 2015-12-26 03:11:58 --> Database Driver Class Initialized
INFO - 2015-12-26 03:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:11:58 --> Controller Class Initialized
INFO - 2015-12-26 03:11:58 --> Model Class Initialized
INFO - 2015-12-26 03:11:58 --> Model Class Initialized
INFO - 2015-12-26 03:11:58 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 03:11:58 --> Final output sent to browser
DEBUG - 2015-12-26 03:11:58 --> Total execution time: 0.4007
INFO - 2015-12-26 03:12:02 --> Config Class Initialized
INFO - 2015-12-26 03:12:02 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:12:02 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:12:02 --> Utf8 Class Initialized
INFO - 2015-12-26 03:12:02 --> URI Class Initialized
INFO - 2015-12-26 03:12:02 --> Router Class Initialized
INFO - 2015-12-26 03:12:02 --> Output Class Initialized
INFO - 2015-12-26 03:12:02 --> Security Class Initialized
DEBUG - 2015-12-26 03:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:12:02 --> Input Class Initialized
INFO - 2015-12-26 03:12:02 --> Language Class Initialized
INFO - 2015-12-26 03:12:02 --> Loader Class Initialized
INFO - 2015-12-26 03:12:02 --> Helper loaded: url_helper
INFO - 2015-12-26 03:12:02 --> Database Driver Class Initialized
INFO - 2015-12-26 03:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:12:02 --> Controller Class Initialized
INFO - 2015-12-26 03:12:02 --> Model Class Initialized
INFO - 2015-12-26 03:12:02 --> Model Class Initialized
INFO - 2015-12-26 03:12:02 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 03:12:02 --> Final output sent to browser
DEBUG - 2015-12-26 03:12:02 --> Total execution time: 0.1199
INFO - 2015-12-26 03:12:03 --> Config Class Initialized
INFO - 2015-12-26 03:12:03 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:12:03 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:12:03 --> Utf8 Class Initialized
INFO - 2015-12-26 03:12:03 --> URI Class Initialized
INFO - 2015-12-26 03:12:03 --> Router Class Initialized
INFO - 2015-12-26 03:12:03 --> Output Class Initialized
INFO - 2015-12-26 03:12:03 --> Security Class Initialized
DEBUG - 2015-12-26 03:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:12:03 --> Input Class Initialized
INFO - 2015-12-26 03:12:03 --> Language Class Initialized
INFO - 2015-12-26 03:12:03 --> Loader Class Initialized
INFO - 2015-12-26 03:12:03 --> Helper loaded: url_helper
INFO - 2015-12-26 03:12:03 --> Database Driver Class Initialized
INFO - 2015-12-26 03:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:12:03 --> Controller Class Initialized
INFO - 2015-12-26 03:12:03 --> Model Class Initialized
INFO - 2015-12-26 03:12:03 --> Model Class Initialized
INFO - 2015-12-26 03:12:03 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 03:12:03 --> Final output sent to browser
DEBUG - 2015-12-26 03:12:03 --> Total execution time: 0.1052
INFO - 2015-12-26 03:12:11 --> Config Class Initialized
INFO - 2015-12-26 03:12:11 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:12:11 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:12:11 --> Utf8 Class Initialized
INFO - 2015-12-26 03:12:11 --> URI Class Initialized
INFO - 2015-12-26 03:12:11 --> Router Class Initialized
INFO - 2015-12-26 03:12:11 --> Output Class Initialized
INFO - 2015-12-26 03:12:11 --> Security Class Initialized
DEBUG - 2015-12-26 03:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:12:11 --> Input Class Initialized
INFO - 2015-12-26 03:12:11 --> Language Class Initialized
INFO - 2015-12-26 03:12:11 --> Loader Class Initialized
INFO - 2015-12-26 03:12:11 --> Helper loaded: url_helper
INFO - 2015-12-26 03:12:11 --> Database Driver Class Initialized
INFO - 2015-12-26 03:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:12:11 --> Controller Class Initialized
INFO - 2015-12-26 03:12:11 --> Model Class Initialized
INFO - 2015-12-26 03:12:11 --> Model Class Initialized
INFO - 2015-12-26 03:12:11 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 03:12:11 --> Final output sent to browser
DEBUG - 2015-12-26 03:12:11 --> Total execution time: 0.1246
INFO - 2015-12-26 03:12:11 --> Config Class Initialized
INFO - 2015-12-26 03:12:11 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:12:11 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:12:11 --> Utf8 Class Initialized
INFO - 2015-12-26 03:12:11 --> URI Class Initialized
INFO - 2015-12-26 03:12:11 --> Router Class Initialized
INFO - 2015-12-26 03:12:11 --> Output Class Initialized
INFO - 2015-12-26 03:12:11 --> Security Class Initialized
DEBUG - 2015-12-26 03:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:12:11 --> Input Class Initialized
INFO - 2015-12-26 03:12:11 --> Language Class Initialized
INFO - 2015-12-26 03:12:11 --> Loader Class Initialized
INFO - 2015-12-26 03:12:11 --> Helper loaded: url_helper
INFO - 2015-12-26 03:12:11 --> Database Driver Class Initialized
INFO - 2015-12-26 03:12:11 --> Config Class Initialized
INFO - 2015-12-26 03:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:12:11 --> Hooks Class Initialized
INFO - 2015-12-26 03:12:11 --> Controller Class Initialized
INFO - 2015-12-26 03:12:11 --> Model Class Initialized
DEBUG - 2015-12-26 03:12:11 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:12:11 --> Model Class Initialized
INFO - 2015-12-26 03:12:11 --> Utf8 Class Initialized
INFO - 2015-12-26 03:12:11 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 03:12:11 --> URI Class Initialized
INFO - 2015-12-26 03:12:11 --> Final output sent to browser
DEBUG - 2015-12-26 03:12:11 --> Total execution time: 0.1190
INFO - 2015-12-26 03:12:11 --> Router Class Initialized
INFO - 2015-12-26 03:12:11 --> Output Class Initialized
INFO - 2015-12-26 03:12:11 --> Security Class Initialized
DEBUG - 2015-12-26 03:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:12:11 --> Input Class Initialized
INFO - 2015-12-26 03:12:11 --> Language Class Initialized
INFO - 2015-12-26 03:12:11 --> Loader Class Initialized
INFO - 2015-12-26 03:12:11 --> Helper loaded: url_helper
INFO - 2015-12-26 03:12:11 --> Database Driver Class Initialized
INFO - 2015-12-26 03:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:12:11 --> Controller Class Initialized
DEBUG - 2015-12-26 03:12:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:12:12 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:12:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:12:12 --> Model Class Initialized
INFO - 2015-12-26 03:12:12 --> Model Class Initialized
INFO - 2015-12-26 03:12:12 --> Final output sent to browser
DEBUG - 2015-12-26 03:12:12 --> Total execution time: 0.1532
INFO - 2015-12-26 03:24:54 --> Config Class Initialized
INFO - 2015-12-26 03:24:54 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:24:54 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:24:54 --> Utf8 Class Initialized
INFO - 2015-12-26 03:24:54 --> URI Class Initialized
DEBUG - 2015-12-26 03:24:54 --> No URI present. Default controller set.
INFO - 2015-12-26 03:24:54 --> Router Class Initialized
INFO - 2015-12-26 03:24:54 --> Output Class Initialized
INFO - 2015-12-26 03:24:54 --> Security Class Initialized
DEBUG - 2015-12-26 03:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:24:54 --> Input Class Initialized
INFO - 2015-12-26 03:24:54 --> Language Class Initialized
INFO - 2015-12-26 03:24:54 --> Loader Class Initialized
INFO - 2015-12-26 03:24:54 --> Helper loaded: url_helper
INFO - 2015-12-26 03:24:54 --> Database Driver Class Initialized
INFO - 2015-12-26 03:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:24:54 --> Controller Class Initialized
INFO - 2015-12-26 03:24:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 03:24:54 --> Final output sent to browser
DEBUG - 2015-12-26 03:24:54 --> Total execution time: 0.3818
INFO - 2015-12-26 03:25:19 --> Config Class Initialized
INFO - 2015-12-26 03:25:19 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:19 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:19 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:19 --> URI Class Initialized
INFO - 2015-12-26 03:25:19 --> Router Class Initialized
INFO - 2015-12-26 03:25:19 --> Output Class Initialized
INFO - 2015-12-26 03:25:19 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:19 --> Input Class Initialized
INFO - 2015-12-26 03:25:19 --> Language Class Initialized
INFO - 2015-12-26 03:25:19 --> Loader Class Initialized
INFO - 2015-12-26 03:25:19 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:19 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:19 --> Controller Class Initialized
INFO - 2015-12-26 03:25:19 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 03:25:19 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:19 --> Total execution time: 0.1652
INFO - 2015-12-26 03:25:19 --> Config Class Initialized
INFO - 2015-12-26 03:25:19 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:19 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:19 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:19 --> URI Class Initialized
INFO - 2015-12-26 03:25:19 --> Router Class Initialized
INFO - 2015-12-26 03:25:19 --> Output Class Initialized
INFO - 2015-12-26 03:25:19 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:19 --> Input Class Initialized
INFO - 2015-12-26 03:25:19 --> Language Class Initialized
INFO - 2015-12-26 03:25:19 --> Loader Class Initialized
INFO - 2015-12-26 03:25:19 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:19 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:19 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:19 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:19 --> Model Class Initialized
INFO - 2015-12-26 03:25:19 --> Model Class Initialized
INFO - 2015-12-26 03:25:19 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:19 --> Total execution time: 0.1350
INFO - 2015-12-26 03:25:22 --> Config Class Initialized
INFO - 2015-12-26 03:25:22 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:22 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:22 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:22 --> URI Class Initialized
INFO - 2015-12-26 03:25:22 --> Router Class Initialized
INFO - 2015-12-26 03:25:22 --> Output Class Initialized
INFO - 2015-12-26 03:25:22 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:22 --> Input Class Initialized
INFO - 2015-12-26 03:25:22 --> Language Class Initialized
INFO - 2015-12-26 03:25:22 --> Loader Class Initialized
INFO - 2015-12-26 03:25:22 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:22 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:22 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:22 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:22 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:22 --> Model Class Initialized
INFO - 2015-12-26 03:25:22 --> Model Class Initialized
INFO - 2015-12-26 03:25:22 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:22 --> Total execution time: 0.1024
INFO - 2015-12-26 03:25:24 --> Config Class Initialized
INFO - 2015-12-26 03:25:24 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:24 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:24 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:24 --> URI Class Initialized
INFO - 2015-12-26 03:25:24 --> Router Class Initialized
INFO - 2015-12-26 03:25:24 --> Output Class Initialized
INFO - 2015-12-26 03:25:24 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:24 --> Input Class Initialized
INFO - 2015-12-26 03:25:24 --> Language Class Initialized
INFO - 2015-12-26 03:25:24 --> Loader Class Initialized
INFO - 2015-12-26 03:25:24 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:24 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:24 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:24 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:24 --> Model Class Initialized
INFO - 2015-12-26 03:25:24 --> Model Class Initialized
INFO - 2015-12-26 03:25:24 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:24 --> Total execution time: 0.1012
INFO - 2015-12-26 03:25:28 --> Config Class Initialized
INFO - 2015-12-26 03:25:28 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:28 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:28 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:28 --> URI Class Initialized
INFO - 2015-12-26 03:25:28 --> Router Class Initialized
INFO - 2015-12-26 03:25:28 --> Output Class Initialized
INFO - 2015-12-26 03:25:28 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:28 --> Input Class Initialized
INFO - 2015-12-26 03:25:28 --> Language Class Initialized
INFO - 2015-12-26 03:25:28 --> Loader Class Initialized
INFO - 2015-12-26 03:25:28 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:28 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:28 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:28 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:28 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:28 --> Model Class Initialized
INFO - 2015-12-26 03:25:28 --> Model Class Initialized
INFO - 2015-12-26 03:25:28 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:28 --> Total execution time: 0.1148
INFO - 2015-12-26 03:25:30 --> Config Class Initialized
INFO - 2015-12-26 03:25:30 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:30 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:30 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:30 --> URI Class Initialized
INFO - 2015-12-26 03:25:30 --> Router Class Initialized
INFO - 2015-12-26 03:25:30 --> Output Class Initialized
INFO - 2015-12-26 03:25:30 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:30 --> Input Class Initialized
INFO - 2015-12-26 03:25:30 --> Language Class Initialized
INFO - 2015-12-26 03:25:30 --> Loader Class Initialized
INFO - 2015-12-26 03:25:30 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:30 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:30 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:30 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:30 --> Model Class Initialized
INFO - 2015-12-26 03:25:30 --> Model Class Initialized
INFO - 2015-12-26 03:25:30 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:30 --> Total execution time: 0.1486
INFO - 2015-12-26 03:25:32 --> Config Class Initialized
INFO - 2015-12-26 03:25:32 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:32 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:32 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:32 --> URI Class Initialized
INFO - 2015-12-26 03:25:32 --> Router Class Initialized
INFO - 2015-12-26 03:25:32 --> Output Class Initialized
INFO - 2015-12-26 03:25:32 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:32 --> Input Class Initialized
INFO - 2015-12-26 03:25:32 --> Language Class Initialized
INFO - 2015-12-26 03:25:32 --> Loader Class Initialized
INFO - 2015-12-26 03:25:32 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:32 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:32 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:32 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:32 --> Model Class Initialized
INFO - 2015-12-26 03:25:32 --> Model Class Initialized
INFO - 2015-12-26 03:25:32 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:32 --> Total execution time: 0.1614
INFO - 2015-12-26 03:25:34 --> Config Class Initialized
INFO - 2015-12-26 03:25:34 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:34 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:34 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:34 --> URI Class Initialized
INFO - 2015-12-26 03:25:34 --> Router Class Initialized
INFO - 2015-12-26 03:25:34 --> Output Class Initialized
INFO - 2015-12-26 03:25:34 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:34 --> Input Class Initialized
INFO - 2015-12-26 03:25:34 --> Language Class Initialized
INFO - 2015-12-26 03:25:34 --> Loader Class Initialized
INFO - 2015-12-26 03:25:34 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:34 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:34 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:34 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:34 --> Model Class Initialized
INFO - 2015-12-26 03:25:34 --> Model Class Initialized
INFO - 2015-12-26 03:25:34 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:34 --> Total execution time: 0.1126
INFO - 2015-12-26 03:25:38 --> Config Class Initialized
INFO - 2015-12-26 03:25:39 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:39 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:39 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:39 --> URI Class Initialized
INFO - 2015-12-26 03:25:39 --> Router Class Initialized
INFO - 2015-12-26 03:25:39 --> Output Class Initialized
INFO - 2015-12-26 03:25:39 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:39 --> Input Class Initialized
INFO - 2015-12-26 03:25:39 --> Language Class Initialized
INFO - 2015-12-26 03:25:39 --> Loader Class Initialized
INFO - 2015-12-26 03:25:39 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:39 --> Database Driver Class Initialized
ERROR - 2015-12-26 03:25:39 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2015-12-26 03:25:39 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
ERROR - 2015-12-26 03:25:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/libraries/Session/Session.php 168
INFO - 2015-12-26 03:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:39 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:39 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:39 --> Model Class Initialized
INFO - 2015-12-26 03:25:39 --> Model Class Initialized
ERROR - 2015-12-26 03:25:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/core/Common.php 573
INFO - 2015-12-26 03:25:39 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:39 --> Total execution time: 0.1741
INFO - 2015-12-26 03:25:49 --> Config Class Initialized
INFO - 2015-12-26 03:25:49 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:49 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:49 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:49 --> URI Class Initialized
INFO - 2015-12-26 03:25:49 --> Router Class Initialized
INFO - 2015-12-26 03:25:49 --> Output Class Initialized
INFO - 2015-12-26 03:25:49 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:49 --> Input Class Initialized
INFO - 2015-12-26 03:25:49 --> Language Class Initialized
INFO - 2015-12-26 03:25:49 --> Loader Class Initialized
INFO - 2015-12-26 03:25:49 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:49 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:49 --> Controller Class Initialized
INFO - 2015-12-26 03:25:49 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 03:25:49 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:49 --> Total execution time: 0.0897
INFO - 2015-12-26 03:25:49 --> Config Class Initialized
INFO - 2015-12-26 03:25:49 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:49 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:49 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:49 --> URI Class Initialized
DEBUG - 2015-12-26 03:25:49 --> No URI present. Default controller set.
INFO - 2015-12-26 03:25:49 --> Router Class Initialized
INFO - 2015-12-26 03:25:49 --> Output Class Initialized
INFO - 2015-12-26 03:25:49 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:49 --> Input Class Initialized
INFO - 2015-12-26 03:25:49 --> Language Class Initialized
INFO - 2015-12-26 03:25:49 --> Loader Class Initialized
INFO - 2015-12-26 03:25:49 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:49 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:49 --> Controller Class Initialized
INFO - 2015-12-26 03:25:49 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 03:25:49 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:49 --> Total execution time: 0.0910
INFO - 2015-12-26 03:25:51 --> Config Class Initialized
INFO - 2015-12-26 03:25:51 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:51 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:51 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:51 --> URI Class Initialized
INFO - 2015-12-26 03:25:51 --> Router Class Initialized
INFO - 2015-12-26 03:25:51 --> Output Class Initialized
INFO - 2015-12-26 03:25:51 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:51 --> Input Class Initialized
INFO - 2015-12-26 03:25:51 --> Language Class Initialized
INFO - 2015-12-26 03:25:51 --> Loader Class Initialized
INFO - 2015-12-26 03:25:51 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:51 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:51 --> Controller Class Initialized
INFO - 2015-12-26 03:25:51 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 03:25:51 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:51 --> Total execution time: 0.0801
INFO - 2015-12-26 03:25:51 --> Config Class Initialized
INFO - 2015-12-26 03:25:51 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:51 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:51 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:51 --> URI Class Initialized
INFO - 2015-12-26 03:25:51 --> Router Class Initialized
INFO - 2015-12-26 03:25:51 --> Output Class Initialized
INFO - 2015-12-26 03:25:51 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:51 --> Input Class Initialized
INFO - 2015-12-26 03:25:51 --> Language Class Initialized
INFO - 2015-12-26 03:25:51 --> Loader Class Initialized
INFO - 2015-12-26 03:25:51 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:51 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:51 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:51 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:51 --> Model Class Initialized
INFO - 2015-12-26 03:25:51 --> Model Class Initialized
INFO - 2015-12-26 03:25:51 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:51 --> Total execution time: 0.1088
INFO - 2015-12-26 03:25:54 --> Config Class Initialized
INFO - 2015-12-26 03:25:54 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:54 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:54 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:54 --> URI Class Initialized
INFO - 2015-12-26 03:25:54 --> Router Class Initialized
INFO - 2015-12-26 03:25:54 --> Output Class Initialized
INFO - 2015-12-26 03:25:54 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:54 --> Input Class Initialized
INFO - 2015-12-26 03:25:54 --> Language Class Initialized
INFO - 2015-12-26 03:25:54 --> Loader Class Initialized
INFO - 2015-12-26 03:25:54 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:54 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:54 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:54 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:54 --> Model Class Initialized
INFO - 2015-12-26 03:25:54 --> Model Class Initialized
INFO - 2015-12-26 03:25:54 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:54 --> Total execution time: 0.1026
INFO - 2015-12-26 03:25:56 --> Config Class Initialized
INFO - 2015-12-26 03:25:56 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:56 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:56 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:56 --> URI Class Initialized
INFO - 2015-12-26 03:25:56 --> Router Class Initialized
INFO - 2015-12-26 03:25:56 --> Output Class Initialized
INFO - 2015-12-26 03:25:56 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:56 --> Input Class Initialized
INFO - 2015-12-26 03:25:56 --> Language Class Initialized
INFO - 2015-12-26 03:25:56 --> Loader Class Initialized
INFO - 2015-12-26 03:25:56 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:56 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:56 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:56 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:56 --> Model Class Initialized
INFO - 2015-12-26 03:25:56 --> Model Class Initialized
INFO - 2015-12-26 03:25:56 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:56 --> Total execution time: 0.1159
INFO - 2015-12-26 03:25:58 --> Config Class Initialized
INFO - 2015-12-26 03:25:58 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:58 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:58 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:58 --> URI Class Initialized
INFO - 2015-12-26 03:25:58 --> Router Class Initialized
INFO - 2015-12-26 03:25:58 --> Output Class Initialized
INFO - 2015-12-26 03:25:58 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:58 --> Input Class Initialized
INFO - 2015-12-26 03:25:58 --> Language Class Initialized
INFO - 2015-12-26 03:25:58 --> Loader Class Initialized
INFO - 2015-12-26 03:25:58 --> Helper loaded: url_helper
INFO - 2015-12-26 03:25:58 --> Database Driver Class Initialized
INFO - 2015-12-26 03:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:25:58 --> Controller Class Initialized
DEBUG - 2015-12-26 03:25:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:25:58 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:25:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:25:58 --> Model Class Initialized
INFO - 2015-12-26 03:25:58 --> Model Class Initialized
INFO - 2015-12-26 03:25:58 --> Final output sent to browser
DEBUG - 2015-12-26 03:25:58 --> Total execution time: 0.1200
INFO - 2015-12-26 03:25:59 --> Config Class Initialized
INFO - 2015-12-26 03:25:59 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:25:59 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:25:59 --> Utf8 Class Initialized
INFO - 2015-12-26 03:25:59 --> URI Class Initialized
INFO - 2015-12-26 03:25:59 --> Router Class Initialized
INFO - 2015-12-26 03:25:59 --> Output Class Initialized
INFO - 2015-12-26 03:25:59 --> Security Class Initialized
DEBUG - 2015-12-26 03:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:25:59 --> Input Class Initialized
INFO - 2015-12-26 03:25:59 --> Language Class Initialized
INFO - 2015-12-26 03:25:59 --> Loader Class Initialized
INFO - 2015-12-26 03:25:59 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:00 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:00 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:00 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:00 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:00 --> Model Class Initialized
INFO - 2015-12-26 03:26:00 --> Model Class Initialized
INFO - 2015-12-26 03:26:00 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:00 --> Total execution time: 0.1017
INFO - 2015-12-26 03:26:01 --> Config Class Initialized
INFO - 2015-12-26 03:26:01 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:01 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:01 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:02 --> URI Class Initialized
INFO - 2015-12-26 03:26:02 --> Router Class Initialized
INFO - 2015-12-26 03:26:02 --> Output Class Initialized
INFO - 2015-12-26 03:26:02 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:02 --> Input Class Initialized
INFO - 2015-12-26 03:26:02 --> Language Class Initialized
INFO - 2015-12-26 03:26:02 --> Loader Class Initialized
INFO - 2015-12-26 03:26:02 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:02 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:02 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:02 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:02 --> Model Class Initialized
INFO - 2015-12-26 03:26:02 --> Model Class Initialized
INFO - 2015-12-26 03:26:02 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:02 --> Total execution time: 0.0989
INFO - 2015-12-26 03:26:03 --> Config Class Initialized
INFO - 2015-12-26 03:26:03 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:03 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:03 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:03 --> URI Class Initialized
INFO - 2015-12-26 03:26:03 --> Router Class Initialized
INFO - 2015-12-26 03:26:03 --> Output Class Initialized
INFO - 2015-12-26 03:26:03 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:03 --> Input Class Initialized
INFO - 2015-12-26 03:26:03 --> Language Class Initialized
INFO - 2015-12-26 03:26:03 --> Loader Class Initialized
INFO - 2015-12-26 03:26:03 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:03 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:03 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:03 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:03 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:03 --> Model Class Initialized
INFO - 2015-12-26 03:26:03 --> Model Class Initialized
INFO - 2015-12-26 03:26:03 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:03 --> Total execution time: 0.1083
INFO - 2015-12-26 03:26:07 --> Config Class Initialized
INFO - 2015-12-26 03:26:07 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:07 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:07 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:07 --> URI Class Initialized
INFO - 2015-12-26 03:26:07 --> Router Class Initialized
INFO - 2015-12-26 03:26:07 --> Output Class Initialized
INFO - 2015-12-26 03:26:07 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:07 --> Input Class Initialized
INFO - 2015-12-26 03:26:07 --> Language Class Initialized
INFO - 2015-12-26 03:26:07 --> Loader Class Initialized
INFO - 2015-12-26 03:26:08 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:08 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:08 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:08 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:08 --> Model Class Initialized
INFO - 2015-12-26 03:26:08 --> Model Class Initialized
INFO - 2015-12-26 03:26:08 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:08 --> Total execution time: 0.1023
INFO - 2015-12-26 03:26:09 --> Config Class Initialized
INFO - 2015-12-26 03:26:09 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:09 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:09 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:09 --> URI Class Initialized
INFO - 2015-12-26 03:26:09 --> Router Class Initialized
INFO - 2015-12-26 03:26:09 --> Output Class Initialized
INFO - 2015-12-26 03:26:09 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:09 --> Input Class Initialized
INFO - 2015-12-26 03:26:09 --> Language Class Initialized
INFO - 2015-12-26 03:26:09 --> Loader Class Initialized
INFO - 2015-12-26 03:26:09 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:09 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:09 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:09 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:09 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:09 --> Model Class Initialized
INFO - 2015-12-26 03:26:09 --> Model Class Initialized
INFO - 2015-12-26 03:26:09 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:09 --> Total execution time: 0.1470
INFO - 2015-12-26 03:26:13 --> Config Class Initialized
INFO - 2015-12-26 03:26:13 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:13 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:13 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:13 --> URI Class Initialized
INFO - 2015-12-26 03:26:13 --> Router Class Initialized
INFO - 2015-12-26 03:26:13 --> Output Class Initialized
INFO - 2015-12-26 03:26:13 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:13 --> Input Class Initialized
INFO - 2015-12-26 03:26:13 --> Language Class Initialized
INFO - 2015-12-26 03:26:13 --> Loader Class Initialized
INFO - 2015-12-26 03:26:13 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:13 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:13 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:13 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:13 --> Model Class Initialized
INFO - 2015-12-26 03:26:13 --> Model Class Initialized
INFO - 2015-12-26 03:26:13 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:13 --> Total execution time: 0.0992
INFO - 2015-12-26 03:26:17 --> Config Class Initialized
INFO - 2015-12-26 03:26:17 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:17 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:17 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:17 --> URI Class Initialized
INFO - 2015-12-26 03:26:17 --> Router Class Initialized
INFO - 2015-12-26 03:26:17 --> Output Class Initialized
INFO - 2015-12-26 03:26:17 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:17 --> Input Class Initialized
INFO - 2015-12-26 03:26:17 --> Language Class Initialized
INFO - 2015-12-26 03:26:17 --> Loader Class Initialized
INFO - 2015-12-26 03:26:17 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:17 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:17 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:17 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:17 --> Model Class Initialized
INFO - 2015-12-26 03:26:17 --> Model Class Initialized
INFO - 2015-12-26 03:26:17 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:17 --> Total execution time: 0.1607
INFO - 2015-12-26 03:26:20 --> Config Class Initialized
INFO - 2015-12-26 03:26:20 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:20 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:20 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:20 --> URI Class Initialized
INFO - 2015-12-26 03:26:20 --> Router Class Initialized
INFO - 2015-12-26 03:26:20 --> Output Class Initialized
INFO - 2015-12-26 03:26:20 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:20 --> Input Class Initialized
INFO - 2015-12-26 03:26:20 --> Language Class Initialized
INFO - 2015-12-26 03:26:20 --> Loader Class Initialized
INFO - 2015-12-26 03:26:20 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:20 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:20 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:20 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:20 --> Model Class Initialized
INFO - 2015-12-26 03:26:20 --> Model Class Initialized
INFO - 2015-12-26 03:26:20 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:20 --> Total execution time: 0.1161
INFO - 2015-12-26 03:26:22 --> Config Class Initialized
INFO - 2015-12-26 03:26:22 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:22 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:22 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:22 --> URI Class Initialized
INFO - 2015-12-26 03:26:22 --> Router Class Initialized
INFO - 2015-12-26 03:26:22 --> Output Class Initialized
INFO - 2015-12-26 03:26:22 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:22 --> Input Class Initialized
INFO - 2015-12-26 03:26:22 --> Language Class Initialized
INFO - 2015-12-26 03:26:22 --> Loader Class Initialized
INFO - 2015-12-26 03:26:22 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:22 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:22 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:22 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:22 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:22 --> Model Class Initialized
INFO - 2015-12-26 03:26:22 --> Model Class Initialized
INFO - 2015-12-26 03:26:22 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:22 --> Total execution time: 0.2300
INFO - 2015-12-26 03:26:28 --> Config Class Initialized
INFO - 2015-12-26 03:26:28 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:28 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:28 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:28 --> URI Class Initialized
INFO - 2015-12-26 03:26:28 --> Router Class Initialized
INFO - 2015-12-26 03:26:28 --> Output Class Initialized
INFO - 2015-12-26 03:26:28 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:28 --> Input Class Initialized
INFO - 2015-12-26 03:26:28 --> Language Class Initialized
INFO - 2015-12-26 03:26:28 --> Loader Class Initialized
INFO - 2015-12-26 03:26:28 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:28 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:28 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:28 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:28 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:28 --> Model Class Initialized
INFO - 2015-12-26 03:26:28 --> Model Class Initialized
INFO - 2015-12-26 03:26:28 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:28 --> Total execution time: 0.1073
INFO - 2015-12-26 03:26:33 --> Config Class Initialized
INFO - 2015-12-26 03:26:33 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:33 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:33 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:33 --> URI Class Initialized
INFO - 2015-12-26 03:26:33 --> Router Class Initialized
INFO - 2015-12-26 03:26:33 --> Output Class Initialized
INFO - 2015-12-26 03:26:33 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:33 --> Input Class Initialized
INFO - 2015-12-26 03:26:33 --> Language Class Initialized
INFO - 2015-12-26 03:26:33 --> Loader Class Initialized
INFO - 2015-12-26 03:26:33 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:33 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:33 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:33 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:33 --> Model Class Initialized
INFO - 2015-12-26 03:26:33 --> Model Class Initialized
INFO - 2015-12-26 03:26:33 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:33 --> Total execution time: 0.1181
INFO - 2015-12-26 03:26:37 --> Config Class Initialized
INFO - 2015-12-26 03:26:37 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:37 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:37 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:37 --> URI Class Initialized
INFO - 2015-12-26 03:26:37 --> Router Class Initialized
INFO - 2015-12-26 03:26:37 --> Output Class Initialized
INFO - 2015-12-26 03:26:37 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:37 --> Input Class Initialized
INFO - 2015-12-26 03:26:37 --> Language Class Initialized
INFO - 2015-12-26 03:26:37 --> Loader Class Initialized
INFO - 2015-12-26 03:26:37 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:37 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:37 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:37 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:37 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:37 --> Model Class Initialized
INFO - 2015-12-26 03:26:37 --> Model Class Initialized
INFO - 2015-12-26 03:26:37 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:37 --> Total execution time: 0.1534
INFO - 2015-12-26 03:26:39 --> Config Class Initialized
INFO - 2015-12-26 03:26:39 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:39 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:39 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:39 --> URI Class Initialized
INFO - 2015-12-26 03:26:39 --> Router Class Initialized
INFO - 2015-12-26 03:26:39 --> Output Class Initialized
INFO - 2015-12-26 03:26:39 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:39 --> Input Class Initialized
INFO - 2015-12-26 03:26:39 --> Language Class Initialized
INFO - 2015-12-26 03:26:39 --> Loader Class Initialized
INFO - 2015-12-26 03:26:39 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:39 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:39 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:39 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:39 --> Model Class Initialized
INFO - 2015-12-26 03:26:39 --> Model Class Initialized
INFO - 2015-12-26 03:26:39 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:39 --> Total execution time: 0.2135
INFO - 2015-12-26 03:26:42 --> Config Class Initialized
INFO - 2015-12-26 03:26:42 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:42 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:42 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:42 --> URI Class Initialized
INFO - 2015-12-26 03:26:42 --> Router Class Initialized
INFO - 2015-12-26 03:26:42 --> Output Class Initialized
INFO - 2015-12-26 03:26:42 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:42 --> Input Class Initialized
INFO - 2015-12-26 03:26:42 --> Language Class Initialized
INFO - 2015-12-26 03:26:42 --> Loader Class Initialized
INFO - 2015-12-26 03:26:42 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:42 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:42 --> Controller Class Initialized
INFO - 2015-12-26 03:26:42 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 03:26:42 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:42 --> Total execution time: 0.0840
INFO - 2015-12-26 03:26:42 --> Config Class Initialized
INFO - 2015-12-26 03:26:42 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:42 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:42 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:42 --> URI Class Initialized
INFO - 2015-12-26 03:26:42 --> Router Class Initialized
INFO - 2015-12-26 03:26:42 --> Output Class Initialized
INFO - 2015-12-26 03:26:42 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:42 --> Input Class Initialized
INFO - 2015-12-26 03:26:42 --> Language Class Initialized
INFO - 2015-12-26 03:26:42 --> Loader Class Initialized
INFO - 2015-12-26 03:26:42 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:42 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:42 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:42 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:42 --> Model Class Initialized
INFO - 2015-12-26 03:26:42 --> Model Class Initialized
INFO - 2015-12-26 03:26:42 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:42 --> Total execution time: 0.1044
INFO - 2015-12-26 03:26:45 --> Config Class Initialized
INFO - 2015-12-26 03:26:45 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:45 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:45 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:45 --> URI Class Initialized
INFO - 2015-12-26 03:26:45 --> Router Class Initialized
INFO - 2015-12-26 03:26:45 --> Output Class Initialized
INFO - 2015-12-26 03:26:45 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:45 --> Input Class Initialized
INFO - 2015-12-26 03:26:45 --> Language Class Initialized
INFO - 2015-12-26 03:26:45 --> Loader Class Initialized
INFO - 2015-12-26 03:26:45 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:45 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:45 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:46 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:46 --> Model Class Initialized
INFO - 2015-12-26 03:26:46 --> Model Class Initialized
INFO - 2015-12-26 03:26:46 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:46 --> Total execution time: 0.1485
INFO - 2015-12-26 03:26:47 --> Config Class Initialized
INFO - 2015-12-26 03:26:47 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:47 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:47 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:47 --> URI Class Initialized
INFO - 2015-12-26 03:26:47 --> Router Class Initialized
INFO - 2015-12-26 03:26:47 --> Output Class Initialized
INFO - 2015-12-26 03:26:47 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:47 --> Input Class Initialized
INFO - 2015-12-26 03:26:47 --> Language Class Initialized
INFO - 2015-12-26 03:26:47 --> Loader Class Initialized
INFO - 2015-12-26 03:26:47 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:47 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:47 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:47 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:47 --> Model Class Initialized
INFO - 2015-12-26 03:26:47 --> Model Class Initialized
INFO - 2015-12-26 03:26:47 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:47 --> Total execution time: 0.1232
INFO - 2015-12-26 03:26:51 --> Config Class Initialized
INFO - 2015-12-26 03:26:51 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:51 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:51 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:51 --> URI Class Initialized
INFO - 2015-12-26 03:26:51 --> Router Class Initialized
INFO - 2015-12-26 03:26:51 --> Output Class Initialized
INFO - 2015-12-26 03:26:51 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:51 --> Input Class Initialized
INFO - 2015-12-26 03:26:51 --> Language Class Initialized
INFO - 2015-12-26 03:26:51 --> Loader Class Initialized
INFO - 2015-12-26 03:26:51 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:51 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:51 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:51 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:51 --> Model Class Initialized
INFO - 2015-12-26 03:26:51 --> Model Class Initialized
INFO - 2015-12-26 03:26:51 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:51 --> Total execution time: 0.1071
INFO - 2015-12-26 03:26:53 --> Config Class Initialized
INFO - 2015-12-26 03:26:53 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:53 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:53 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:53 --> URI Class Initialized
INFO - 2015-12-26 03:26:53 --> Router Class Initialized
INFO - 2015-12-26 03:26:53 --> Output Class Initialized
INFO - 2015-12-26 03:26:53 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:53 --> Input Class Initialized
INFO - 2015-12-26 03:26:53 --> Language Class Initialized
INFO - 2015-12-26 03:26:53 --> Loader Class Initialized
INFO - 2015-12-26 03:26:53 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:53 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:53 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:53 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:53 --> Model Class Initialized
INFO - 2015-12-26 03:26:53 --> Model Class Initialized
INFO - 2015-12-26 03:26:53 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:53 --> Total execution time: 0.1585
INFO - 2015-12-26 03:26:55 --> Config Class Initialized
INFO - 2015-12-26 03:26:56 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:56 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:56 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:56 --> URI Class Initialized
INFO - 2015-12-26 03:26:56 --> Router Class Initialized
INFO - 2015-12-26 03:26:56 --> Output Class Initialized
INFO - 2015-12-26 03:26:56 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:56 --> Input Class Initialized
INFO - 2015-12-26 03:26:56 --> Language Class Initialized
INFO - 2015-12-26 03:26:56 --> Loader Class Initialized
INFO - 2015-12-26 03:26:56 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:56 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:56 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:56 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:56 --> Model Class Initialized
INFO - 2015-12-26 03:26:56 --> Model Class Initialized
INFO - 2015-12-26 03:26:56 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:56 --> Total execution time: 0.1152
INFO - 2015-12-26 03:26:57 --> Config Class Initialized
INFO - 2015-12-26 03:26:57 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:57 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:57 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:57 --> URI Class Initialized
INFO - 2015-12-26 03:26:57 --> Router Class Initialized
INFO - 2015-12-26 03:26:57 --> Output Class Initialized
INFO - 2015-12-26 03:26:57 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:57 --> Input Class Initialized
INFO - 2015-12-26 03:26:57 --> Language Class Initialized
INFO - 2015-12-26 03:26:57 --> Loader Class Initialized
INFO - 2015-12-26 03:26:57 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:57 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:57 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:57 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:57 --> Model Class Initialized
INFO - 2015-12-26 03:26:57 --> Model Class Initialized
INFO - 2015-12-26 03:26:57 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:57 --> Total execution time: 0.1505
INFO - 2015-12-26 03:26:59 --> Config Class Initialized
INFO - 2015-12-26 03:26:59 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:26:59 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:26:59 --> Utf8 Class Initialized
INFO - 2015-12-26 03:26:59 --> URI Class Initialized
INFO - 2015-12-26 03:26:59 --> Router Class Initialized
INFO - 2015-12-26 03:26:59 --> Output Class Initialized
INFO - 2015-12-26 03:26:59 --> Security Class Initialized
DEBUG - 2015-12-26 03:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:26:59 --> Input Class Initialized
INFO - 2015-12-26 03:26:59 --> Language Class Initialized
INFO - 2015-12-26 03:26:59 --> Loader Class Initialized
INFO - 2015-12-26 03:26:59 --> Helper loaded: url_helper
INFO - 2015-12-26 03:26:59 --> Database Driver Class Initialized
INFO - 2015-12-26 03:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:26:59 --> Controller Class Initialized
DEBUG - 2015-12-26 03:26:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:26:59 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:26:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:26:59 --> Model Class Initialized
INFO - 2015-12-26 03:26:59 --> Model Class Initialized
INFO - 2015-12-26 03:26:59 --> Final output sent to browser
DEBUG - 2015-12-26 03:26:59 --> Total execution time: 0.1495
INFO - 2015-12-26 03:27:01 --> Config Class Initialized
INFO - 2015-12-26 03:27:01 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:01 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:01 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:01 --> URI Class Initialized
INFO - 2015-12-26 03:27:01 --> Router Class Initialized
INFO - 2015-12-26 03:27:01 --> Output Class Initialized
INFO - 2015-12-26 03:27:01 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:01 --> Input Class Initialized
INFO - 2015-12-26 03:27:01 --> Language Class Initialized
INFO - 2015-12-26 03:27:01 --> Loader Class Initialized
INFO - 2015-12-26 03:27:01 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:01 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:01 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:01 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:01 --> Model Class Initialized
INFO - 2015-12-26 03:27:01 --> Model Class Initialized
INFO - 2015-12-26 03:27:01 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:01 --> Total execution time: 0.1468
INFO - 2015-12-26 03:27:03 --> Config Class Initialized
INFO - 2015-12-26 03:27:03 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:03 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:03 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:03 --> URI Class Initialized
INFO - 2015-12-26 03:27:03 --> Router Class Initialized
INFO - 2015-12-26 03:27:03 --> Output Class Initialized
INFO - 2015-12-26 03:27:03 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:03 --> Input Class Initialized
INFO - 2015-12-26 03:27:03 --> Language Class Initialized
INFO - 2015-12-26 03:27:03 --> Loader Class Initialized
INFO - 2015-12-26 03:27:03 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:03 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:03 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:03 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:03 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:03 --> Model Class Initialized
INFO - 2015-12-26 03:27:03 --> Model Class Initialized
INFO - 2015-12-26 03:27:03 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:03 --> Total execution time: 0.1026
INFO - 2015-12-26 03:27:04 --> Config Class Initialized
INFO - 2015-12-26 03:27:04 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:04 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:04 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:04 --> URI Class Initialized
INFO - 2015-12-26 03:27:04 --> Router Class Initialized
INFO - 2015-12-26 03:27:04 --> Output Class Initialized
INFO - 2015-12-26 03:27:04 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:04 --> Input Class Initialized
INFO - 2015-12-26 03:27:04 --> Language Class Initialized
INFO - 2015-12-26 03:27:04 --> Loader Class Initialized
INFO - 2015-12-26 03:27:04 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:04 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:04 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:04 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:04 --> Model Class Initialized
INFO - 2015-12-26 03:27:04 --> Model Class Initialized
INFO - 2015-12-26 03:27:04 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:04 --> Total execution time: 0.1461
INFO - 2015-12-26 03:27:19 --> Config Class Initialized
INFO - 2015-12-26 03:27:19 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:19 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:19 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:19 --> URI Class Initialized
INFO - 2015-12-26 03:27:19 --> Router Class Initialized
INFO - 2015-12-26 03:27:19 --> Output Class Initialized
INFO - 2015-12-26 03:27:19 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:19 --> Input Class Initialized
INFO - 2015-12-26 03:27:19 --> Language Class Initialized
INFO - 2015-12-26 03:27:19 --> Loader Class Initialized
INFO - 2015-12-26 03:27:19 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:19 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:19 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:19 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:19 --> Model Class Initialized
INFO - 2015-12-26 03:27:19 --> Model Class Initialized
INFO - 2015-12-26 03:27:19 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:19 --> Total execution time: 0.1080
INFO - 2015-12-26 03:27:21 --> Config Class Initialized
INFO - 2015-12-26 03:27:21 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:21 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:21 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:21 --> URI Class Initialized
INFO - 2015-12-26 03:27:21 --> Router Class Initialized
INFO - 2015-12-26 03:27:21 --> Output Class Initialized
INFO - 2015-12-26 03:27:21 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:21 --> Input Class Initialized
INFO - 2015-12-26 03:27:21 --> Language Class Initialized
INFO - 2015-12-26 03:27:21 --> Loader Class Initialized
INFO - 2015-12-26 03:27:21 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:21 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:21 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:21 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:21 --> Model Class Initialized
INFO - 2015-12-26 03:27:21 --> Model Class Initialized
INFO - 2015-12-26 03:27:21 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:21 --> Total execution time: 0.1436
INFO - 2015-12-26 03:27:31 --> Config Class Initialized
INFO - 2015-12-26 03:27:31 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:31 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:31 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:31 --> URI Class Initialized
INFO - 2015-12-26 03:27:31 --> Router Class Initialized
INFO - 2015-12-26 03:27:31 --> Output Class Initialized
INFO - 2015-12-26 03:27:31 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:31 --> Input Class Initialized
INFO - 2015-12-26 03:27:31 --> Language Class Initialized
INFO - 2015-12-26 03:27:31 --> Loader Class Initialized
INFO - 2015-12-26 03:27:31 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:31 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:31 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:31 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:31 --> Model Class Initialized
INFO - 2015-12-26 03:27:31 --> Model Class Initialized
INFO - 2015-12-26 03:27:31 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:31 --> Total execution time: 0.1234
INFO - 2015-12-26 03:27:32 --> Config Class Initialized
INFO - 2015-12-26 03:27:32 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:32 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:32 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:32 --> URI Class Initialized
INFO - 2015-12-26 03:27:32 --> Router Class Initialized
INFO - 2015-12-26 03:27:32 --> Output Class Initialized
INFO - 2015-12-26 03:27:32 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:32 --> Input Class Initialized
INFO - 2015-12-26 03:27:32 --> Language Class Initialized
INFO - 2015-12-26 03:27:32 --> Loader Class Initialized
INFO - 2015-12-26 03:27:32 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:32 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:32 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:32 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:32 --> Model Class Initialized
INFO - 2015-12-26 03:27:32 --> Model Class Initialized
INFO - 2015-12-26 03:27:32 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:32 --> Total execution time: 0.1100
INFO - 2015-12-26 03:27:41 --> Config Class Initialized
INFO - 2015-12-26 03:27:41 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:41 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:41 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:41 --> URI Class Initialized
INFO - 2015-12-26 03:27:41 --> Router Class Initialized
INFO - 2015-12-26 03:27:41 --> Output Class Initialized
INFO - 2015-12-26 03:27:41 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:41 --> Input Class Initialized
INFO - 2015-12-26 03:27:41 --> Language Class Initialized
INFO - 2015-12-26 03:27:41 --> Loader Class Initialized
INFO - 2015-12-26 03:27:41 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:41 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:41 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:41 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:41 --> Model Class Initialized
INFO - 2015-12-26 03:27:41 --> Model Class Initialized
INFO - 2015-12-26 03:27:41 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:41 --> Total execution time: 0.1122
INFO - 2015-12-26 03:27:43 --> Config Class Initialized
INFO - 2015-12-26 03:27:43 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:43 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:43 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:43 --> URI Class Initialized
INFO - 2015-12-26 03:27:43 --> Router Class Initialized
INFO - 2015-12-26 03:27:43 --> Output Class Initialized
INFO - 2015-12-26 03:27:43 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:43 --> Input Class Initialized
INFO - 2015-12-26 03:27:43 --> Language Class Initialized
INFO - 2015-12-26 03:27:43 --> Loader Class Initialized
INFO - 2015-12-26 03:27:43 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:43 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:43 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:43 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:43 --> Model Class Initialized
INFO - 2015-12-26 03:27:43 --> Model Class Initialized
INFO - 2015-12-26 03:27:43 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:43 --> Total execution time: 0.1785
INFO - 2015-12-26 03:27:48 --> Config Class Initialized
INFO - 2015-12-26 03:27:48 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:48 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:48 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:48 --> URI Class Initialized
DEBUG - 2015-12-26 03:27:48 --> No URI present. Default controller set.
INFO - 2015-12-26 03:27:48 --> Router Class Initialized
INFO - 2015-12-26 03:27:48 --> Output Class Initialized
INFO - 2015-12-26 03:27:48 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:48 --> Input Class Initialized
INFO - 2015-12-26 03:27:48 --> Language Class Initialized
INFO - 2015-12-26 03:27:48 --> Loader Class Initialized
INFO - 2015-12-26 03:27:48 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:48 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:48 --> Controller Class Initialized
INFO - 2015-12-26 03:27:48 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 03:27:48 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:48 --> Total execution time: 0.1075
INFO - 2015-12-26 03:27:49 --> Config Class Initialized
INFO - 2015-12-26 03:27:49 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:49 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:49 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:49 --> URI Class Initialized
INFO - 2015-12-26 03:27:49 --> Router Class Initialized
INFO - 2015-12-26 03:27:49 --> Output Class Initialized
INFO - 2015-12-26 03:27:49 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:49 --> Input Class Initialized
INFO - 2015-12-26 03:27:49 --> Language Class Initialized
INFO - 2015-12-26 03:27:49 --> Loader Class Initialized
INFO - 2015-12-26 03:27:49 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:49 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:49 --> Controller Class Initialized
INFO - 2015-12-26 03:27:49 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 03:27:49 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:49 --> Total execution time: 0.0816
INFO - 2015-12-26 03:27:49 --> Config Class Initialized
INFO - 2015-12-26 03:27:49 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:49 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:49 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:49 --> URI Class Initialized
INFO - 2015-12-26 03:27:49 --> Router Class Initialized
INFO - 2015-12-26 03:27:49 --> Output Class Initialized
INFO - 2015-12-26 03:27:49 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:49 --> Input Class Initialized
INFO - 2015-12-26 03:27:49 --> Language Class Initialized
INFO - 2015-12-26 03:27:49 --> Loader Class Initialized
INFO - 2015-12-26 03:27:49 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:49 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:49 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:49 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:49 --> Model Class Initialized
INFO - 2015-12-26 03:27:49 --> Model Class Initialized
INFO - 2015-12-26 03:27:49 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:49 --> Total execution time: 0.0985
INFO - 2015-12-26 03:27:51 --> Config Class Initialized
INFO - 2015-12-26 03:27:51 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:51 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:51 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:51 --> URI Class Initialized
INFO - 2015-12-26 03:27:51 --> Router Class Initialized
INFO - 2015-12-26 03:27:51 --> Output Class Initialized
INFO - 2015-12-26 03:27:51 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:51 --> Input Class Initialized
INFO - 2015-12-26 03:27:51 --> Language Class Initialized
INFO - 2015-12-26 03:27:51 --> Loader Class Initialized
INFO - 2015-12-26 03:27:51 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:51 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:51 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:51 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:51 --> Model Class Initialized
INFO - 2015-12-26 03:27:51 --> Model Class Initialized
INFO - 2015-12-26 03:27:51 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:51 --> Total execution time: 0.1125
INFO - 2015-12-26 03:27:53 --> Config Class Initialized
INFO - 2015-12-26 03:27:53 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:53 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:53 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:53 --> URI Class Initialized
INFO - 2015-12-26 03:27:53 --> Router Class Initialized
INFO - 2015-12-26 03:27:53 --> Output Class Initialized
INFO - 2015-12-26 03:27:53 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:53 --> Input Class Initialized
INFO - 2015-12-26 03:27:53 --> Language Class Initialized
INFO - 2015-12-26 03:27:53 --> Loader Class Initialized
INFO - 2015-12-26 03:27:53 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:53 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:53 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:53 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:53 --> Model Class Initialized
INFO - 2015-12-26 03:27:53 --> Model Class Initialized
INFO - 2015-12-26 03:27:53 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:53 --> Total execution time: 0.1188
INFO - 2015-12-26 03:27:54 --> Config Class Initialized
INFO - 2015-12-26 03:27:54 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:54 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:54 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:54 --> URI Class Initialized
INFO - 2015-12-26 03:27:54 --> Router Class Initialized
INFO - 2015-12-26 03:27:54 --> Output Class Initialized
INFO - 2015-12-26 03:27:54 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:54 --> Input Class Initialized
INFO - 2015-12-26 03:27:54 --> Language Class Initialized
INFO - 2015-12-26 03:27:54 --> Loader Class Initialized
INFO - 2015-12-26 03:27:54 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:54 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:54 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:54 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:54 --> Model Class Initialized
INFO - 2015-12-26 03:27:54 --> Model Class Initialized
INFO - 2015-12-26 03:27:55 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:55 --> Total execution time: 0.1070
INFO - 2015-12-26 03:27:56 --> Config Class Initialized
INFO - 2015-12-26 03:27:56 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:56 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:56 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:56 --> URI Class Initialized
INFO - 2015-12-26 03:27:56 --> Router Class Initialized
INFO - 2015-12-26 03:27:56 --> Output Class Initialized
INFO - 2015-12-26 03:27:56 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:56 --> Input Class Initialized
INFO - 2015-12-26 03:27:56 --> Language Class Initialized
INFO - 2015-12-26 03:27:56 --> Loader Class Initialized
INFO - 2015-12-26 03:27:56 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:56 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:56 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:56 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:56 --> Model Class Initialized
INFO - 2015-12-26 03:27:56 --> Model Class Initialized
INFO - 2015-12-26 03:27:56 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:56 --> Total execution time: 0.1514
INFO - 2015-12-26 03:27:59 --> Config Class Initialized
INFO - 2015-12-26 03:27:59 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:27:59 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:27:59 --> Utf8 Class Initialized
INFO - 2015-12-26 03:27:59 --> URI Class Initialized
INFO - 2015-12-26 03:27:59 --> Router Class Initialized
INFO - 2015-12-26 03:27:59 --> Output Class Initialized
INFO - 2015-12-26 03:27:59 --> Security Class Initialized
DEBUG - 2015-12-26 03:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:27:59 --> Input Class Initialized
INFO - 2015-12-26 03:27:59 --> Language Class Initialized
INFO - 2015-12-26 03:27:59 --> Loader Class Initialized
INFO - 2015-12-26 03:27:59 --> Helper loaded: url_helper
INFO - 2015-12-26 03:27:59 --> Database Driver Class Initialized
INFO - 2015-12-26 03:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:27:59 --> Controller Class Initialized
DEBUG - 2015-12-26 03:27:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:27:59 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:27:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:27:59 --> Model Class Initialized
INFO - 2015-12-26 03:27:59 --> Model Class Initialized
INFO - 2015-12-26 03:27:59 --> Final output sent to browser
DEBUG - 2015-12-26 03:27:59 --> Total execution time: 0.1274
INFO - 2015-12-26 03:28:00 --> Config Class Initialized
INFO - 2015-12-26 03:28:00 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:00 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:00 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:00 --> URI Class Initialized
INFO - 2015-12-26 03:28:00 --> Router Class Initialized
INFO - 2015-12-26 03:28:00 --> Output Class Initialized
INFO - 2015-12-26 03:28:00 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:00 --> Input Class Initialized
INFO - 2015-12-26 03:28:00 --> Language Class Initialized
INFO - 2015-12-26 03:28:00 --> Loader Class Initialized
INFO - 2015-12-26 03:28:00 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:00 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:00 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:00 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:00 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:00 --> Model Class Initialized
INFO - 2015-12-26 03:28:00 --> Model Class Initialized
INFO - 2015-12-26 03:28:00 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:00 --> Total execution time: 0.1081
INFO - 2015-12-26 03:28:03 --> Config Class Initialized
INFO - 2015-12-26 03:28:03 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:03 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:03 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:03 --> URI Class Initialized
INFO - 2015-12-26 03:28:03 --> Router Class Initialized
INFO - 2015-12-26 03:28:03 --> Output Class Initialized
INFO - 2015-12-26 03:28:03 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:03 --> Input Class Initialized
INFO - 2015-12-26 03:28:03 --> Language Class Initialized
INFO - 2015-12-26 03:28:03 --> Loader Class Initialized
INFO - 2015-12-26 03:28:03 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:03 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:03 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:03 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:03 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:03 --> Model Class Initialized
INFO - 2015-12-26 03:28:03 --> Model Class Initialized
INFO - 2015-12-26 03:28:03 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:03 --> Total execution time: 0.1002
INFO - 2015-12-26 03:28:08 --> Config Class Initialized
INFO - 2015-12-26 03:28:08 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:08 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:08 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:08 --> URI Class Initialized
INFO - 2015-12-26 03:28:08 --> Router Class Initialized
INFO - 2015-12-26 03:28:08 --> Output Class Initialized
INFO - 2015-12-26 03:28:08 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:08 --> Input Class Initialized
INFO - 2015-12-26 03:28:08 --> Language Class Initialized
INFO - 2015-12-26 03:28:08 --> Loader Class Initialized
INFO - 2015-12-26 03:28:08 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:08 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:08 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:08 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:08 --> Model Class Initialized
INFO - 2015-12-26 03:28:08 --> Model Class Initialized
INFO - 2015-12-26 03:28:08 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:08 --> Total execution time: 0.1065
INFO - 2015-12-26 03:28:11 --> Config Class Initialized
INFO - 2015-12-26 03:28:11 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:11 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:11 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:11 --> URI Class Initialized
INFO - 2015-12-26 03:28:11 --> Router Class Initialized
INFO - 2015-12-26 03:28:11 --> Output Class Initialized
INFO - 2015-12-26 03:28:11 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:11 --> Input Class Initialized
INFO - 2015-12-26 03:28:11 --> Language Class Initialized
INFO - 2015-12-26 03:28:11 --> Loader Class Initialized
INFO - 2015-12-26 03:28:11 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:11 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:11 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:11 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:11 --> Model Class Initialized
INFO - 2015-12-26 03:28:11 --> Model Class Initialized
INFO - 2015-12-26 03:28:11 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:11 --> Total execution time: 0.1369
INFO - 2015-12-26 03:28:12 --> Config Class Initialized
INFO - 2015-12-26 03:28:12 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:12 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:12 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:12 --> URI Class Initialized
INFO - 2015-12-26 03:28:12 --> Router Class Initialized
INFO - 2015-12-26 03:28:12 --> Output Class Initialized
INFO - 2015-12-26 03:28:12 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:12 --> Input Class Initialized
INFO - 2015-12-26 03:28:12 --> Language Class Initialized
INFO - 2015-12-26 03:28:12 --> Loader Class Initialized
INFO - 2015-12-26 03:28:12 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:12 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:12 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:12 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:12 --> Model Class Initialized
INFO - 2015-12-26 03:28:12 --> Model Class Initialized
INFO - 2015-12-26 03:28:12 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:12 --> Total execution time: 0.0977
INFO - 2015-12-26 03:28:16 --> Config Class Initialized
INFO - 2015-12-26 03:28:16 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:16 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:16 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:16 --> URI Class Initialized
INFO - 2015-12-26 03:28:16 --> Router Class Initialized
INFO - 2015-12-26 03:28:16 --> Output Class Initialized
INFO - 2015-12-26 03:28:16 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:16 --> Input Class Initialized
INFO - 2015-12-26 03:28:16 --> Language Class Initialized
INFO - 2015-12-26 03:28:16 --> Loader Class Initialized
INFO - 2015-12-26 03:28:16 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:16 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:16 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:16 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:16 --> Model Class Initialized
INFO - 2015-12-26 03:28:16 --> Model Class Initialized
INFO - 2015-12-26 03:28:16 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:16 --> Total execution time: 0.1024
INFO - 2015-12-26 03:28:17 --> Config Class Initialized
INFO - 2015-12-26 03:28:17 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:17 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:17 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:17 --> URI Class Initialized
INFO - 2015-12-26 03:28:17 --> Router Class Initialized
INFO - 2015-12-26 03:28:17 --> Output Class Initialized
INFO - 2015-12-26 03:28:17 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:17 --> Input Class Initialized
INFO - 2015-12-26 03:28:17 --> Language Class Initialized
INFO - 2015-12-26 03:28:17 --> Loader Class Initialized
INFO - 2015-12-26 03:28:17 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:17 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:17 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:17 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:17 --> Model Class Initialized
INFO - 2015-12-26 03:28:17 --> Model Class Initialized
INFO - 2015-12-26 03:28:17 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:17 --> Total execution time: 0.1056
INFO - 2015-12-26 03:28:19 --> Config Class Initialized
INFO - 2015-12-26 03:28:19 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:19 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:19 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:19 --> URI Class Initialized
INFO - 2015-12-26 03:28:19 --> Router Class Initialized
INFO - 2015-12-26 03:28:19 --> Output Class Initialized
INFO - 2015-12-26 03:28:19 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:19 --> Input Class Initialized
INFO - 2015-12-26 03:28:19 --> Language Class Initialized
INFO - 2015-12-26 03:28:20 --> Loader Class Initialized
INFO - 2015-12-26 03:28:20 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:20 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:20 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:20 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:20 --> Model Class Initialized
INFO - 2015-12-26 03:28:20 --> Model Class Initialized
INFO - 2015-12-26 03:28:20 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:20 --> Total execution time: 0.1452
INFO - 2015-12-26 03:28:21 --> Config Class Initialized
INFO - 2015-12-26 03:28:21 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:21 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:21 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:21 --> URI Class Initialized
INFO - 2015-12-26 03:28:21 --> Router Class Initialized
INFO - 2015-12-26 03:28:21 --> Output Class Initialized
INFO - 2015-12-26 03:28:21 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:21 --> Input Class Initialized
INFO - 2015-12-26 03:28:21 --> Language Class Initialized
INFO - 2015-12-26 03:28:21 --> Loader Class Initialized
INFO - 2015-12-26 03:28:21 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:21 --> Database Driver Class Initialized
ERROR - 2015-12-26 03:28:21 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2015-12-26 03:28:21 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
ERROR - 2015-12-26 03:28:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/libraries/Session/Session.php 168
INFO - 2015-12-26 03:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:21 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:21 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:21 --> Model Class Initialized
INFO - 2015-12-26 03:28:21 --> Model Class Initialized
ERROR - 2015-12-26 03:28:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/core/Common.php 573
INFO - 2015-12-26 03:28:21 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:21 --> Total execution time: 0.1271
INFO - 2015-12-26 03:28:24 --> Config Class Initialized
INFO - 2015-12-26 03:28:24 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:24 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:24 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:24 --> URI Class Initialized
INFO - 2015-12-26 03:28:24 --> Router Class Initialized
INFO - 2015-12-26 03:28:24 --> Output Class Initialized
INFO - 2015-12-26 03:28:24 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:24 --> Input Class Initialized
INFO - 2015-12-26 03:28:24 --> Language Class Initialized
INFO - 2015-12-26 03:28:24 --> Loader Class Initialized
INFO - 2015-12-26 03:28:24 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:24 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:24 --> Controller Class Initialized
INFO - 2015-12-26 03:28:24 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 03:28:24 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:24 --> Total execution time: 0.0898
INFO - 2015-12-26 03:28:24 --> Config Class Initialized
INFO - 2015-12-26 03:28:24 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:24 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:24 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:24 --> URI Class Initialized
DEBUG - 2015-12-26 03:28:24 --> No URI present. Default controller set.
INFO - 2015-12-26 03:28:24 --> Router Class Initialized
INFO - 2015-12-26 03:28:24 --> Output Class Initialized
INFO - 2015-12-26 03:28:24 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:24 --> Input Class Initialized
INFO - 2015-12-26 03:28:24 --> Language Class Initialized
INFO - 2015-12-26 03:28:24 --> Loader Class Initialized
INFO - 2015-12-26 03:28:24 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:24 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:24 --> Controller Class Initialized
INFO - 2015-12-26 03:28:24 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 03:28:24 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:24 --> Total execution time: 0.0898
INFO - 2015-12-26 03:28:26 --> Config Class Initialized
INFO - 2015-12-26 03:28:26 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:26 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:26 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:26 --> URI Class Initialized
INFO - 2015-12-26 03:28:26 --> Router Class Initialized
INFO - 2015-12-26 03:28:26 --> Output Class Initialized
INFO - 2015-12-26 03:28:26 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:26 --> Input Class Initialized
INFO - 2015-12-26 03:28:26 --> Language Class Initialized
INFO - 2015-12-26 03:28:26 --> Loader Class Initialized
INFO - 2015-12-26 03:28:26 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:26 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:26 --> Controller Class Initialized
INFO - 2015-12-26 03:28:26 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 03:28:26 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:26 --> Total execution time: 0.1008
INFO - 2015-12-26 03:28:26 --> Config Class Initialized
INFO - 2015-12-26 03:28:26 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:26 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:26 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:26 --> URI Class Initialized
INFO - 2015-12-26 03:28:26 --> Router Class Initialized
INFO - 2015-12-26 03:28:26 --> Output Class Initialized
INFO - 2015-12-26 03:28:26 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:26 --> Input Class Initialized
INFO - 2015-12-26 03:28:26 --> Language Class Initialized
INFO - 2015-12-26 03:28:26 --> Loader Class Initialized
INFO - 2015-12-26 03:28:26 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:26 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:26 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:26 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:26 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:26 --> Model Class Initialized
INFO - 2015-12-26 03:28:26 --> Model Class Initialized
INFO - 2015-12-26 03:28:26 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:26 --> Total execution time: 0.1041
INFO - 2015-12-26 03:28:28 --> Config Class Initialized
INFO - 2015-12-26 03:28:28 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:28 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:28 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:28 --> URI Class Initialized
INFO - 2015-12-26 03:28:28 --> Router Class Initialized
INFO - 2015-12-26 03:28:28 --> Output Class Initialized
INFO - 2015-12-26 03:28:28 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:28 --> Input Class Initialized
INFO - 2015-12-26 03:28:28 --> Language Class Initialized
INFO - 2015-12-26 03:28:28 --> Loader Class Initialized
INFO - 2015-12-26 03:28:28 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:28 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:28 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:28 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:28 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:28 --> Model Class Initialized
INFO - 2015-12-26 03:28:28 --> Model Class Initialized
INFO - 2015-12-26 03:28:28 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:28 --> Total execution time: 0.1026
INFO - 2015-12-26 03:28:29 --> Config Class Initialized
INFO - 2015-12-26 03:28:29 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:29 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:29 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:29 --> URI Class Initialized
INFO - 2015-12-26 03:28:29 --> Router Class Initialized
INFO - 2015-12-26 03:28:29 --> Output Class Initialized
INFO - 2015-12-26 03:28:29 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:29 --> Input Class Initialized
INFO - 2015-12-26 03:28:29 --> Language Class Initialized
INFO - 2015-12-26 03:28:29 --> Loader Class Initialized
INFO - 2015-12-26 03:28:29 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:29 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:29 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:29 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:30 --> Model Class Initialized
INFO - 2015-12-26 03:28:30 --> Model Class Initialized
INFO - 2015-12-26 03:28:30 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:30 --> Total execution time: 0.1014
INFO - 2015-12-26 03:28:32 --> Config Class Initialized
INFO - 2015-12-26 03:28:32 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:32 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:32 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:32 --> URI Class Initialized
INFO - 2015-12-26 03:28:32 --> Router Class Initialized
INFO - 2015-12-26 03:28:32 --> Output Class Initialized
INFO - 2015-12-26 03:28:32 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:32 --> Input Class Initialized
INFO - 2015-12-26 03:28:32 --> Language Class Initialized
INFO - 2015-12-26 03:28:32 --> Loader Class Initialized
INFO - 2015-12-26 03:28:32 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:32 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:32 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:32 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:32 --> Model Class Initialized
INFO - 2015-12-26 03:28:32 --> Model Class Initialized
INFO - 2015-12-26 03:28:32 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:32 --> Total execution time: 0.1197
INFO - 2015-12-26 03:28:33 --> Config Class Initialized
INFO - 2015-12-26 03:28:33 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:33 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:33 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:33 --> URI Class Initialized
INFO - 2015-12-26 03:28:33 --> Router Class Initialized
INFO - 2015-12-26 03:28:33 --> Output Class Initialized
INFO - 2015-12-26 03:28:33 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:33 --> Input Class Initialized
INFO - 2015-12-26 03:28:33 --> Language Class Initialized
INFO - 2015-12-26 03:28:33 --> Loader Class Initialized
INFO - 2015-12-26 03:28:33 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:33 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:33 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:33 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:33 --> Model Class Initialized
INFO - 2015-12-26 03:28:33 --> Model Class Initialized
INFO - 2015-12-26 03:28:33 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:33 --> Total execution time: 0.1524
INFO - 2015-12-26 03:28:37 --> Config Class Initialized
INFO - 2015-12-26 03:28:37 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:37 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:37 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:37 --> URI Class Initialized
INFO - 2015-12-26 03:28:37 --> Router Class Initialized
INFO - 2015-12-26 03:28:37 --> Output Class Initialized
INFO - 2015-12-26 03:28:37 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:37 --> Input Class Initialized
INFO - 2015-12-26 03:28:37 --> Language Class Initialized
INFO - 2015-12-26 03:28:37 --> Loader Class Initialized
INFO - 2015-12-26 03:28:37 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:37 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:37 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:37 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:37 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:37 --> Model Class Initialized
INFO - 2015-12-26 03:28:37 --> Model Class Initialized
INFO - 2015-12-26 03:28:37 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:37 --> Total execution time: 0.1654
INFO - 2015-12-26 03:28:39 --> Config Class Initialized
INFO - 2015-12-26 03:28:39 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:39 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:39 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:39 --> URI Class Initialized
INFO - 2015-12-26 03:28:39 --> Router Class Initialized
INFO - 2015-12-26 03:28:39 --> Output Class Initialized
INFO - 2015-12-26 03:28:39 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:39 --> Input Class Initialized
INFO - 2015-12-26 03:28:39 --> Language Class Initialized
INFO - 2015-12-26 03:28:39 --> Loader Class Initialized
INFO - 2015-12-26 03:28:39 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:39 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:39 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:39 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:39 --> Model Class Initialized
INFO - 2015-12-26 03:28:39 --> Model Class Initialized
INFO - 2015-12-26 03:28:39 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:39 --> Total execution time: 0.1202
INFO - 2015-12-26 03:28:45 --> Config Class Initialized
INFO - 2015-12-26 03:28:45 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:45 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:45 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:45 --> URI Class Initialized
INFO - 2015-12-26 03:28:45 --> Router Class Initialized
INFO - 2015-12-26 03:28:45 --> Output Class Initialized
INFO - 2015-12-26 03:28:45 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:45 --> Input Class Initialized
INFO - 2015-12-26 03:28:45 --> Language Class Initialized
INFO - 2015-12-26 03:28:45 --> Loader Class Initialized
INFO - 2015-12-26 03:28:45 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:45 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:45 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:45 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:45 --> Model Class Initialized
INFO - 2015-12-26 03:28:45 --> Model Class Initialized
INFO - 2015-12-26 03:28:45 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:45 --> Total execution time: 0.1183
INFO - 2015-12-26 03:28:46 --> Config Class Initialized
INFO - 2015-12-26 03:28:46 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:46 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:46 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:46 --> URI Class Initialized
INFO - 2015-12-26 03:28:46 --> Router Class Initialized
INFO - 2015-12-26 03:28:46 --> Output Class Initialized
INFO - 2015-12-26 03:28:46 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:46 --> Input Class Initialized
INFO - 2015-12-26 03:28:46 --> Language Class Initialized
INFO - 2015-12-26 03:28:46 --> Loader Class Initialized
INFO - 2015-12-26 03:28:46 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:46 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:46 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:46 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:47 --> Model Class Initialized
INFO - 2015-12-26 03:28:47 --> Model Class Initialized
INFO - 2015-12-26 03:28:47 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:47 --> Total execution time: 0.2358
INFO - 2015-12-26 03:28:50 --> Config Class Initialized
INFO - 2015-12-26 03:28:50 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:50 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:50 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:50 --> URI Class Initialized
INFO - 2015-12-26 03:28:50 --> Router Class Initialized
INFO - 2015-12-26 03:28:50 --> Output Class Initialized
INFO - 2015-12-26 03:28:50 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:50 --> Input Class Initialized
INFO - 2015-12-26 03:28:50 --> Language Class Initialized
INFO - 2015-12-26 03:28:50 --> Loader Class Initialized
INFO - 2015-12-26 03:28:50 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:50 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:50 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:50 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:50 --> Model Class Initialized
INFO - 2015-12-26 03:28:50 --> Model Class Initialized
INFO - 2015-12-26 03:28:50 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:50 --> Total execution time: 0.1248
INFO - 2015-12-26 03:28:51 --> Config Class Initialized
INFO - 2015-12-26 03:28:51 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:51 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:51 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:51 --> URI Class Initialized
INFO - 2015-12-26 03:28:51 --> Router Class Initialized
INFO - 2015-12-26 03:28:51 --> Output Class Initialized
INFO - 2015-12-26 03:28:51 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:51 --> Input Class Initialized
INFO - 2015-12-26 03:28:51 --> Language Class Initialized
INFO - 2015-12-26 03:28:51 --> Loader Class Initialized
INFO - 2015-12-26 03:28:51 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:51 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:51 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:51 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:51 --> Model Class Initialized
INFO - 2015-12-26 03:28:51 --> Model Class Initialized
INFO - 2015-12-26 03:28:51 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:51 --> Total execution time: 0.1019
INFO - 2015-12-26 03:28:55 --> Config Class Initialized
INFO - 2015-12-26 03:28:55 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:55 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:55 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:55 --> URI Class Initialized
INFO - 2015-12-26 03:28:55 --> Router Class Initialized
INFO - 2015-12-26 03:28:55 --> Output Class Initialized
INFO - 2015-12-26 03:28:55 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:55 --> Input Class Initialized
INFO - 2015-12-26 03:28:55 --> Language Class Initialized
INFO - 2015-12-26 03:28:55 --> Loader Class Initialized
INFO - 2015-12-26 03:28:55 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:55 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:55 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:55 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:55 --> Model Class Initialized
INFO - 2015-12-26 03:28:55 --> Model Class Initialized
INFO - 2015-12-26 03:28:55 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:55 --> Total execution time: 0.1015
INFO - 2015-12-26 03:28:57 --> Config Class Initialized
INFO - 2015-12-26 03:28:57 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:28:57 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:28:57 --> Utf8 Class Initialized
INFO - 2015-12-26 03:28:57 --> URI Class Initialized
INFO - 2015-12-26 03:28:57 --> Router Class Initialized
INFO - 2015-12-26 03:28:57 --> Output Class Initialized
INFO - 2015-12-26 03:28:57 --> Security Class Initialized
DEBUG - 2015-12-26 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:28:57 --> Input Class Initialized
INFO - 2015-12-26 03:28:57 --> Language Class Initialized
INFO - 2015-12-26 03:28:57 --> Loader Class Initialized
INFO - 2015-12-26 03:28:57 --> Helper loaded: url_helper
INFO - 2015-12-26 03:28:57 --> Database Driver Class Initialized
INFO - 2015-12-26 03:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:28:57 --> Controller Class Initialized
DEBUG - 2015-12-26 03:28:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:28:57 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:28:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:28:57 --> Model Class Initialized
INFO - 2015-12-26 03:28:57 --> Model Class Initialized
INFO - 2015-12-26 03:28:57 --> Final output sent to browser
DEBUG - 2015-12-26 03:28:57 --> Total execution time: 0.1474
INFO - 2015-12-26 03:29:06 --> Config Class Initialized
INFO - 2015-12-26 03:29:06 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:06 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:06 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:06 --> URI Class Initialized
INFO - 2015-12-26 03:29:06 --> Router Class Initialized
INFO - 2015-12-26 03:29:06 --> Output Class Initialized
INFO - 2015-12-26 03:29:06 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:06 --> Input Class Initialized
INFO - 2015-12-26 03:29:06 --> Language Class Initialized
INFO - 2015-12-26 03:29:06 --> Loader Class Initialized
INFO - 2015-12-26 03:29:06 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:06 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:06 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:06 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:06 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:06 --> Model Class Initialized
INFO - 2015-12-26 03:29:06 --> Model Class Initialized
INFO - 2015-12-26 03:29:06 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:06 --> Total execution time: 0.1043
INFO - 2015-12-26 03:29:09 --> Config Class Initialized
INFO - 2015-12-26 03:29:09 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:09 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:09 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:09 --> URI Class Initialized
INFO - 2015-12-26 03:29:09 --> Router Class Initialized
INFO - 2015-12-26 03:29:09 --> Output Class Initialized
INFO - 2015-12-26 03:29:09 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:09 --> Input Class Initialized
INFO - 2015-12-26 03:29:09 --> Language Class Initialized
INFO - 2015-12-26 03:29:09 --> Loader Class Initialized
INFO - 2015-12-26 03:29:10 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:10 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:10 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:10 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:10 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:10 --> Model Class Initialized
INFO - 2015-12-26 03:29:10 --> Model Class Initialized
INFO - 2015-12-26 03:29:10 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:10 --> Total execution time: 0.1379
INFO - 2015-12-26 03:29:16 --> Config Class Initialized
INFO - 2015-12-26 03:29:16 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:16 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:16 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:16 --> URI Class Initialized
INFO - 2015-12-26 03:29:16 --> Router Class Initialized
INFO - 2015-12-26 03:29:16 --> Output Class Initialized
INFO - 2015-12-26 03:29:16 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:16 --> Input Class Initialized
INFO - 2015-12-26 03:29:16 --> Language Class Initialized
INFO - 2015-12-26 03:29:16 --> Loader Class Initialized
INFO - 2015-12-26 03:29:16 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:16 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:16 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:16 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:16 --> Model Class Initialized
INFO - 2015-12-26 03:29:16 --> Model Class Initialized
INFO - 2015-12-26 03:29:16 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:16 --> Total execution time: 0.1142
INFO - 2015-12-26 03:29:17 --> Config Class Initialized
INFO - 2015-12-26 03:29:17 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:17 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:17 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:17 --> URI Class Initialized
INFO - 2015-12-26 03:29:17 --> Router Class Initialized
INFO - 2015-12-26 03:29:17 --> Output Class Initialized
INFO - 2015-12-26 03:29:17 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:18 --> Input Class Initialized
INFO - 2015-12-26 03:29:18 --> Language Class Initialized
INFO - 2015-12-26 03:29:18 --> Loader Class Initialized
INFO - 2015-12-26 03:29:18 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:18 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:18 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:18 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:18 --> Model Class Initialized
INFO - 2015-12-26 03:29:18 --> Model Class Initialized
INFO - 2015-12-26 03:29:18 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:18 --> Total execution time: 0.2056
INFO - 2015-12-26 03:29:21 --> Config Class Initialized
INFO - 2015-12-26 03:29:21 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:21 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:21 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:21 --> URI Class Initialized
DEBUG - 2015-12-26 03:29:21 --> No URI present. Default controller set.
INFO - 2015-12-26 03:29:21 --> Router Class Initialized
INFO - 2015-12-26 03:29:21 --> Output Class Initialized
INFO - 2015-12-26 03:29:21 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:21 --> Input Class Initialized
INFO - 2015-12-26 03:29:21 --> Language Class Initialized
INFO - 2015-12-26 03:29:21 --> Loader Class Initialized
INFO - 2015-12-26 03:29:21 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:21 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:21 --> Controller Class Initialized
INFO - 2015-12-26 03:29:21 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 03:29:21 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:21 --> Total execution time: 0.0875
INFO - 2015-12-26 03:29:22 --> Config Class Initialized
INFO - 2015-12-26 03:29:22 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:22 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:22 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:22 --> URI Class Initialized
INFO - 2015-12-26 03:29:22 --> Router Class Initialized
INFO - 2015-12-26 03:29:23 --> Output Class Initialized
INFO - 2015-12-26 03:29:23 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:23 --> Input Class Initialized
INFO - 2015-12-26 03:29:23 --> Language Class Initialized
INFO - 2015-12-26 03:29:23 --> Loader Class Initialized
INFO - 2015-12-26 03:29:23 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:23 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:23 --> Controller Class Initialized
INFO - 2015-12-26 03:29:23 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 03:29:23 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:23 --> Total execution time: 0.0857
INFO - 2015-12-26 03:29:23 --> Config Class Initialized
INFO - 2015-12-26 03:29:23 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:23 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:23 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:23 --> URI Class Initialized
INFO - 2015-12-26 03:29:23 --> Router Class Initialized
INFO - 2015-12-26 03:29:23 --> Output Class Initialized
INFO - 2015-12-26 03:29:23 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:23 --> Input Class Initialized
INFO - 2015-12-26 03:29:23 --> Language Class Initialized
INFO - 2015-12-26 03:29:23 --> Loader Class Initialized
INFO - 2015-12-26 03:29:23 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:23 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:23 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:23 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:23 --> Model Class Initialized
INFO - 2015-12-26 03:29:23 --> Model Class Initialized
INFO - 2015-12-26 03:29:23 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:23 --> Total execution time: 0.1457
INFO - 2015-12-26 03:29:31 --> Config Class Initialized
INFO - 2015-12-26 03:29:31 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:31 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:31 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:31 --> URI Class Initialized
INFO - 2015-12-26 03:29:31 --> Router Class Initialized
INFO - 2015-12-26 03:29:31 --> Output Class Initialized
INFO - 2015-12-26 03:29:31 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:31 --> Input Class Initialized
INFO - 2015-12-26 03:29:31 --> Language Class Initialized
INFO - 2015-12-26 03:29:31 --> Loader Class Initialized
INFO - 2015-12-26 03:29:31 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:31 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:31 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:31 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:31 --> Model Class Initialized
INFO - 2015-12-26 03:29:31 --> Model Class Initialized
INFO - 2015-12-26 03:29:31 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:31 --> Total execution time: 0.1638
INFO - 2015-12-26 03:29:32 --> Config Class Initialized
INFO - 2015-12-26 03:29:32 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:33 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:33 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:33 --> URI Class Initialized
INFO - 2015-12-26 03:29:33 --> Router Class Initialized
INFO - 2015-12-26 03:29:33 --> Output Class Initialized
INFO - 2015-12-26 03:29:33 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:33 --> Input Class Initialized
INFO - 2015-12-26 03:29:33 --> Language Class Initialized
INFO - 2015-12-26 03:29:33 --> Loader Class Initialized
INFO - 2015-12-26 03:29:33 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:33 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:33 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:33 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:33 --> Model Class Initialized
INFO - 2015-12-26 03:29:33 --> Model Class Initialized
INFO - 2015-12-26 03:29:33 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:33 --> Total execution time: 0.1490
INFO - 2015-12-26 03:29:35 --> Config Class Initialized
INFO - 2015-12-26 03:29:35 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:35 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:35 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:35 --> URI Class Initialized
INFO - 2015-12-26 03:29:35 --> Router Class Initialized
INFO - 2015-12-26 03:29:35 --> Output Class Initialized
INFO - 2015-12-26 03:29:35 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:35 --> Input Class Initialized
INFO - 2015-12-26 03:29:35 --> Language Class Initialized
INFO - 2015-12-26 03:29:35 --> Loader Class Initialized
INFO - 2015-12-26 03:29:35 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:35 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:35 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:35 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:35 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:35 --> Model Class Initialized
INFO - 2015-12-26 03:29:35 --> Model Class Initialized
INFO - 2015-12-26 03:29:35 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:35 --> Total execution time: 0.1172
INFO - 2015-12-26 03:29:37 --> Config Class Initialized
INFO - 2015-12-26 03:29:37 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:37 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:37 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:37 --> URI Class Initialized
INFO - 2015-12-26 03:29:37 --> Router Class Initialized
INFO - 2015-12-26 03:29:37 --> Output Class Initialized
INFO - 2015-12-26 03:29:37 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:37 --> Input Class Initialized
INFO - 2015-12-26 03:29:37 --> Language Class Initialized
INFO - 2015-12-26 03:29:37 --> Loader Class Initialized
INFO - 2015-12-26 03:29:37 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:37 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:37 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:37 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:37 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:37 --> Model Class Initialized
INFO - 2015-12-26 03:29:37 --> Model Class Initialized
INFO - 2015-12-26 03:29:37 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:37 --> Total execution time: 0.1024
INFO - 2015-12-26 03:29:41 --> Config Class Initialized
INFO - 2015-12-26 03:29:41 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:41 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:41 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:41 --> URI Class Initialized
INFO - 2015-12-26 03:29:41 --> Router Class Initialized
INFO - 2015-12-26 03:29:41 --> Output Class Initialized
INFO - 2015-12-26 03:29:41 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:41 --> Input Class Initialized
INFO - 2015-12-26 03:29:41 --> Language Class Initialized
INFO - 2015-12-26 03:29:41 --> Loader Class Initialized
INFO - 2015-12-26 03:29:41 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:41 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:41 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:41 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:41 --> Model Class Initialized
INFO - 2015-12-26 03:29:41 --> Model Class Initialized
INFO - 2015-12-26 03:29:41 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:41 --> Total execution time: 0.1007
INFO - 2015-12-26 03:29:43 --> Config Class Initialized
INFO - 2015-12-26 03:29:43 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:43 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:43 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:43 --> URI Class Initialized
INFO - 2015-12-26 03:29:43 --> Router Class Initialized
INFO - 2015-12-26 03:29:43 --> Output Class Initialized
INFO - 2015-12-26 03:29:43 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:43 --> Input Class Initialized
INFO - 2015-12-26 03:29:43 --> Language Class Initialized
INFO - 2015-12-26 03:29:43 --> Loader Class Initialized
INFO - 2015-12-26 03:29:43 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:43 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:43 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:43 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:43 --> Model Class Initialized
INFO - 2015-12-26 03:29:43 --> Model Class Initialized
INFO - 2015-12-26 03:29:43 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:43 --> Total execution time: 0.1025
INFO - 2015-12-26 03:29:45 --> Config Class Initialized
INFO - 2015-12-26 03:29:45 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:45 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:45 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:45 --> URI Class Initialized
INFO - 2015-12-26 03:29:45 --> Router Class Initialized
INFO - 2015-12-26 03:29:45 --> Output Class Initialized
INFO - 2015-12-26 03:29:45 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:45 --> Input Class Initialized
INFO - 2015-12-26 03:29:45 --> Language Class Initialized
INFO - 2015-12-26 03:29:45 --> Loader Class Initialized
INFO - 2015-12-26 03:29:45 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:45 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:45 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:45 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:45 --> Model Class Initialized
INFO - 2015-12-26 03:29:45 --> Model Class Initialized
INFO - 2015-12-26 03:29:45 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:45 --> Total execution time: 0.1194
INFO - 2015-12-26 03:29:47 --> Config Class Initialized
INFO - 2015-12-26 03:29:47 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:47 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:47 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:47 --> URI Class Initialized
INFO - 2015-12-26 03:29:47 --> Router Class Initialized
INFO - 2015-12-26 03:29:47 --> Output Class Initialized
INFO - 2015-12-26 03:29:47 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:47 --> Input Class Initialized
INFO - 2015-12-26 03:29:47 --> Language Class Initialized
INFO - 2015-12-26 03:29:47 --> Loader Class Initialized
INFO - 2015-12-26 03:29:47 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:47 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:47 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:47 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:47 --> Model Class Initialized
INFO - 2015-12-26 03:29:47 --> Model Class Initialized
INFO - 2015-12-26 03:29:47 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:47 --> Total execution time: 0.1585
INFO - 2015-12-26 03:29:53 --> Config Class Initialized
INFO - 2015-12-26 03:29:53 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:53 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:53 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:53 --> URI Class Initialized
INFO - 2015-12-26 03:29:53 --> Router Class Initialized
INFO - 2015-12-26 03:29:53 --> Output Class Initialized
INFO - 2015-12-26 03:29:53 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:53 --> Input Class Initialized
INFO - 2015-12-26 03:29:53 --> Language Class Initialized
INFO - 2015-12-26 03:29:53 --> Loader Class Initialized
INFO - 2015-12-26 03:29:53 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:53 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:53 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:53 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:53 --> Model Class Initialized
INFO - 2015-12-26 03:29:53 --> Model Class Initialized
INFO - 2015-12-26 03:29:53 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:53 --> Total execution time: 0.1775
INFO - 2015-12-26 03:29:54 --> Config Class Initialized
INFO - 2015-12-26 03:29:54 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:29:54 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:29:54 --> Utf8 Class Initialized
INFO - 2015-12-26 03:29:54 --> URI Class Initialized
INFO - 2015-12-26 03:29:54 --> Router Class Initialized
INFO - 2015-12-26 03:29:55 --> Output Class Initialized
INFO - 2015-12-26 03:29:55 --> Security Class Initialized
DEBUG - 2015-12-26 03:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:29:55 --> Input Class Initialized
INFO - 2015-12-26 03:29:55 --> Language Class Initialized
INFO - 2015-12-26 03:29:55 --> Loader Class Initialized
INFO - 2015-12-26 03:29:55 --> Helper loaded: url_helper
INFO - 2015-12-26 03:29:55 --> Database Driver Class Initialized
INFO - 2015-12-26 03:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:29:55 --> Controller Class Initialized
DEBUG - 2015-12-26 03:29:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:29:55 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:29:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:29:55 --> Model Class Initialized
INFO - 2015-12-26 03:29:55 --> Model Class Initialized
INFO - 2015-12-26 03:29:55 --> Final output sent to browser
DEBUG - 2015-12-26 03:29:55 --> Total execution time: 0.1024
INFO - 2015-12-26 03:30:01 --> Config Class Initialized
INFO - 2015-12-26 03:30:01 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:30:01 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:30:01 --> Utf8 Class Initialized
INFO - 2015-12-26 03:30:01 --> URI Class Initialized
INFO - 2015-12-26 03:30:01 --> Router Class Initialized
INFO - 2015-12-26 03:30:01 --> Output Class Initialized
INFO - 2015-12-26 03:30:01 --> Security Class Initialized
DEBUG - 2015-12-26 03:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:30:01 --> Input Class Initialized
INFO - 2015-12-26 03:30:01 --> Language Class Initialized
INFO - 2015-12-26 03:30:01 --> Loader Class Initialized
INFO - 2015-12-26 03:30:01 --> Helper loaded: url_helper
INFO - 2015-12-26 03:30:01 --> Database Driver Class Initialized
INFO - 2015-12-26 03:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:30:01 --> Controller Class Initialized
DEBUG - 2015-12-26 03:30:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:30:01 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:30:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:30:01 --> Model Class Initialized
INFO - 2015-12-26 03:30:01 --> Model Class Initialized
INFO - 2015-12-26 03:30:01 --> Final output sent to browser
DEBUG - 2015-12-26 03:30:01 --> Total execution time: 0.1634
INFO - 2015-12-26 03:30:03 --> Config Class Initialized
INFO - 2015-12-26 03:30:03 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:30:03 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:30:03 --> Utf8 Class Initialized
INFO - 2015-12-26 03:30:03 --> URI Class Initialized
INFO - 2015-12-26 03:30:03 --> Router Class Initialized
INFO - 2015-12-26 03:30:03 --> Output Class Initialized
INFO - 2015-12-26 03:30:03 --> Security Class Initialized
DEBUG - 2015-12-26 03:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:30:03 --> Input Class Initialized
INFO - 2015-12-26 03:30:03 --> Language Class Initialized
INFO - 2015-12-26 03:30:03 --> Loader Class Initialized
INFO - 2015-12-26 03:30:03 --> Helper loaded: url_helper
INFO - 2015-12-26 03:30:03 --> Database Driver Class Initialized
INFO - 2015-12-26 03:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:30:03 --> Controller Class Initialized
DEBUG - 2015-12-26 03:30:03 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:30:03 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:30:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:30:03 --> Model Class Initialized
INFO - 2015-12-26 03:30:03 --> Model Class Initialized
INFO - 2015-12-26 03:30:03 --> Final output sent to browser
DEBUG - 2015-12-26 03:30:03 --> Total execution time: 0.0994
INFO - 2015-12-26 03:30:06 --> Config Class Initialized
INFO - 2015-12-26 03:30:06 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:30:06 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:30:06 --> Utf8 Class Initialized
INFO - 2015-12-26 03:30:06 --> URI Class Initialized
INFO - 2015-12-26 03:30:06 --> Router Class Initialized
INFO - 2015-12-26 03:30:06 --> Output Class Initialized
INFO - 2015-12-26 03:30:06 --> Security Class Initialized
DEBUG - 2015-12-26 03:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:30:06 --> Input Class Initialized
INFO - 2015-12-26 03:30:06 --> Language Class Initialized
INFO - 2015-12-26 03:30:06 --> Loader Class Initialized
INFO - 2015-12-26 03:30:06 --> Helper loaded: url_helper
INFO - 2015-12-26 03:30:06 --> Database Driver Class Initialized
INFO - 2015-12-26 03:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:30:06 --> Controller Class Initialized
DEBUG - 2015-12-26 03:30:06 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:30:06 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:30:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:30:06 --> Model Class Initialized
INFO - 2015-12-26 03:30:06 --> Model Class Initialized
INFO - 2015-12-26 03:30:06 --> Final output sent to browser
DEBUG - 2015-12-26 03:30:06 --> Total execution time: 0.1159
INFO - 2015-12-26 03:30:07 --> Config Class Initialized
INFO - 2015-12-26 03:30:07 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:30:07 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:30:07 --> Utf8 Class Initialized
INFO - 2015-12-26 03:30:07 --> URI Class Initialized
INFO - 2015-12-26 03:30:07 --> Router Class Initialized
INFO - 2015-12-26 03:30:07 --> Output Class Initialized
INFO - 2015-12-26 03:30:07 --> Security Class Initialized
DEBUG - 2015-12-26 03:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:30:07 --> Input Class Initialized
INFO - 2015-12-26 03:30:07 --> Language Class Initialized
INFO - 2015-12-26 03:30:07 --> Loader Class Initialized
INFO - 2015-12-26 03:30:07 --> Helper loaded: url_helper
INFO - 2015-12-26 03:30:07 --> Database Driver Class Initialized
INFO - 2015-12-26 03:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:30:07 --> Controller Class Initialized
DEBUG - 2015-12-26 03:30:07 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:30:07 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:30:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:30:07 --> Model Class Initialized
INFO - 2015-12-26 03:30:07 --> Model Class Initialized
INFO - 2015-12-26 03:30:07 --> Final output sent to browser
DEBUG - 2015-12-26 03:30:07 --> Total execution time: 0.1054
INFO - 2015-12-26 03:30:09 --> Config Class Initialized
INFO - 2015-12-26 03:30:09 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:30:09 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:30:09 --> Utf8 Class Initialized
INFO - 2015-12-26 03:30:09 --> URI Class Initialized
INFO - 2015-12-26 03:30:09 --> Router Class Initialized
INFO - 2015-12-26 03:30:09 --> Output Class Initialized
INFO - 2015-12-26 03:30:09 --> Security Class Initialized
DEBUG - 2015-12-26 03:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:30:09 --> Input Class Initialized
INFO - 2015-12-26 03:30:09 --> Language Class Initialized
INFO - 2015-12-26 03:30:09 --> Loader Class Initialized
INFO - 2015-12-26 03:30:09 --> Helper loaded: url_helper
INFO - 2015-12-26 03:30:09 --> Database Driver Class Initialized
INFO - 2015-12-26 03:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:30:09 --> Controller Class Initialized
DEBUG - 2015-12-26 03:30:09 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:30:09 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:30:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:30:09 --> Model Class Initialized
INFO - 2015-12-26 03:30:09 --> Model Class Initialized
INFO - 2015-12-26 03:30:09 --> Final output sent to browser
DEBUG - 2015-12-26 03:30:09 --> Total execution time: 0.1254
INFO - 2015-12-26 03:30:11 --> Config Class Initialized
INFO - 2015-12-26 03:30:11 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:30:11 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:30:11 --> Utf8 Class Initialized
INFO - 2015-12-26 03:30:11 --> URI Class Initialized
INFO - 2015-12-26 03:30:11 --> Router Class Initialized
INFO - 2015-12-26 03:30:11 --> Output Class Initialized
INFO - 2015-12-26 03:30:11 --> Security Class Initialized
DEBUG - 2015-12-26 03:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:30:11 --> Input Class Initialized
INFO - 2015-12-26 03:30:11 --> Language Class Initialized
INFO - 2015-12-26 03:30:11 --> Loader Class Initialized
INFO - 2015-12-26 03:30:11 --> Helper loaded: url_helper
INFO - 2015-12-26 03:30:11 --> Database Driver Class Initialized
INFO - 2015-12-26 03:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:30:11 --> Controller Class Initialized
DEBUG - 2015-12-26 03:30:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:30:11 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:30:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:30:11 --> Model Class Initialized
INFO - 2015-12-26 03:30:11 --> Model Class Initialized
INFO - 2015-12-26 03:30:11 --> Final output sent to browser
DEBUG - 2015-12-26 03:30:11 --> Total execution time: 0.1564
INFO - 2015-12-26 03:30:15 --> Config Class Initialized
INFO - 2015-12-26 03:30:15 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:30:15 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:30:15 --> Utf8 Class Initialized
INFO - 2015-12-26 03:30:15 --> URI Class Initialized
DEBUG - 2015-12-26 03:30:15 --> No URI present. Default controller set.
INFO - 2015-12-26 03:30:15 --> Router Class Initialized
INFO - 2015-12-26 03:30:15 --> Output Class Initialized
INFO - 2015-12-26 03:30:15 --> Security Class Initialized
DEBUG - 2015-12-26 03:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:30:15 --> Input Class Initialized
INFO - 2015-12-26 03:30:15 --> Language Class Initialized
INFO - 2015-12-26 03:30:15 --> Loader Class Initialized
INFO - 2015-12-26 03:30:15 --> Helper loaded: url_helper
INFO - 2015-12-26 03:30:15 --> Database Driver Class Initialized
INFO - 2015-12-26 03:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:30:15 --> Controller Class Initialized
INFO - 2015-12-26 03:30:15 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 03:30:15 --> Final output sent to browser
DEBUG - 2015-12-26 03:30:15 --> Total execution time: 0.1310
INFO - 2015-12-26 03:30:16 --> Config Class Initialized
INFO - 2015-12-26 03:30:16 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:30:16 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:30:16 --> Utf8 Class Initialized
INFO - 2015-12-26 03:30:16 --> URI Class Initialized
INFO - 2015-12-26 03:30:16 --> Router Class Initialized
INFO - 2015-12-26 03:30:16 --> Output Class Initialized
INFO - 2015-12-26 03:30:16 --> Security Class Initialized
DEBUG - 2015-12-26 03:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:30:16 --> Input Class Initialized
INFO - 2015-12-26 03:30:16 --> Language Class Initialized
INFO - 2015-12-26 03:30:16 --> Loader Class Initialized
INFO - 2015-12-26 03:30:16 --> Helper loaded: url_helper
INFO - 2015-12-26 03:30:16 --> Database Driver Class Initialized
INFO - 2015-12-26 03:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:30:16 --> Controller Class Initialized
INFO - 2015-12-26 03:30:16 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 03:30:16 --> Final output sent to browser
DEBUG - 2015-12-26 03:30:16 --> Total execution time: 0.1316
INFO - 2015-12-26 03:30:16 --> Config Class Initialized
INFO - 2015-12-26 03:30:16 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:30:16 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:30:16 --> Utf8 Class Initialized
INFO - 2015-12-26 03:30:16 --> URI Class Initialized
INFO - 2015-12-26 03:30:16 --> Router Class Initialized
INFO - 2015-12-26 03:30:16 --> Output Class Initialized
INFO - 2015-12-26 03:30:16 --> Security Class Initialized
DEBUG - 2015-12-26 03:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:30:16 --> Input Class Initialized
INFO - 2015-12-26 03:30:16 --> Language Class Initialized
INFO - 2015-12-26 03:30:16 --> Loader Class Initialized
INFO - 2015-12-26 03:30:16 --> Helper loaded: url_helper
INFO - 2015-12-26 03:30:16 --> Database Driver Class Initialized
INFO - 2015-12-26 03:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:30:16 --> Controller Class Initialized
DEBUG - 2015-12-26 03:30:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:30:16 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:30:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:30:16 --> Model Class Initialized
INFO - 2015-12-26 03:30:16 --> Model Class Initialized
INFO - 2015-12-26 03:30:16 --> Final output sent to browser
DEBUG - 2015-12-26 03:30:16 --> Total execution time: 0.1476
INFO - 2015-12-26 03:31:42 --> Config Class Initialized
INFO - 2015-12-26 03:31:42 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:31:42 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:31:42 --> Utf8 Class Initialized
INFO - 2015-12-26 03:31:42 --> URI Class Initialized
INFO - 2015-12-26 03:31:42 --> Router Class Initialized
INFO - 2015-12-26 03:31:42 --> Output Class Initialized
INFO - 2015-12-26 03:31:42 --> Security Class Initialized
DEBUG - 2015-12-26 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:31:42 --> Input Class Initialized
INFO - 2015-12-26 03:31:42 --> Language Class Initialized
INFO - 2015-12-26 03:31:42 --> Loader Class Initialized
INFO - 2015-12-26 03:31:42 --> Helper loaded: url_helper
INFO - 2015-12-26 03:31:42 --> Database Driver Class Initialized
INFO - 2015-12-26 03:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:31:42 --> Controller Class Initialized
INFO - 2015-12-26 03:31:42 --> Helper loaded: form_helper
INFO - 2015-12-26 03:31:42 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 03:31:42 --> Final output sent to browser
DEBUG - 2015-12-26 03:31:42 --> Total execution time: 0.4468
INFO - 2015-12-26 03:31:46 --> Config Class Initialized
INFO - 2015-12-26 03:31:46 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:31:46 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:31:46 --> Utf8 Class Initialized
INFO - 2015-12-26 03:31:46 --> URI Class Initialized
INFO - 2015-12-26 03:31:46 --> Router Class Initialized
INFO - 2015-12-26 03:31:46 --> Output Class Initialized
INFO - 2015-12-26 03:31:46 --> Security Class Initialized
DEBUG - 2015-12-26 03:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:31:46 --> Input Class Initialized
INFO - 2015-12-26 03:31:46 --> Language Class Initialized
INFO - 2015-12-26 03:31:46 --> Loader Class Initialized
INFO - 2015-12-26 03:31:46 --> Helper loaded: url_helper
INFO - 2015-12-26 03:31:46 --> Database Driver Class Initialized
INFO - 2015-12-26 03:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:31:46 --> Controller Class Initialized
INFO - 2015-12-26 03:31:46 --> Model Class Initialized
INFO - 2015-12-26 03:31:46 --> Model Class Initialized
INFO - 2015-12-26 03:31:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 03:31:46 --> Final output sent to browser
DEBUG - 2015-12-26 03:31:46 --> Total execution time: 0.1026
INFO - 2015-12-26 03:31:46 --> Config Class Initialized
INFO - 2015-12-26 03:31:46 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:31:46 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:31:46 --> Utf8 Class Initialized
INFO - 2015-12-26 03:31:46 --> URI Class Initialized
INFO - 2015-12-26 03:31:46 --> Router Class Initialized
INFO - 2015-12-26 03:31:46 --> Output Class Initialized
INFO - 2015-12-26 03:31:46 --> Security Class Initialized
DEBUG - 2015-12-26 03:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:31:46 --> Input Class Initialized
INFO - 2015-12-26 03:31:46 --> Language Class Initialized
INFO - 2015-12-26 03:31:46 --> Loader Class Initialized
INFO - 2015-12-26 03:31:46 --> Helper loaded: url_helper
INFO - 2015-12-26 03:31:46 --> Database Driver Class Initialized
INFO - 2015-12-26 03:31:46 --> Config Class Initialized
ERROR - 2015-12-26 03:31:46 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
INFO - 2015-12-26 03:31:46 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:31:46 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
DEBUG - 2015-12-26 03:31:46 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:31:46 --> Utf8 Class Initialized
INFO - 2015-12-26 03:31:46 --> Controller Class Initialized
INFO - 2015-12-26 03:31:46 --> URI Class Initialized
INFO - 2015-12-26 03:31:46 --> Model Class Initialized
INFO - 2015-12-26 03:31:46 --> Router Class Initialized
INFO - 2015-12-26 03:31:46 --> Model Class Initialized
INFO - 2015-12-26 03:31:46 --> Output Class Initialized
INFO - 2015-12-26 03:31:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 03:31:46 --> Security Class Initialized
INFO - 2015-12-26 03:31:46 --> Final output sent to browser
DEBUG - 2015-12-26 03:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-12-26 03:31:46 --> Total execution time: 0.1208
INFO - 2015-12-26 03:31:46 --> Input Class Initialized
INFO - 2015-12-26 03:31:46 --> Language Class Initialized
INFO - 2015-12-26 03:31:46 --> Loader Class Initialized
INFO - 2015-12-26 03:31:46 --> Helper loaded: url_helper
INFO - 2015-12-26 03:31:46 --> Database Driver Class Initialized
INFO - 2015-12-26 03:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:31:46 --> Controller Class Initialized
DEBUG - 2015-12-26 03:31:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:31:46 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:31:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:31:46 --> Model Class Initialized
INFO - 2015-12-26 03:31:46 --> Model Class Initialized
INFO - 2015-12-26 03:31:46 --> Final output sent to browser
DEBUG - 2015-12-26 03:31:46 --> Total execution time: 0.1458
INFO - 2015-12-26 03:31:55 --> Config Class Initialized
INFO - 2015-12-26 03:31:55 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:31:55 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:31:55 --> Utf8 Class Initialized
INFO - 2015-12-26 03:31:55 --> URI Class Initialized
INFO - 2015-12-26 03:31:55 --> Router Class Initialized
INFO - 2015-12-26 03:31:55 --> Output Class Initialized
INFO - 2015-12-26 03:31:55 --> Security Class Initialized
DEBUG - 2015-12-26 03:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:31:55 --> Input Class Initialized
INFO - 2015-12-26 03:31:55 --> Language Class Initialized
INFO - 2015-12-26 03:31:55 --> Loader Class Initialized
INFO - 2015-12-26 03:31:56 --> Helper loaded: url_helper
INFO - 2015-12-26 03:31:56 --> Database Driver Class Initialized
INFO - 2015-12-26 03:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:31:56 --> Controller Class Initialized
DEBUG - 2015-12-26 03:31:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:31:56 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:31:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:31:56 --> Model Class Initialized
INFO - 2015-12-26 03:31:56 --> Model Class Initialized
INFO - 2015-12-26 03:31:56 --> Final output sent to browser
DEBUG - 2015-12-26 03:31:56 --> Total execution time: 0.1063
INFO - 2015-12-26 03:32:02 --> Config Class Initialized
INFO - 2015-12-26 03:32:02 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:32:02 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:32:02 --> Utf8 Class Initialized
INFO - 2015-12-26 03:32:02 --> URI Class Initialized
INFO - 2015-12-26 03:32:02 --> Router Class Initialized
INFO - 2015-12-26 03:32:02 --> Output Class Initialized
INFO - 2015-12-26 03:32:02 --> Security Class Initialized
DEBUG - 2015-12-26 03:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:32:02 --> Input Class Initialized
INFO - 2015-12-26 03:32:02 --> Language Class Initialized
INFO - 2015-12-26 03:32:02 --> Loader Class Initialized
INFO - 2015-12-26 03:32:02 --> Helper loaded: url_helper
INFO - 2015-12-26 03:32:02 --> Database Driver Class Initialized
INFO - 2015-12-26 03:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:32:02 --> Controller Class Initialized
DEBUG - 2015-12-26 03:32:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:32:02 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:32:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:32:02 --> Model Class Initialized
INFO - 2015-12-26 03:32:02 --> Model Class Initialized
INFO - 2015-12-26 03:32:02 --> Final output sent to browser
DEBUG - 2015-12-26 03:32:02 --> Total execution time: 0.1051
INFO - 2015-12-26 03:32:31 --> Config Class Initialized
INFO - 2015-12-26 03:32:32 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:32:32 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:32:32 --> Utf8 Class Initialized
INFO - 2015-12-26 03:32:32 --> URI Class Initialized
INFO - 2015-12-26 03:32:32 --> Router Class Initialized
INFO - 2015-12-26 03:32:32 --> Output Class Initialized
INFO - 2015-12-26 03:32:32 --> Security Class Initialized
DEBUG - 2015-12-26 03:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:32:32 --> Input Class Initialized
INFO - 2015-12-26 03:32:32 --> Language Class Initialized
INFO - 2015-12-26 03:32:32 --> Loader Class Initialized
INFO - 2015-12-26 03:32:32 --> Helper loaded: url_helper
INFO - 2015-12-26 03:32:32 --> Database Driver Class Initialized
INFO - 2015-12-26 03:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:32:32 --> Controller Class Initialized
DEBUG - 2015-12-26 03:32:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:32:32 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:32:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:32:32 --> Model Class Initialized
INFO - 2015-12-26 03:32:32 --> Model Class Initialized
INFO - 2015-12-26 03:32:32 --> Final output sent to browser
DEBUG - 2015-12-26 03:32:32 --> Total execution time: 0.2855
INFO - 2015-12-26 03:32:32 --> Config Class Initialized
INFO - 2015-12-26 03:32:32 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:32:32 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:32:32 --> Utf8 Class Initialized
INFO - 2015-12-26 03:32:32 --> URI Class Initialized
INFO - 2015-12-26 03:32:32 --> Router Class Initialized
INFO - 2015-12-26 03:32:32 --> Output Class Initialized
INFO - 2015-12-26 03:32:32 --> Security Class Initialized
DEBUG - 2015-12-26 03:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:32:32 --> Input Class Initialized
INFO - 2015-12-26 03:32:32 --> Language Class Initialized
INFO - 2015-12-26 03:32:32 --> Loader Class Initialized
INFO - 2015-12-26 03:32:32 --> Helper loaded: url_helper
INFO - 2015-12-26 03:32:32 --> Database Driver Class Initialized
INFO - 2015-12-26 03:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:32:32 --> Controller Class Initialized
DEBUG - 2015-12-26 03:32:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:32:32 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:32:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:32:32 --> Model Class Initialized
INFO - 2015-12-26 03:32:32 --> Model Class Initialized
INFO - 2015-12-26 03:32:32 --> Final output sent to browser
DEBUG - 2015-12-26 03:32:32 --> Total execution time: 0.1305
INFO - 2015-12-26 03:32:34 --> Config Class Initialized
INFO - 2015-12-26 03:32:34 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:32:34 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:32:34 --> Utf8 Class Initialized
INFO - 2015-12-26 03:32:34 --> URI Class Initialized
INFO - 2015-12-26 03:32:34 --> Router Class Initialized
INFO - 2015-12-26 03:32:34 --> Output Class Initialized
INFO - 2015-12-26 03:32:34 --> Security Class Initialized
DEBUG - 2015-12-26 03:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:32:34 --> Input Class Initialized
INFO - 2015-12-26 03:32:34 --> Language Class Initialized
INFO - 2015-12-26 03:32:34 --> Loader Class Initialized
INFO - 2015-12-26 03:32:34 --> Helper loaded: url_helper
INFO - 2015-12-26 03:32:34 --> Database Driver Class Initialized
INFO - 2015-12-26 03:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:32:34 --> Controller Class Initialized
DEBUG - 2015-12-26 03:32:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:32:34 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:32:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:32:34 --> Model Class Initialized
INFO - 2015-12-26 03:32:34 --> Model Class Initialized
INFO - 2015-12-26 03:32:34 --> Final output sent to browser
DEBUG - 2015-12-26 03:32:34 --> Total execution time: 0.1037
INFO - 2015-12-26 03:32:44 --> Config Class Initialized
INFO - 2015-12-26 03:32:44 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:32:44 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:32:44 --> Utf8 Class Initialized
INFO - 2015-12-26 03:32:44 --> URI Class Initialized
INFO - 2015-12-26 03:32:44 --> Router Class Initialized
INFO - 2015-12-26 03:32:44 --> Output Class Initialized
INFO - 2015-12-26 03:32:44 --> Security Class Initialized
DEBUG - 2015-12-26 03:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:32:44 --> Input Class Initialized
INFO - 2015-12-26 03:32:44 --> Language Class Initialized
INFO - 2015-12-26 03:32:44 --> Loader Class Initialized
INFO - 2015-12-26 03:32:44 --> Helper loaded: url_helper
INFO - 2015-12-26 03:32:44 --> Database Driver Class Initialized
INFO - 2015-12-26 03:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:32:44 --> Controller Class Initialized
DEBUG - 2015-12-26 03:32:44 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:32:44 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:32:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:32:44 --> Model Class Initialized
INFO - 2015-12-26 03:32:44 --> Model Class Initialized
INFO - 2015-12-26 03:32:44 --> Final output sent to browser
DEBUG - 2015-12-26 03:32:44 --> Total execution time: 0.1293
INFO - 2015-12-26 03:33:26 --> Config Class Initialized
INFO - 2015-12-26 03:33:26 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:33:26 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:33:26 --> Utf8 Class Initialized
INFO - 2015-12-26 03:33:26 --> URI Class Initialized
INFO - 2015-12-26 03:33:26 --> Router Class Initialized
INFO - 2015-12-26 03:33:26 --> Output Class Initialized
INFO - 2015-12-26 03:33:26 --> Security Class Initialized
DEBUG - 2015-12-26 03:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:33:26 --> Input Class Initialized
INFO - 2015-12-26 03:33:26 --> Language Class Initialized
INFO - 2015-12-26 03:33:26 --> Loader Class Initialized
INFO - 2015-12-26 03:33:26 --> Helper loaded: url_helper
INFO - 2015-12-26 03:33:26 --> Database Driver Class Initialized
INFO - 2015-12-26 03:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:33:27 --> Controller Class Initialized
DEBUG - 2015-12-26 03:33:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:33:27 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:33:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:33:27 --> Model Class Initialized
INFO - 2015-12-26 03:33:27 --> Model Class Initialized
INFO - 2015-12-26 03:33:27 --> Final output sent to browser
DEBUG - 2015-12-26 03:33:27 --> Total execution time: 0.4675
INFO - 2015-12-26 03:33:27 --> Config Class Initialized
INFO - 2015-12-26 03:33:27 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:33:27 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:33:27 --> Utf8 Class Initialized
INFO - 2015-12-26 03:33:27 --> URI Class Initialized
INFO - 2015-12-26 03:33:27 --> Router Class Initialized
INFO - 2015-12-26 03:33:27 --> Output Class Initialized
INFO - 2015-12-26 03:33:27 --> Security Class Initialized
DEBUG - 2015-12-26 03:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:33:27 --> Input Class Initialized
INFO - 2015-12-26 03:33:27 --> Language Class Initialized
INFO - 2015-12-26 03:33:27 --> Loader Class Initialized
INFO - 2015-12-26 03:33:27 --> Helper loaded: url_helper
INFO - 2015-12-26 03:33:27 --> Database Driver Class Initialized
INFO - 2015-12-26 03:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:33:27 --> Controller Class Initialized
DEBUG - 2015-12-26 03:33:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:33:27 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:33:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:33:27 --> Model Class Initialized
INFO - 2015-12-26 03:33:27 --> Model Class Initialized
INFO - 2015-12-26 03:33:27 --> Final output sent to browser
DEBUG - 2015-12-26 03:33:27 --> Total execution time: 0.2740
INFO - 2015-12-26 03:33:29 --> Config Class Initialized
INFO - 2015-12-26 03:33:29 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:33:29 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:33:29 --> Utf8 Class Initialized
INFO - 2015-12-26 03:33:29 --> URI Class Initialized
INFO - 2015-12-26 03:33:29 --> Router Class Initialized
INFO - 2015-12-26 03:33:29 --> Output Class Initialized
INFO - 2015-12-26 03:33:29 --> Security Class Initialized
DEBUG - 2015-12-26 03:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:33:29 --> Input Class Initialized
INFO - 2015-12-26 03:33:29 --> Language Class Initialized
INFO - 2015-12-26 03:33:29 --> Loader Class Initialized
INFO - 2015-12-26 03:33:29 --> Helper loaded: url_helper
INFO - 2015-12-26 03:33:29 --> Database Driver Class Initialized
INFO - 2015-12-26 03:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:33:29 --> Controller Class Initialized
DEBUG - 2015-12-26 03:33:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:33:29 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:33:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:33:29 --> Model Class Initialized
INFO - 2015-12-26 03:33:29 --> Model Class Initialized
INFO - 2015-12-26 03:33:29 --> Final output sent to browser
DEBUG - 2015-12-26 03:33:29 --> Total execution time: 0.1456
INFO - 2015-12-26 03:33:31 --> Config Class Initialized
INFO - 2015-12-26 03:33:31 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:33:31 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:33:31 --> Utf8 Class Initialized
INFO - 2015-12-26 03:33:31 --> URI Class Initialized
INFO - 2015-12-26 03:33:31 --> Router Class Initialized
INFO - 2015-12-26 03:33:31 --> Output Class Initialized
INFO - 2015-12-26 03:33:31 --> Security Class Initialized
DEBUG - 2015-12-26 03:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:33:31 --> Input Class Initialized
INFO - 2015-12-26 03:33:31 --> Language Class Initialized
INFO - 2015-12-26 03:33:31 --> Loader Class Initialized
INFO - 2015-12-26 03:33:31 --> Helper loaded: url_helper
INFO - 2015-12-26 03:33:31 --> Database Driver Class Initialized
INFO - 2015-12-26 03:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:33:31 --> Controller Class Initialized
INFO - 2015-12-26 03:33:31 --> Config Class Initialized
INFO - 2015-12-26 03:33:31 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:33:31 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:33:31 --> Utf8 Class Initialized
INFO - 2015-12-26 03:33:31 --> URI Class Initialized
INFO - 2015-12-26 03:33:31 --> Router Class Initialized
INFO - 2015-12-26 03:33:31 --> Output Class Initialized
INFO - 2015-12-26 03:33:31 --> Security Class Initialized
DEBUG - 2015-12-26 03:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:33:31 --> Input Class Initialized
INFO - 2015-12-26 03:33:31 --> Language Class Initialized
INFO - 2015-12-26 03:33:31 --> Loader Class Initialized
INFO - 2015-12-26 03:33:31 --> Helper loaded: url_helper
INFO - 2015-12-26 03:33:31 --> Database Driver Class Initialized
INFO - 2015-12-26 03:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:33:31 --> Controller Class Initialized
INFO - 2015-12-26 03:33:31 --> Helper loaded: form_helper
INFO - 2015-12-26 03:33:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 03:33:31 --> Final output sent to browser
DEBUG - 2015-12-26 03:33:31 --> Total execution time: 0.0901
INFO - 2015-12-26 03:34:10 --> Config Class Initialized
INFO - 2015-12-26 03:34:10 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:10 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:10 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:10 --> URI Class Initialized
DEBUG - 2015-12-26 03:34:10 --> No URI present. Default controller set.
INFO - 2015-12-26 03:34:10 --> Router Class Initialized
INFO - 2015-12-26 03:34:10 --> Output Class Initialized
INFO - 2015-12-26 03:34:10 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:10 --> Input Class Initialized
INFO - 2015-12-26 03:34:10 --> Language Class Initialized
INFO - 2015-12-26 03:34:10 --> Loader Class Initialized
INFO - 2015-12-26 03:34:10 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:10 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:10 --> Controller Class Initialized
INFO - 2015-12-26 03:34:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 03:34:10 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:10 --> Total execution time: 0.1741
INFO - 2015-12-26 03:34:14 --> Config Class Initialized
INFO - 2015-12-26 03:34:14 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:14 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:14 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:14 --> URI Class Initialized
INFO - 2015-12-26 03:34:14 --> Router Class Initialized
INFO - 2015-12-26 03:34:14 --> Output Class Initialized
INFO - 2015-12-26 03:34:14 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:14 --> Input Class Initialized
INFO - 2015-12-26 03:34:14 --> Language Class Initialized
INFO - 2015-12-26 03:34:14 --> Loader Class Initialized
INFO - 2015-12-26 03:34:14 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:14 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:14 --> Controller Class Initialized
INFO - 2015-12-26 03:34:14 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 03:34:14 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:14 --> Total execution time: 0.1094
INFO - 2015-12-26 03:34:14 --> Config Class Initialized
INFO - 2015-12-26 03:34:14 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:14 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:14 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:14 --> URI Class Initialized
INFO - 2015-12-26 03:34:14 --> Router Class Initialized
INFO - 2015-12-26 03:34:14 --> Output Class Initialized
INFO - 2015-12-26 03:34:14 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:14 --> Input Class Initialized
INFO - 2015-12-26 03:34:14 --> Language Class Initialized
INFO - 2015-12-26 03:34:14 --> Loader Class Initialized
INFO - 2015-12-26 03:34:14 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:14 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:14 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:14 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:14 --> Model Class Initialized
INFO - 2015-12-26 03:34:14 --> Model Class Initialized
INFO - 2015-12-26 03:34:14 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:14 --> Total execution time: 0.1161
INFO - 2015-12-26 03:34:17 --> Config Class Initialized
INFO - 2015-12-26 03:34:17 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:17 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:17 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:17 --> URI Class Initialized
INFO - 2015-12-26 03:34:17 --> Router Class Initialized
INFO - 2015-12-26 03:34:17 --> Output Class Initialized
INFO - 2015-12-26 03:34:17 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:17 --> Input Class Initialized
INFO - 2015-12-26 03:34:17 --> Language Class Initialized
INFO - 2015-12-26 03:34:17 --> Loader Class Initialized
INFO - 2015-12-26 03:34:17 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:17 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:17 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:17 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:17 --> Model Class Initialized
INFO - 2015-12-26 03:34:17 --> Model Class Initialized
INFO - 2015-12-26 03:34:17 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:17 --> Total execution time: 0.1487
INFO - 2015-12-26 03:34:18 --> Config Class Initialized
INFO - 2015-12-26 03:34:18 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:18 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:18 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:18 --> URI Class Initialized
INFO - 2015-12-26 03:34:18 --> Router Class Initialized
INFO - 2015-12-26 03:34:18 --> Output Class Initialized
INFO - 2015-12-26 03:34:18 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:18 --> Input Class Initialized
INFO - 2015-12-26 03:34:18 --> Language Class Initialized
INFO - 2015-12-26 03:34:18 --> Loader Class Initialized
INFO - 2015-12-26 03:34:18 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:18 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:18 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:18 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:18 --> Model Class Initialized
INFO - 2015-12-26 03:34:18 --> Model Class Initialized
INFO - 2015-12-26 03:34:18 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:18 --> Total execution time: 0.1004
INFO - 2015-12-26 03:34:20 --> Config Class Initialized
INFO - 2015-12-26 03:34:20 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:20 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:20 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:20 --> URI Class Initialized
INFO - 2015-12-26 03:34:20 --> Router Class Initialized
INFO - 2015-12-26 03:34:20 --> Output Class Initialized
INFO - 2015-12-26 03:34:20 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:20 --> Input Class Initialized
INFO - 2015-12-26 03:34:20 --> Language Class Initialized
INFO - 2015-12-26 03:34:20 --> Loader Class Initialized
INFO - 2015-12-26 03:34:20 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:20 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:20 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:20 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:20 --> Model Class Initialized
INFO - 2015-12-26 03:34:20 --> Model Class Initialized
INFO - 2015-12-26 03:34:20 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:20 --> Total execution time: 0.1297
INFO - 2015-12-26 03:34:21 --> Config Class Initialized
INFO - 2015-12-26 03:34:21 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:21 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:21 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:21 --> URI Class Initialized
INFO - 2015-12-26 03:34:21 --> Router Class Initialized
INFO - 2015-12-26 03:34:21 --> Output Class Initialized
INFO - 2015-12-26 03:34:21 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:21 --> Input Class Initialized
INFO - 2015-12-26 03:34:21 --> Language Class Initialized
INFO - 2015-12-26 03:34:21 --> Loader Class Initialized
INFO - 2015-12-26 03:34:21 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:21 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:21 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:21 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:21 --> Model Class Initialized
INFO - 2015-12-26 03:34:21 --> Model Class Initialized
INFO - 2015-12-26 03:34:21 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:21 --> Total execution time: 0.1220
INFO - 2015-12-26 03:34:23 --> Config Class Initialized
INFO - 2015-12-26 03:34:23 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:23 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:23 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:23 --> URI Class Initialized
INFO - 2015-12-26 03:34:23 --> Router Class Initialized
INFO - 2015-12-26 03:34:23 --> Output Class Initialized
INFO - 2015-12-26 03:34:23 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:23 --> Input Class Initialized
INFO - 2015-12-26 03:34:23 --> Language Class Initialized
INFO - 2015-12-26 03:34:23 --> Loader Class Initialized
INFO - 2015-12-26 03:34:23 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:23 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:23 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:23 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:23 --> Model Class Initialized
INFO - 2015-12-26 03:34:23 --> Model Class Initialized
INFO - 2015-12-26 03:34:23 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:23 --> Total execution time: 0.1577
INFO - 2015-12-26 03:34:24 --> Config Class Initialized
INFO - 2015-12-26 03:34:24 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:24 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:24 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:24 --> URI Class Initialized
INFO - 2015-12-26 03:34:24 --> Router Class Initialized
INFO - 2015-12-26 03:34:24 --> Output Class Initialized
INFO - 2015-12-26 03:34:24 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:24 --> Input Class Initialized
INFO - 2015-12-26 03:34:24 --> Language Class Initialized
INFO - 2015-12-26 03:34:24 --> Loader Class Initialized
INFO - 2015-12-26 03:34:24 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:24 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:24 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:24 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:24 --> Model Class Initialized
INFO - 2015-12-26 03:34:24 --> Model Class Initialized
INFO - 2015-12-26 03:34:24 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:24 --> Total execution time: 0.1489
INFO - 2015-12-26 03:34:29 --> Config Class Initialized
INFO - 2015-12-26 03:34:29 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:29 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:29 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:29 --> URI Class Initialized
INFO - 2015-12-26 03:34:29 --> Router Class Initialized
INFO - 2015-12-26 03:34:29 --> Output Class Initialized
INFO - 2015-12-26 03:34:29 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:29 --> Input Class Initialized
INFO - 2015-12-26 03:34:29 --> Language Class Initialized
INFO - 2015-12-26 03:34:29 --> Loader Class Initialized
INFO - 2015-12-26 03:34:29 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:29 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:29 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:29 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:29 --> Model Class Initialized
INFO - 2015-12-26 03:34:29 --> Model Class Initialized
INFO - 2015-12-26 03:34:29 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:29 --> Total execution time: 0.1104
INFO - 2015-12-26 03:34:29 --> Config Class Initialized
INFO - 2015-12-26 03:34:29 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:29 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:29 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:29 --> URI Class Initialized
INFO - 2015-12-26 03:34:29 --> Router Class Initialized
INFO - 2015-12-26 03:34:29 --> Output Class Initialized
INFO - 2015-12-26 03:34:29 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:29 --> Input Class Initialized
INFO - 2015-12-26 03:34:29 --> Language Class Initialized
INFO - 2015-12-26 03:34:29 --> Loader Class Initialized
INFO - 2015-12-26 03:34:29 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:29 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:29 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:29 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:29 --> Model Class Initialized
INFO - 2015-12-26 03:34:29 --> Model Class Initialized
INFO - 2015-12-26 03:34:29 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:29 --> Total execution time: 0.1048
INFO - 2015-12-26 03:34:31 --> Config Class Initialized
INFO - 2015-12-26 03:34:31 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:31 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:31 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:31 --> URI Class Initialized
INFO - 2015-12-26 03:34:31 --> Router Class Initialized
INFO - 2015-12-26 03:34:31 --> Output Class Initialized
INFO - 2015-12-26 03:34:31 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:31 --> Input Class Initialized
INFO - 2015-12-26 03:34:31 --> Language Class Initialized
INFO - 2015-12-26 03:34:31 --> Loader Class Initialized
INFO - 2015-12-26 03:34:31 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:31 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:31 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:31 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:31 --> Model Class Initialized
INFO - 2015-12-26 03:34:31 --> Model Class Initialized
INFO - 2015-12-26 03:34:31 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:31 --> Total execution time: 0.1004
INFO - 2015-12-26 03:34:32 --> Config Class Initialized
INFO - 2015-12-26 03:34:32 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:32 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:32 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:32 --> URI Class Initialized
INFO - 2015-12-26 03:34:32 --> Router Class Initialized
INFO - 2015-12-26 03:34:32 --> Output Class Initialized
INFO - 2015-12-26 03:34:32 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:32 --> Input Class Initialized
INFO - 2015-12-26 03:34:32 --> Language Class Initialized
INFO - 2015-12-26 03:34:32 --> Loader Class Initialized
INFO - 2015-12-26 03:34:32 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:32 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:32 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:32 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:32 --> Model Class Initialized
INFO - 2015-12-26 03:34:32 --> Model Class Initialized
INFO - 2015-12-26 03:34:32 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:32 --> Total execution time: 0.1418
INFO - 2015-12-26 03:34:35 --> Config Class Initialized
INFO - 2015-12-26 03:34:35 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:35 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:35 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:35 --> URI Class Initialized
INFO - 2015-12-26 03:34:35 --> Router Class Initialized
INFO - 2015-12-26 03:34:35 --> Output Class Initialized
INFO - 2015-12-26 03:34:35 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:35 --> Input Class Initialized
INFO - 2015-12-26 03:34:35 --> Language Class Initialized
INFO - 2015-12-26 03:34:35 --> Loader Class Initialized
INFO - 2015-12-26 03:34:35 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:35 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:35 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:35 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:35 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:35 --> Model Class Initialized
INFO - 2015-12-26 03:34:35 --> Model Class Initialized
INFO - 2015-12-26 03:34:35 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:35 --> Total execution time: 0.0990
INFO - 2015-12-26 03:34:35 --> Config Class Initialized
INFO - 2015-12-26 03:34:35 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:35 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:35 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:35 --> URI Class Initialized
INFO - 2015-12-26 03:34:35 --> Router Class Initialized
INFO - 2015-12-26 03:34:35 --> Output Class Initialized
INFO - 2015-12-26 03:34:35 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:35 --> Input Class Initialized
INFO - 2015-12-26 03:34:35 --> Language Class Initialized
INFO - 2015-12-26 03:34:35 --> Loader Class Initialized
INFO - 2015-12-26 03:34:35 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:35 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:35 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:35 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:35 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:35 --> Model Class Initialized
INFO - 2015-12-26 03:34:35 --> Model Class Initialized
INFO - 2015-12-26 03:34:35 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:35 --> Total execution time: 0.1015
INFO - 2015-12-26 03:34:39 --> Config Class Initialized
INFO - 2015-12-26 03:34:39 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:39 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:39 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:39 --> URI Class Initialized
INFO - 2015-12-26 03:34:39 --> Router Class Initialized
INFO - 2015-12-26 03:34:39 --> Output Class Initialized
INFO - 2015-12-26 03:34:39 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:39 --> Input Class Initialized
INFO - 2015-12-26 03:34:39 --> Language Class Initialized
INFO - 2015-12-26 03:34:39 --> Loader Class Initialized
INFO - 2015-12-26 03:34:39 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:39 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:39 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:39 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:39 --> Model Class Initialized
INFO - 2015-12-26 03:34:39 --> Model Class Initialized
INFO - 2015-12-26 03:34:39 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:39 --> Total execution time: 0.1602
INFO - 2015-12-26 03:34:39 --> Config Class Initialized
INFO - 2015-12-26 03:34:39 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:39 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:39 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:39 --> URI Class Initialized
INFO - 2015-12-26 03:34:39 --> Router Class Initialized
INFO - 2015-12-26 03:34:39 --> Output Class Initialized
INFO - 2015-12-26 03:34:39 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:39 --> Input Class Initialized
INFO - 2015-12-26 03:34:39 --> Language Class Initialized
INFO - 2015-12-26 03:34:39 --> Loader Class Initialized
INFO - 2015-12-26 03:34:39 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:39 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:39 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:39 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:39 --> Model Class Initialized
INFO - 2015-12-26 03:34:39 --> Model Class Initialized
INFO - 2015-12-26 03:34:39 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:39 --> Total execution time: 0.1425
INFO - 2015-12-26 03:34:41 --> Config Class Initialized
INFO - 2015-12-26 03:34:41 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:41 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:41 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:41 --> URI Class Initialized
INFO - 2015-12-26 03:34:41 --> Router Class Initialized
INFO - 2015-12-26 03:34:41 --> Output Class Initialized
INFO - 2015-12-26 03:34:41 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:41 --> Input Class Initialized
INFO - 2015-12-26 03:34:41 --> Language Class Initialized
INFO - 2015-12-26 03:34:41 --> Loader Class Initialized
INFO - 2015-12-26 03:34:41 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:41 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:41 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:41 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:41 --> Model Class Initialized
INFO - 2015-12-26 03:34:41 --> Model Class Initialized
INFO - 2015-12-26 03:34:41 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:41 --> Total execution time: 0.1011
INFO - 2015-12-26 03:34:42 --> Config Class Initialized
INFO - 2015-12-26 03:34:42 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:42 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:42 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:42 --> URI Class Initialized
INFO - 2015-12-26 03:34:42 --> Router Class Initialized
INFO - 2015-12-26 03:34:42 --> Output Class Initialized
INFO - 2015-12-26 03:34:42 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:42 --> Input Class Initialized
INFO - 2015-12-26 03:34:42 --> Language Class Initialized
INFO - 2015-12-26 03:34:42 --> Loader Class Initialized
INFO - 2015-12-26 03:34:42 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:42 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:42 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:42 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:42 --> Model Class Initialized
INFO - 2015-12-26 03:34:42 --> Model Class Initialized
INFO - 2015-12-26 03:34:42 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:42 --> Total execution time: 0.1143
INFO - 2015-12-26 03:34:44 --> Config Class Initialized
INFO - 2015-12-26 03:34:44 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:44 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:44 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:44 --> URI Class Initialized
INFO - 2015-12-26 03:34:44 --> Router Class Initialized
INFO - 2015-12-26 03:34:44 --> Output Class Initialized
INFO - 2015-12-26 03:34:44 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:44 --> Input Class Initialized
INFO - 2015-12-26 03:34:44 --> Language Class Initialized
INFO - 2015-12-26 03:34:44 --> Loader Class Initialized
INFO - 2015-12-26 03:34:44 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:44 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:44 --> Controller Class Initialized
INFO - 2015-12-26 03:34:44 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-26 03:34:44 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:44 --> Total execution time: 0.0798
INFO - 2015-12-26 03:34:44 --> Config Class Initialized
INFO - 2015-12-26 03:34:44 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:44 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:44 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:44 --> URI Class Initialized
INFO - 2015-12-26 03:34:44 --> Router Class Initialized
INFO - 2015-12-26 03:34:44 --> Output Class Initialized
INFO - 2015-12-26 03:34:44 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:44 --> Input Class Initialized
INFO - 2015-12-26 03:34:44 --> Language Class Initialized
INFO - 2015-12-26 03:34:44 --> Loader Class Initialized
INFO - 2015-12-26 03:34:44 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:44 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:44 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:44 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:44 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:44 --> Model Class Initialized
INFO - 2015-12-26 03:34:44 --> Model Class Initialized
INFO - 2015-12-26 03:34:44 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:44 --> Total execution time: 0.0985
INFO - 2015-12-26 03:34:45 --> Config Class Initialized
INFO - 2015-12-26 03:34:45 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:45 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:45 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:45 --> URI Class Initialized
INFO - 2015-12-26 03:34:45 --> Router Class Initialized
INFO - 2015-12-26 03:34:45 --> Output Class Initialized
INFO - 2015-12-26 03:34:45 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:45 --> Input Class Initialized
INFO - 2015-12-26 03:34:45 --> Language Class Initialized
INFO - 2015-12-26 03:34:45 --> Loader Class Initialized
INFO - 2015-12-26 03:34:45 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:45 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:45 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:45 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:45 --> Model Class Initialized
INFO - 2015-12-26 03:34:45 --> Model Class Initialized
INFO - 2015-12-26 03:34:45 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:45 --> Total execution time: 0.0957
INFO - 2015-12-26 03:34:46 --> Config Class Initialized
INFO - 2015-12-26 03:34:46 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:46 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:46 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:46 --> URI Class Initialized
INFO - 2015-12-26 03:34:46 --> Router Class Initialized
INFO - 2015-12-26 03:34:46 --> Output Class Initialized
INFO - 2015-12-26 03:34:46 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:46 --> Input Class Initialized
INFO - 2015-12-26 03:34:46 --> Language Class Initialized
INFO - 2015-12-26 03:34:46 --> Loader Class Initialized
INFO - 2015-12-26 03:34:46 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:46 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:46 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:46 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:46 --> Model Class Initialized
INFO - 2015-12-26 03:34:46 --> Model Class Initialized
INFO - 2015-12-26 03:34:46 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:46 --> Total execution time: 0.1232
INFO - 2015-12-26 03:34:47 --> Config Class Initialized
INFO - 2015-12-26 03:34:47 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:47 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:47 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:47 --> URI Class Initialized
INFO - 2015-12-26 03:34:47 --> Router Class Initialized
INFO - 2015-12-26 03:34:47 --> Output Class Initialized
INFO - 2015-12-26 03:34:47 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:47 --> Input Class Initialized
INFO - 2015-12-26 03:34:47 --> Language Class Initialized
INFO - 2015-12-26 03:34:47 --> Loader Class Initialized
INFO - 2015-12-26 03:34:47 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:47 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:47 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:47 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:47 --> Model Class Initialized
INFO - 2015-12-26 03:34:47 --> Model Class Initialized
INFO - 2015-12-26 03:34:47 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:47 --> Total execution time: 0.1155
INFO - 2015-12-26 03:34:48 --> Config Class Initialized
INFO - 2015-12-26 03:34:48 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:48 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:48 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:48 --> URI Class Initialized
INFO - 2015-12-26 03:34:48 --> Router Class Initialized
INFO - 2015-12-26 03:34:48 --> Output Class Initialized
INFO - 2015-12-26 03:34:48 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:48 --> Input Class Initialized
INFO - 2015-12-26 03:34:48 --> Language Class Initialized
INFO - 2015-12-26 03:34:48 --> Loader Class Initialized
INFO - 2015-12-26 03:34:48 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:48 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:48 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:48 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:48 --> Model Class Initialized
INFO - 2015-12-26 03:34:48 --> Model Class Initialized
INFO - 2015-12-26 03:34:48 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:48 --> Total execution time: 0.1116
INFO - 2015-12-26 03:34:49 --> Config Class Initialized
INFO - 2015-12-26 03:34:49 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:49 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:49 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:49 --> URI Class Initialized
INFO - 2015-12-26 03:34:49 --> Router Class Initialized
INFO - 2015-12-26 03:34:49 --> Output Class Initialized
INFO - 2015-12-26 03:34:49 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:49 --> Input Class Initialized
INFO - 2015-12-26 03:34:49 --> Language Class Initialized
INFO - 2015-12-26 03:34:49 --> Loader Class Initialized
INFO - 2015-12-26 03:34:49 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:49 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:49 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:49 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:49 --> Model Class Initialized
INFO - 2015-12-26 03:34:49 --> Model Class Initialized
INFO - 2015-12-26 03:34:49 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:49 --> Total execution time: 0.1055
INFO - 2015-12-26 03:34:50 --> Config Class Initialized
INFO - 2015-12-26 03:34:50 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:50 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:50 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:50 --> URI Class Initialized
INFO - 2015-12-26 03:34:50 --> Router Class Initialized
INFO - 2015-12-26 03:34:50 --> Output Class Initialized
INFO - 2015-12-26 03:34:50 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:50 --> Input Class Initialized
INFO - 2015-12-26 03:34:50 --> Language Class Initialized
INFO - 2015-12-26 03:34:50 --> Loader Class Initialized
INFO - 2015-12-26 03:34:50 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:50 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:50 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:50 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:50 --> Model Class Initialized
INFO - 2015-12-26 03:34:50 --> Model Class Initialized
INFO - 2015-12-26 03:34:50 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:50 --> Total execution time: 0.0957
INFO - 2015-12-26 03:34:52 --> Config Class Initialized
INFO - 2015-12-26 03:34:52 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:52 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:52 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:52 --> URI Class Initialized
INFO - 2015-12-26 03:34:52 --> Router Class Initialized
INFO - 2015-12-26 03:34:52 --> Output Class Initialized
INFO - 2015-12-26 03:34:52 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:52 --> Input Class Initialized
INFO - 2015-12-26 03:34:52 --> Language Class Initialized
INFO - 2015-12-26 03:34:52 --> Loader Class Initialized
INFO - 2015-12-26 03:34:52 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:52 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:52 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:52 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:52 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:52 --> Model Class Initialized
INFO - 2015-12-26 03:34:52 --> Model Class Initialized
INFO - 2015-12-26 03:34:52 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:52 --> Total execution time: 0.0978
INFO - 2015-12-26 03:34:52 --> Config Class Initialized
INFO - 2015-12-26 03:34:52 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:52 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:52 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:52 --> URI Class Initialized
INFO - 2015-12-26 03:34:52 --> Router Class Initialized
INFO - 2015-12-26 03:34:52 --> Output Class Initialized
INFO - 2015-12-26 03:34:52 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:52 --> Input Class Initialized
INFO - 2015-12-26 03:34:52 --> Language Class Initialized
INFO - 2015-12-26 03:34:52 --> Loader Class Initialized
INFO - 2015-12-26 03:34:52 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:52 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:52 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:52 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:52 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:52 --> Model Class Initialized
INFO - 2015-12-26 03:34:52 --> Model Class Initialized
INFO - 2015-12-26 03:34:52 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:52 --> Total execution time: 0.1008
INFO - 2015-12-26 03:34:54 --> Config Class Initialized
INFO - 2015-12-26 03:34:54 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:54 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:54 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:54 --> URI Class Initialized
INFO - 2015-12-26 03:34:54 --> Router Class Initialized
INFO - 2015-12-26 03:34:54 --> Output Class Initialized
INFO - 2015-12-26 03:34:54 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:54 --> Input Class Initialized
INFO - 2015-12-26 03:34:54 --> Language Class Initialized
INFO - 2015-12-26 03:34:54 --> Loader Class Initialized
INFO - 2015-12-26 03:34:54 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:54 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:54 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:54 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:54 --> Model Class Initialized
INFO - 2015-12-26 03:34:54 --> Model Class Initialized
INFO - 2015-12-26 03:34:54 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:54 --> Total execution time: 0.1521
INFO - 2015-12-26 03:34:54 --> Config Class Initialized
INFO - 2015-12-26 03:34:54 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:54 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:54 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:54 --> URI Class Initialized
INFO - 2015-12-26 03:34:54 --> Router Class Initialized
INFO - 2015-12-26 03:34:54 --> Output Class Initialized
INFO - 2015-12-26 03:34:54 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:54 --> Input Class Initialized
INFO - 2015-12-26 03:34:54 --> Language Class Initialized
INFO - 2015-12-26 03:34:54 --> Loader Class Initialized
INFO - 2015-12-26 03:34:54 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:54 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:54 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:54 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:54 --> Model Class Initialized
INFO - 2015-12-26 03:34:54 --> Model Class Initialized
INFO - 2015-12-26 03:34:54 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:54 --> Total execution time: 0.1011
INFO - 2015-12-26 03:34:57 --> Config Class Initialized
INFO - 2015-12-26 03:34:57 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:57 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:57 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:57 --> URI Class Initialized
INFO - 2015-12-26 03:34:57 --> Router Class Initialized
INFO - 2015-12-26 03:34:57 --> Output Class Initialized
INFO - 2015-12-26 03:34:57 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:57 --> Input Class Initialized
INFO - 2015-12-26 03:34:57 --> Language Class Initialized
INFO - 2015-12-26 03:34:57 --> Loader Class Initialized
INFO - 2015-12-26 03:34:57 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:57 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:57 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:57 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:57 --> Model Class Initialized
INFO - 2015-12-26 03:34:57 --> Model Class Initialized
INFO - 2015-12-26 03:34:57 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:57 --> Total execution time: 0.1107
INFO - 2015-12-26 03:34:57 --> Config Class Initialized
INFO - 2015-12-26 03:34:57 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:57 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:57 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:57 --> URI Class Initialized
INFO - 2015-12-26 03:34:57 --> Router Class Initialized
INFO - 2015-12-26 03:34:57 --> Output Class Initialized
INFO - 2015-12-26 03:34:57 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:57 --> Input Class Initialized
INFO - 2015-12-26 03:34:57 --> Language Class Initialized
INFO - 2015-12-26 03:34:57 --> Loader Class Initialized
INFO - 2015-12-26 03:34:57 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:57 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:57 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:57 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:57 --> Model Class Initialized
INFO - 2015-12-26 03:34:57 --> Model Class Initialized
INFO - 2015-12-26 03:34:57 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:57 --> Total execution time: 0.1035
INFO - 2015-12-26 03:34:58 --> Config Class Initialized
INFO - 2015-12-26 03:34:58 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:58 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:58 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:58 --> URI Class Initialized
INFO - 2015-12-26 03:34:58 --> Router Class Initialized
INFO - 2015-12-26 03:34:58 --> Output Class Initialized
INFO - 2015-12-26 03:34:58 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:58 --> Input Class Initialized
INFO - 2015-12-26 03:34:58 --> Language Class Initialized
INFO - 2015-12-26 03:34:58 --> Loader Class Initialized
INFO - 2015-12-26 03:34:58 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:59 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:59 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:59 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:59 --> Model Class Initialized
INFO - 2015-12-26 03:34:59 --> Model Class Initialized
INFO - 2015-12-26 03:34:59 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:59 --> Total execution time: 0.0983
INFO - 2015-12-26 03:34:59 --> Config Class Initialized
INFO - 2015-12-26 03:34:59 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:34:59 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:34:59 --> Utf8 Class Initialized
INFO - 2015-12-26 03:34:59 --> URI Class Initialized
INFO - 2015-12-26 03:34:59 --> Router Class Initialized
INFO - 2015-12-26 03:34:59 --> Output Class Initialized
INFO - 2015-12-26 03:34:59 --> Security Class Initialized
DEBUG - 2015-12-26 03:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:34:59 --> Input Class Initialized
INFO - 2015-12-26 03:34:59 --> Language Class Initialized
INFO - 2015-12-26 03:34:59 --> Loader Class Initialized
INFO - 2015-12-26 03:34:59 --> Helper loaded: url_helper
INFO - 2015-12-26 03:34:59 --> Database Driver Class Initialized
INFO - 2015-12-26 03:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:34:59 --> Controller Class Initialized
DEBUG - 2015-12-26 03:34:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:34:59 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:34:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:34:59 --> Model Class Initialized
INFO - 2015-12-26 03:34:59 --> Model Class Initialized
INFO - 2015-12-26 03:34:59 --> Final output sent to browser
DEBUG - 2015-12-26 03:34:59 --> Total execution time: 0.1125
INFO - 2015-12-26 03:35:00 --> Config Class Initialized
INFO - 2015-12-26 03:35:00 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:35:00 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:35:00 --> Utf8 Class Initialized
INFO - 2015-12-26 03:35:00 --> URI Class Initialized
INFO - 2015-12-26 03:35:00 --> Router Class Initialized
INFO - 2015-12-26 03:35:01 --> Output Class Initialized
INFO - 2015-12-26 03:35:01 --> Security Class Initialized
DEBUG - 2015-12-26 03:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:35:01 --> Input Class Initialized
INFO - 2015-12-26 03:35:01 --> Language Class Initialized
INFO - 2015-12-26 03:35:01 --> Loader Class Initialized
INFO - 2015-12-26 03:35:01 --> Helper loaded: url_helper
INFO - 2015-12-26 03:35:01 --> Database Driver Class Initialized
INFO - 2015-12-26 03:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:35:01 --> Controller Class Initialized
DEBUG - 2015-12-26 03:35:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:35:01 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:35:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:35:01 --> Model Class Initialized
INFO - 2015-12-26 03:35:01 --> Model Class Initialized
INFO - 2015-12-26 03:35:01 --> Final output sent to browser
DEBUG - 2015-12-26 03:35:01 --> Total execution time: 0.1311
INFO - 2015-12-26 03:35:01 --> Config Class Initialized
INFO - 2015-12-26 03:35:01 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:35:01 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:35:01 --> Utf8 Class Initialized
INFO - 2015-12-26 03:35:01 --> URI Class Initialized
INFO - 2015-12-26 03:35:01 --> Router Class Initialized
INFO - 2015-12-26 03:35:01 --> Output Class Initialized
INFO - 2015-12-26 03:35:01 --> Security Class Initialized
DEBUG - 2015-12-26 03:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:35:01 --> Input Class Initialized
INFO - 2015-12-26 03:35:01 --> Language Class Initialized
INFO - 2015-12-26 03:35:01 --> Loader Class Initialized
INFO - 2015-12-26 03:35:01 --> Helper loaded: url_helper
INFO - 2015-12-26 03:35:01 --> Database Driver Class Initialized
INFO - 2015-12-26 03:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:35:01 --> Controller Class Initialized
DEBUG - 2015-12-26 03:35:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 03:35:01 --> Helper loaded: inflector_helper
INFO - 2015-12-26 03:35:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 03:35:01 --> Model Class Initialized
INFO - 2015-12-26 03:35:01 --> Model Class Initialized
INFO - 2015-12-26 03:35:01 --> Final output sent to browser
DEBUG - 2015-12-26 03:35:01 --> Total execution time: 0.1543
INFO - 2015-12-26 03:35:03 --> Config Class Initialized
INFO - 2015-12-26 03:35:03 --> Hooks Class Initialized
DEBUG - 2015-12-26 03:35:03 --> UTF-8 Support Enabled
INFO - 2015-12-26 03:35:03 --> Utf8 Class Initialized
INFO - 2015-12-26 03:35:03 --> URI Class Initialized
DEBUG - 2015-12-26 03:35:03 --> No URI present. Default controller set.
INFO - 2015-12-26 03:35:03 --> Router Class Initialized
INFO - 2015-12-26 03:35:03 --> Output Class Initialized
INFO - 2015-12-26 03:35:03 --> Security Class Initialized
DEBUG - 2015-12-26 03:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 03:35:03 --> Input Class Initialized
INFO - 2015-12-26 03:35:03 --> Language Class Initialized
INFO - 2015-12-26 03:35:03 --> Loader Class Initialized
INFO - 2015-12-26 03:35:03 --> Helper loaded: url_helper
INFO - 2015-12-26 03:35:03 --> Database Driver Class Initialized
INFO - 2015-12-26 03:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 03:35:03 --> Controller Class Initialized
INFO - 2015-12-26 03:35:03 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 03:35:03 --> Final output sent to browser
DEBUG - 2015-12-26 03:35:03 --> Total execution time: 0.0820
INFO - 2015-12-26 05:48:15 --> Config Class Initialized
INFO - 2015-12-26 05:48:15 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:48:15 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:48:16 --> Utf8 Class Initialized
INFO - 2015-12-26 05:48:16 --> URI Class Initialized
INFO - 2015-12-26 05:48:16 --> Router Class Initialized
INFO - 2015-12-26 05:48:16 --> Output Class Initialized
INFO - 2015-12-26 05:48:16 --> Security Class Initialized
DEBUG - 2015-12-26 05:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:48:16 --> Input Class Initialized
INFO - 2015-12-26 05:48:16 --> Language Class Initialized
INFO - 2015-12-26 05:48:16 --> Loader Class Initialized
INFO - 2015-12-26 05:48:16 --> Helper loaded: url_helper
INFO - 2015-12-26 05:48:16 --> Database Driver Class Initialized
INFO - 2015-12-26 05:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:48:16 --> Controller Class Initialized
INFO - 2015-12-26 05:48:16 --> Helper loaded: form_helper
INFO - 2015-12-26 05:48:16 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 05:48:16 --> Final output sent to browser
DEBUG - 2015-12-26 05:48:16 --> Total execution time: 0.4390
INFO - 2015-12-26 05:50:57 --> Config Class Initialized
INFO - 2015-12-26 05:50:57 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:50:57 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:50:57 --> Utf8 Class Initialized
INFO - 2015-12-26 05:50:57 --> URI Class Initialized
INFO - 2015-12-26 05:50:57 --> Router Class Initialized
INFO - 2015-12-26 05:50:57 --> Output Class Initialized
INFO - 2015-12-26 05:50:57 --> Security Class Initialized
DEBUG - 2015-12-26 05:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:50:57 --> Input Class Initialized
INFO - 2015-12-26 05:50:57 --> Language Class Initialized
INFO - 2015-12-26 05:50:57 --> Loader Class Initialized
INFO - 2015-12-26 05:50:57 --> Helper loaded: url_helper
INFO - 2015-12-26 05:50:57 --> Database Driver Class Initialized
INFO - 2015-12-26 05:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:50:57 --> Controller Class Initialized
INFO - 2015-12-26 05:50:57 --> Model Class Initialized
INFO - 2015-12-26 05:50:57 --> Model Class Initialized
INFO - 2015-12-26 05:50:57 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 05:50:57 --> Final output sent to browser
DEBUG - 2015-12-26 05:50:57 --> Total execution time: 0.4215
INFO - 2015-12-26 05:50:58 --> Config Class Initialized
INFO - 2015-12-26 05:50:58 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:50:58 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:50:58 --> Utf8 Class Initialized
INFO - 2015-12-26 05:50:58 --> URI Class Initialized
INFO - 2015-12-26 05:50:58 --> Router Class Initialized
INFO - 2015-12-26 05:50:58 --> Config Class Initialized
INFO - 2015-12-26 05:50:58 --> Output Class Initialized
INFO - 2015-12-26 05:50:58 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:50:58 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:50:58 --> Security Class Initialized
INFO - 2015-12-26 05:50:58 --> Utf8 Class Initialized
INFO - 2015-12-26 05:50:58 --> URI Class Initialized
DEBUG - 2015-12-26 05:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:50:58 --> Input Class Initialized
INFO - 2015-12-26 05:50:58 --> Router Class Initialized
INFO - 2015-12-26 05:50:58 --> Language Class Initialized
INFO - 2015-12-26 05:50:58 --> Output Class Initialized
INFO - 2015-12-26 05:50:58 --> Loader Class Initialized
INFO - 2015-12-26 05:50:58 --> Security Class Initialized
INFO - 2015-12-26 05:50:58 --> Helper loaded: url_helper
DEBUG - 2015-12-26 05:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:50:58 --> Input Class Initialized
INFO - 2015-12-26 05:50:58 --> Language Class Initialized
INFO - 2015-12-26 05:50:58 --> Database Driver Class Initialized
INFO - 2015-12-26 05:50:58 --> Loader Class Initialized
INFO - 2015-12-26 05:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:50:58 --> Controller Class Initialized
INFO - 2015-12-26 05:50:58 --> Helper loaded: url_helper
INFO - 2015-12-26 05:50:58 --> Model Class Initialized
INFO - 2015-12-26 05:50:58 --> Model Class Initialized
INFO - 2015-12-26 05:50:58 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 05:50:58 --> Final output sent to browser
DEBUG - 2015-12-26 05:50:58 --> Total execution time: 0.1956
INFO - 2015-12-26 05:50:58 --> Database Driver Class Initialized
INFO - 2015-12-26 05:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:50:58 --> Controller Class Initialized
DEBUG - 2015-12-26 05:50:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 05:50:58 --> Helper loaded: inflector_helper
INFO - 2015-12-26 05:50:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 05:50:58 --> Model Class Initialized
INFO - 2015-12-26 05:50:58 --> Model Class Initialized
INFO - 2015-12-26 05:50:58 --> Final output sent to browser
DEBUG - 2015-12-26 05:50:58 --> Total execution time: 0.2405
INFO - 2015-12-26 05:55:03 --> Config Class Initialized
INFO - 2015-12-26 05:55:03 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:03 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:03 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:03 --> URI Class Initialized
INFO - 2015-12-26 05:55:03 --> Router Class Initialized
INFO - 2015-12-26 05:55:03 --> Output Class Initialized
INFO - 2015-12-26 05:55:03 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:03 --> Input Class Initialized
INFO - 2015-12-26 05:55:03 --> Language Class Initialized
INFO - 2015-12-26 05:55:03 --> Loader Class Initialized
INFO - 2015-12-26 05:55:03 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:03 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:03 --> Controller Class Initialized
INFO - 2015-12-26 05:55:03 --> Model Class Initialized
INFO - 2015-12-26 05:55:03 --> Model Class Initialized
INFO - 2015-12-26 05:55:03 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 05:55:03 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:03 --> Total execution time: 0.4078
INFO - 2015-12-26 05:55:03 --> Config Class Initialized
INFO - 2015-12-26 05:55:03 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:03 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:03 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:03 --> URI Class Initialized
INFO - 2015-12-26 05:55:03 --> Router Class Initialized
INFO - 2015-12-26 05:55:03 --> Output Class Initialized
INFO - 2015-12-26 05:55:03 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:03 --> Input Class Initialized
INFO - 2015-12-26 05:55:04 --> Language Class Initialized
INFO - 2015-12-26 05:55:04 --> Loader Class Initialized
INFO - 2015-12-26 05:55:04 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:04 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:04 --> Config Class Initialized
INFO - 2015-12-26 05:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:04 --> Hooks Class Initialized
INFO - 2015-12-26 05:55:04 --> Controller Class Initialized
INFO - 2015-12-26 05:55:04 --> Model Class Initialized
INFO - 2015-12-26 05:55:04 --> Model Class Initialized
DEBUG - 2015-12-26 05:55:04 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:04 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 05:55:04 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:04 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:04 --> Total execution time: 0.1615
INFO - 2015-12-26 05:55:04 --> URI Class Initialized
INFO - 2015-12-26 05:55:04 --> Router Class Initialized
INFO - 2015-12-26 05:55:04 --> Output Class Initialized
INFO - 2015-12-26 05:55:04 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:04 --> Input Class Initialized
INFO - 2015-12-26 05:55:04 --> Language Class Initialized
INFO - 2015-12-26 05:55:04 --> Loader Class Initialized
INFO - 2015-12-26 05:55:04 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:04 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:04 --> Controller Class Initialized
DEBUG - 2015-12-26 05:55:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 05:55:04 --> Helper loaded: inflector_helper
INFO - 2015-12-26 05:55:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 05:55:04 --> Model Class Initialized
INFO - 2015-12-26 05:55:04 --> Model Class Initialized
INFO - 2015-12-26 05:55:04 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:04 --> Total execution time: 0.2055
INFO - 2015-12-26 05:55:05 --> Config Class Initialized
INFO - 2015-12-26 05:55:05 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:05 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:05 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:05 --> URI Class Initialized
INFO - 2015-12-26 05:55:05 --> Router Class Initialized
INFO - 2015-12-26 05:55:05 --> Output Class Initialized
INFO - 2015-12-26 05:55:05 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:05 --> Input Class Initialized
INFO - 2015-12-26 05:55:05 --> Language Class Initialized
INFO - 2015-12-26 05:55:05 --> Loader Class Initialized
INFO - 2015-12-26 05:55:05 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:05 --> Database Driver Class Initialized
ERROR - 2015-12-26 05:55:05 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2015-12-26 05:55:05 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
INFO - 2015-12-26 05:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:05 --> Controller Class Initialized
ERROR - 2015-12-26 05:55:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/libraries/Session/Session_driver.php 110
ERROR - 2015-12-26 05:55:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/helpers/url_helper.php 561
INFO - 2015-12-26 05:55:08 --> Config Class Initialized
INFO - 2015-12-26 05:55:08 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:08 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:08 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:08 --> URI Class Initialized
INFO - 2015-12-26 05:55:08 --> Router Class Initialized
INFO - 2015-12-26 05:55:08 --> Output Class Initialized
INFO - 2015-12-26 05:55:08 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:08 --> Input Class Initialized
INFO - 2015-12-26 05:55:08 --> Language Class Initialized
INFO - 2015-12-26 05:55:08 --> Loader Class Initialized
INFO - 2015-12-26 05:55:08 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:08 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:08 --> Controller Class Initialized
INFO - 2015-12-26 05:55:09 --> Model Class Initialized
INFO - 2015-12-26 05:55:09 --> Model Class Initialized
ERROR - 2015-12-26 05:55:09 --> Severity: Notice --> Undefined variable: username /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php 30
INFO - 2015-12-26 05:55:09 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 05:55:09 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:09 --> Total execution time: 0.1605
INFO - 2015-12-26 05:55:09 --> Config Class Initialized
INFO - 2015-12-26 05:55:09 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:09 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:09 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:09 --> URI Class Initialized
INFO - 2015-12-26 05:55:09 --> Router Class Initialized
INFO - 2015-12-26 05:55:09 --> Output Class Initialized
INFO - 2015-12-26 05:55:09 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:09 --> Input Class Initialized
INFO - 2015-12-26 05:55:09 --> Language Class Initialized
INFO - 2015-12-26 05:55:09 --> Loader Class Initialized
INFO - 2015-12-26 05:55:09 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:09 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:09 --> Controller Class Initialized
INFO - 2015-12-26 05:55:09 --> Helper loaded: form_helper
INFO - 2015-12-26 05:55:09 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 05:55:09 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:09 --> Total execution time: 0.1394
INFO - 2015-12-26 05:55:12 --> Config Class Initialized
INFO - 2015-12-26 05:55:12 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:12 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:12 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:12 --> URI Class Initialized
INFO - 2015-12-26 05:55:12 --> Router Class Initialized
INFO - 2015-12-26 05:55:12 --> Output Class Initialized
INFO - 2015-12-26 05:55:12 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:12 --> Input Class Initialized
INFO - 2015-12-26 05:55:12 --> Language Class Initialized
INFO - 2015-12-26 05:55:12 --> Loader Class Initialized
INFO - 2015-12-26 05:55:12 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:12 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:12 --> Controller Class Initialized
INFO - 2015-12-26 05:55:12 --> Helper loaded: form_helper
INFO - 2015-12-26 05:55:12 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 05:55:12 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:12 --> Total execution time: 0.0930
INFO - 2015-12-26 05:55:15 --> Config Class Initialized
INFO - 2015-12-26 05:55:15 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:15 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:15 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:15 --> URI Class Initialized
INFO - 2015-12-26 05:55:15 --> Router Class Initialized
INFO - 2015-12-26 05:55:15 --> Output Class Initialized
INFO - 2015-12-26 05:55:15 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:15 --> Input Class Initialized
INFO - 2015-12-26 05:55:15 --> Language Class Initialized
INFO - 2015-12-26 05:55:15 --> Loader Class Initialized
INFO - 2015-12-26 05:55:15 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:15 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:15 --> Controller Class Initialized
INFO - 2015-12-26 05:55:15 --> Model Class Initialized
INFO - 2015-12-26 05:55:15 --> Model Class Initialized
INFO - 2015-12-26 05:55:15 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 05:55:15 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:15 --> Total execution time: 0.1479
INFO - 2015-12-26 05:55:15 --> Config Class Initialized
INFO - 2015-12-26 05:55:15 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:15 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:15 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:15 --> URI Class Initialized
INFO - 2015-12-26 05:55:15 --> Router Class Initialized
INFO - 2015-12-26 05:55:15 --> Output Class Initialized
INFO - 2015-12-26 05:55:15 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:15 --> Input Class Initialized
INFO - 2015-12-26 05:55:15 --> Language Class Initialized
INFO - 2015-12-26 05:55:15 --> Loader Class Initialized
INFO - 2015-12-26 05:55:15 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:15 --> Config Class Initialized
INFO - 2015-12-26 05:55:15 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:15 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:15 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:15 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:15 --> URI Class Initialized
INFO - 2015-12-26 05:55:15 --> Router Class Initialized
INFO - 2015-12-26 05:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:15 --> Output Class Initialized
INFO - 2015-12-26 05:55:15 --> Controller Class Initialized
INFO - 2015-12-26 05:55:15 --> Security Class Initialized
INFO - 2015-12-26 05:55:15 --> Model Class Initialized
DEBUG - 2015-12-26 05:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:15 --> Model Class Initialized
INFO - 2015-12-26 05:55:15 --> Input Class Initialized
INFO - 2015-12-26 05:55:15 --> Language Class Initialized
INFO - 2015-12-26 05:55:15 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 05:55:16 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:16 --> Total execution time: 0.1939
INFO - 2015-12-26 05:55:16 --> Loader Class Initialized
INFO - 2015-12-26 05:55:16 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:16 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:16 --> Controller Class Initialized
DEBUG - 2015-12-26 05:55:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 05:55:16 --> Helper loaded: inflector_helper
INFO - 2015-12-26 05:55:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 05:55:16 --> Model Class Initialized
INFO - 2015-12-26 05:55:16 --> Model Class Initialized
INFO - 2015-12-26 05:55:16 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:16 --> Total execution time: 0.1819
INFO - 2015-12-26 05:55:17 --> Config Class Initialized
INFO - 2015-12-26 05:55:17 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:17 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:17 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:17 --> URI Class Initialized
INFO - 2015-12-26 05:55:17 --> Router Class Initialized
INFO - 2015-12-26 05:55:17 --> Output Class Initialized
INFO - 2015-12-26 05:55:17 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:17 --> Input Class Initialized
INFO - 2015-12-26 05:55:17 --> Language Class Initialized
INFO - 2015-12-26 05:55:17 --> Loader Class Initialized
INFO - 2015-12-26 05:55:17 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:17 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:17 --> Controller Class Initialized
INFO - 2015-12-26 05:55:17 --> Config Class Initialized
INFO - 2015-12-26 05:55:17 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:17 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:17 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:17 --> URI Class Initialized
INFO - 2015-12-26 05:55:17 --> Router Class Initialized
INFO - 2015-12-26 05:55:17 --> Output Class Initialized
INFO - 2015-12-26 05:55:17 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:17 --> Input Class Initialized
INFO - 2015-12-26 05:55:17 --> Language Class Initialized
INFO - 2015-12-26 05:55:17 --> Loader Class Initialized
INFO - 2015-12-26 05:55:17 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:17 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:17 --> Controller Class Initialized
INFO - 2015-12-26 05:55:17 --> Helper loaded: form_helper
INFO - 2015-12-26 05:55:17 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 05:55:17 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:17 --> Total execution time: 0.0914
INFO - 2015-12-26 05:55:20 --> Config Class Initialized
INFO - 2015-12-26 05:55:20 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:20 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:20 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:20 --> URI Class Initialized
INFO - 2015-12-26 05:55:20 --> Router Class Initialized
INFO - 2015-12-26 05:55:20 --> Output Class Initialized
INFO - 2015-12-26 05:55:20 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:20 --> Input Class Initialized
INFO - 2015-12-26 05:55:20 --> Language Class Initialized
INFO - 2015-12-26 05:55:20 --> Loader Class Initialized
INFO - 2015-12-26 05:55:20 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:20 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:20 --> Controller Class Initialized
INFO - 2015-12-26 05:55:20 --> Model Class Initialized
INFO - 2015-12-26 05:55:20 --> Model Class Initialized
INFO - 2015-12-26 05:55:20 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-26 05:55:20 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:20 --> Total execution time: 0.1066
INFO - 2015-12-26 05:55:20 --> Config Class Initialized
INFO - 2015-12-26 05:55:20 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:20 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:20 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:20 --> URI Class Initialized
INFO - 2015-12-26 05:55:20 --> Router Class Initialized
INFO - 2015-12-26 05:55:20 --> Output Class Initialized
INFO - 2015-12-26 05:55:20 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:21 --> Input Class Initialized
INFO - 2015-12-26 05:55:21 --> Language Class Initialized
INFO - 2015-12-26 05:55:21 --> Config Class Initialized
INFO - 2015-12-26 05:55:21 --> Hooks Class Initialized
INFO - 2015-12-26 05:55:21 --> Loader Class Initialized
DEBUG - 2015-12-26 05:55:21 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:21 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:21 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:21 --> URI Class Initialized
INFO - 2015-12-26 05:55:21 --> Router Class Initialized
INFO - 2015-12-26 05:55:21 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:21 --> Output Class Initialized
INFO - 2015-12-26 05:55:21 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:21 --> Input Class Initialized
INFO - 2015-12-26 05:55:21 --> Controller Class Initialized
INFO - 2015-12-26 05:55:21 --> Language Class Initialized
INFO - 2015-12-26 05:55:21 --> Model Class Initialized
INFO - 2015-12-26 05:55:21 --> Loader Class Initialized
INFO - 2015-12-26 05:55:21 --> Model Class Initialized
INFO - 2015-12-26 05:55:21 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:21 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 05:55:21 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:21 --> Total execution time: 0.2180
INFO - 2015-12-26 05:55:21 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:21 --> Controller Class Initialized
DEBUG - 2015-12-26 05:55:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 05:55:21 --> Helper loaded: inflector_helper
INFO - 2015-12-26 05:55:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 05:55:21 --> Model Class Initialized
INFO - 2015-12-26 05:55:21 --> Model Class Initialized
INFO - 2015-12-26 05:55:21 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:21 --> Total execution time: 0.2427
INFO - 2015-12-26 05:55:22 --> Config Class Initialized
INFO - 2015-12-26 05:55:22 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:22 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:22 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:22 --> URI Class Initialized
INFO - 2015-12-26 05:55:22 --> Router Class Initialized
INFO - 2015-12-26 05:55:22 --> Output Class Initialized
INFO - 2015-12-26 05:55:22 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:22 --> Input Class Initialized
INFO - 2015-12-26 05:55:22 --> Language Class Initialized
INFO - 2015-12-26 05:55:22 --> Loader Class Initialized
INFO - 2015-12-26 05:55:22 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:22 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:22 --> Controller Class Initialized
DEBUG - 2015-12-26 05:55:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-26 05:55:23 --> Helper loaded: inflector_helper
INFO - 2015-12-26 05:55:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-26 05:55:23 --> Model Class Initialized
INFO - 2015-12-26 05:55:23 --> Model Class Initialized
INFO - 2015-12-26 05:55:23 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:23 --> Total execution time: 0.1522
INFO - 2015-12-26 05:55:23 --> Config Class Initialized
INFO - 2015-12-26 05:55:23 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:23 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:23 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:23 --> URI Class Initialized
INFO - 2015-12-26 05:55:23 --> Router Class Initialized
INFO - 2015-12-26 05:55:23 --> Output Class Initialized
INFO - 2015-12-26 05:55:23 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:23 --> Input Class Initialized
INFO - 2015-12-26 05:55:23 --> Language Class Initialized
INFO - 2015-12-26 05:55:23 --> Loader Class Initialized
INFO - 2015-12-26 05:55:23 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:23 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:23 --> Controller Class Initialized
INFO - 2015-12-26 05:55:23 --> Config Class Initialized
INFO - 2015-12-26 05:55:23 --> Hooks Class Initialized
DEBUG - 2015-12-26 05:55:23 --> UTF-8 Support Enabled
INFO - 2015-12-26 05:55:23 --> Utf8 Class Initialized
INFO - 2015-12-26 05:55:23 --> URI Class Initialized
INFO - 2015-12-26 05:55:23 --> Router Class Initialized
INFO - 2015-12-26 05:55:23 --> Output Class Initialized
INFO - 2015-12-26 05:55:23 --> Security Class Initialized
DEBUG - 2015-12-26 05:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 05:55:23 --> Input Class Initialized
INFO - 2015-12-26 05:55:23 --> Language Class Initialized
INFO - 2015-12-26 05:55:23 --> Loader Class Initialized
INFO - 2015-12-26 05:55:23 --> Helper loaded: url_helper
INFO - 2015-12-26 05:55:23 --> Database Driver Class Initialized
INFO - 2015-12-26 05:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 05:55:23 --> Controller Class Initialized
INFO - 2015-12-26 05:55:23 --> Helper loaded: form_helper
INFO - 2015-12-26 05:55:23 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 05:55:23 --> Final output sent to browser
DEBUG - 2015-12-26 05:55:23 --> Total execution time: 0.1078
INFO - 2015-12-26 06:03:22 --> Config Class Initialized
INFO - 2015-12-26 06:03:22 --> Hooks Class Initialized
DEBUG - 2015-12-26 06:03:22 --> UTF-8 Support Enabled
INFO - 2015-12-26 06:03:22 --> Utf8 Class Initialized
INFO - 2015-12-26 06:03:22 --> URI Class Initialized
INFO - 2015-12-26 06:03:22 --> Router Class Initialized
INFO - 2015-12-26 06:03:22 --> Output Class Initialized
INFO - 2015-12-26 06:03:22 --> Security Class Initialized
DEBUG - 2015-12-26 06:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 06:03:22 --> Input Class Initialized
INFO - 2015-12-26 06:03:22 --> Language Class Initialized
INFO - 2015-12-26 06:03:22 --> Loader Class Initialized
INFO - 2015-12-26 06:03:22 --> Helper loaded: url_helper
INFO - 2015-12-26 06:03:22 --> Database Driver Class Initialized
INFO - 2015-12-26 06:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 06:03:22 --> Controller Class Initialized
INFO - 2015-12-26 06:03:22 --> Helper loaded: form_helper
INFO - 2015-12-26 06:03:22 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-26 06:03:22 --> Final output sent to browser
DEBUG - 2015-12-26 06:03:22 --> Total execution time: 0.4594
INFO - 2015-12-26 06:06:24 --> Config Class Initialized
INFO - 2015-12-26 06:06:24 --> Hooks Class Initialized
DEBUG - 2015-12-26 06:06:24 --> UTF-8 Support Enabled
INFO - 2015-12-26 06:06:24 --> Utf8 Class Initialized
INFO - 2015-12-26 06:06:24 --> URI Class Initialized
DEBUG - 2015-12-26 06:06:24 --> No URI present. Default controller set.
INFO - 2015-12-26 06:06:24 --> Router Class Initialized
INFO - 2015-12-26 06:06:24 --> Output Class Initialized
INFO - 2015-12-26 06:06:24 --> Security Class Initialized
DEBUG - 2015-12-26 06:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-26 06:06:24 --> Input Class Initialized
INFO - 2015-12-26 06:06:24 --> Language Class Initialized
INFO - 2015-12-26 06:06:24 --> Loader Class Initialized
INFO - 2015-12-26 06:06:24 --> Helper loaded: url_helper
INFO - 2015-12-26 06:06:24 --> Database Driver Class Initialized
INFO - 2015-12-26 06:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-26 06:06:24 --> Controller Class Initialized
INFO - 2015-12-26 06:06:24 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-26 06:06:24 --> Final output sent to browser
DEBUG - 2015-12-26 06:06:24 --> Total execution time: 0.3832
