<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-04 01:16:39 --> Config Class Initialized
INFO - 2016-01-04 01:16:39 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:16:39 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:16:39 --> Utf8 Class Initialized
INFO - 2016-01-04 01:16:39 --> URI Class Initialized
INFO - 2016-01-04 01:16:39 --> Router Class Initialized
INFO - 2016-01-04 01:16:39 --> Output Class Initialized
INFO - 2016-01-04 01:16:39 --> Security Class Initialized
DEBUG - 2016-01-04 01:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:16:39 --> Input Class Initialized
INFO - 2016-01-04 01:16:39 --> Language Class Initialized
INFO - 2016-01-04 01:16:39 --> Loader Class Initialized
INFO - 2016-01-04 01:16:39 --> Helper loaded: url_helper
INFO - 2016-01-04 01:16:39 --> Database Driver Class Initialized
INFO - 2016-01-04 01:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:16:39 --> Controller Class Initialized
INFO - 2016-01-04 01:16:39 --> Helper loaded: form_helper
INFO - 2016-01-04 01:16:39 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 01:16:39 --> Final output sent to browser
DEBUG - 2016-01-04 01:16:39 --> Total execution time: 0.1420
INFO - 2016-01-04 01:16:46 --> Config Class Initialized
INFO - 2016-01-04 01:16:46 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:16:46 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:16:46 --> Utf8 Class Initialized
INFO - 2016-01-04 01:16:46 --> URI Class Initialized
INFO - 2016-01-04 01:16:46 --> Router Class Initialized
INFO - 2016-01-04 01:16:46 --> Output Class Initialized
INFO - 2016-01-04 01:16:46 --> Security Class Initialized
DEBUG - 2016-01-04 01:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:16:46 --> Input Class Initialized
INFO - 2016-01-04 01:16:46 --> Language Class Initialized
INFO - 2016-01-04 01:16:46 --> Loader Class Initialized
INFO - 2016-01-04 01:16:46 --> Helper loaded: url_helper
INFO - 2016-01-04 01:16:46 --> Database Driver Class Initialized
INFO - 2016-01-04 01:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:16:46 --> Controller Class Initialized
INFO - 2016-01-04 01:16:46 --> Model Class Initialized
INFO - 2016-01-04 01:16:46 --> Model Class Initialized
INFO - 2016-01-04 01:16:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 01:16:46 --> Final output sent to browser
DEBUG - 2016-01-04 01:16:46 --> Total execution time: 0.1225
INFO - 2016-01-04 01:16:46 --> Config Class Initialized
INFO - 2016-01-04 01:16:46 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:16:46 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:16:46 --> Utf8 Class Initialized
INFO - 2016-01-04 01:16:46 --> URI Class Initialized
INFO - 2016-01-04 01:16:46 --> Router Class Initialized
INFO - 2016-01-04 01:16:46 --> Output Class Initialized
INFO - 2016-01-04 01:16:46 --> Security Class Initialized
DEBUG - 2016-01-04 01:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:16:46 --> Input Class Initialized
INFO - 2016-01-04 01:16:46 --> Language Class Initialized
INFO - 2016-01-04 01:16:46 --> Loader Class Initialized
INFO - 2016-01-04 01:16:46 --> Helper loaded: url_helper
INFO - 2016-01-04 01:16:46 --> Database Driver Class Initialized
INFO - 2016-01-04 01:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:16:46 --> Controller Class Initialized
INFO - 2016-01-04 01:16:46 --> Model Class Initialized
INFO - 2016-01-04 01:16:46 --> Model Class Initialized
INFO - 2016-01-04 01:16:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 01:16:46 --> Final output sent to browser
DEBUG - 2016-01-04 01:16:46 --> Total execution time: 0.1487
INFO - 2016-01-04 01:16:46 --> Config Class Initialized
INFO - 2016-01-04 01:16:46 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:16:46 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:16:46 --> Utf8 Class Initialized
INFO - 2016-01-04 01:16:46 --> URI Class Initialized
INFO - 2016-01-04 01:16:46 --> Router Class Initialized
INFO - 2016-01-04 01:16:46 --> Output Class Initialized
INFO - 2016-01-04 01:16:46 --> Security Class Initialized
DEBUG - 2016-01-04 01:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:16:46 --> Input Class Initialized
INFO - 2016-01-04 01:16:46 --> Language Class Initialized
INFO - 2016-01-04 01:16:46 --> Loader Class Initialized
INFO - 2016-01-04 01:16:46 --> Helper loaded: url_helper
INFO - 2016-01-04 01:16:46 --> Database Driver Class Initialized
INFO - 2016-01-04 01:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:16:46 --> Controller Class Initialized
DEBUG - 2016-01-04 01:16:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:16:46 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:16:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:16:46 --> Model Class Initialized
INFO - 2016-01-04 01:16:46 --> Model Class Initialized
INFO - 2016-01-04 01:16:46 --> Final output sent to browser
DEBUG - 2016-01-04 01:16:46 --> Total execution time: 0.1411
INFO - 2016-01-04 01:16:55 --> Config Class Initialized
INFO - 2016-01-04 01:16:55 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:16:56 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:16:56 --> Utf8 Class Initialized
INFO - 2016-01-04 01:16:56 --> URI Class Initialized
INFO - 2016-01-04 01:16:56 --> Router Class Initialized
INFO - 2016-01-04 01:16:56 --> Output Class Initialized
INFO - 2016-01-04 01:16:56 --> Security Class Initialized
DEBUG - 2016-01-04 01:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:16:56 --> Input Class Initialized
INFO - 2016-01-04 01:16:56 --> Language Class Initialized
INFO - 2016-01-04 01:16:56 --> Loader Class Initialized
INFO - 2016-01-04 01:16:56 --> Helper loaded: url_helper
INFO - 2016-01-04 01:16:56 --> Database Driver Class Initialized
INFO - 2016-01-04 01:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:16:56 --> Controller Class Initialized
DEBUG - 2016-01-04 01:16:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:16:56 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:16:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:16:56 --> Model Class Initialized
INFO - 2016-01-04 01:16:56 --> Model Class Initialized
INFO - 2016-01-04 01:16:56 --> Final output sent to browser
DEBUG - 2016-01-04 01:16:56 --> Total execution time: 0.1318
INFO - 2016-01-04 01:17:08 --> Config Class Initialized
INFO - 2016-01-04 01:17:08 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:17:08 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:17:08 --> Utf8 Class Initialized
INFO - 2016-01-04 01:17:08 --> URI Class Initialized
INFO - 2016-01-04 01:17:08 --> Router Class Initialized
INFO - 2016-01-04 01:17:08 --> Output Class Initialized
INFO - 2016-01-04 01:17:08 --> Security Class Initialized
DEBUG - 2016-01-04 01:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:17:08 --> Input Class Initialized
INFO - 2016-01-04 01:17:08 --> Language Class Initialized
INFO - 2016-01-04 01:17:08 --> Loader Class Initialized
INFO - 2016-01-04 01:17:08 --> Helper loaded: url_helper
INFO - 2016-01-04 01:17:08 --> Database Driver Class Initialized
INFO - 2016-01-04 01:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:17:08 --> Controller Class Initialized
DEBUG - 2016-01-04 01:17:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:17:08 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:17:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:17:08 --> Model Class Initialized
INFO - 2016-01-04 01:17:08 --> Model Class Initialized
INFO - 2016-01-04 01:17:08 --> Final output sent to browser
DEBUG - 2016-01-04 01:17:08 --> Total execution time: 0.1387
INFO - 2016-01-04 01:17:08 --> Config Class Initialized
INFO - 2016-01-04 01:17:08 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:17:08 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:17:08 --> Utf8 Class Initialized
INFO - 2016-01-04 01:17:08 --> URI Class Initialized
INFO - 2016-01-04 01:17:08 --> Router Class Initialized
INFO - 2016-01-04 01:17:08 --> Output Class Initialized
INFO - 2016-01-04 01:17:08 --> Security Class Initialized
DEBUG - 2016-01-04 01:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:17:08 --> Input Class Initialized
INFO - 2016-01-04 01:17:08 --> Language Class Initialized
INFO - 2016-01-04 01:17:08 --> Loader Class Initialized
INFO - 2016-01-04 01:17:08 --> Helper loaded: url_helper
INFO - 2016-01-04 01:17:08 --> Database Driver Class Initialized
INFO - 2016-01-04 01:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:17:08 --> Controller Class Initialized
DEBUG - 2016-01-04 01:17:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:17:08 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:17:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:17:08 --> Model Class Initialized
INFO - 2016-01-04 01:17:08 --> Model Class Initialized
INFO - 2016-01-04 01:17:08 --> Final output sent to browser
DEBUG - 2016-01-04 01:17:08 --> Total execution time: 0.1528
INFO - 2016-01-04 01:17:14 --> Config Class Initialized
INFO - 2016-01-04 01:17:14 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:17:14 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:17:14 --> Utf8 Class Initialized
INFO - 2016-01-04 01:17:14 --> URI Class Initialized
INFO - 2016-01-04 01:17:14 --> Router Class Initialized
INFO - 2016-01-04 01:17:14 --> Output Class Initialized
INFO - 2016-01-04 01:17:14 --> Security Class Initialized
DEBUG - 2016-01-04 01:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:17:14 --> Input Class Initialized
INFO - 2016-01-04 01:17:14 --> Language Class Initialized
INFO - 2016-01-04 01:17:14 --> Loader Class Initialized
INFO - 2016-01-04 01:17:14 --> Helper loaded: url_helper
INFO - 2016-01-04 01:17:14 --> Database Driver Class Initialized
INFO - 2016-01-04 01:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:17:14 --> Controller Class Initialized
DEBUG - 2016-01-04 01:17:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:17:14 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:17:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:17:14 --> Model Class Initialized
INFO - 2016-01-04 01:17:14 --> Model Class Initialized
INFO - 2016-01-04 01:17:14 --> Final output sent to browser
DEBUG - 2016-01-04 01:17:14 --> Total execution time: 0.1378
INFO - 2016-01-04 01:18:24 --> Config Class Initialized
INFO - 2016-01-04 01:18:24 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:18:24 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:18:24 --> Utf8 Class Initialized
INFO - 2016-01-04 01:18:24 --> URI Class Initialized
INFO - 2016-01-04 01:18:24 --> Router Class Initialized
INFO - 2016-01-04 01:18:24 --> Output Class Initialized
INFO - 2016-01-04 01:18:24 --> Security Class Initialized
DEBUG - 2016-01-04 01:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:18:24 --> Input Class Initialized
INFO - 2016-01-04 01:18:24 --> Language Class Initialized
INFO - 2016-01-04 01:18:24 --> Loader Class Initialized
INFO - 2016-01-04 01:18:24 --> Helper loaded: url_helper
INFO - 2016-01-04 01:18:24 --> Database Driver Class Initialized
INFO - 2016-01-04 01:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:18:24 --> Controller Class Initialized
DEBUG - 2016-01-04 01:18:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:18:24 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:18:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:18:24 --> Model Class Initialized
INFO - 2016-01-04 01:18:24 --> Model Class Initialized
INFO - 2016-01-04 01:18:24 --> Final output sent to browser
DEBUG - 2016-01-04 01:18:24 --> Total execution time: 0.1887
INFO - 2016-01-04 01:18:34 --> Config Class Initialized
INFO - 2016-01-04 01:18:34 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:18:34 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:18:34 --> Utf8 Class Initialized
INFO - 2016-01-04 01:18:34 --> URI Class Initialized
INFO - 2016-01-04 01:18:34 --> Router Class Initialized
INFO - 2016-01-04 01:18:34 --> Output Class Initialized
INFO - 2016-01-04 01:18:34 --> Security Class Initialized
DEBUG - 2016-01-04 01:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:18:34 --> Input Class Initialized
INFO - 2016-01-04 01:18:34 --> Language Class Initialized
INFO - 2016-01-04 01:18:34 --> Loader Class Initialized
INFO - 2016-01-04 01:18:34 --> Helper loaded: url_helper
INFO - 2016-01-04 01:18:34 --> Database Driver Class Initialized
INFO - 2016-01-04 01:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:18:34 --> Controller Class Initialized
DEBUG - 2016-01-04 01:18:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:18:34 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:18:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:18:34 --> Model Class Initialized
INFO - 2016-01-04 01:18:34 --> Model Class Initialized
INFO - 2016-01-04 01:18:34 --> Final output sent to browser
DEBUG - 2016-01-04 01:18:34 --> Total execution time: 0.1264
INFO - 2016-01-04 01:18:34 --> Config Class Initialized
INFO - 2016-01-04 01:18:34 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:18:34 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:18:34 --> Utf8 Class Initialized
INFO - 2016-01-04 01:18:34 --> URI Class Initialized
INFO - 2016-01-04 01:18:34 --> Router Class Initialized
INFO - 2016-01-04 01:18:34 --> Output Class Initialized
INFO - 2016-01-04 01:18:34 --> Security Class Initialized
DEBUG - 2016-01-04 01:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:18:34 --> Input Class Initialized
INFO - 2016-01-04 01:18:34 --> Language Class Initialized
INFO - 2016-01-04 01:18:34 --> Loader Class Initialized
INFO - 2016-01-04 01:18:34 --> Helper loaded: url_helper
INFO - 2016-01-04 01:18:34 --> Database Driver Class Initialized
INFO - 2016-01-04 01:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:18:34 --> Controller Class Initialized
DEBUG - 2016-01-04 01:18:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:18:34 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:18:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:18:34 --> Model Class Initialized
INFO - 2016-01-04 01:18:34 --> Model Class Initialized
INFO - 2016-01-04 01:18:34 --> Final output sent to browser
DEBUG - 2016-01-04 01:18:34 --> Total execution time: 0.1244
INFO - 2016-01-04 01:18:35 --> Config Class Initialized
INFO - 2016-01-04 01:18:35 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:18:35 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:18:35 --> Utf8 Class Initialized
INFO - 2016-01-04 01:18:35 --> URI Class Initialized
INFO - 2016-01-04 01:18:35 --> Router Class Initialized
INFO - 2016-01-04 01:18:35 --> Output Class Initialized
INFO - 2016-01-04 01:18:35 --> Security Class Initialized
DEBUG - 2016-01-04 01:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:18:35 --> Input Class Initialized
INFO - 2016-01-04 01:18:35 --> Language Class Initialized
INFO - 2016-01-04 01:18:35 --> Loader Class Initialized
INFO - 2016-01-04 01:18:35 --> Helper loaded: url_helper
INFO - 2016-01-04 01:18:35 --> Database Driver Class Initialized
INFO - 2016-01-04 01:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:18:35 --> Controller Class Initialized
DEBUG - 2016-01-04 01:18:35 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:18:35 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:18:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:18:35 --> Model Class Initialized
INFO - 2016-01-04 01:18:35 --> Model Class Initialized
INFO - 2016-01-04 01:18:35 --> Final output sent to browser
DEBUG - 2016-01-04 01:18:35 --> Total execution time: 0.1311
INFO - 2016-01-04 01:18:44 --> Config Class Initialized
INFO - 2016-01-04 01:18:44 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:18:44 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:18:44 --> Utf8 Class Initialized
INFO - 2016-01-04 01:18:44 --> URI Class Initialized
INFO - 2016-01-04 01:18:44 --> Router Class Initialized
INFO - 2016-01-04 01:18:44 --> Output Class Initialized
INFO - 2016-01-04 01:18:44 --> Security Class Initialized
DEBUG - 2016-01-04 01:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:18:44 --> Input Class Initialized
INFO - 2016-01-04 01:18:44 --> Language Class Initialized
INFO - 2016-01-04 01:18:44 --> Loader Class Initialized
INFO - 2016-01-04 01:18:44 --> Helper loaded: url_helper
INFO - 2016-01-04 01:18:44 --> Database Driver Class Initialized
INFO - 2016-01-04 01:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:18:44 --> Controller Class Initialized
DEBUG - 2016-01-04 01:18:44 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:18:44 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:18:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:18:44 --> Model Class Initialized
INFO - 2016-01-04 01:18:44 --> Model Class Initialized
INFO - 2016-01-04 01:18:44 --> Final output sent to browser
DEBUG - 2016-01-04 01:18:44 --> Total execution time: 0.1028
INFO - 2016-01-04 01:18:47 --> Config Class Initialized
INFO - 2016-01-04 01:18:47 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:18:47 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:18:47 --> Utf8 Class Initialized
INFO - 2016-01-04 01:18:47 --> URI Class Initialized
INFO - 2016-01-04 01:18:47 --> Router Class Initialized
INFO - 2016-01-04 01:18:47 --> Output Class Initialized
INFO - 2016-01-04 01:18:47 --> Security Class Initialized
DEBUG - 2016-01-04 01:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:18:47 --> Input Class Initialized
INFO - 2016-01-04 01:18:47 --> Language Class Initialized
INFO - 2016-01-04 01:18:47 --> Loader Class Initialized
INFO - 2016-01-04 01:18:47 --> Helper loaded: url_helper
INFO - 2016-01-04 01:18:47 --> Database Driver Class Initialized
INFO - 2016-01-04 01:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:18:47 --> Controller Class Initialized
INFO - 2016-01-04 01:18:47 --> Model Class Initialized
INFO - 2016-01-04 01:18:47 --> Model Class Initialized
INFO - 2016-01-04 01:18:47 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 01:18:47 --> Final output sent to browser
DEBUG - 2016-01-04 01:18:47 --> Total execution time: 0.1073
INFO - 2016-01-04 01:18:48 --> Config Class Initialized
INFO - 2016-01-04 01:18:48 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:18:48 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:18:48 --> Utf8 Class Initialized
INFO - 2016-01-04 01:18:48 --> URI Class Initialized
INFO - 2016-01-04 01:18:48 --> Router Class Initialized
INFO - 2016-01-04 01:18:48 --> Output Class Initialized
INFO - 2016-01-04 01:18:48 --> Security Class Initialized
DEBUG - 2016-01-04 01:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:18:48 --> Input Class Initialized
INFO - 2016-01-04 01:18:48 --> Language Class Initialized
INFO - 2016-01-04 01:18:48 --> Loader Class Initialized
INFO - 2016-01-04 01:18:48 --> Helper loaded: url_helper
INFO - 2016-01-04 01:18:48 --> Database Driver Class Initialized
INFO - 2016-01-04 01:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:18:48 --> Controller Class Initialized
INFO - 2016-01-04 01:18:48 --> Model Class Initialized
INFO - 2016-01-04 01:18:48 --> Model Class Initialized
INFO - 2016-01-04 01:18:48 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 01:18:48 --> Final output sent to browser
DEBUG - 2016-01-04 01:18:48 --> Total execution time: 0.1194
INFO - 2016-01-04 01:18:48 --> Config Class Initialized
INFO - 2016-01-04 01:18:48 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:18:48 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:18:48 --> Utf8 Class Initialized
INFO - 2016-01-04 01:18:48 --> URI Class Initialized
INFO - 2016-01-04 01:18:48 --> Router Class Initialized
INFO - 2016-01-04 01:18:48 --> Output Class Initialized
INFO - 2016-01-04 01:18:48 --> Security Class Initialized
DEBUG - 2016-01-04 01:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:18:48 --> Input Class Initialized
INFO - 2016-01-04 01:18:48 --> Language Class Initialized
INFO - 2016-01-04 01:18:48 --> Loader Class Initialized
INFO - 2016-01-04 01:18:48 --> Helper loaded: url_helper
INFO - 2016-01-04 01:18:48 --> Database Driver Class Initialized
INFO - 2016-01-04 01:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:18:48 --> Controller Class Initialized
DEBUG - 2016-01-04 01:18:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:18:48 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:18:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:18:48 --> Model Class Initialized
INFO - 2016-01-04 01:18:48 --> Model Class Initialized
INFO - 2016-01-04 01:18:48 --> Final output sent to browser
DEBUG - 2016-01-04 01:18:48 --> Total execution time: 0.1208
INFO - 2016-01-04 01:18:50 --> Config Class Initialized
INFO - 2016-01-04 01:18:50 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:18:50 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:18:50 --> Utf8 Class Initialized
INFO - 2016-01-04 01:18:50 --> URI Class Initialized
INFO - 2016-01-04 01:18:50 --> Router Class Initialized
INFO - 2016-01-04 01:18:50 --> Output Class Initialized
INFO - 2016-01-04 01:18:50 --> Security Class Initialized
DEBUG - 2016-01-04 01:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:18:50 --> Input Class Initialized
INFO - 2016-01-04 01:18:50 --> Language Class Initialized
INFO - 2016-01-04 01:18:50 --> Loader Class Initialized
INFO - 2016-01-04 01:18:50 --> Helper loaded: url_helper
INFO - 2016-01-04 01:18:50 --> Database Driver Class Initialized
INFO - 2016-01-04 01:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:18:50 --> Controller Class Initialized
DEBUG - 2016-01-04 01:18:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:18:50 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:18:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:18:50 --> Model Class Initialized
INFO - 2016-01-04 01:18:50 --> Model Class Initialized
INFO - 2016-01-04 01:18:50 --> Final output sent to browser
DEBUG - 2016-01-04 01:18:50 --> Total execution time: 0.0676
INFO - 2016-01-04 01:18:53 --> Config Class Initialized
INFO - 2016-01-04 01:18:53 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:18:53 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:18:53 --> Utf8 Class Initialized
INFO - 2016-01-04 01:18:53 --> URI Class Initialized
INFO - 2016-01-04 01:18:53 --> Router Class Initialized
INFO - 2016-01-04 01:18:53 --> Output Class Initialized
INFO - 2016-01-04 01:18:53 --> Security Class Initialized
DEBUG - 2016-01-04 01:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:18:53 --> Input Class Initialized
INFO - 2016-01-04 01:18:53 --> Language Class Initialized
INFO - 2016-01-04 01:18:53 --> Loader Class Initialized
INFO - 2016-01-04 01:18:53 --> Helper loaded: url_helper
INFO - 2016-01-04 01:18:53 --> Database Driver Class Initialized
INFO - 2016-01-04 01:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:18:53 --> Controller Class Initialized
DEBUG - 2016-01-04 01:18:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:18:53 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:18:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:18:53 --> Model Class Initialized
INFO - 2016-01-04 01:18:53 --> Model Class Initialized
INFO - 2016-01-04 01:18:53 --> Final output sent to browser
DEBUG - 2016-01-04 01:18:53 --> Total execution time: 0.1169
INFO - 2016-01-04 01:18:53 --> Config Class Initialized
INFO - 2016-01-04 01:18:53 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:18:53 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:18:53 --> Utf8 Class Initialized
INFO - 2016-01-04 01:18:53 --> URI Class Initialized
INFO - 2016-01-04 01:18:53 --> Router Class Initialized
INFO - 2016-01-04 01:18:53 --> Output Class Initialized
INFO - 2016-01-04 01:18:53 --> Security Class Initialized
DEBUG - 2016-01-04 01:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:18:53 --> Input Class Initialized
INFO - 2016-01-04 01:18:53 --> Language Class Initialized
INFO - 2016-01-04 01:18:53 --> Loader Class Initialized
INFO - 2016-01-04 01:18:53 --> Helper loaded: url_helper
INFO - 2016-01-04 01:18:53 --> Database Driver Class Initialized
INFO - 2016-01-04 01:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:18:53 --> Controller Class Initialized
DEBUG - 2016-01-04 01:18:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:18:53 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:18:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:18:53 --> Model Class Initialized
INFO - 2016-01-04 01:18:53 --> Model Class Initialized
INFO - 2016-01-04 01:18:53 --> Final output sent to browser
DEBUG - 2016-01-04 01:18:53 --> Total execution time: 0.0806
INFO - 2016-01-04 01:19:00 --> Config Class Initialized
INFO - 2016-01-04 01:19:00 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:19:00 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:19:00 --> Utf8 Class Initialized
INFO - 2016-01-04 01:19:00 --> URI Class Initialized
INFO - 2016-01-04 01:19:00 --> Router Class Initialized
INFO - 2016-01-04 01:19:00 --> Output Class Initialized
INFO - 2016-01-04 01:19:00 --> Security Class Initialized
DEBUG - 2016-01-04 01:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:19:00 --> Input Class Initialized
INFO - 2016-01-04 01:19:00 --> Language Class Initialized
INFO - 2016-01-04 01:19:00 --> Loader Class Initialized
INFO - 2016-01-04 01:19:00 --> Helper loaded: url_helper
INFO - 2016-01-04 01:19:00 --> Database Driver Class Initialized
INFO - 2016-01-04 01:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:19:00 --> Controller Class Initialized
DEBUG - 2016-01-04 01:19:00 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:19:00 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:19:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:19:00 --> Model Class Initialized
INFO - 2016-01-04 01:19:00 --> Model Class Initialized
INFO - 2016-01-04 01:19:00 --> Final output sent to browser
DEBUG - 2016-01-04 01:19:00 --> Total execution time: 0.0987
INFO - 2016-01-04 01:22:55 --> Config Class Initialized
INFO - 2016-01-04 01:22:55 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:22:55 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:22:55 --> Utf8 Class Initialized
INFO - 2016-01-04 01:22:55 --> URI Class Initialized
INFO - 2016-01-04 01:22:55 --> Router Class Initialized
INFO - 2016-01-04 01:22:55 --> Output Class Initialized
INFO - 2016-01-04 01:22:55 --> Security Class Initialized
DEBUG - 2016-01-04 01:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:22:55 --> Input Class Initialized
INFO - 2016-01-04 01:22:55 --> Language Class Initialized
INFO - 2016-01-04 01:22:55 --> Loader Class Initialized
INFO - 2016-01-04 01:22:55 --> Helper loaded: url_helper
INFO - 2016-01-04 01:22:55 --> Database Driver Class Initialized
INFO - 2016-01-04 01:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:22:55 --> Controller Class Initialized
DEBUG - 2016-01-04 01:22:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:22:55 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:22:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:22:55 --> Model Class Initialized
INFO - 2016-01-04 01:22:55 --> Model Class Initialized
INFO - 2016-01-04 01:22:55 --> Final output sent to browser
DEBUG - 2016-01-04 01:22:55 --> Total execution time: 0.1626
INFO - 2016-01-04 01:23:19 --> Config Class Initialized
INFO - 2016-01-04 01:23:19 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:23:19 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:23:19 --> Utf8 Class Initialized
INFO - 2016-01-04 01:23:19 --> URI Class Initialized
INFO - 2016-01-04 01:23:19 --> Router Class Initialized
INFO - 2016-01-04 01:23:19 --> Output Class Initialized
INFO - 2016-01-04 01:23:19 --> Security Class Initialized
DEBUG - 2016-01-04 01:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:23:19 --> Input Class Initialized
INFO - 2016-01-04 01:23:19 --> Language Class Initialized
INFO - 2016-01-04 01:23:19 --> Loader Class Initialized
INFO - 2016-01-04 01:23:19 --> Helper loaded: url_helper
INFO - 2016-01-04 01:23:19 --> Database Driver Class Initialized
INFO - 2016-01-04 01:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:23:19 --> Controller Class Initialized
DEBUG - 2016-01-04 01:23:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:23:19 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:23:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:23:19 --> Model Class Initialized
INFO - 2016-01-04 01:23:19 --> Model Class Initialized
INFO - 2016-01-04 01:23:19 --> Final output sent to browser
DEBUG - 2016-01-04 01:23:19 --> Total execution time: 0.0754
INFO - 2016-01-04 01:23:19 --> Config Class Initialized
INFO - 2016-01-04 01:23:19 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:23:19 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:23:19 --> Utf8 Class Initialized
INFO - 2016-01-04 01:23:19 --> URI Class Initialized
INFO - 2016-01-04 01:23:19 --> Router Class Initialized
INFO - 2016-01-04 01:23:19 --> Output Class Initialized
INFO - 2016-01-04 01:23:19 --> Security Class Initialized
DEBUG - 2016-01-04 01:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:23:19 --> Input Class Initialized
INFO - 2016-01-04 01:23:19 --> Language Class Initialized
INFO - 2016-01-04 01:23:19 --> Loader Class Initialized
INFO - 2016-01-04 01:23:19 --> Helper loaded: url_helper
INFO - 2016-01-04 01:23:19 --> Database Driver Class Initialized
INFO - 2016-01-04 01:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:23:19 --> Controller Class Initialized
DEBUG - 2016-01-04 01:23:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:23:19 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:23:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:23:19 --> Model Class Initialized
INFO - 2016-01-04 01:23:19 --> Model Class Initialized
INFO - 2016-01-04 01:23:19 --> Final output sent to browser
DEBUG - 2016-01-04 01:23:19 --> Total execution time: 0.0752
INFO - 2016-01-04 01:23:21 --> Config Class Initialized
INFO - 2016-01-04 01:23:21 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:23:21 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:23:21 --> Utf8 Class Initialized
INFO - 2016-01-04 01:23:21 --> URI Class Initialized
INFO - 2016-01-04 01:23:21 --> Router Class Initialized
INFO - 2016-01-04 01:23:21 --> Output Class Initialized
INFO - 2016-01-04 01:23:21 --> Security Class Initialized
DEBUG - 2016-01-04 01:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:23:21 --> Input Class Initialized
INFO - 2016-01-04 01:23:21 --> Language Class Initialized
INFO - 2016-01-04 01:23:21 --> Loader Class Initialized
INFO - 2016-01-04 01:23:21 --> Helper loaded: url_helper
INFO - 2016-01-04 01:23:21 --> Database Driver Class Initialized
INFO - 2016-01-04 01:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:23:21 --> Controller Class Initialized
DEBUG - 2016-01-04 01:23:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:23:21 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:23:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:23:21 --> Model Class Initialized
INFO - 2016-01-04 01:23:21 --> Model Class Initialized
INFO - 2016-01-04 01:23:21 --> Final output sent to browser
DEBUG - 2016-01-04 01:23:21 --> Total execution time: 0.0847
INFO - 2016-01-04 01:24:01 --> Config Class Initialized
INFO - 2016-01-04 01:24:01 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:24:01 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:24:01 --> Utf8 Class Initialized
INFO - 2016-01-04 01:24:01 --> URI Class Initialized
INFO - 2016-01-04 01:24:01 --> Router Class Initialized
INFO - 2016-01-04 01:24:01 --> Output Class Initialized
INFO - 2016-01-04 01:24:01 --> Security Class Initialized
DEBUG - 2016-01-04 01:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:24:01 --> Input Class Initialized
INFO - 2016-01-04 01:24:01 --> Language Class Initialized
INFO - 2016-01-04 01:24:01 --> Loader Class Initialized
INFO - 2016-01-04 01:24:01 --> Helper loaded: url_helper
INFO - 2016-01-04 01:24:01 --> Database Driver Class Initialized
INFO - 2016-01-04 01:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:24:01 --> Controller Class Initialized
INFO - 2016-01-04 01:24:01 --> Config Class Initialized
INFO - 2016-01-04 01:24:01 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:24:01 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:24:01 --> Utf8 Class Initialized
INFO - 2016-01-04 01:24:01 --> URI Class Initialized
INFO - 2016-01-04 01:24:01 --> Router Class Initialized
INFO - 2016-01-04 01:24:01 --> Output Class Initialized
INFO - 2016-01-04 01:24:01 --> Security Class Initialized
DEBUG - 2016-01-04 01:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:24:01 --> Input Class Initialized
INFO - 2016-01-04 01:24:01 --> Language Class Initialized
INFO - 2016-01-04 01:24:01 --> Loader Class Initialized
INFO - 2016-01-04 01:24:01 --> Helper loaded: url_helper
INFO - 2016-01-04 01:24:01 --> Database Driver Class Initialized
INFO - 2016-01-04 01:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:24:01 --> Controller Class Initialized
INFO - 2016-01-04 01:24:01 --> Helper loaded: form_helper
INFO - 2016-01-04 01:24:01 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 01:24:01 --> Final output sent to browser
DEBUG - 2016-01-04 01:24:01 --> Total execution time: 0.0708
INFO - 2016-01-04 01:50:07 --> Config Class Initialized
INFO - 2016-01-04 01:50:07 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:50:07 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:50:07 --> Utf8 Class Initialized
INFO - 2016-01-04 01:50:07 --> URI Class Initialized
INFO - 2016-01-04 01:50:07 --> Router Class Initialized
INFO - 2016-01-04 01:50:07 --> Output Class Initialized
INFO - 2016-01-04 01:50:07 --> Security Class Initialized
DEBUG - 2016-01-04 01:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:50:07 --> Input Class Initialized
INFO - 2016-01-04 01:50:07 --> Language Class Initialized
INFO - 2016-01-04 01:50:07 --> Loader Class Initialized
INFO - 2016-01-04 01:50:07 --> Helper loaded: url_helper
INFO - 2016-01-04 01:50:07 --> Database Driver Class Initialized
INFO - 2016-01-04 01:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:50:07 --> Controller Class Initialized
INFO - 2016-01-04 01:50:07 --> Helper loaded: form_helper
INFO - 2016-01-04 01:50:07 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 01:50:07 --> Final output sent to browser
DEBUG - 2016-01-04 01:50:07 --> Total execution time: 0.1246
INFO - 2016-01-04 01:50:21 --> Config Class Initialized
INFO - 2016-01-04 01:50:21 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:50:21 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:50:21 --> Utf8 Class Initialized
INFO - 2016-01-04 01:50:21 --> URI Class Initialized
INFO - 2016-01-04 01:50:21 --> Router Class Initialized
INFO - 2016-01-04 01:50:21 --> Output Class Initialized
INFO - 2016-01-04 01:50:21 --> Security Class Initialized
DEBUG - 2016-01-04 01:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:50:21 --> Input Class Initialized
INFO - 2016-01-04 01:50:21 --> Language Class Initialized
INFO - 2016-01-04 01:50:21 --> Loader Class Initialized
INFO - 2016-01-04 01:50:21 --> Helper loaded: url_helper
INFO - 2016-01-04 01:50:21 --> Database Driver Class Initialized
INFO - 2016-01-04 01:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:50:21 --> Controller Class Initialized
INFO - 2016-01-04 01:50:21 --> Model Class Initialized
INFO - 2016-01-04 01:50:21 --> Model Class Initialized
INFO - 2016-01-04 01:50:21 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 01:50:21 --> Final output sent to browser
DEBUG - 2016-01-04 01:50:21 --> Total execution time: 0.1160
INFO - 2016-01-04 01:50:21 --> Config Class Initialized
INFO - 2016-01-04 01:50:21 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:50:21 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:50:21 --> Utf8 Class Initialized
INFO - 2016-01-04 01:50:21 --> URI Class Initialized
INFO - 2016-01-04 01:50:21 --> Router Class Initialized
INFO - 2016-01-04 01:50:21 --> Output Class Initialized
INFO - 2016-01-04 01:50:21 --> Security Class Initialized
DEBUG - 2016-01-04 01:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:50:21 --> Input Class Initialized
INFO - 2016-01-04 01:50:21 --> Language Class Initialized
INFO - 2016-01-04 01:50:21 --> Loader Class Initialized
INFO - 2016-01-04 01:50:21 --> Helper loaded: url_helper
INFO - 2016-01-04 01:50:21 --> Database Driver Class Initialized
INFO - 2016-01-04 01:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:50:21 --> Controller Class Initialized
INFO - 2016-01-04 01:50:21 --> Model Class Initialized
INFO - 2016-01-04 01:50:22 --> Model Class Initialized
INFO - 2016-01-04 01:50:22 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 01:50:22 --> Final output sent to browser
DEBUG - 2016-01-04 01:50:22 --> Total execution time: 0.0729
INFO - 2016-01-04 01:50:22 --> Config Class Initialized
INFO - 2016-01-04 01:50:22 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:50:22 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:50:22 --> Utf8 Class Initialized
INFO - 2016-01-04 01:50:22 --> URI Class Initialized
INFO - 2016-01-04 01:50:22 --> Router Class Initialized
INFO - 2016-01-04 01:50:22 --> Output Class Initialized
INFO - 2016-01-04 01:50:22 --> Security Class Initialized
DEBUG - 2016-01-04 01:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:50:22 --> Input Class Initialized
INFO - 2016-01-04 01:50:22 --> Language Class Initialized
INFO - 2016-01-04 01:50:22 --> Loader Class Initialized
INFO - 2016-01-04 01:50:22 --> Helper loaded: url_helper
INFO - 2016-01-04 01:50:22 --> Database Driver Class Initialized
INFO - 2016-01-04 01:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:50:22 --> Controller Class Initialized
DEBUG - 2016-01-04 01:50:22 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:50:22 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:50:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:50:22 --> Model Class Initialized
INFO - 2016-01-04 01:50:22 --> Model Class Initialized
INFO - 2016-01-04 01:50:22 --> Final output sent to browser
DEBUG - 2016-01-04 01:50:22 --> Total execution time: 0.0812
INFO - 2016-01-04 01:51:04 --> Config Class Initialized
INFO - 2016-01-04 01:51:04 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:51:04 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:51:04 --> Utf8 Class Initialized
INFO - 2016-01-04 01:51:04 --> URI Class Initialized
INFO - 2016-01-04 01:51:04 --> Router Class Initialized
INFO - 2016-01-04 01:51:04 --> Output Class Initialized
INFO - 2016-01-04 01:51:04 --> Security Class Initialized
DEBUG - 2016-01-04 01:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:51:04 --> Input Class Initialized
INFO - 2016-01-04 01:51:04 --> Language Class Initialized
INFO - 2016-01-04 01:51:04 --> Loader Class Initialized
INFO - 2016-01-04 01:51:04 --> Helper loaded: url_helper
INFO - 2016-01-04 01:51:04 --> Database Driver Class Initialized
INFO - 2016-01-04 01:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:51:04 --> Controller Class Initialized
DEBUG - 2016-01-04 01:51:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:51:04 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:51:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:51:05 --> Model Class Initialized
INFO - 2016-01-04 01:51:05 --> Model Class Initialized
INFO - 2016-01-04 01:51:05 --> Final output sent to browser
DEBUG - 2016-01-04 01:51:05 --> Total execution time: 0.1634
INFO - 2016-01-04 01:51:05 --> Config Class Initialized
INFO - 2016-01-04 01:51:05 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:51:05 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:51:05 --> Utf8 Class Initialized
INFO - 2016-01-04 01:51:05 --> URI Class Initialized
INFO - 2016-01-04 01:51:05 --> Router Class Initialized
INFO - 2016-01-04 01:51:05 --> Output Class Initialized
INFO - 2016-01-04 01:51:05 --> Security Class Initialized
DEBUG - 2016-01-04 01:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:51:05 --> Input Class Initialized
INFO - 2016-01-04 01:51:05 --> Language Class Initialized
INFO - 2016-01-04 01:51:05 --> Loader Class Initialized
INFO - 2016-01-04 01:51:05 --> Helper loaded: url_helper
INFO - 2016-01-04 01:51:05 --> Database Driver Class Initialized
INFO - 2016-01-04 01:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:51:05 --> Controller Class Initialized
DEBUG - 2016-01-04 01:51:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:51:05 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:51:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:51:05 --> Model Class Initialized
INFO - 2016-01-04 01:51:05 --> Model Class Initialized
INFO - 2016-01-04 01:51:05 --> Final output sent to browser
DEBUG - 2016-01-04 01:51:05 --> Total execution time: 0.1256
INFO - 2016-01-04 01:51:08 --> Config Class Initialized
INFO - 2016-01-04 01:51:08 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:51:08 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:51:08 --> Utf8 Class Initialized
INFO - 2016-01-04 01:51:08 --> URI Class Initialized
INFO - 2016-01-04 01:51:08 --> Router Class Initialized
INFO - 2016-01-04 01:51:08 --> Output Class Initialized
INFO - 2016-01-04 01:51:08 --> Security Class Initialized
DEBUG - 2016-01-04 01:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:51:08 --> Input Class Initialized
INFO - 2016-01-04 01:51:08 --> Language Class Initialized
INFO - 2016-01-04 01:51:08 --> Loader Class Initialized
INFO - 2016-01-04 01:51:08 --> Helper loaded: url_helper
INFO - 2016-01-04 01:51:08 --> Database Driver Class Initialized
ERROR - 2016-01-04 01:51:08 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2016-01-04 01:51:08 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
ERROR - 2016-01-04 01:51:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/libraries/Session/Session.php 168
INFO - 2016-01-04 01:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:51:08 --> Controller Class Initialized
DEBUG - 2016-01-04 01:51:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:51:08 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:51:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:51:08 --> Model Class Initialized
INFO - 2016-01-04 01:51:08 --> Model Class Initialized
ERROR - 2016-01-04 01:51:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/core/Common.php 573
INFO - 2016-01-04 01:51:08 --> Final output sent to browser
DEBUG - 2016-01-04 01:51:08 --> Total execution time: 0.0825
INFO - 2016-01-04 01:51:14 --> Config Class Initialized
INFO - 2016-01-04 01:51:14 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:51:14 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:51:14 --> Utf8 Class Initialized
INFO - 2016-01-04 01:51:14 --> URI Class Initialized
INFO - 2016-01-04 01:51:14 --> Router Class Initialized
INFO - 2016-01-04 01:51:14 --> Output Class Initialized
INFO - 2016-01-04 01:51:14 --> Security Class Initialized
DEBUG - 2016-01-04 01:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:51:14 --> Input Class Initialized
INFO - 2016-01-04 01:51:14 --> Language Class Initialized
INFO - 2016-01-04 01:51:14 --> Loader Class Initialized
INFO - 2016-01-04 01:51:14 --> Helper loaded: url_helper
INFO - 2016-01-04 01:51:14 --> Database Driver Class Initialized
INFO - 2016-01-04 01:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:51:14 --> Controller Class Initialized
INFO - 2016-01-04 01:51:14 --> Model Class Initialized
INFO - 2016-01-04 01:51:14 --> Model Class Initialized
INFO - 2016-01-04 01:51:14 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 01:51:14 --> Final output sent to browser
DEBUG - 2016-01-04 01:51:14 --> Total execution time: 0.0793
INFO - 2016-01-04 01:51:14 --> Config Class Initialized
INFO - 2016-01-04 01:51:14 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:51:14 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:51:14 --> Utf8 Class Initialized
INFO - 2016-01-04 01:51:14 --> URI Class Initialized
INFO - 2016-01-04 01:51:14 --> Router Class Initialized
INFO - 2016-01-04 01:51:14 --> Output Class Initialized
INFO - 2016-01-04 01:51:14 --> Security Class Initialized
DEBUG - 2016-01-04 01:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:51:14 --> Input Class Initialized
INFO - 2016-01-04 01:51:14 --> Language Class Initialized
INFO - 2016-01-04 01:51:14 --> Loader Class Initialized
INFO - 2016-01-04 01:51:14 --> Helper loaded: url_helper
INFO - 2016-01-04 01:51:14 --> Database Driver Class Initialized
INFO - 2016-01-04 01:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:51:15 --> Controller Class Initialized
INFO - 2016-01-04 01:51:15 --> Model Class Initialized
INFO - 2016-01-04 01:51:15 --> Model Class Initialized
INFO - 2016-01-04 01:51:15 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 01:51:15 --> Final output sent to browser
DEBUG - 2016-01-04 01:51:15 --> Total execution time: 0.0632
INFO - 2016-01-04 01:51:15 --> Config Class Initialized
INFO - 2016-01-04 01:51:15 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:51:15 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:51:15 --> Utf8 Class Initialized
INFO - 2016-01-04 01:51:15 --> URI Class Initialized
INFO - 2016-01-04 01:51:15 --> Router Class Initialized
INFO - 2016-01-04 01:51:15 --> Output Class Initialized
INFO - 2016-01-04 01:51:15 --> Security Class Initialized
DEBUG - 2016-01-04 01:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:51:15 --> Input Class Initialized
INFO - 2016-01-04 01:51:15 --> Language Class Initialized
INFO - 2016-01-04 01:51:15 --> Loader Class Initialized
INFO - 2016-01-04 01:51:15 --> Helper loaded: url_helper
INFO - 2016-01-04 01:51:15 --> Database Driver Class Initialized
INFO - 2016-01-04 01:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:51:15 --> Controller Class Initialized
DEBUG - 2016-01-04 01:51:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:51:15 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:51:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:51:15 --> Model Class Initialized
INFO - 2016-01-04 01:51:15 --> Model Class Initialized
INFO - 2016-01-04 01:51:15 --> Final output sent to browser
DEBUG - 2016-01-04 01:51:15 --> Total execution time: 0.1731
INFO - 2016-01-04 01:51:33 --> Config Class Initialized
INFO - 2016-01-04 01:51:33 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:51:33 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:51:33 --> Utf8 Class Initialized
INFO - 2016-01-04 01:51:33 --> URI Class Initialized
INFO - 2016-01-04 01:51:33 --> Router Class Initialized
INFO - 2016-01-04 01:51:33 --> Output Class Initialized
INFO - 2016-01-04 01:51:33 --> Security Class Initialized
DEBUG - 2016-01-04 01:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:51:33 --> Input Class Initialized
INFO - 2016-01-04 01:51:33 --> Language Class Initialized
INFO - 2016-01-04 01:51:33 --> Loader Class Initialized
INFO - 2016-01-04 01:51:33 --> Helper loaded: url_helper
INFO - 2016-01-04 01:51:33 --> Database Driver Class Initialized
INFO - 2016-01-04 01:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:51:33 --> Controller Class Initialized
DEBUG - 2016-01-04 01:51:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:51:33 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:51:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:51:33 --> Model Class Initialized
INFO - 2016-01-04 01:51:33 --> Model Class Initialized
INFO - 2016-01-04 01:51:33 --> Final output sent to browser
DEBUG - 2016-01-04 01:51:33 --> Total execution time: 0.0983
INFO - 2016-01-04 01:51:37 --> Config Class Initialized
INFO - 2016-01-04 01:51:37 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:51:37 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:51:37 --> Utf8 Class Initialized
INFO - 2016-01-04 01:51:37 --> URI Class Initialized
INFO - 2016-01-04 01:51:37 --> Router Class Initialized
INFO - 2016-01-04 01:51:37 --> Output Class Initialized
INFO - 2016-01-04 01:51:37 --> Security Class Initialized
DEBUG - 2016-01-04 01:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:51:37 --> Input Class Initialized
INFO - 2016-01-04 01:51:37 --> Language Class Initialized
INFO - 2016-01-04 01:51:37 --> Loader Class Initialized
INFO - 2016-01-04 01:51:37 --> Helper loaded: url_helper
INFO - 2016-01-04 01:51:37 --> Database Driver Class Initialized
INFO - 2016-01-04 01:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:51:37 --> Controller Class Initialized
DEBUG - 2016-01-04 01:51:37 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:51:37 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:51:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:51:37 --> Model Class Initialized
INFO - 2016-01-04 01:51:37 --> Model Class Initialized
INFO - 2016-01-04 01:51:37 --> Final output sent to browser
DEBUG - 2016-01-04 01:51:37 --> Total execution time: 0.0677
INFO - 2016-01-04 01:54:43 --> Config Class Initialized
INFO - 2016-01-04 01:54:43 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:54:43 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:54:43 --> Utf8 Class Initialized
INFO - 2016-01-04 01:54:43 --> URI Class Initialized
INFO - 2016-01-04 01:54:43 --> Router Class Initialized
INFO - 2016-01-04 01:54:43 --> Output Class Initialized
INFO - 2016-01-04 01:54:43 --> Security Class Initialized
DEBUG - 2016-01-04 01:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:54:43 --> Input Class Initialized
INFO - 2016-01-04 01:54:43 --> Language Class Initialized
INFO - 2016-01-04 01:54:43 --> Loader Class Initialized
INFO - 2016-01-04 01:54:43 --> Helper loaded: url_helper
INFO - 2016-01-04 01:54:43 --> Database Driver Class Initialized
INFO - 2016-01-04 01:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:54:43 --> Controller Class Initialized
DEBUG - 2016-01-04 01:54:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:54:43 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:54:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:54:43 --> Model Class Initialized
INFO - 2016-01-04 01:54:43 --> Model Class Initialized
INFO - 2016-01-04 01:54:43 --> Final output sent to browser
DEBUG - 2016-01-04 01:54:43 --> Total execution time: 0.1494
INFO - 2016-01-04 01:54:43 --> Config Class Initialized
INFO - 2016-01-04 01:54:43 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:54:43 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:54:43 --> Utf8 Class Initialized
INFO - 2016-01-04 01:54:43 --> URI Class Initialized
INFO - 2016-01-04 01:54:43 --> Router Class Initialized
INFO - 2016-01-04 01:54:43 --> Output Class Initialized
INFO - 2016-01-04 01:54:43 --> Security Class Initialized
DEBUG - 2016-01-04 01:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:54:43 --> Input Class Initialized
INFO - 2016-01-04 01:54:43 --> Language Class Initialized
INFO - 2016-01-04 01:54:43 --> Loader Class Initialized
INFO - 2016-01-04 01:54:43 --> Helper loaded: url_helper
INFO - 2016-01-04 01:54:43 --> Database Driver Class Initialized
INFO - 2016-01-04 01:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:54:43 --> Controller Class Initialized
DEBUG - 2016-01-04 01:54:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:54:43 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:54:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:54:43 --> Model Class Initialized
INFO - 2016-01-04 01:54:43 --> Model Class Initialized
INFO - 2016-01-04 01:54:43 --> Final output sent to browser
DEBUG - 2016-01-04 01:54:43 --> Total execution time: 0.1435
INFO - 2016-01-04 01:54:45 --> Config Class Initialized
INFO - 2016-01-04 01:54:45 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:54:45 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:54:45 --> Utf8 Class Initialized
INFO - 2016-01-04 01:54:45 --> URI Class Initialized
INFO - 2016-01-04 01:54:45 --> Router Class Initialized
INFO - 2016-01-04 01:54:45 --> Output Class Initialized
INFO - 2016-01-04 01:54:45 --> Security Class Initialized
DEBUG - 2016-01-04 01:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:54:45 --> Input Class Initialized
INFO - 2016-01-04 01:54:45 --> Language Class Initialized
INFO - 2016-01-04 01:54:45 --> Loader Class Initialized
INFO - 2016-01-04 01:54:45 --> Helper loaded: url_helper
INFO - 2016-01-04 01:54:45 --> Database Driver Class Initialized
INFO - 2016-01-04 01:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:54:45 --> Controller Class Initialized
DEBUG - 2016-01-04 01:54:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:54:45 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:54:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:54:45 --> Model Class Initialized
INFO - 2016-01-04 01:54:45 --> Model Class Initialized
INFO - 2016-01-04 01:54:45 --> Final output sent to browser
DEBUG - 2016-01-04 01:54:45 --> Total execution time: 0.1090
INFO - 2016-01-04 01:55:04 --> Config Class Initialized
INFO - 2016-01-04 01:55:04 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:55:04 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:55:04 --> Utf8 Class Initialized
INFO - 2016-01-04 01:55:04 --> URI Class Initialized
INFO - 2016-01-04 01:55:04 --> Router Class Initialized
INFO - 2016-01-04 01:55:04 --> Output Class Initialized
INFO - 2016-01-04 01:55:04 --> Security Class Initialized
DEBUG - 2016-01-04 01:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:55:04 --> Input Class Initialized
INFO - 2016-01-04 01:55:04 --> Language Class Initialized
INFO - 2016-01-04 01:55:04 --> Loader Class Initialized
INFO - 2016-01-04 01:55:04 --> Helper loaded: url_helper
INFO - 2016-01-04 01:55:04 --> Database Driver Class Initialized
INFO - 2016-01-04 01:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:55:04 --> Controller Class Initialized
DEBUG - 2016-01-04 01:55:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:55:04 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:55:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:55:04 --> Model Class Initialized
INFO - 2016-01-04 01:55:04 --> Model Class Initialized
INFO - 2016-01-04 01:55:04 --> Final output sent to browser
DEBUG - 2016-01-04 01:55:04 --> Total execution time: 0.1295
INFO - 2016-01-04 01:55:15 --> Config Class Initialized
INFO - 2016-01-04 01:55:15 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:55:15 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:55:15 --> Utf8 Class Initialized
INFO - 2016-01-04 01:55:15 --> URI Class Initialized
INFO - 2016-01-04 01:55:15 --> Router Class Initialized
INFO - 2016-01-04 01:55:15 --> Output Class Initialized
INFO - 2016-01-04 01:55:15 --> Security Class Initialized
DEBUG - 2016-01-04 01:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:55:15 --> Input Class Initialized
INFO - 2016-01-04 01:55:15 --> Language Class Initialized
INFO - 2016-01-04 01:55:15 --> Loader Class Initialized
INFO - 2016-01-04 01:55:15 --> Helper loaded: url_helper
INFO - 2016-01-04 01:55:15 --> Database Driver Class Initialized
INFO - 2016-01-04 01:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:55:15 --> Controller Class Initialized
DEBUG - 2016-01-04 01:55:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:55:15 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:55:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:55:15 --> Model Class Initialized
INFO - 2016-01-04 01:55:15 --> Model Class Initialized
INFO - 2016-01-04 01:55:15 --> Final output sent to browser
DEBUG - 2016-01-04 01:55:15 --> Total execution time: 0.0959
INFO - 2016-01-04 01:55:21 --> Config Class Initialized
INFO - 2016-01-04 01:55:21 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:55:21 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:55:21 --> Utf8 Class Initialized
INFO - 2016-01-04 01:55:21 --> URI Class Initialized
INFO - 2016-01-04 01:55:21 --> Router Class Initialized
INFO - 2016-01-04 01:55:21 --> Output Class Initialized
INFO - 2016-01-04 01:55:21 --> Security Class Initialized
DEBUG - 2016-01-04 01:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:55:21 --> Input Class Initialized
INFO - 2016-01-04 01:55:21 --> Language Class Initialized
INFO - 2016-01-04 01:55:21 --> Loader Class Initialized
INFO - 2016-01-04 01:55:21 --> Helper loaded: url_helper
INFO - 2016-01-04 01:55:21 --> Database Driver Class Initialized
INFO - 2016-01-04 01:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:55:21 --> Controller Class Initialized
DEBUG - 2016-01-04 01:55:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:55:21 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:55:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:55:21 --> Model Class Initialized
INFO - 2016-01-04 01:55:21 --> Model Class Initialized
INFO - 2016-01-04 01:55:21 --> Final output sent to browser
DEBUG - 2016-01-04 01:55:21 --> Total execution time: 0.1122
INFO - 2016-01-04 01:55:23 --> Config Class Initialized
INFO - 2016-01-04 01:55:23 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:55:23 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:55:23 --> Utf8 Class Initialized
INFO - 2016-01-04 01:55:23 --> URI Class Initialized
INFO - 2016-01-04 01:55:23 --> Router Class Initialized
INFO - 2016-01-04 01:55:23 --> Output Class Initialized
INFO - 2016-01-04 01:55:23 --> Security Class Initialized
DEBUG - 2016-01-04 01:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:55:23 --> Input Class Initialized
INFO - 2016-01-04 01:55:23 --> Language Class Initialized
INFO - 2016-01-04 01:55:23 --> Loader Class Initialized
INFO - 2016-01-04 01:55:23 --> Helper loaded: url_helper
INFO - 2016-01-04 01:55:23 --> Database Driver Class Initialized
INFO - 2016-01-04 01:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:55:23 --> Controller Class Initialized
DEBUG - 2016-01-04 01:55:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:55:23 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:55:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:55:23 --> Model Class Initialized
INFO - 2016-01-04 01:55:23 --> Model Class Initialized
INFO - 2016-01-04 01:55:23 --> Final output sent to browser
DEBUG - 2016-01-04 01:55:23 --> Total execution time: 0.1322
INFO - 2016-01-04 01:55:26 --> Config Class Initialized
INFO - 2016-01-04 01:55:26 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:55:26 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:55:26 --> Utf8 Class Initialized
INFO - 2016-01-04 01:55:26 --> URI Class Initialized
INFO - 2016-01-04 01:55:26 --> Router Class Initialized
INFO - 2016-01-04 01:55:26 --> Output Class Initialized
INFO - 2016-01-04 01:55:26 --> Security Class Initialized
DEBUG - 2016-01-04 01:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:55:26 --> Input Class Initialized
INFO - 2016-01-04 01:55:26 --> Language Class Initialized
INFO - 2016-01-04 01:55:26 --> Loader Class Initialized
INFO - 2016-01-04 01:55:26 --> Helper loaded: url_helper
INFO - 2016-01-04 01:55:26 --> Database Driver Class Initialized
INFO - 2016-01-04 01:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:55:26 --> Controller Class Initialized
DEBUG - 2016-01-04 01:55:26 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:55:26 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:55:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:55:26 --> Model Class Initialized
INFO - 2016-01-04 01:55:26 --> Model Class Initialized
INFO - 2016-01-04 01:55:26 --> Final output sent to browser
DEBUG - 2016-01-04 01:55:26 --> Total execution time: 0.0672
INFO - 2016-01-04 01:55:29 --> Config Class Initialized
INFO - 2016-01-04 01:55:29 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:55:29 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:55:29 --> Utf8 Class Initialized
INFO - 2016-01-04 01:55:29 --> URI Class Initialized
INFO - 2016-01-04 01:55:29 --> Router Class Initialized
INFO - 2016-01-04 01:55:29 --> Output Class Initialized
INFO - 2016-01-04 01:55:29 --> Security Class Initialized
DEBUG - 2016-01-04 01:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:55:29 --> Input Class Initialized
INFO - 2016-01-04 01:55:29 --> Language Class Initialized
INFO - 2016-01-04 01:55:29 --> Loader Class Initialized
INFO - 2016-01-04 01:55:29 --> Helper loaded: url_helper
INFO - 2016-01-04 01:55:29 --> Database Driver Class Initialized
INFO - 2016-01-04 01:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:55:29 --> Controller Class Initialized
DEBUG - 2016-01-04 01:55:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 01:55:29 --> Helper loaded: inflector_helper
INFO - 2016-01-04 01:55:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 01:55:29 --> Model Class Initialized
INFO - 2016-01-04 01:55:29 --> Model Class Initialized
INFO - 2016-01-04 01:55:29 --> Final output sent to browser
DEBUG - 2016-01-04 01:55:29 --> Total execution time: 0.1292
INFO - 2016-01-04 01:55:32 --> Config Class Initialized
INFO - 2016-01-04 01:55:32 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:55:32 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:55:32 --> Utf8 Class Initialized
INFO - 2016-01-04 01:55:32 --> URI Class Initialized
INFO - 2016-01-04 01:55:32 --> Router Class Initialized
INFO - 2016-01-04 01:55:32 --> Output Class Initialized
INFO - 2016-01-04 01:55:32 --> Security Class Initialized
DEBUG - 2016-01-04 01:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:55:32 --> Input Class Initialized
INFO - 2016-01-04 01:55:32 --> Language Class Initialized
INFO - 2016-01-04 01:55:32 --> Loader Class Initialized
INFO - 2016-01-04 01:55:32 --> Helper loaded: url_helper
INFO - 2016-01-04 01:55:32 --> Database Driver Class Initialized
INFO - 2016-01-04 01:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:55:32 --> Controller Class Initialized
INFO - 2016-01-04 01:55:32 --> Config Class Initialized
INFO - 2016-01-04 01:55:32 --> Hooks Class Initialized
DEBUG - 2016-01-04 01:55:32 --> UTF-8 Support Enabled
INFO - 2016-01-04 01:55:32 --> Utf8 Class Initialized
INFO - 2016-01-04 01:55:32 --> URI Class Initialized
INFO - 2016-01-04 01:55:32 --> Router Class Initialized
INFO - 2016-01-04 01:55:32 --> Output Class Initialized
INFO - 2016-01-04 01:55:32 --> Security Class Initialized
DEBUG - 2016-01-04 01:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 01:55:32 --> Input Class Initialized
INFO - 2016-01-04 01:55:32 --> Language Class Initialized
INFO - 2016-01-04 01:55:32 --> Loader Class Initialized
INFO - 2016-01-04 01:55:32 --> Helper loaded: url_helper
INFO - 2016-01-04 01:55:32 --> Database Driver Class Initialized
INFO - 2016-01-04 01:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 01:55:32 --> Controller Class Initialized
INFO - 2016-01-04 01:55:32 --> Helper loaded: form_helper
INFO - 2016-01-04 01:55:32 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 01:55:32 --> Final output sent to browser
DEBUG - 2016-01-04 01:55:32 --> Total execution time: 0.0674
INFO - 2016-01-04 18:46:30 --> Config Class Initialized
INFO - 2016-01-04 18:46:30 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:46:30 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:46:30 --> Utf8 Class Initialized
INFO - 2016-01-04 18:46:30 --> URI Class Initialized
INFO - 2016-01-04 18:46:30 --> Router Class Initialized
INFO - 2016-01-04 18:46:30 --> Output Class Initialized
INFO - 2016-01-04 18:46:30 --> Security Class Initialized
DEBUG - 2016-01-04 18:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:46:30 --> Input Class Initialized
INFO - 2016-01-04 18:46:30 --> Language Class Initialized
INFO - 2016-01-04 18:46:30 --> Loader Class Initialized
INFO - 2016-01-04 18:46:30 --> Helper loaded: url_helper
INFO - 2016-01-04 18:46:30 --> Database Driver Class Initialized
INFO - 2016-01-04 18:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:46:30 --> Controller Class Initialized
INFO - 2016-01-04 18:46:30 --> Helper loaded: form_helper
INFO - 2016-01-04 18:46:30 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 18:46:30 --> Final output sent to browser
DEBUG - 2016-01-04 18:46:30 --> Total execution time: 0.1098
INFO - 2016-01-04 18:46:46 --> Config Class Initialized
INFO - 2016-01-04 18:46:46 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:46:46 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:46:46 --> Utf8 Class Initialized
INFO - 2016-01-04 18:46:46 --> URI Class Initialized
INFO - 2016-01-04 18:46:46 --> Router Class Initialized
INFO - 2016-01-04 18:46:46 --> Output Class Initialized
INFO - 2016-01-04 18:46:46 --> Security Class Initialized
DEBUG - 2016-01-04 18:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:46:46 --> Input Class Initialized
INFO - 2016-01-04 18:46:46 --> Language Class Initialized
INFO - 2016-01-04 18:46:46 --> Loader Class Initialized
INFO - 2016-01-04 18:46:46 --> Helper loaded: url_helper
INFO - 2016-01-04 18:46:46 --> Database Driver Class Initialized
ERROR - 2016-01-04 18:46:46 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2016-01-04 18:46:46 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
INFO - 2016-01-04 18:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:46:46 --> Controller Class Initialized
INFO - 2016-01-04 18:46:46 --> Helper loaded: form_helper
INFO - 2016-01-04 18:46:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 18:46:46 --> Final output sent to browser
DEBUG - 2016-01-04 18:46:46 --> Total execution time: 0.0995
INFO - 2016-01-04 18:46:51 --> Config Class Initialized
INFO - 2016-01-04 18:46:51 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:46:51 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:46:51 --> Utf8 Class Initialized
INFO - 2016-01-04 18:46:51 --> URI Class Initialized
DEBUG - 2016-01-04 18:46:51 --> No URI present. Default controller set.
INFO - 2016-01-04 18:46:51 --> Router Class Initialized
INFO - 2016-01-04 18:46:51 --> Output Class Initialized
INFO - 2016-01-04 18:46:51 --> Security Class Initialized
DEBUG - 2016-01-04 18:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:46:51 --> Input Class Initialized
INFO - 2016-01-04 18:46:51 --> Language Class Initialized
INFO - 2016-01-04 18:46:51 --> Loader Class Initialized
INFO - 2016-01-04 18:46:51 --> Helper loaded: url_helper
INFO - 2016-01-04 18:46:51 --> Database Driver Class Initialized
INFO - 2016-01-04 18:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:46:51 --> Controller Class Initialized
INFO - 2016-01-04 18:46:51 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 18:46:51 --> Final output sent to browser
DEBUG - 2016-01-04 18:46:51 --> Total execution time: 0.0547
INFO - 2016-01-04 18:46:53 --> Config Class Initialized
INFO - 2016-01-04 18:46:53 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:46:53 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:46:53 --> Utf8 Class Initialized
INFO - 2016-01-04 18:46:53 --> URI Class Initialized
INFO - 2016-01-04 18:46:53 --> Router Class Initialized
INFO - 2016-01-04 18:46:53 --> Output Class Initialized
INFO - 2016-01-04 18:46:53 --> Security Class Initialized
DEBUG - 2016-01-04 18:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:46:53 --> Input Class Initialized
INFO - 2016-01-04 18:46:53 --> Language Class Initialized
INFO - 2016-01-04 18:46:53 --> Loader Class Initialized
INFO - 2016-01-04 18:46:53 --> Helper loaded: url_helper
INFO - 2016-01-04 18:46:53 --> Database Driver Class Initialized
INFO - 2016-01-04 18:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:46:53 --> Controller Class Initialized
INFO - 2016-01-04 18:46:53 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 18:46:53 --> Final output sent to browser
DEBUG - 2016-01-04 18:46:53 --> Total execution time: 0.0547
INFO - 2016-01-04 18:46:53 --> Config Class Initialized
INFO - 2016-01-04 18:46:53 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:46:53 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:46:53 --> Utf8 Class Initialized
INFO - 2016-01-04 18:46:53 --> URI Class Initialized
INFO - 2016-01-04 18:46:53 --> Router Class Initialized
INFO - 2016-01-04 18:46:53 --> Output Class Initialized
INFO - 2016-01-04 18:46:53 --> Security Class Initialized
DEBUG - 2016-01-04 18:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:46:53 --> Input Class Initialized
INFO - 2016-01-04 18:46:53 --> Language Class Initialized
INFO - 2016-01-04 18:46:53 --> Loader Class Initialized
INFO - 2016-01-04 18:46:53 --> Helper loaded: url_helper
INFO - 2016-01-04 18:46:53 --> Database Driver Class Initialized
INFO - 2016-01-04 18:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:46:53 --> Controller Class Initialized
DEBUG - 2016-01-04 18:46:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 18:46:53 --> Helper loaded: inflector_helper
INFO - 2016-01-04 18:46:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 18:46:53 --> Model Class Initialized
INFO - 2016-01-04 18:46:53 --> Model Class Initialized
INFO - 2016-01-04 18:46:53 --> Final output sent to browser
DEBUG - 2016-01-04 18:46:53 --> Total execution time: 0.1112
INFO - 2016-01-04 18:47:54 --> Config Class Initialized
INFO - 2016-01-04 18:47:54 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:47:54 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:47:54 --> Utf8 Class Initialized
INFO - 2016-01-04 18:47:54 --> URI Class Initialized
INFO - 2016-01-04 18:47:54 --> Router Class Initialized
INFO - 2016-01-04 18:47:54 --> Output Class Initialized
INFO - 2016-01-04 18:47:54 --> Security Class Initialized
DEBUG - 2016-01-04 18:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:47:54 --> Input Class Initialized
INFO - 2016-01-04 18:47:54 --> Language Class Initialized
INFO - 2016-01-04 18:47:54 --> Loader Class Initialized
INFO - 2016-01-04 18:47:54 --> Helper loaded: url_helper
INFO - 2016-01-04 18:47:54 --> Database Driver Class Initialized
INFO - 2016-01-04 18:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:47:54 --> Controller Class Initialized
DEBUG - 2016-01-04 18:47:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 18:47:54 --> Helper loaded: inflector_helper
INFO - 2016-01-04 18:47:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 18:47:54 --> Model Class Initialized
INFO - 2016-01-04 18:47:54 --> Model Class Initialized
INFO - 2016-01-04 18:47:54 --> Final output sent to browser
DEBUG - 2016-01-04 18:47:54 --> Total execution time: 0.1078
INFO - 2016-01-04 18:48:04 --> Config Class Initialized
INFO - 2016-01-04 18:48:04 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:48:04 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:48:04 --> Utf8 Class Initialized
INFO - 2016-01-04 18:48:04 --> URI Class Initialized
INFO - 2016-01-04 18:48:04 --> Router Class Initialized
INFO - 2016-01-04 18:48:04 --> Output Class Initialized
INFO - 2016-01-04 18:48:04 --> Security Class Initialized
DEBUG - 2016-01-04 18:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:48:04 --> Input Class Initialized
INFO - 2016-01-04 18:48:04 --> Language Class Initialized
INFO - 2016-01-04 18:48:04 --> Loader Class Initialized
INFO - 2016-01-04 18:48:04 --> Helper loaded: url_helper
INFO - 2016-01-04 18:48:04 --> Database Driver Class Initialized
INFO - 2016-01-04 18:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:48:05 --> Controller Class Initialized
DEBUG - 2016-01-04 18:48:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 18:48:05 --> Helper loaded: inflector_helper
INFO - 2016-01-04 18:48:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 18:48:05 --> Model Class Initialized
INFO - 2016-01-04 18:48:05 --> Model Class Initialized
INFO - 2016-01-04 18:48:05 --> Final output sent to browser
DEBUG - 2016-01-04 18:48:05 --> Total execution time: 0.1515
INFO - 2016-01-04 18:49:05 --> Config Class Initialized
INFO - 2016-01-04 18:49:05 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:49:05 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:49:05 --> Utf8 Class Initialized
INFO - 2016-01-04 18:49:05 --> URI Class Initialized
DEBUG - 2016-01-04 18:49:05 --> No URI present. Default controller set.
INFO - 2016-01-04 18:49:05 --> Router Class Initialized
INFO - 2016-01-04 18:49:05 --> Output Class Initialized
INFO - 2016-01-04 18:49:05 --> Security Class Initialized
DEBUG - 2016-01-04 18:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:49:05 --> Input Class Initialized
INFO - 2016-01-04 18:49:05 --> Language Class Initialized
INFO - 2016-01-04 18:49:05 --> Loader Class Initialized
INFO - 2016-01-04 18:49:05 --> Helper loaded: url_helper
INFO - 2016-01-04 18:49:05 --> Database Driver Class Initialized
INFO - 2016-01-04 18:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:49:05 --> Controller Class Initialized
INFO - 2016-01-04 18:49:05 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 18:49:05 --> Final output sent to browser
DEBUG - 2016-01-04 18:49:05 --> Total execution time: 0.1276
INFO - 2016-01-04 18:52:11 --> Config Class Initialized
INFO - 2016-01-04 18:52:11 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:52:11 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:52:11 --> Utf8 Class Initialized
INFO - 2016-01-04 18:52:11 --> URI Class Initialized
INFO - 2016-01-04 18:52:11 --> Router Class Initialized
INFO - 2016-01-04 18:52:11 --> Output Class Initialized
INFO - 2016-01-04 18:52:11 --> Security Class Initialized
DEBUG - 2016-01-04 18:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:52:11 --> Input Class Initialized
INFO - 2016-01-04 18:52:11 --> Language Class Initialized
INFO - 2016-01-04 18:52:11 --> Loader Class Initialized
INFO - 2016-01-04 18:52:11 --> Helper loaded: url_helper
INFO - 2016-01-04 18:52:11 --> Database Driver Class Initialized
INFO - 2016-01-04 18:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:52:11 --> Controller Class Initialized
INFO - 2016-01-04 18:52:11 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 18:52:11 --> Final output sent to browser
DEBUG - 2016-01-04 18:52:11 --> Total execution time: 0.1211
INFO - 2016-01-04 18:52:11 --> Config Class Initialized
INFO - 2016-01-04 18:52:11 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:52:11 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:52:11 --> Utf8 Class Initialized
INFO - 2016-01-04 18:52:11 --> URI Class Initialized
INFO - 2016-01-04 18:52:11 --> Router Class Initialized
INFO - 2016-01-04 18:52:11 --> Output Class Initialized
INFO - 2016-01-04 18:52:11 --> Security Class Initialized
DEBUG - 2016-01-04 18:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:52:11 --> Input Class Initialized
INFO - 2016-01-04 18:52:11 --> Language Class Initialized
INFO - 2016-01-04 18:52:11 --> Loader Class Initialized
INFO - 2016-01-04 18:52:11 --> Helper loaded: url_helper
INFO - 2016-01-04 18:52:11 --> Database Driver Class Initialized
INFO - 2016-01-04 18:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:52:11 --> Controller Class Initialized
DEBUG - 2016-01-04 18:52:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 18:52:11 --> Helper loaded: inflector_helper
INFO - 2016-01-04 18:52:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 18:52:11 --> Model Class Initialized
INFO - 2016-01-04 18:52:11 --> Model Class Initialized
INFO - 2016-01-04 18:52:11 --> Final output sent to browser
DEBUG - 2016-01-04 18:52:11 --> Total execution time: 0.1216
INFO - 2016-01-04 18:52:57 --> Config Class Initialized
INFO - 2016-01-04 18:52:57 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:52:57 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:52:57 --> Utf8 Class Initialized
INFO - 2016-01-04 18:52:57 --> URI Class Initialized
INFO - 2016-01-04 18:52:57 --> Router Class Initialized
INFO - 2016-01-04 18:52:57 --> Output Class Initialized
INFO - 2016-01-04 18:52:57 --> Security Class Initialized
DEBUG - 2016-01-04 18:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:52:57 --> Input Class Initialized
INFO - 2016-01-04 18:52:57 --> Language Class Initialized
INFO - 2016-01-04 18:52:57 --> Loader Class Initialized
INFO - 2016-01-04 18:52:57 --> Helper loaded: url_helper
INFO - 2016-01-04 18:52:57 --> Database Driver Class Initialized
INFO - 2016-01-04 18:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:52:57 --> Controller Class Initialized
DEBUG - 2016-01-04 18:52:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 18:52:57 --> Helper loaded: inflector_helper
INFO - 2016-01-04 18:52:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 18:52:57 --> Model Class Initialized
INFO - 2016-01-04 18:52:57 --> Model Class Initialized
INFO - 2016-01-04 18:52:57 --> Final output sent to browser
DEBUG - 2016-01-04 18:52:57 --> Total execution time: 0.0742
INFO - 2016-01-04 18:52:58 --> Config Class Initialized
INFO - 2016-01-04 18:52:58 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:52:58 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:52:58 --> Utf8 Class Initialized
INFO - 2016-01-04 18:52:58 --> URI Class Initialized
INFO - 2016-01-04 18:52:58 --> Router Class Initialized
INFO - 2016-01-04 18:52:58 --> Output Class Initialized
INFO - 2016-01-04 18:52:58 --> Security Class Initialized
DEBUG - 2016-01-04 18:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:52:58 --> Input Class Initialized
INFO - 2016-01-04 18:52:58 --> Language Class Initialized
INFO - 2016-01-04 18:52:58 --> Loader Class Initialized
INFO - 2016-01-04 18:52:58 --> Helper loaded: url_helper
INFO - 2016-01-04 18:52:58 --> Database Driver Class Initialized
INFO - 2016-01-04 18:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:52:58 --> Controller Class Initialized
DEBUG - 2016-01-04 18:52:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 18:52:58 --> Helper loaded: inflector_helper
INFO - 2016-01-04 18:52:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 18:52:58 --> Model Class Initialized
INFO - 2016-01-04 18:52:58 --> Model Class Initialized
INFO - 2016-01-04 18:52:58 --> Final output sent to browser
DEBUG - 2016-01-04 18:52:58 --> Total execution time: 0.1396
INFO - 2016-01-04 18:53:59 --> Config Class Initialized
INFO - 2016-01-04 18:53:59 --> Hooks Class Initialized
DEBUG - 2016-01-04 18:53:59 --> UTF-8 Support Enabled
INFO - 2016-01-04 18:53:59 --> Utf8 Class Initialized
INFO - 2016-01-04 18:53:59 --> URI Class Initialized
INFO - 2016-01-04 18:53:59 --> Router Class Initialized
INFO - 2016-01-04 18:53:59 --> Output Class Initialized
INFO - 2016-01-04 18:53:59 --> Security Class Initialized
DEBUG - 2016-01-04 18:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 18:53:59 --> Input Class Initialized
INFO - 2016-01-04 18:53:59 --> Language Class Initialized
INFO - 2016-01-04 18:53:59 --> Loader Class Initialized
INFO - 2016-01-04 18:53:59 --> Helper loaded: url_helper
INFO - 2016-01-04 18:53:59 --> Database Driver Class Initialized
INFO - 2016-01-04 18:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 18:53:59 --> Controller Class Initialized
DEBUG - 2016-01-04 18:53:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 18:53:59 --> Helper loaded: inflector_helper
INFO - 2016-01-04 18:53:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 18:53:59 --> Model Class Initialized
INFO - 2016-01-04 18:53:59 --> Model Class Initialized
INFO - 2016-01-04 18:53:59 --> Final output sent to browser
DEBUG - 2016-01-04 18:53:59 --> Total execution time: 0.2145
INFO - 2016-01-04 19:13:12 --> Config Class Initialized
INFO - 2016-01-04 19:13:12 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:13:12 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:13:12 --> Utf8 Class Initialized
INFO - 2016-01-04 19:13:12 --> URI Class Initialized
DEBUG - 2016-01-04 19:13:12 --> No URI present. Default controller set.
INFO - 2016-01-04 19:13:12 --> Router Class Initialized
INFO - 2016-01-04 19:13:12 --> Output Class Initialized
INFO - 2016-01-04 19:13:12 --> Security Class Initialized
DEBUG - 2016-01-04 19:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:13:12 --> Input Class Initialized
INFO - 2016-01-04 19:13:12 --> Language Class Initialized
INFO - 2016-01-04 19:13:12 --> Loader Class Initialized
INFO - 2016-01-04 19:13:12 --> Helper loaded: url_helper
INFO - 2016-01-04 19:13:12 --> Database Driver Class Initialized
INFO - 2016-01-04 19:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:13:12 --> Controller Class Initialized
INFO - 2016-01-04 19:13:12 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 19:13:12 --> Final output sent to browser
DEBUG - 2016-01-04 19:13:12 --> Total execution time: 0.0965
INFO - 2016-01-04 19:13:13 --> Config Class Initialized
INFO - 2016-01-04 19:13:13 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:13:13 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:13:13 --> Utf8 Class Initialized
INFO - 2016-01-04 19:13:13 --> URI Class Initialized
INFO - 2016-01-04 19:13:13 --> Router Class Initialized
INFO - 2016-01-04 19:13:13 --> Output Class Initialized
INFO - 2016-01-04 19:13:13 --> Security Class Initialized
DEBUG - 2016-01-04 19:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:13:13 --> Input Class Initialized
INFO - 2016-01-04 19:13:13 --> Language Class Initialized
INFO - 2016-01-04 19:13:13 --> Loader Class Initialized
INFO - 2016-01-04 19:13:13 --> Helper loaded: url_helper
INFO - 2016-01-04 19:13:13 --> Database Driver Class Initialized
INFO - 2016-01-04 19:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:13:13 --> Controller Class Initialized
INFO - 2016-01-04 19:13:13 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 19:13:13 --> Final output sent to browser
DEBUG - 2016-01-04 19:13:13 --> Total execution time: 0.0727
INFO - 2016-01-04 19:13:13 --> Config Class Initialized
INFO - 2016-01-04 19:13:13 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:13:13 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:13:13 --> Utf8 Class Initialized
INFO - 2016-01-04 19:13:13 --> URI Class Initialized
INFO - 2016-01-04 19:13:13 --> Router Class Initialized
INFO - 2016-01-04 19:13:14 --> Output Class Initialized
INFO - 2016-01-04 19:13:14 --> Security Class Initialized
DEBUG - 2016-01-04 19:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:13:14 --> Input Class Initialized
INFO - 2016-01-04 19:13:14 --> Language Class Initialized
INFO - 2016-01-04 19:13:14 --> Loader Class Initialized
INFO - 2016-01-04 19:13:14 --> Helper loaded: url_helper
INFO - 2016-01-04 19:13:14 --> Database Driver Class Initialized
INFO - 2016-01-04 19:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:13:14 --> Controller Class Initialized
DEBUG - 2016-01-04 19:13:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:13:14 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:13:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:13:14 --> Model Class Initialized
INFO - 2016-01-04 19:13:14 --> Model Class Initialized
INFO - 2016-01-04 19:13:14 --> Final output sent to browser
DEBUG - 2016-01-04 19:13:14 --> Total execution time: 0.0794
INFO - 2016-01-04 19:21:08 --> Config Class Initialized
INFO - 2016-01-04 19:21:08 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:21:08 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:21:08 --> Utf8 Class Initialized
INFO - 2016-01-04 19:21:08 --> URI Class Initialized
INFO - 2016-01-04 19:21:08 --> Router Class Initialized
INFO - 2016-01-04 19:21:08 --> Output Class Initialized
INFO - 2016-01-04 19:21:08 --> Security Class Initialized
DEBUG - 2016-01-04 19:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:21:08 --> Input Class Initialized
INFO - 2016-01-04 19:21:08 --> Language Class Initialized
INFO - 2016-01-04 19:21:08 --> Loader Class Initialized
INFO - 2016-01-04 19:21:08 --> Helper loaded: url_helper
INFO - 2016-01-04 19:21:08 --> Database Driver Class Initialized
ERROR - 2016-01-04 19:21:08 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2016-01-04 19:21:08 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
ERROR - 2016-01-04 19:21:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/libraries/Session/Session.php 168
INFO - 2016-01-04 19:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:21:08 --> Controller Class Initialized
DEBUG - 2016-01-04 19:21:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:21:08 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:21:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:21:08 --> Model Class Initialized
INFO - 2016-01-04 19:21:08 --> Model Class Initialized
ERROR - 2016-01-04 19:21:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/core/Common.php 573
INFO - 2016-01-04 19:21:08 --> Final output sent to browser
DEBUG - 2016-01-04 19:21:08 --> Total execution time: 0.2128
INFO - 2016-01-04 19:21:22 --> Config Class Initialized
INFO - 2016-01-04 19:21:22 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:21:22 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:21:22 --> Utf8 Class Initialized
INFO - 2016-01-04 19:21:22 --> URI Class Initialized
INFO - 2016-01-04 19:21:22 --> Router Class Initialized
INFO - 2016-01-04 19:21:22 --> Output Class Initialized
INFO - 2016-01-04 19:21:22 --> Security Class Initialized
DEBUG - 2016-01-04 19:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:21:22 --> Input Class Initialized
INFO - 2016-01-04 19:21:22 --> Language Class Initialized
INFO - 2016-01-04 19:21:22 --> Loader Class Initialized
INFO - 2016-01-04 19:21:22 --> Helper loaded: url_helper
INFO - 2016-01-04 19:21:22 --> Database Driver Class Initialized
INFO - 2016-01-04 19:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:21:22 --> Controller Class Initialized
INFO - 2016-01-04 19:21:22 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 19:21:22 --> Final output sent to browser
DEBUG - 2016-01-04 19:21:22 --> Total execution time: 0.0644
INFO - 2016-01-04 19:21:22 --> Config Class Initialized
INFO - 2016-01-04 19:21:22 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:21:22 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:21:22 --> Utf8 Class Initialized
INFO - 2016-01-04 19:21:22 --> URI Class Initialized
INFO - 2016-01-04 19:21:22 --> Router Class Initialized
INFO - 2016-01-04 19:21:22 --> Output Class Initialized
INFO - 2016-01-04 19:21:22 --> Security Class Initialized
DEBUG - 2016-01-04 19:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:21:22 --> Input Class Initialized
INFO - 2016-01-04 19:21:22 --> Language Class Initialized
INFO - 2016-01-04 19:21:22 --> Loader Class Initialized
INFO - 2016-01-04 19:21:22 --> Helper loaded: url_helper
INFO - 2016-01-04 19:21:22 --> Database Driver Class Initialized
INFO - 2016-01-04 19:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:21:22 --> Controller Class Initialized
DEBUG - 2016-01-04 19:21:22 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:21:22 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:21:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:21:22 --> Model Class Initialized
INFO - 2016-01-04 19:21:22 --> Model Class Initialized
INFO - 2016-01-04 19:21:22 --> Final output sent to browser
DEBUG - 2016-01-04 19:21:22 --> Total execution time: 0.0735
INFO - 2016-01-04 19:22:23 --> Config Class Initialized
INFO - 2016-01-04 19:22:23 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:22:23 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:22:23 --> Utf8 Class Initialized
INFO - 2016-01-04 19:22:23 --> URI Class Initialized
INFO - 2016-01-04 19:22:23 --> Router Class Initialized
INFO - 2016-01-04 19:22:23 --> Output Class Initialized
INFO - 2016-01-04 19:22:23 --> Security Class Initialized
DEBUG - 2016-01-04 19:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:22:23 --> Input Class Initialized
INFO - 2016-01-04 19:22:23 --> Language Class Initialized
INFO - 2016-01-04 19:22:23 --> Loader Class Initialized
INFO - 2016-01-04 19:22:23 --> Helper loaded: url_helper
INFO - 2016-01-04 19:22:23 --> Database Driver Class Initialized
INFO - 2016-01-04 19:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:22:23 --> Controller Class Initialized
DEBUG - 2016-01-04 19:22:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:22:23 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:22:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:22:23 --> Model Class Initialized
INFO - 2016-01-04 19:22:23 --> Model Class Initialized
INFO - 2016-01-04 19:22:23 --> Final output sent to browser
DEBUG - 2016-01-04 19:22:23 --> Total execution time: 0.0923
INFO - 2016-01-04 19:22:26 --> Config Class Initialized
INFO - 2016-01-04 19:22:26 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:22:26 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:22:26 --> Utf8 Class Initialized
INFO - 2016-01-04 19:22:26 --> URI Class Initialized
INFO - 2016-01-04 19:22:26 --> Router Class Initialized
INFO - 2016-01-04 19:22:26 --> Output Class Initialized
INFO - 2016-01-04 19:22:26 --> Security Class Initialized
DEBUG - 2016-01-04 19:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:22:26 --> Input Class Initialized
INFO - 2016-01-04 19:22:26 --> Language Class Initialized
INFO - 2016-01-04 19:22:26 --> Loader Class Initialized
INFO - 2016-01-04 19:22:26 --> Helper loaded: url_helper
INFO - 2016-01-04 19:22:26 --> Database Driver Class Initialized
INFO - 2016-01-04 19:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:22:26 --> Controller Class Initialized
DEBUG - 2016-01-04 19:22:26 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:22:26 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:22:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:22:26 --> Model Class Initialized
INFO - 2016-01-04 19:22:26 --> Model Class Initialized
INFO - 2016-01-04 19:22:26 --> Final output sent to browser
DEBUG - 2016-01-04 19:22:26 --> Total execution time: 0.0704
INFO - 2016-01-04 19:23:27 --> Config Class Initialized
INFO - 2016-01-04 19:23:27 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:23:27 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:23:27 --> Utf8 Class Initialized
INFO - 2016-01-04 19:23:27 --> URI Class Initialized
INFO - 2016-01-04 19:23:27 --> Router Class Initialized
INFO - 2016-01-04 19:23:27 --> Output Class Initialized
INFO - 2016-01-04 19:23:27 --> Security Class Initialized
DEBUG - 2016-01-04 19:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:23:27 --> Input Class Initialized
INFO - 2016-01-04 19:23:27 --> Language Class Initialized
INFO - 2016-01-04 19:23:27 --> Loader Class Initialized
INFO - 2016-01-04 19:23:27 --> Helper loaded: url_helper
INFO - 2016-01-04 19:23:27 --> Database Driver Class Initialized
INFO - 2016-01-04 19:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:23:27 --> Controller Class Initialized
DEBUG - 2016-01-04 19:23:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:23:27 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:23:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:23:27 --> Model Class Initialized
INFO - 2016-01-04 19:23:27 --> Model Class Initialized
INFO - 2016-01-04 19:23:27 --> Final output sent to browser
DEBUG - 2016-01-04 19:23:27 --> Total execution time: 0.1464
INFO - 2016-01-04 19:23:30 --> Config Class Initialized
INFO - 2016-01-04 19:23:30 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:23:30 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:23:30 --> Utf8 Class Initialized
INFO - 2016-01-04 19:23:30 --> URI Class Initialized
INFO - 2016-01-04 19:23:30 --> Router Class Initialized
INFO - 2016-01-04 19:23:30 --> Output Class Initialized
INFO - 2016-01-04 19:23:30 --> Security Class Initialized
DEBUG - 2016-01-04 19:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:23:30 --> Input Class Initialized
INFO - 2016-01-04 19:23:30 --> Language Class Initialized
INFO - 2016-01-04 19:23:30 --> Loader Class Initialized
INFO - 2016-01-04 19:23:30 --> Helper loaded: url_helper
INFO - 2016-01-04 19:23:30 --> Database Driver Class Initialized
INFO - 2016-01-04 19:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:23:30 --> Controller Class Initialized
DEBUG - 2016-01-04 19:23:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:23:30 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:23:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:23:30 --> Model Class Initialized
INFO - 2016-01-04 19:23:30 --> Model Class Initialized
INFO - 2016-01-04 19:23:30 --> Final output sent to browser
DEBUG - 2016-01-04 19:23:30 --> Total execution time: 0.0693
INFO - 2016-01-04 19:23:31 --> Config Class Initialized
INFO - 2016-01-04 19:23:31 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:23:31 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:23:31 --> Utf8 Class Initialized
INFO - 2016-01-04 19:23:31 --> URI Class Initialized
DEBUG - 2016-01-04 19:23:31 --> No URI present. Default controller set.
INFO - 2016-01-04 19:23:31 --> Router Class Initialized
INFO - 2016-01-04 19:23:31 --> Output Class Initialized
INFO - 2016-01-04 19:23:31 --> Security Class Initialized
DEBUG - 2016-01-04 19:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:23:31 --> Input Class Initialized
INFO - 2016-01-04 19:23:31 --> Language Class Initialized
INFO - 2016-01-04 19:23:31 --> Loader Class Initialized
INFO - 2016-01-04 19:23:31 --> Helper loaded: url_helper
INFO - 2016-01-04 19:23:31 --> Database Driver Class Initialized
INFO - 2016-01-04 19:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:23:31 --> Controller Class Initialized
INFO - 2016-01-04 19:23:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 19:23:31 --> Final output sent to browser
DEBUG - 2016-01-04 19:23:31 --> Total execution time: 0.0548
INFO - 2016-01-04 19:23:38 --> Config Class Initialized
INFO - 2016-01-04 19:23:38 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:23:38 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:23:38 --> Utf8 Class Initialized
INFO - 2016-01-04 19:23:38 --> URI Class Initialized
INFO - 2016-01-04 19:23:38 --> Router Class Initialized
INFO - 2016-01-04 19:23:38 --> Output Class Initialized
INFO - 2016-01-04 19:23:38 --> Security Class Initialized
DEBUG - 2016-01-04 19:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:23:38 --> Input Class Initialized
INFO - 2016-01-04 19:23:38 --> Language Class Initialized
INFO - 2016-01-04 19:23:38 --> Loader Class Initialized
INFO - 2016-01-04 19:23:38 --> Helper loaded: url_helper
INFO - 2016-01-04 19:23:38 --> Database Driver Class Initialized
INFO - 2016-01-04 19:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:23:38 --> Controller Class Initialized
INFO - 2016-01-04 19:23:38 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 19:23:38 --> Final output sent to browser
DEBUG - 2016-01-04 19:23:38 --> Total execution time: 0.0570
INFO - 2016-01-04 19:23:38 --> Config Class Initialized
INFO - 2016-01-04 19:23:38 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:23:38 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:23:38 --> Utf8 Class Initialized
INFO - 2016-01-04 19:23:38 --> URI Class Initialized
INFO - 2016-01-04 19:23:38 --> Router Class Initialized
INFO - 2016-01-04 19:23:38 --> Output Class Initialized
INFO - 2016-01-04 19:23:38 --> Security Class Initialized
DEBUG - 2016-01-04 19:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:23:38 --> Input Class Initialized
INFO - 2016-01-04 19:23:38 --> Language Class Initialized
INFO - 2016-01-04 19:23:38 --> Loader Class Initialized
INFO - 2016-01-04 19:23:38 --> Helper loaded: url_helper
INFO - 2016-01-04 19:23:38 --> Database Driver Class Initialized
INFO - 2016-01-04 19:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:23:38 --> Controller Class Initialized
DEBUG - 2016-01-04 19:23:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:23:38 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:23:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:23:38 --> Model Class Initialized
INFO - 2016-01-04 19:23:38 --> Model Class Initialized
INFO - 2016-01-04 19:23:38 --> Final output sent to browser
DEBUG - 2016-01-04 19:23:38 --> Total execution time: 0.0677
INFO - 2016-01-04 19:24:39 --> Config Class Initialized
INFO - 2016-01-04 19:24:39 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:24:39 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:24:39 --> Utf8 Class Initialized
INFO - 2016-01-04 19:24:39 --> URI Class Initialized
INFO - 2016-01-04 19:24:39 --> Router Class Initialized
INFO - 2016-01-04 19:24:39 --> Output Class Initialized
INFO - 2016-01-04 19:24:39 --> Security Class Initialized
DEBUG - 2016-01-04 19:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:24:39 --> Input Class Initialized
INFO - 2016-01-04 19:24:39 --> Language Class Initialized
INFO - 2016-01-04 19:24:39 --> Loader Class Initialized
INFO - 2016-01-04 19:24:39 --> Helper loaded: url_helper
INFO - 2016-01-04 19:24:39 --> Database Driver Class Initialized
INFO - 2016-01-04 19:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:24:39 --> Controller Class Initialized
DEBUG - 2016-01-04 19:24:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:24:39 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:24:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:24:39 --> Model Class Initialized
INFO - 2016-01-04 19:24:39 --> Model Class Initialized
INFO - 2016-01-04 19:24:39 --> Final output sent to browser
DEBUG - 2016-01-04 19:24:39 --> Total execution time: 0.1343
INFO - 2016-01-04 19:28:35 --> Config Class Initialized
INFO - 2016-01-04 19:28:35 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:28:35 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:28:35 --> Utf8 Class Initialized
INFO - 2016-01-04 19:28:35 --> URI Class Initialized
INFO - 2016-01-04 19:28:35 --> Router Class Initialized
INFO - 2016-01-04 19:28:35 --> Output Class Initialized
INFO - 2016-01-04 19:28:35 --> Security Class Initialized
DEBUG - 2016-01-04 19:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:28:35 --> Input Class Initialized
INFO - 2016-01-04 19:28:35 --> Language Class Initialized
INFO - 2016-01-04 19:28:35 --> Loader Class Initialized
INFO - 2016-01-04 19:28:35 --> Helper loaded: url_helper
INFO - 2016-01-04 19:28:35 --> Database Driver Class Initialized
INFO - 2016-01-04 19:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:28:35 --> Controller Class Initialized
DEBUG - 2016-01-04 19:28:35 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:28:35 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:28:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:28:35 --> Model Class Initialized
INFO - 2016-01-04 19:28:35 --> Model Class Initialized
INFO - 2016-01-04 19:28:35 --> Final output sent to browser
DEBUG - 2016-01-04 19:28:35 --> Total execution time: 0.0999
INFO - 2016-01-04 19:29:36 --> Config Class Initialized
INFO - 2016-01-04 19:29:36 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:29:36 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:29:36 --> Utf8 Class Initialized
INFO - 2016-01-04 19:29:36 --> URI Class Initialized
INFO - 2016-01-04 19:29:36 --> Router Class Initialized
INFO - 2016-01-04 19:29:36 --> Output Class Initialized
INFO - 2016-01-04 19:29:36 --> Security Class Initialized
DEBUG - 2016-01-04 19:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:29:36 --> Input Class Initialized
INFO - 2016-01-04 19:29:36 --> Language Class Initialized
INFO - 2016-01-04 19:29:36 --> Loader Class Initialized
INFO - 2016-01-04 19:29:36 --> Helper loaded: url_helper
INFO - 2016-01-04 19:29:36 --> Database Driver Class Initialized
INFO - 2016-01-04 19:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:29:36 --> Controller Class Initialized
DEBUG - 2016-01-04 19:29:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:29:36 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:29:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:29:36 --> Model Class Initialized
INFO - 2016-01-04 19:29:36 --> Model Class Initialized
INFO - 2016-01-04 19:29:36 --> Final output sent to browser
DEBUG - 2016-01-04 19:29:36 --> Total execution time: 0.0962
INFO - 2016-01-04 19:34:04 --> Config Class Initialized
INFO - 2016-01-04 19:34:04 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:34:04 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:34:04 --> Utf8 Class Initialized
INFO - 2016-01-04 19:34:04 --> URI Class Initialized
INFO - 2016-01-04 19:34:04 --> Router Class Initialized
INFO - 2016-01-04 19:34:04 --> Output Class Initialized
INFO - 2016-01-04 19:34:04 --> Security Class Initialized
DEBUG - 2016-01-04 19:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:34:04 --> Input Class Initialized
INFO - 2016-01-04 19:34:04 --> Language Class Initialized
INFO - 2016-01-04 19:34:04 --> Loader Class Initialized
INFO - 2016-01-04 19:34:04 --> Helper loaded: url_helper
INFO - 2016-01-04 19:34:04 --> Database Driver Class Initialized
INFO - 2016-01-04 19:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:34:04 --> Controller Class Initialized
DEBUG - 2016-01-04 19:34:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:34:04 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:34:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:34:04 --> Model Class Initialized
INFO - 2016-01-04 19:34:04 --> Model Class Initialized
INFO - 2016-01-04 19:34:04 --> Final output sent to browser
DEBUG - 2016-01-04 19:34:04 --> Total execution time: 0.1515
INFO - 2016-01-04 19:34:05 --> Config Class Initialized
INFO - 2016-01-04 19:34:05 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:34:05 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:34:05 --> Utf8 Class Initialized
INFO - 2016-01-04 19:34:05 --> URI Class Initialized
DEBUG - 2016-01-04 19:34:05 --> No URI present. Default controller set.
INFO - 2016-01-04 19:34:05 --> Router Class Initialized
INFO - 2016-01-04 19:34:05 --> Output Class Initialized
INFO - 2016-01-04 19:34:05 --> Security Class Initialized
DEBUG - 2016-01-04 19:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:34:05 --> Input Class Initialized
INFO - 2016-01-04 19:34:05 --> Language Class Initialized
INFO - 2016-01-04 19:34:05 --> Loader Class Initialized
INFO - 2016-01-04 19:34:05 --> Helper loaded: url_helper
INFO - 2016-01-04 19:34:05 --> Database Driver Class Initialized
INFO - 2016-01-04 19:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:34:05 --> Controller Class Initialized
INFO - 2016-01-04 19:34:05 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 19:34:05 --> Final output sent to browser
DEBUG - 2016-01-04 19:34:05 --> Total execution time: 0.0913
INFO - 2016-01-04 19:34:09 --> Config Class Initialized
INFO - 2016-01-04 19:34:09 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:34:09 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:34:09 --> Utf8 Class Initialized
INFO - 2016-01-04 19:34:09 --> URI Class Initialized
INFO - 2016-01-04 19:34:09 --> Router Class Initialized
INFO - 2016-01-04 19:34:09 --> Output Class Initialized
INFO - 2016-01-04 19:34:09 --> Security Class Initialized
DEBUG - 2016-01-04 19:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:34:09 --> Input Class Initialized
INFO - 2016-01-04 19:34:09 --> Language Class Initialized
INFO - 2016-01-04 19:34:09 --> Loader Class Initialized
INFO - 2016-01-04 19:34:09 --> Helper loaded: url_helper
INFO - 2016-01-04 19:34:09 --> Database Driver Class Initialized
INFO - 2016-01-04 19:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:34:09 --> Controller Class Initialized
INFO - 2016-01-04 19:34:09 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 19:34:09 --> Final output sent to browser
DEBUG - 2016-01-04 19:34:09 --> Total execution time: 0.0725
INFO - 2016-01-04 19:34:09 --> Config Class Initialized
INFO - 2016-01-04 19:34:09 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:34:09 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:34:09 --> Utf8 Class Initialized
INFO - 2016-01-04 19:34:09 --> URI Class Initialized
INFO - 2016-01-04 19:34:09 --> Router Class Initialized
INFO - 2016-01-04 19:34:09 --> Output Class Initialized
INFO - 2016-01-04 19:34:09 --> Security Class Initialized
DEBUG - 2016-01-04 19:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:34:09 --> Input Class Initialized
INFO - 2016-01-04 19:34:09 --> Language Class Initialized
INFO - 2016-01-04 19:34:09 --> Loader Class Initialized
INFO - 2016-01-04 19:34:09 --> Helper loaded: url_helper
INFO - 2016-01-04 19:34:09 --> Database Driver Class Initialized
INFO - 2016-01-04 19:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:34:09 --> Controller Class Initialized
DEBUG - 2016-01-04 19:34:09 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:34:09 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:34:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:34:09 --> Model Class Initialized
INFO - 2016-01-04 19:34:09 --> Model Class Initialized
INFO - 2016-01-04 19:34:09 --> Final output sent to browser
DEBUG - 2016-01-04 19:34:09 --> Total execution time: 0.1248
INFO - 2016-01-04 19:34:21 --> Config Class Initialized
INFO - 2016-01-04 19:34:21 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:34:21 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:34:21 --> Utf8 Class Initialized
INFO - 2016-01-04 19:34:21 --> URI Class Initialized
INFO - 2016-01-04 19:34:21 --> Router Class Initialized
INFO - 2016-01-04 19:34:21 --> Output Class Initialized
INFO - 2016-01-04 19:34:21 --> Security Class Initialized
DEBUG - 2016-01-04 19:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:34:21 --> Input Class Initialized
INFO - 2016-01-04 19:34:21 --> Language Class Initialized
INFO - 2016-01-04 19:34:21 --> Loader Class Initialized
INFO - 2016-01-04 19:34:21 --> Helper loaded: url_helper
INFO - 2016-01-04 19:34:21 --> Database Driver Class Initialized
INFO - 2016-01-04 19:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:34:21 --> Controller Class Initialized
DEBUG - 2016-01-04 19:34:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:34:21 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:34:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:34:21 --> Model Class Initialized
INFO - 2016-01-04 19:34:21 --> Model Class Initialized
INFO - 2016-01-04 19:34:21 --> Final output sent to browser
DEBUG - 2016-01-04 19:34:21 --> Total execution time: 0.0842
INFO - 2016-01-04 19:34:22 --> Config Class Initialized
INFO - 2016-01-04 19:34:22 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:34:22 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:34:22 --> Utf8 Class Initialized
INFO - 2016-01-04 19:34:22 --> URI Class Initialized
INFO - 2016-01-04 19:34:22 --> Router Class Initialized
INFO - 2016-01-04 19:34:22 --> Output Class Initialized
INFO - 2016-01-04 19:34:22 --> Security Class Initialized
DEBUG - 2016-01-04 19:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:34:22 --> Input Class Initialized
INFO - 2016-01-04 19:34:22 --> Language Class Initialized
INFO - 2016-01-04 19:34:22 --> Loader Class Initialized
INFO - 2016-01-04 19:34:22 --> Helper loaded: url_helper
INFO - 2016-01-04 19:34:22 --> Database Driver Class Initialized
INFO - 2016-01-04 19:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:34:22 --> Controller Class Initialized
DEBUG - 2016-01-04 19:34:22 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:34:22 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:34:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:34:22 --> Model Class Initialized
INFO - 2016-01-04 19:34:22 --> Model Class Initialized
INFO - 2016-01-04 19:34:22 --> Final output sent to browser
DEBUG - 2016-01-04 19:34:22 --> Total execution time: 0.0684
INFO - 2016-01-04 19:35:23 --> Config Class Initialized
INFO - 2016-01-04 19:35:23 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:35:23 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:35:23 --> Utf8 Class Initialized
INFO - 2016-01-04 19:35:23 --> URI Class Initialized
INFO - 2016-01-04 19:35:23 --> Router Class Initialized
INFO - 2016-01-04 19:35:23 --> Output Class Initialized
INFO - 2016-01-04 19:35:23 --> Security Class Initialized
DEBUG - 2016-01-04 19:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:35:23 --> Input Class Initialized
INFO - 2016-01-04 19:35:23 --> Language Class Initialized
INFO - 2016-01-04 19:35:23 --> Loader Class Initialized
INFO - 2016-01-04 19:35:23 --> Helper loaded: url_helper
INFO - 2016-01-04 19:35:23 --> Database Driver Class Initialized
INFO - 2016-01-04 19:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:35:23 --> Controller Class Initialized
DEBUG - 2016-01-04 19:35:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:35:23 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:35:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:35:23 --> Model Class Initialized
INFO - 2016-01-04 19:35:23 --> Model Class Initialized
INFO - 2016-01-04 19:35:23 --> Final output sent to browser
DEBUG - 2016-01-04 19:35:23 --> Total execution time: 0.2122
INFO - 2016-01-04 19:38:38 --> Config Class Initialized
INFO - 2016-01-04 19:38:38 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:38:38 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:38:38 --> Utf8 Class Initialized
INFO - 2016-01-04 19:38:38 --> URI Class Initialized
INFO - 2016-01-04 19:38:38 --> Router Class Initialized
INFO - 2016-01-04 19:38:38 --> Output Class Initialized
INFO - 2016-01-04 19:38:38 --> Security Class Initialized
DEBUG - 2016-01-04 19:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:38:38 --> Input Class Initialized
INFO - 2016-01-04 19:38:38 --> Language Class Initialized
INFO - 2016-01-04 19:38:38 --> Loader Class Initialized
INFO - 2016-01-04 19:38:38 --> Helper loaded: url_helper
INFO - 2016-01-04 19:38:38 --> Database Driver Class Initialized
INFO - 2016-01-04 19:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:38:38 --> Controller Class Initialized
DEBUG - 2016-01-04 19:38:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:38:38 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:38:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:38:38 --> Model Class Initialized
INFO - 2016-01-04 19:38:38 --> Model Class Initialized
INFO - 2016-01-04 19:38:38 --> Final output sent to browser
DEBUG - 2016-01-04 19:38:38 --> Total execution time: 0.0966
INFO - 2016-01-04 19:38:44 --> Config Class Initialized
INFO - 2016-01-04 19:38:44 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:38:44 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:38:44 --> Utf8 Class Initialized
INFO - 2016-01-04 19:38:44 --> URI Class Initialized
DEBUG - 2016-01-04 19:38:44 --> No URI present. Default controller set.
INFO - 2016-01-04 19:38:44 --> Router Class Initialized
INFO - 2016-01-04 19:38:44 --> Output Class Initialized
INFO - 2016-01-04 19:38:44 --> Security Class Initialized
DEBUG - 2016-01-04 19:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:38:44 --> Input Class Initialized
INFO - 2016-01-04 19:38:44 --> Language Class Initialized
INFO - 2016-01-04 19:38:44 --> Loader Class Initialized
INFO - 2016-01-04 19:38:44 --> Helper loaded: url_helper
INFO - 2016-01-04 19:38:44 --> Database Driver Class Initialized
INFO - 2016-01-04 19:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:38:44 --> Controller Class Initialized
INFO - 2016-01-04 19:38:44 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 19:38:44 --> Final output sent to browser
DEBUG - 2016-01-04 19:38:44 --> Total execution time: 0.0976
INFO - 2016-01-04 19:38:46 --> Config Class Initialized
INFO - 2016-01-04 19:38:46 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:38:46 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:38:46 --> Utf8 Class Initialized
INFO - 2016-01-04 19:38:46 --> URI Class Initialized
INFO - 2016-01-04 19:38:46 --> Router Class Initialized
INFO - 2016-01-04 19:38:46 --> Output Class Initialized
INFO - 2016-01-04 19:38:46 --> Security Class Initialized
DEBUG - 2016-01-04 19:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:38:46 --> Input Class Initialized
INFO - 2016-01-04 19:38:46 --> Language Class Initialized
INFO - 2016-01-04 19:38:46 --> Loader Class Initialized
INFO - 2016-01-04 19:38:46 --> Helper loaded: url_helper
INFO - 2016-01-04 19:38:46 --> Database Driver Class Initialized
INFO - 2016-01-04 19:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:38:46 --> Controller Class Initialized
INFO - 2016-01-04 19:38:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 19:38:46 --> Final output sent to browser
DEBUG - 2016-01-04 19:38:46 --> Total execution time: 0.0530
INFO - 2016-01-04 19:38:46 --> Config Class Initialized
INFO - 2016-01-04 19:38:46 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:38:46 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:38:46 --> Utf8 Class Initialized
INFO - 2016-01-04 19:38:46 --> URI Class Initialized
INFO - 2016-01-04 19:38:46 --> Router Class Initialized
INFO - 2016-01-04 19:38:46 --> Output Class Initialized
INFO - 2016-01-04 19:38:46 --> Security Class Initialized
DEBUG - 2016-01-04 19:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:38:46 --> Input Class Initialized
INFO - 2016-01-04 19:38:46 --> Language Class Initialized
INFO - 2016-01-04 19:38:46 --> Loader Class Initialized
INFO - 2016-01-04 19:38:46 --> Helper loaded: url_helper
INFO - 2016-01-04 19:38:46 --> Database Driver Class Initialized
INFO - 2016-01-04 19:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:38:46 --> Controller Class Initialized
DEBUG - 2016-01-04 19:38:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:38:46 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:38:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:38:46 --> Model Class Initialized
INFO - 2016-01-04 19:38:46 --> Model Class Initialized
INFO - 2016-01-04 19:38:46 --> Final output sent to browser
DEBUG - 2016-01-04 19:38:46 --> Total execution time: 0.1627
INFO - 2016-01-04 19:39:02 --> Config Class Initialized
INFO - 2016-01-04 19:39:02 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:02 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:02 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:02 --> URI Class Initialized
DEBUG - 2016-01-04 19:39:02 --> No URI present. Default controller set.
INFO - 2016-01-04 19:39:02 --> Router Class Initialized
INFO - 2016-01-04 19:39:02 --> Output Class Initialized
INFO - 2016-01-04 19:39:02 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:02 --> Input Class Initialized
INFO - 2016-01-04 19:39:02 --> Language Class Initialized
INFO - 2016-01-04 19:39:02 --> Loader Class Initialized
INFO - 2016-01-04 19:39:02 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:02 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:02 --> Controller Class Initialized
INFO - 2016-01-04 19:39:02 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 19:39:02 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:02 --> Total execution time: 0.0626
INFO - 2016-01-04 19:39:04 --> Config Class Initialized
INFO - 2016-01-04 19:39:04 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:04 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:04 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:04 --> URI Class Initialized
DEBUG - 2016-01-04 19:39:04 --> No URI present. Default controller set.
INFO - 2016-01-04 19:39:04 --> Router Class Initialized
INFO - 2016-01-04 19:39:04 --> Output Class Initialized
INFO - 2016-01-04 19:39:04 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:04 --> Input Class Initialized
INFO - 2016-01-04 19:39:04 --> Language Class Initialized
INFO - 2016-01-04 19:39:04 --> Loader Class Initialized
INFO - 2016-01-04 19:39:04 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:04 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:04 --> Controller Class Initialized
INFO - 2016-01-04 19:39:04 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 19:39:04 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:04 --> Total execution time: 0.0524
INFO - 2016-01-04 19:39:06 --> Config Class Initialized
INFO - 2016-01-04 19:39:06 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:06 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:06 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:06 --> URI Class Initialized
INFO - 2016-01-04 19:39:06 --> Router Class Initialized
INFO - 2016-01-04 19:39:06 --> Output Class Initialized
INFO - 2016-01-04 19:39:06 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:06 --> Input Class Initialized
INFO - 2016-01-04 19:39:06 --> Language Class Initialized
INFO - 2016-01-04 19:39:06 --> Loader Class Initialized
INFO - 2016-01-04 19:39:06 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:06 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:06 --> Controller Class Initialized
INFO - 2016-01-04 19:39:06 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 19:39:06 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:06 --> Total execution time: 0.0862
INFO - 2016-01-04 19:39:06 --> Config Class Initialized
INFO - 2016-01-04 19:39:06 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:06 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:06 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:06 --> URI Class Initialized
INFO - 2016-01-04 19:39:06 --> Router Class Initialized
INFO - 2016-01-04 19:39:06 --> Output Class Initialized
INFO - 2016-01-04 19:39:06 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:06 --> Input Class Initialized
INFO - 2016-01-04 19:39:06 --> Language Class Initialized
INFO - 2016-01-04 19:39:06 --> Loader Class Initialized
INFO - 2016-01-04 19:39:06 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:06 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:06 --> Controller Class Initialized
DEBUG - 2016-01-04 19:39:06 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:39:06 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:39:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:39:06 --> Model Class Initialized
INFO - 2016-01-04 19:39:06 --> Model Class Initialized
INFO - 2016-01-04 19:39:06 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:06 --> Total execution time: 0.1170
INFO - 2016-01-04 19:39:11 --> Config Class Initialized
INFO - 2016-01-04 19:39:11 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:11 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:11 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:11 --> URI Class Initialized
INFO - 2016-01-04 19:39:11 --> Router Class Initialized
INFO - 2016-01-04 19:39:11 --> Output Class Initialized
INFO - 2016-01-04 19:39:11 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:11 --> Input Class Initialized
INFO - 2016-01-04 19:39:11 --> Language Class Initialized
INFO - 2016-01-04 19:39:11 --> Loader Class Initialized
INFO - 2016-01-04 19:39:11 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:11 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:11 --> Controller Class Initialized
DEBUG - 2016-01-04 19:39:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:39:11 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:39:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:39:11 --> Model Class Initialized
INFO - 2016-01-04 19:39:11 --> Model Class Initialized
INFO - 2016-01-04 19:39:11 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:11 --> Total execution time: 0.0803
INFO - 2016-01-04 19:39:12 --> Config Class Initialized
INFO - 2016-01-04 19:39:12 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:12 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:12 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:12 --> URI Class Initialized
INFO - 2016-01-04 19:39:12 --> Router Class Initialized
INFO - 2016-01-04 19:39:12 --> Output Class Initialized
INFO - 2016-01-04 19:39:12 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:12 --> Input Class Initialized
INFO - 2016-01-04 19:39:12 --> Language Class Initialized
INFO - 2016-01-04 19:39:12 --> Loader Class Initialized
INFO - 2016-01-04 19:39:12 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:12 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:12 --> Controller Class Initialized
DEBUG - 2016-01-04 19:39:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:39:12 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:39:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:39:12 --> Model Class Initialized
INFO - 2016-01-04 19:39:12 --> Model Class Initialized
INFO - 2016-01-04 19:39:12 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:12 --> Total execution time: 0.0687
INFO - 2016-01-04 19:39:12 --> Config Class Initialized
INFO - 2016-01-04 19:39:12 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:12 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:12 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:12 --> URI Class Initialized
INFO - 2016-01-04 19:39:12 --> Router Class Initialized
INFO - 2016-01-04 19:39:12 --> Output Class Initialized
INFO - 2016-01-04 19:39:12 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:12 --> Input Class Initialized
INFO - 2016-01-04 19:39:12 --> Language Class Initialized
INFO - 2016-01-04 19:39:12 --> Loader Class Initialized
INFO - 2016-01-04 19:39:12 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:12 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:13 --> Controller Class Initialized
DEBUG - 2016-01-04 19:39:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:39:13 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:39:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:39:13 --> Model Class Initialized
INFO - 2016-01-04 19:39:13 --> Model Class Initialized
INFO - 2016-01-04 19:39:13 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:13 --> Total execution time: 0.0640
INFO - 2016-01-04 19:39:14 --> Config Class Initialized
INFO - 2016-01-04 19:39:14 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:14 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:14 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:14 --> URI Class Initialized
INFO - 2016-01-04 19:39:14 --> Router Class Initialized
INFO - 2016-01-04 19:39:14 --> Output Class Initialized
INFO - 2016-01-04 19:39:14 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:14 --> Input Class Initialized
INFO - 2016-01-04 19:39:14 --> Language Class Initialized
INFO - 2016-01-04 19:39:14 --> Loader Class Initialized
INFO - 2016-01-04 19:39:14 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:14 --> Database Driver Class Initialized
ERROR - 2016-01-04 19:39:14 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2016-01-04 19:39:14 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
ERROR - 2016-01-04 19:39:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/libraries/Session/Session.php 168
INFO - 2016-01-04 19:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:14 --> Controller Class Initialized
DEBUG - 2016-01-04 19:39:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:39:14 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:39:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:39:14 --> Model Class Initialized
INFO - 2016-01-04 19:39:14 --> Model Class Initialized
ERROR - 2016-01-04 19:39:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/core/Common.php 573
INFO - 2016-01-04 19:39:14 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:14 --> Total execution time: 0.0738
INFO - 2016-01-04 19:39:23 --> Config Class Initialized
INFO - 2016-01-04 19:39:23 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:23 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:23 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:23 --> URI Class Initialized
INFO - 2016-01-04 19:39:23 --> Router Class Initialized
INFO - 2016-01-04 19:39:23 --> Output Class Initialized
INFO - 2016-01-04 19:39:23 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:23 --> Input Class Initialized
INFO - 2016-01-04 19:39:23 --> Language Class Initialized
INFO - 2016-01-04 19:39:23 --> Loader Class Initialized
INFO - 2016-01-04 19:39:23 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:23 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:23 --> Controller Class Initialized
INFO - 2016-01-04 19:39:23 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 19:39:23 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:23 --> Total execution time: 0.0588
INFO - 2016-01-04 19:39:24 --> Config Class Initialized
INFO - 2016-01-04 19:39:24 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:24 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:24 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:24 --> URI Class Initialized
INFO - 2016-01-04 19:39:24 --> Router Class Initialized
INFO - 2016-01-04 19:39:24 --> Output Class Initialized
INFO - 2016-01-04 19:39:24 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:24 --> Input Class Initialized
INFO - 2016-01-04 19:39:24 --> Language Class Initialized
INFO - 2016-01-04 19:39:24 --> Loader Class Initialized
INFO - 2016-01-04 19:39:24 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:24 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:24 --> Controller Class Initialized
DEBUG - 2016-01-04 19:39:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:39:24 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:39:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:39:24 --> Model Class Initialized
INFO - 2016-01-04 19:39:24 --> Model Class Initialized
INFO - 2016-01-04 19:39:24 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:24 --> Total execution time: 0.0711
INFO - 2016-01-04 19:39:30 --> Config Class Initialized
INFO - 2016-01-04 19:39:30 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:30 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:30 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:30 --> URI Class Initialized
DEBUG - 2016-01-04 19:39:30 --> No URI present. Default controller set.
INFO - 2016-01-04 19:39:30 --> Router Class Initialized
INFO - 2016-01-04 19:39:30 --> Output Class Initialized
INFO - 2016-01-04 19:39:30 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:30 --> Input Class Initialized
INFO - 2016-01-04 19:39:30 --> Language Class Initialized
INFO - 2016-01-04 19:39:30 --> Loader Class Initialized
INFO - 2016-01-04 19:39:30 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:30 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:30 --> Controller Class Initialized
INFO - 2016-01-04 19:39:30 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 19:39:30 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:30 --> Total execution time: 0.0659
INFO - 2016-01-04 19:39:32 --> Config Class Initialized
INFO - 2016-01-04 19:39:32 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:32 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:32 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:32 --> URI Class Initialized
INFO - 2016-01-04 19:39:32 --> Router Class Initialized
INFO - 2016-01-04 19:39:32 --> Output Class Initialized
INFO - 2016-01-04 19:39:33 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:33 --> Input Class Initialized
INFO - 2016-01-04 19:39:33 --> Language Class Initialized
INFO - 2016-01-04 19:39:33 --> Loader Class Initialized
INFO - 2016-01-04 19:39:33 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:33 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:33 --> Controller Class Initialized
INFO - 2016-01-04 19:39:33 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 19:39:33 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:33 --> Total execution time: 0.0541
INFO - 2016-01-04 19:39:33 --> Config Class Initialized
INFO - 2016-01-04 19:39:33 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:39:33 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:39:33 --> Utf8 Class Initialized
INFO - 2016-01-04 19:39:33 --> URI Class Initialized
INFO - 2016-01-04 19:39:33 --> Router Class Initialized
INFO - 2016-01-04 19:39:33 --> Output Class Initialized
INFO - 2016-01-04 19:39:33 --> Security Class Initialized
DEBUG - 2016-01-04 19:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:39:33 --> Input Class Initialized
INFO - 2016-01-04 19:39:33 --> Language Class Initialized
INFO - 2016-01-04 19:39:33 --> Loader Class Initialized
INFO - 2016-01-04 19:39:33 --> Helper loaded: url_helper
INFO - 2016-01-04 19:39:33 --> Database Driver Class Initialized
INFO - 2016-01-04 19:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:39:33 --> Controller Class Initialized
DEBUG - 2016-01-04 19:39:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:39:33 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:39:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:39:33 --> Model Class Initialized
INFO - 2016-01-04 19:39:33 --> Model Class Initialized
INFO - 2016-01-04 19:39:33 --> Final output sent to browser
DEBUG - 2016-01-04 19:39:33 --> Total execution time: 0.0766
INFO - 2016-01-04 19:40:20 --> Config Class Initialized
INFO - 2016-01-04 19:40:20 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:40:20 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:40:20 --> Utf8 Class Initialized
INFO - 2016-01-04 19:40:20 --> URI Class Initialized
INFO - 2016-01-04 19:40:20 --> Router Class Initialized
INFO - 2016-01-04 19:40:20 --> Output Class Initialized
INFO - 2016-01-04 19:40:20 --> Security Class Initialized
DEBUG - 2016-01-04 19:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:40:20 --> Input Class Initialized
INFO - 2016-01-04 19:40:20 --> Language Class Initialized
INFO - 2016-01-04 19:40:20 --> Loader Class Initialized
INFO - 2016-01-04 19:40:20 --> Helper loaded: url_helper
INFO - 2016-01-04 19:40:20 --> Database Driver Class Initialized
INFO - 2016-01-04 19:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:40:20 --> Controller Class Initialized
DEBUG - 2016-01-04 19:40:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:40:20 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:40:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:40:20 --> Model Class Initialized
INFO - 2016-01-04 19:40:20 --> Model Class Initialized
INFO - 2016-01-04 19:40:20 --> Final output sent to browser
DEBUG - 2016-01-04 19:40:20 --> Total execution time: 0.1563
INFO - 2016-01-04 19:40:20 --> Config Class Initialized
INFO - 2016-01-04 19:40:20 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:40:20 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:40:20 --> Utf8 Class Initialized
INFO - 2016-01-04 19:40:20 --> URI Class Initialized
INFO - 2016-01-04 19:40:20 --> Router Class Initialized
INFO - 2016-01-04 19:40:20 --> Output Class Initialized
INFO - 2016-01-04 19:40:20 --> Security Class Initialized
DEBUG - 2016-01-04 19:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:40:20 --> Input Class Initialized
INFO - 2016-01-04 19:40:20 --> Language Class Initialized
INFO - 2016-01-04 19:40:20 --> Loader Class Initialized
INFO - 2016-01-04 19:40:20 --> Helper loaded: url_helper
INFO - 2016-01-04 19:40:20 --> Database Driver Class Initialized
INFO - 2016-01-04 19:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:40:20 --> Controller Class Initialized
DEBUG - 2016-01-04 19:40:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:40:20 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:40:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:40:20 --> Model Class Initialized
INFO - 2016-01-04 19:40:20 --> Model Class Initialized
INFO - 2016-01-04 19:40:20 --> Final output sent to browser
DEBUG - 2016-01-04 19:40:20 --> Total execution time: 0.1278
INFO - 2016-01-04 19:40:21 --> Config Class Initialized
INFO - 2016-01-04 19:40:21 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:40:21 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:40:21 --> Utf8 Class Initialized
INFO - 2016-01-04 19:40:21 --> URI Class Initialized
INFO - 2016-01-04 19:40:21 --> Router Class Initialized
INFO - 2016-01-04 19:40:21 --> Output Class Initialized
INFO - 2016-01-04 19:40:21 --> Security Class Initialized
DEBUG - 2016-01-04 19:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:40:21 --> Input Class Initialized
INFO - 2016-01-04 19:40:21 --> Language Class Initialized
INFO - 2016-01-04 19:40:21 --> Loader Class Initialized
INFO - 2016-01-04 19:40:21 --> Helper loaded: url_helper
INFO - 2016-01-04 19:40:21 --> Database Driver Class Initialized
INFO - 2016-01-04 19:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:40:21 --> Controller Class Initialized
DEBUG - 2016-01-04 19:40:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:40:21 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:40:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:40:21 --> Model Class Initialized
INFO - 2016-01-04 19:40:21 --> Model Class Initialized
INFO - 2016-01-04 19:40:21 --> Final output sent to browser
DEBUG - 2016-01-04 19:40:21 --> Total execution time: 0.1263
INFO - 2016-01-04 19:40:22 --> Config Class Initialized
INFO - 2016-01-04 19:40:22 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:40:22 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:40:22 --> Utf8 Class Initialized
INFO - 2016-01-04 19:40:22 --> URI Class Initialized
INFO - 2016-01-04 19:40:22 --> Router Class Initialized
INFO - 2016-01-04 19:40:22 --> Output Class Initialized
INFO - 2016-01-04 19:40:22 --> Security Class Initialized
DEBUG - 2016-01-04 19:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:40:22 --> Input Class Initialized
INFO - 2016-01-04 19:40:22 --> Language Class Initialized
INFO - 2016-01-04 19:40:22 --> Loader Class Initialized
INFO - 2016-01-04 19:40:22 --> Helper loaded: url_helper
INFO - 2016-01-04 19:40:22 --> Database Driver Class Initialized
INFO - 2016-01-04 19:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:40:22 --> Controller Class Initialized
DEBUG - 2016-01-04 19:40:22 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:40:22 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:40:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:40:22 --> Model Class Initialized
INFO - 2016-01-04 19:40:22 --> Model Class Initialized
INFO - 2016-01-04 19:40:22 --> Final output sent to browser
DEBUG - 2016-01-04 19:40:22 --> Total execution time: 0.0645
INFO - 2016-01-04 19:40:28 --> Config Class Initialized
INFO - 2016-01-04 19:40:28 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:40:28 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:40:28 --> Utf8 Class Initialized
INFO - 2016-01-04 19:40:28 --> URI Class Initialized
DEBUG - 2016-01-04 19:40:28 --> No URI present. Default controller set.
INFO - 2016-01-04 19:40:28 --> Router Class Initialized
INFO - 2016-01-04 19:40:28 --> Output Class Initialized
INFO - 2016-01-04 19:40:28 --> Security Class Initialized
DEBUG - 2016-01-04 19:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:40:28 --> Input Class Initialized
INFO - 2016-01-04 19:40:28 --> Language Class Initialized
INFO - 2016-01-04 19:40:28 --> Loader Class Initialized
INFO - 2016-01-04 19:40:28 --> Helper loaded: url_helper
INFO - 2016-01-04 19:40:28 --> Database Driver Class Initialized
INFO - 2016-01-04 19:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:40:28 --> Controller Class Initialized
INFO - 2016-01-04 19:40:28 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 19:40:28 --> Final output sent to browser
DEBUG - 2016-01-04 19:40:28 --> Total execution time: 0.0664
INFO - 2016-01-04 19:40:56 --> Config Class Initialized
INFO - 2016-01-04 19:40:56 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:40:56 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:40:56 --> Utf8 Class Initialized
INFO - 2016-01-04 19:40:56 --> URI Class Initialized
INFO - 2016-01-04 19:40:56 --> Router Class Initialized
INFO - 2016-01-04 19:40:56 --> Output Class Initialized
INFO - 2016-01-04 19:40:56 --> Security Class Initialized
DEBUG - 2016-01-04 19:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:40:56 --> Input Class Initialized
INFO - 2016-01-04 19:40:56 --> Language Class Initialized
INFO - 2016-01-04 19:40:56 --> Loader Class Initialized
INFO - 2016-01-04 19:40:56 --> Helper loaded: url_helper
INFO - 2016-01-04 19:40:56 --> Database Driver Class Initialized
INFO - 2016-01-04 19:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:40:56 --> Controller Class Initialized
INFO - 2016-01-04 19:40:56 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 19:40:56 --> Final output sent to browser
DEBUG - 2016-01-04 19:40:56 --> Total execution time: 0.1037
INFO - 2016-01-04 19:40:56 --> Config Class Initialized
INFO - 2016-01-04 19:40:56 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:40:56 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:40:56 --> Utf8 Class Initialized
INFO - 2016-01-04 19:40:56 --> URI Class Initialized
INFO - 2016-01-04 19:40:56 --> Router Class Initialized
INFO - 2016-01-04 19:40:56 --> Output Class Initialized
INFO - 2016-01-04 19:40:56 --> Security Class Initialized
DEBUG - 2016-01-04 19:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:40:56 --> Input Class Initialized
INFO - 2016-01-04 19:40:56 --> Language Class Initialized
INFO - 2016-01-04 19:40:56 --> Loader Class Initialized
INFO - 2016-01-04 19:40:56 --> Helper loaded: url_helper
INFO - 2016-01-04 19:40:56 --> Database Driver Class Initialized
INFO - 2016-01-04 19:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:40:56 --> Controller Class Initialized
DEBUG - 2016-01-04 19:40:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:40:56 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:40:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:40:56 --> Model Class Initialized
INFO - 2016-01-04 19:40:56 --> Model Class Initialized
INFO - 2016-01-04 19:40:56 --> Final output sent to browser
DEBUG - 2016-01-04 19:40:56 --> Total execution time: 0.0743
INFO - 2016-01-04 19:41:57 --> Config Class Initialized
INFO - 2016-01-04 19:41:57 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:41:57 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:41:57 --> Utf8 Class Initialized
INFO - 2016-01-04 19:41:57 --> URI Class Initialized
INFO - 2016-01-04 19:41:57 --> Router Class Initialized
INFO - 2016-01-04 19:41:57 --> Output Class Initialized
INFO - 2016-01-04 19:41:57 --> Security Class Initialized
DEBUG - 2016-01-04 19:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:41:57 --> Input Class Initialized
INFO - 2016-01-04 19:41:57 --> Language Class Initialized
INFO - 2016-01-04 19:41:57 --> Loader Class Initialized
INFO - 2016-01-04 19:41:57 --> Helper loaded: url_helper
INFO - 2016-01-04 19:41:57 --> Database Driver Class Initialized
INFO - 2016-01-04 19:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:41:57 --> Controller Class Initialized
DEBUG - 2016-01-04 19:41:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:41:57 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:41:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:41:57 --> Model Class Initialized
INFO - 2016-01-04 19:41:57 --> Model Class Initialized
INFO - 2016-01-04 19:41:57 --> Final output sent to browser
DEBUG - 2016-01-04 19:41:57 --> Total execution time: 0.1506
INFO - 2016-01-04 19:42:00 --> Config Class Initialized
INFO - 2016-01-04 19:42:00 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:42:00 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:42:00 --> Utf8 Class Initialized
INFO - 2016-01-04 19:42:00 --> URI Class Initialized
INFO - 2016-01-04 19:42:00 --> Router Class Initialized
INFO - 2016-01-04 19:42:00 --> Output Class Initialized
INFO - 2016-01-04 19:42:00 --> Security Class Initialized
DEBUG - 2016-01-04 19:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:42:00 --> Input Class Initialized
INFO - 2016-01-04 19:42:00 --> Language Class Initialized
INFO - 2016-01-04 19:42:00 --> Loader Class Initialized
INFO - 2016-01-04 19:42:00 --> Helper loaded: url_helper
INFO - 2016-01-04 19:42:00 --> Database Driver Class Initialized
INFO - 2016-01-04 19:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:42:00 --> Controller Class Initialized
DEBUG - 2016-01-04 19:42:00 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:42:00 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:42:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:42:00 --> Model Class Initialized
INFO - 2016-01-04 19:42:00 --> Model Class Initialized
INFO - 2016-01-04 19:42:00 --> Final output sent to browser
DEBUG - 2016-01-04 19:42:00 --> Total execution time: 0.0891
INFO - 2016-01-04 19:42:53 --> Config Class Initialized
INFO - 2016-01-04 19:42:53 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:42:53 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:42:53 --> Utf8 Class Initialized
INFO - 2016-01-04 19:42:53 --> URI Class Initialized
DEBUG - 2016-01-04 19:42:53 --> No URI present. Default controller set.
INFO - 2016-01-04 19:42:53 --> Router Class Initialized
INFO - 2016-01-04 19:42:53 --> Output Class Initialized
INFO - 2016-01-04 19:42:53 --> Security Class Initialized
DEBUG - 2016-01-04 19:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:42:53 --> Input Class Initialized
INFO - 2016-01-04 19:42:53 --> Language Class Initialized
INFO - 2016-01-04 19:42:53 --> Loader Class Initialized
INFO - 2016-01-04 19:42:53 --> Helper loaded: url_helper
INFO - 2016-01-04 19:42:53 --> Database Driver Class Initialized
INFO - 2016-01-04 19:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:42:53 --> Controller Class Initialized
INFO - 2016-01-04 19:42:53 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 19:42:53 --> Final output sent to browser
DEBUG - 2016-01-04 19:42:53 --> Total execution time: 0.0725
INFO - 2016-01-04 19:42:54 --> Config Class Initialized
INFO - 2016-01-04 19:42:54 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:42:54 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:42:54 --> Utf8 Class Initialized
INFO - 2016-01-04 19:42:54 --> URI Class Initialized
INFO - 2016-01-04 19:42:54 --> Router Class Initialized
INFO - 2016-01-04 19:42:54 --> Output Class Initialized
INFO - 2016-01-04 19:42:54 --> Security Class Initialized
DEBUG - 2016-01-04 19:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:42:54 --> Input Class Initialized
INFO - 2016-01-04 19:42:54 --> Language Class Initialized
INFO - 2016-01-04 19:42:54 --> Loader Class Initialized
INFO - 2016-01-04 19:42:55 --> Helper loaded: url_helper
INFO - 2016-01-04 19:42:55 --> Database Driver Class Initialized
INFO - 2016-01-04 19:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:42:55 --> Controller Class Initialized
INFO - 2016-01-04 19:42:55 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 19:42:55 --> Final output sent to browser
DEBUG - 2016-01-04 19:42:55 --> Total execution time: 0.0925
INFO - 2016-01-04 19:42:55 --> Config Class Initialized
INFO - 2016-01-04 19:42:55 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:42:55 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:42:55 --> Utf8 Class Initialized
INFO - 2016-01-04 19:42:55 --> URI Class Initialized
INFO - 2016-01-04 19:42:55 --> Router Class Initialized
INFO - 2016-01-04 19:42:55 --> Output Class Initialized
INFO - 2016-01-04 19:42:55 --> Security Class Initialized
DEBUG - 2016-01-04 19:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:42:55 --> Input Class Initialized
INFO - 2016-01-04 19:42:55 --> Language Class Initialized
INFO - 2016-01-04 19:42:55 --> Loader Class Initialized
INFO - 2016-01-04 19:42:55 --> Helper loaded: url_helper
INFO - 2016-01-04 19:42:55 --> Database Driver Class Initialized
INFO - 2016-01-04 19:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:42:55 --> Controller Class Initialized
DEBUG - 2016-01-04 19:42:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:42:55 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:42:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:42:55 --> Model Class Initialized
INFO - 2016-01-04 19:42:55 --> Model Class Initialized
INFO - 2016-01-04 19:42:55 --> Final output sent to browser
DEBUG - 2016-01-04 19:42:55 --> Total execution time: 0.1165
INFO - 2016-01-04 19:43:03 --> Config Class Initialized
INFO - 2016-01-04 19:43:03 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:43:03 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:43:03 --> Utf8 Class Initialized
INFO - 2016-01-04 19:43:03 --> URI Class Initialized
INFO - 2016-01-04 19:43:03 --> Router Class Initialized
INFO - 2016-01-04 19:43:03 --> Output Class Initialized
INFO - 2016-01-04 19:43:03 --> Security Class Initialized
DEBUG - 2016-01-04 19:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:43:03 --> Input Class Initialized
INFO - 2016-01-04 19:43:03 --> Language Class Initialized
INFO - 2016-01-04 19:43:03 --> Loader Class Initialized
INFO - 2016-01-04 19:43:03 --> Helper loaded: url_helper
INFO - 2016-01-04 19:43:03 --> Database Driver Class Initialized
INFO - 2016-01-04 19:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:43:03 --> Controller Class Initialized
DEBUG - 2016-01-04 19:43:03 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:43:03 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:43:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:43:03 --> Model Class Initialized
INFO - 2016-01-04 19:43:03 --> Model Class Initialized
INFO - 2016-01-04 19:43:03 --> Final output sent to browser
DEBUG - 2016-01-04 19:43:03 --> Total execution time: 0.1450
INFO - 2016-01-04 19:43:04 --> Config Class Initialized
INFO - 2016-01-04 19:43:04 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:43:04 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:43:04 --> Utf8 Class Initialized
INFO - 2016-01-04 19:43:04 --> URI Class Initialized
INFO - 2016-01-04 19:43:04 --> Router Class Initialized
INFO - 2016-01-04 19:43:04 --> Output Class Initialized
INFO - 2016-01-04 19:43:04 --> Security Class Initialized
DEBUG - 2016-01-04 19:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:43:04 --> Input Class Initialized
INFO - 2016-01-04 19:43:04 --> Language Class Initialized
INFO - 2016-01-04 19:43:04 --> Loader Class Initialized
INFO - 2016-01-04 19:43:04 --> Helper loaded: url_helper
INFO - 2016-01-04 19:43:04 --> Database Driver Class Initialized
INFO - 2016-01-04 19:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:43:04 --> Controller Class Initialized
DEBUG - 2016-01-04 19:43:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:43:04 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:43:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:43:04 --> Model Class Initialized
INFO - 2016-01-04 19:43:04 --> Model Class Initialized
INFO - 2016-01-04 19:43:04 --> Final output sent to browser
DEBUG - 2016-01-04 19:43:04 --> Total execution time: 0.0856
INFO - 2016-01-04 19:44:05 --> Config Class Initialized
INFO - 2016-01-04 19:44:05 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:44:05 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:44:05 --> Utf8 Class Initialized
INFO - 2016-01-04 19:44:05 --> URI Class Initialized
INFO - 2016-01-04 19:44:05 --> Router Class Initialized
INFO - 2016-01-04 19:44:05 --> Output Class Initialized
INFO - 2016-01-04 19:44:05 --> Security Class Initialized
DEBUG - 2016-01-04 19:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:44:05 --> Input Class Initialized
INFO - 2016-01-04 19:44:05 --> Language Class Initialized
INFO - 2016-01-04 19:44:05 --> Loader Class Initialized
INFO - 2016-01-04 19:44:05 --> Helper loaded: url_helper
INFO - 2016-01-04 19:44:05 --> Database Driver Class Initialized
INFO - 2016-01-04 19:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:44:05 --> Controller Class Initialized
DEBUG - 2016-01-04 19:44:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:44:05 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:44:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:44:05 --> Model Class Initialized
INFO - 2016-01-04 19:44:05 --> Model Class Initialized
INFO - 2016-01-04 19:44:05 --> Final output sent to browser
DEBUG - 2016-01-04 19:44:05 --> Total execution time: 0.1033
INFO - 2016-01-04 19:49:57 --> Config Class Initialized
INFO - 2016-01-04 19:49:57 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:49:57 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:49:57 --> Utf8 Class Initialized
INFO - 2016-01-04 19:49:57 --> URI Class Initialized
INFO - 2016-01-04 19:49:57 --> Router Class Initialized
INFO - 2016-01-04 19:49:57 --> Output Class Initialized
INFO - 2016-01-04 19:49:57 --> Security Class Initialized
DEBUG - 2016-01-04 19:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:49:57 --> Input Class Initialized
INFO - 2016-01-04 19:49:57 --> Language Class Initialized
INFO - 2016-01-04 19:49:57 --> Loader Class Initialized
INFO - 2016-01-04 19:49:57 --> Helper loaded: url_helper
INFO - 2016-01-04 19:49:57 --> Database Driver Class Initialized
INFO - 2016-01-04 19:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:49:57 --> Controller Class Initialized
DEBUG - 2016-01-04 19:49:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:49:57 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:49:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:49:57 --> Model Class Initialized
INFO - 2016-01-04 19:49:57 --> Model Class Initialized
INFO - 2016-01-04 19:49:57 --> Final output sent to browser
DEBUG - 2016-01-04 19:49:57 --> Total execution time: 0.0914
INFO - 2016-01-04 19:50:58 --> Config Class Initialized
INFO - 2016-01-04 19:50:58 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:50:58 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:50:58 --> Utf8 Class Initialized
INFO - 2016-01-04 19:50:58 --> URI Class Initialized
INFO - 2016-01-04 19:50:58 --> Router Class Initialized
INFO - 2016-01-04 19:50:58 --> Output Class Initialized
INFO - 2016-01-04 19:50:58 --> Security Class Initialized
DEBUG - 2016-01-04 19:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:50:58 --> Input Class Initialized
INFO - 2016-01-04 19:50:58 --> Language Class Initialized
INFO - 2016-01-04 19:50:58 --> Loader Class Initialized
INFO - 2016-01-04 19:50:58 --> Helper loaded: url_helper
INFO - 2016-01-04 19:50:58 --> Database Driver Class Initialized
INFO - 2016-01-04 19:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:50:58 --> Controller Class Initialized
DEBUG - 2016-01-04 19:50:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:50:58 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:50:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:50:58 --> Model Class Initialized
INFO - 2016-01-04 19:50:58 --> Model Class Initialized
INFO - 2016-01-04 19:50:58 --> Final output sent to browser
DEBUG - 2016-01-04 19:50:58 --> Total execution time: 0.1858
INFO - 2016-01-04 19:51:27 --> Config Class Initialized
INFO - 2016-01-04 19:51:27 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:51:27 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:51:27 --> Utf8 Class Initialized
INFO - 2016-01-04 19:51:27 --> URI Class Initialized
INFO - 2016-01-04 19:51:27 --> Router Class Initialized
INFO - 2016-01-04 19:51:27 --> Output Class Initialized
INFO - 2016-01-04 19:51:27 --> Security Class Initialized
DEBUG - 2016-01-04 19:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:51:27 --> Input Class Initialized
INFO - 2016-01-04 19:51:27 --> Language Class Initialized
INFO - 2016-01-04 19:51:27 --> Loader Class Initialized
INFO - 2016-01-04 19:51:27 --> Helper loaded: url_helper
INFO - 2016-01-04 19:51:27 --> Database Driver Class Initialized
INFO - 2016-01-04 19:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:51:27 --> Controller Class Initialized
DEBUG - 2016-01-04 19:51:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:51:27 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:51:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:51:27 --> Model Class Initialized
INFO - 2016-01-04 19:51:27 --> Model Class Initialized
INFO - 2016-01-04 19:51:27 --> Final output sent to browser
DEBUG - 2016-01-04 19:51:27 --> Total execution time: 0.0779
INFO - 2016-01-04 19:52:28 --> Config Class Initialized
INFO - 2016-01-04 19:52:28 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:52:28 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:52:28 --> Utf8 Class Initialized
INFO - 2016-01-04 19:52:28 --> URI Class Initialized
INFO - 2016-01-04 19:52:28 --> Router Class Initialized
INFO - 2016-01-04 19:52:28 --> Output Class Initialized
INFO - 2016-01-04 19:52:28 --> Security Class Initialized
DEBUG - 2016-01-04 19:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:52:28 --> Input Class Initialized
INFO - 2016-01-04 19:52:28 --> Language Class Initialized
INFO - 2016-01-04 19:52:28 --> Loader Class Initialized
INFO - 2016-01-04 19:52:28 --> Helper loaded: url_helper
INFO - 2016-01-04 19:52:28 --> Database Driver Class Initialized
INFO - 2016-01-04 19:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:52:28 --> Controller Class Initialized
DEBUG - 2016-01-04 19:52:28 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:52:28 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:52:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:52:28 --> Model Class Initialized
INFO - 2016-01-04 19:52:28 --> Model Class Initialized
INFO - 2016-01-04 19:52:28 --> Final output sent to browser
DEBUG - 2016-01-04 19:52:28 --> Total execution time: 0.0927
INFO - 2016-01-04 19:55:22 --> Config Class Initialized
INFO - 2016-01-04 19:55:22 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:55:22 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:55:22 --> Utf8 Class Initialized
INFO - 2016-01-04 19:55:22 --> URI Class Initialized
INFO - 2016-01-04 19:55:22 --> Router Class Initialized
INFO - 2016-01-04 19:55:22 --> Output Class Initialized
INFO - 2016-01-04 19:55:22 --> Security Class Initialized
DEBUG - 2016-01-04 19:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:55:22 --> Input Class Initialized
INFO - 2016-01-04 19:55:22 --> Language Class Initialized
INFO - 2016-01-04 19:55:22 --> Loader Class Initialized
INFO - 2016-01-04 19:55:22 --> Helper loaded: url_helper
INFO - 2016-01-04 19:55:22 --> Database Driver Class Initialized
INFO - 2016-01-04 19:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:55:22 --> Controller Class Initialized
DEBUG - 2016-01-04 19:55:22 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:55:22 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:55:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:55:22 --> Model Class Initialized
INFO - 2016-01-04 19:55:22 --> Model Class Initialized
INFO - 2016-01-04 19:55:22 --> Final output sent to browser
DEBUG - 2016-01-04 19:55:22 --> Total execution time: 0.1396
INFO - 2016-01-04 19:56:23 --> Config Class Initialized
INFO - 2016-01-04 19:56:23 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:56:23 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:56:23 --> Utf8 Class Initialized
INFO - 2016-01-04 19:56:23 --> URI Class Initialized
INFO - 2016-01-04 19:56:23 --> Router Class Initialized
INFO - 2016-01-04 19:56:23 --> Output Class Initialized
INFO - 2016-01-04 19:56:23 --> Security Class Initialized
DEBUG - 2016-01-04 19:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:56:23 --> Input Class Initialized
INFO - 2016-01-04 19:56:23 --> Language Class Initialized
INFO - 2016-01-04 19:56:23 --> Loader Class Initialized
INFO - 2016-01-04 19:56:23 --> Helper loaded: url_helper
INFO - 2016-01-04 19:56:23 --> Database Driver Class Initialized
INFO - 2016-01-04 19:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:56:23 --> Controller Class Initialized
DEBUG - 2016-01-04 19:56:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:56:23 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:56:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:56:23 --> Model Class Initialized
INFO - 2016-01-04 19:56:23 --> Model Class Initialized
INFO - 2016-01-04 19:56:23 --> Final output sent to browser
DEBUG - 2016-01-04 19:56:23 --> Total execution time: 0.1540
INFO - 2016-01-04 19:56:25 --> Config Class Initialized
INFO - 2016-01-04 19:56:25 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:56:25 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:56:25 --> Utf8 Class Initialized
INFO - 2016-01-04 19:56:25 --> URI Class Initialized
INFO - 2016-01-04 19:56:25 --> Router Class Initialized
INFO - 2016-01-04 19:56:25 --> Output Class Initialized
INFO - 2016-01-04 19:56:25 --> Security Class Initialized
DEBUG - 2016-01-04 19:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:56:25 --> Input Class Initialized
INFO - 2016-01-04 19:56:25 --> Language Class Initialized
INFO - 2016-01-04 19:56:25 --> Loader Class Initialized
INFO - 2016-01-04 19:56:25 --> Helper loaded: url_helper
INFO - 2016-01-04 19:56:25 --> Database Driver Class Initialized
INFO - 2016-01-04 19:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:56:25 --> Controller Class Initialized
DEBUG - 2016-01-04 19:56:25 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:56:25 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:56:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:56:25 --> Model Class Initialized
INFO - 2016-01-04 19:56:25 --> Model Class Initialized
INFO - 2016-01-04 19:56:25 --> Final output sent to browser
DEBUG - 2016-01-04 19:56:25 --> Total execution time: 0.0787
INFO - 2016-01-04 19:57:26 --> Config Class Initialized
INFO - 2016-01-04 19:57:26 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:57:26 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:57:26 --> Utf8 Class Initialized
INFO - 2016-01-04 19:57:26 --> URI Class Initialized
INFO - 2016-01-04 19:57:26 --> Router Class Initialized
INFO - 2016-01-04 19:57:26 --> Output Class Initialized
INFO - 2016-01-04 19:57:26 --> Security Class Initialized
DEBUG - 2016-01-04 19:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:57:26 --> Input Class Initialized
INFO - 2016-01-04 19:57:26 --> Language Class Initialized
INFO - 2016-01-04 19:57:26 --> Loader Class Initialized
INFO - 2016-01-04 19:57:26 --> Helper loaded: url_helper
INFO - 2016-01-04 19:57:26 --> Database Driver Class Initialized
INFO - 2016-01-04 19:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:57:26 --> Controller Class Initialized
DEBUG - 2016-01-04 19:57:26 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:57:26 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:57:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:57:26 --> Model Class Initialized
INFO - 2016-01-04 19:57:26 --> Model Class Initialized
INFO - 2016-01-04 19:57:26 --> Final output sent to browser
DEBUG - 2016-01-04 19:57:26 --> Total execution time: 0.1017
INFO - 2016-01-04 19:57:28 --> Config Class Initialized
INFO - 2016-01-04 19:57:28 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:57:28 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:57:28 --> Utf8 Class Initialized
INFO - 2016-01-04 19:57:28 --> URI Class Initialized
INFO - 2016-01-04 19:57:28 --> Router Class Initialized
INFO - 2016-01-04 19:57:28 --> Output Class Initialized
INFO - 2016-01-04 19:57:28 --> Security Class Initialized
DEBUG - 2016-01-04 19:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:57:28 --> Input Class Initialized
INFO - 2016-01-04 19:57:28 --> Language Class Initialized
INFO - 2016-01-04 19:57:28 --> Loader Class Initialized
INFO - 2016-01-04 19:57:28 --> Helper loaded: url_helper
INFO - 2016-01-04 19:57:28 --> Database Driver Class Initialized
INFO - 2016-01-04 19:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:57:28 --> Controller Class Initialized
DEBUG - 2016-01-04 19:57:28 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:57:28 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:57:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:57:28 --> Model Class Initialized
INFO - 2016-01-04 19:57:28 --> Model Class Initialized
INFO - 2016-01-04 19:57:28 --> Final output sent to browser
DEBUG - 2016-01-04 19:57:28 --> Total execution time: 0.1253
INFO - 2016-01-04 19:58:29 --> Config Class Initialized
INFO - 2016-01-04 19:58:29 --> Hooks Class Initialized
DEBUG - 2016-01-04 19:58:29 --> UTF-8 Support Enabled
INFO - 2016-01-04 19:58:29 --> Utf8 Class Initialized
INFO - 2016-01-04 19:58:29 --> URI Class Initialized
INFO - 2016-01-04 19:58:29 --> Router Class Initialized
INFO - 2016-01-04 19:58:29 --> Output Class Initialized
INFO - 2016-01-04 19:58:29 --> Security Class Initialized
DEBUG - 2016-01-04 19:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 19:58:29 --> Input Class Initialized
INFO - 2016-01-04 19:58:29 --> Language Class Initialized
INFO - 2016-01-04 19:58:29 --> Loader Class Initialized
INFO - 2016-01-04 19:58:29 --> Helper loaded: url_helper
INFO - 2016-01-04 19:58:29 --> Database Driver Class Initialized
INFO - 2016-01-04 19:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 19:58:29 --> Controller Class Initialized
DEBUG - 2016-01-04 19:58:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 19:58:29 --> Helper loaded: inflector_helper
INFO - 2016-01-04 19:58:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 19:58:29 --> Model Class Initialized
INFO - 2016-01-04 19:58:29 --> Model Class Initialized
INFO - 2016-01-04 19:58:29 --> Final output sent to browser
DEBUG - 2016-01-04 19:58:29 --> Total execution time: 0.1575
INFO - 2016-01-04 20:05:11 --> Config Class Initialized
INFO - 2016-01-04 20:05:11 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:05:11 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:05:11 --> Utf8 Class Initialized
INFO - 2016-01-04 20:05:11 --> URI Class Initialized
DEBUG - 2016-01-04 20:05:11 --> No URI present. Default controller set.
INFO - 2016-01-04 20:05:11 --> Router Class Initialized
INFO - 2016-01-04 20:05:11 --> Output Class Initialized
INFO - 2016-01-04 20:05:11 --> Security Class Initialized
DEBUG - 2016-01-04 20:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:05:11 --> Input Class Initialized
INFO - 2016-01-04 20:05:11 --> Language Class Initialized
INFO - 2016-01-04 20:05:11 --> Loader Class Initialized
INFO - 2016-01-04 20:05:11 --> Helper loaded: url_helper
INFO - 2016-01-04 20:05:11 --> Database Driver Class Initialized
INFO - 2016-01-04 20:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:05:12 --> Controller Class Initialized
INFO - 2016-01-04 20:05:12 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 20:05:12 --> Final output sent to browser
DEBUG - 2016-01-04 20:05:12 --> Total execution time: 0.0872
INFO - 2016-01-04 20:05:16 --> Config Class Initialized
INFO - 2016-01-04 20:05:16 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:05:16 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:05:16 --> Utf8 Class Initialized
INFO - 2016-01-04 20:05:16 --> URI Class Initialized
INFO - 2016-01-04 20:05:16 --> Router Class Initialized
INFO - 2016-01-04 20:05:16 --> Output Class Initialized
INFO - 2016-01-04 20:05:16 --> Security Class Initialized
DEBUG - 2016-01-04 20:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:05:16 --> Input Class Initialized
INFO - 2016-01-04 20:05:16 --> Language Class Initialized
INFO - 2016-01-04 20:05:16 --> Loader Class Initialized
INFO - 2016-01-04 20:05:16 --> Helper loaded: url_helper
INFO - 2016-01-04 20:05:16 --> Database Driver Class Initialized
INFO - 2016-01-04 20:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:05:16 --> Controller Class Initialized
INFO - 2016-01-04 20:05:16 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 20:05:16 --> Final output sent to browser
DEBUG - 2016-01-04 20:05:16 --> Total execution time: 0.0573
INFO - 2016-01-04 20:05:16 --> Config Class Initialized
INFO - 2016-01-04 20:05:16 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:05:16 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:05:16 --> Utf8 Class Initialized
INFO - 2016-01-04 20:05:16 --> URI Class Initialized
INFO - 2016-01-04 20:05:16 --> Router Class Initialized
INFO - 2016-01-04 20:05:16 --> Output Class Initialized
INFO - 2016-01-04 20:05:16 --> Security Class Initialized
DEBUG - 2016-01-04 20:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:05:16 --> Input Class Initialized
INFO - 2016-01-04 20:05:16 --> Language Class Initialized
INFO - 2016-01-04 20:05:16 --> Loader Class Initialized
INFO - 2016-01-04 20:05:16 --> Helper loaded: url_helper
INFO - 2016-01-04 20:05:16 --> Database Driver Class Initialized
INFO - 2016-01-04 20:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:05:16 --> Controller Class Initialized
DEBUG - 2016-01-04 20:05:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:05:16 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:05:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:05:16 --> Model Class Initialized
INFO - 2016-01-04 20:05:16 --> Model Class Initialized
INFO - 2016-01-04 20:05:16 --> Final output sent to browser
DEBUG - 2016-01-04 20:05:16 --> Total execution time: 0.0851
INFO - 2016-01-04 20:05:20 --> Config Class Initialized
INFO - 2016-01-04 20:05:20 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:05:20 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:05:20 --> Utf8 Class Initialized
INFO - 2016-01-04 20:05:20 --> URI Class Initialized
INFO - 2016-01-04 20:05:20 --> Router Class Initialized
INFO - 2016-01-04 20:05:20 --> Output Class Initialized
INFO - 2016-01-04 20:05:20 --> Security Class Initialized
DEBUG - 2016-01-04 20:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:05:20 --> Input Class Initialized
INFO - 2016-01-04 20:05:20 --> Language Class Initialized
INFO - 2016-01-04 20:05:20 --> Loader Class Initialized
INFO - 2016-01-04 20:05:20 --> Helper loaded: url_helper
INFO - 2016-01-04 20:05:20 --> Database Driver Class Initialized
INFO - 2016-01-04 20:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:05:20 --> Controller Class Initialized
DEBUG - 2016-01-04 20:05:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:05:20 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:05:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:05:20 --> Model Class Initialized
INFO - 2016-01-04 20:05:20 --> Model Class Initialized
INFO - 2016-01-04 20:05:20 --> Final output sent to browser
DEBUG - 2016-01-04 20:05:20 --> Total execution time: 0.0701
INFO - 2016-01-04 20:05:21 --> Config Class Initialized
INFO - 2016-01-04 20:05:21 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:05:21 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:05:21 --> Utf8 Class Initialized
INFO - 2016-01-04 20:05:21 --> URI Class Initialized
INFO - 2016-01-04 20:05:21 --> Router Class Initialized
INFO - 2016-01-04 20:05:21 --> Output Class Initialized
INFO - 2016-01-04 20:05:21 --> Security Class Initialized
DEBUG - 2016-01-04 20:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:05:21 --> Input Class Initialized
INFO - 2016-01-04 20:05:21 --> Language Class Initialized
INFO - 2016-01-04 20:05:21 --> Loader Class Initialized
INFO - 2016-01-04 20:05:21 --> Helper loaded: url_helper
INFO - 2016-01-04 20:05:21 --> Database Driver Class Initialized
INFO - 2016-01-04 20:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:05:21 --> Controller Class Initialized
DEBUG - 2016-01-04 20:05:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:05:21 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:05:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:05:21 --> Model Class Initialized
INFO - 2016-01-04 20:05:21 --> Model Class Initialized
INFO - 2016-01-04 20:05:21 --> Final output sent to browser
DEBUG - 2016-01-04 20:05:21 --> Total execution time: 0.0908
INFO - 2016-01-04 20:21:57 --> Config Class Initialized
INFO - 2016-01-04 20:21:57 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:21:57 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:21:57 --> Utf8 Class Initialized
INFO - 2016-01-04 20:21:57 --> URI Class Initialized
DEBUG - 2016-01-04 20:21:57 --> No URI present. Default controller set.
INFO - 2016-01-04 20:21:57 --> Router Class Initialized
INFO - 2016-01-04 20:21:57 --> Output Class Initialized
INFO - 2016-01-04 20:21:57 --> Security Class Initialized
DEBUG - 2016-01-04 20:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:21:57 --> Input Class Initialized
INFO - 2016-01-04 20:21:57 --> Language Class Initialized
INFO - 2016-01-04 20:21:57 --> Loader Class Initialized
INFO - 2016-01-04 20:21:57 --> Helper loaded: url_helper
INFO - 2016-01-04 20:21:57 --> Database Driver Class Initialized
INFO - 2016-01-04 20:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:21:57 --> Controller Class Initialized
INFO - 2016-01-04 20:21:57 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 20:21:57 --> Final output sent to browser
DEBUG - 2016-01-04 20:21:57 --> Total execution time: 0.0825
INFO - 2016-01-04 20:21:58 --> Config Class Initialized
INFO - 2016-01-04 20:21:58 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:21:58 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:21:58 --> Utf8 Class Initialized
INFO - 2016-01-04 20:21:58 --> URI Class Initialized
INFO - 2016-01-04 20:21:58 --> Router Class Initialized
INFO - 2016-01-04 20:21:58 --> Output Class Initialized
INFO - 2016-01-04 20:21:58 --> Security Class Initialized
DEBUG - 2016-01-04 20:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:21:58 --> Input Class Initialized
INFO - 2016-01-04 20:21:58 --> Language Class Initialized
INFO - 2016-01-04 20:21:58 --> Loader Class Initialized
INFO - 2016-01-04 20:21:58 --> Helper loaded: url_helper
INFO - 2016-01-04 20:21:58 --> Database Driver Class Initialized
INFO - 2016-01-04 20:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:21:58 --> Controller Class Initialized
INFO - 2016-01-04 20:21:58 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 20:21:58 --> Final output sent to browser
DEBUG - 2016-01-04 20:21:58 --> Total execution time: 0.0650
INFO - 2016-01-04 20:21:58 --> Config Class Initialized
INFO - 2016-01-04 20:21:58 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:21:58 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:21:58 --> Utf8 Class Initialized
INFO - 2016-01-04 20:21:58 --> URI Class Initialized
INFO - 2016-01-04 20:21:58 --> Router Class Initialized
INFO - 2016-01-04 20:21:58 --> Output Class Initialized
INFO - 2016-01-04 20:21:58 --> Security Class Initialized
DEBUG - 2016-01-04 20:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:21:58 --> Input Class Initialized
INFO - 2016-01-04 20:21:58 --> Language Class Initialized
INFO - 2016-01-04 20:21:58 --> Loader Class Initialized
INFO - 2016-01-04 20:21:58 --> Helper loaded: url_helper
INFO - 2016-01-04 20:21:58 --> Database Driver Class Initialized
INFO - 2016-01-04 20:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:21:59 --> Controller Class Initialized
DEBUG - 2016-01-04 20:21:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:21:59 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:21:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:21:59 --> Model Class Initialized
INFO - 2016-01-04 20:21:59 --> Model Class Initialized
INFO - 2016-01-04 20:21:59 --> Final output sent to browser
DEBUG - 2016-01-04 20:21:59 --> Total execution time: 0.0721
INFO - 2016-01-04 20:22:03 --> Config Class Initialized
INFO - 2016-01-04 20:22:03 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:22:03 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:22:03 --> Utf8 Class Initialized
INFO - 2016-01-04 20:22:03 --> URI Class Initialized
DEBUG - 2016-01-04 20:22:03 --> No URI present. Default controller set.
INFO - 2016-01-04 20:22:03 --> Router Class Initialized
INFO - 2016-01-04 20:22:03 --> Output Class Initialized
INFO - 2016-01-04 20:22:03 --> Security Class Initialized
DEBUG - 2016-01-04 20:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:22:03 --> Input Class Initialized
INFO - 2016-01-04 20:22:03 --> Language Class Initialized
INFO - 2016-01-04 20:22:03 --> Loader Class Initialized
INFO - 2016-01-04 20:22:03 --> Helper loaded: url_helper
INFO - 2016-01-04 20:22:03 --> Database Driver Class Initialized
INFO - 2016-01-04 20:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:22:03 --> Controller Class Initialized
INFO - 2016-01-04 20:22:03 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 20:22:03 --> Final output sent to browser
DEBUG - 2016-01-04 20:22:03 --> Total execution time: 0.0857
INFO - 2016-01-04 20:22:04 --> Config Class Initialized
INFO - 2016-01-04 20:22:04 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:22:04 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:22:04 --> Utf8 Class Initialized
INFO - 2016-01-04 20:22:04 --> URI Class Initialized
DEBUG - 2016-01-04 20:22:04 --> No URI present. Default controller set.
INFO - 2016-01-04 20:22:04 --> Router Class Initialized
INFO - 2016-01-04 20:22:04 --> Output Class Initialized
INFO - 2016-01-04 20:22:04 --> Security Class Initialized
DEBUG - 2016-01-04 20:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:22:04 --> Input Class Initialized
INFO - 2016-01-04 20:22:04 --> Language Class Initialized
INFO - 2016-01-04 20:22:04 --> Loader Class Initialized
INFO - 2016-01-04 20:22:04 --> Helper loaded: url_helper
INFO - 2016-01-04 20:22:04 --> Database Driver Class Initialized
INFO - 2016-01-04 20:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:22:04 --> Controller Class Initialized
INFO - 2016-01-04 20:22:04 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 20:22:04 --> Final output sent to browser
DEBUG - 2016-01-04 20:22:04 --> Total execution time: 0.0976
INFO - 2016-01-04 20:22:08 --> Config Class Initialized
INFO - 2016-01-04 20:22:08 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:22:08 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:22:08 --> Utf8 Class Initialized
INFO - 2016-01-04 20:22:08 --> URI Class Initialized
INFO - 2016-01-04 20:22:08 --> Router Class Initialized
INFO - 2016-01-04 20:22:08 --> Output Class Initialized
INFO - 2016-01-04 20:22:08 --> Security Class Initialized
DEBUG - 2016-01-04 20:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:22:08 --> Input Class Initialized
INFO - 2016-01-04 20:22:08 --> Language Class Initialized
INFO - 2016-01-04 20:22:08 --> Loader Class Initialized
INFO - 2016-01-04 20:22:08 --> Helper loaded: url_helper
INFO - 2016-01-04 20:22:08 --> Database Driver Class Initialized
INFO - 2016-01-04 20:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:22:08 --> Controller Class Initialized
INFO - 2016-01-04 20:22:08 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 20:22:08 --> Final output sent to browser
DEBUG - 2016-01-04 20:22:08 --> Total execution time: 0.0528
INFO - 2016-01-04 20:22:08 --> Config Class Initialized
INFO - 2016-01-04 20:22:08 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:22:09 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:22:09 --> Utf8 Class Initialized
INFO - 2016-01-04 20:22:09 --> URI Class Initialized
INFO - 2016-01-04 20:22:09 --> Router Class Initialized
INFO - 2016-01-04 20:22:09 --> Output Class Initialized
INFO - 2016-01-04 20:22:09 --> Security Class Initialized
DEBUG - 2016-01-04 20:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:22:09 --> Input Class Initialized
INFO - 2016-01-04 20:22:09 --> Language Class Initialized
INFO - 2016-01-04 20:22:09 --> Loader Class Initialized
INFO - 2016-01-04 20:22:09 --> Helper loaded: url_helper
INFO - 2016-01-04 20:22:09 --> Database Driver Class Initialized
INFO - 2016-01-04 20:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:22:09 --> Controller Class Initialized
DEBUG - 2016-01-04 20:22:09 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:22:09 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:22:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:22:09 --> Model Class Initialized
INFO - 2016-01-04 20:22:09 --> Model Class Initialized
INFO - 2016-01-04 20:22:09 --> Final output sent to browser
DEBUG - 2016-01-04 20:22:09 --> Total execution time: 0.1102
INFO - 2016-01-04 20:22:13 --> Config Class Initialized
INFO - 2016-01-04 20:22:13 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:22:13 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:22:13 --> Utf8 Class Initialized
INFO - 2016-01-04 20:22:13 --> URI Class Initialized
INFO - 2016-01-04 20:22:13 --> Router Class Initialized
INFO - 2016-01-04 20:22:13 --> Output Class Initialized
INFO - 2016-01-04 20:22:13 --> Security Class Initialized
DEBUG - 2016-01-04 20:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:22:13 --> Input Class Initialized
INFO - 2016-01-04 20:22:13 --> Language Class Initialized
INFO - 2016-01-04 20:22:13 --> Loader Class Initialized
INFO - 2016-01-04 20:22:13 --> Helper loaded: url_helper
INFO - 2016-01-04 20:22:13 --> Database Driver Class Initialized
INFO - 2016-01-04 20:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:22:13 --> Controller Class Initialized
DEBUG - 2016-01-04 20:22:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:22:13 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:22:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:22:13 --> Model Class Initialized
INFO - 2016-01-04 20:22:13 --> Model Class Initialized
INFO - 2016-01-04 20:22:13 --> Final output sent to browser
DEBUG - 2016-01-04 20:22:13 --> Total execution time: 0.0672
INFO - 2016-01-04 20:22:14 --> Config Class Initialized
INFO - 2016-01-04 20:22:14 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:22:14 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:22:14 --> Utf8 Class Initialized
INFO - 2016-01-04 20:22:14 --> URI Class Initialized
INFO - 2016-01-04 20:22:14 --> Router Class Initialized
INFO - 2016-01-04 20:22:14 --> Output Class Initialized
INFO - 2016-01-04 20:22:14 --> Security Class Initialized
DEBUG - 2016-01-04 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:22:14 --> Input Class Initialized
INFO - 2016-01-04 20:22:14 --> Language Class Initialized
INFO - 2016-01-04 20:22:14 --> Loader Class Initialized
INFO - 2016-01-04 20:22:14 --> Helper loaded: url_helper
INFO - 2016-01-04 20:22:14 --> Database Driver Class Initialized
INFO - 2016-01-04 20:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:22:14 --> Controller Class Initialized
DEBUG - 2016-01-04 20:22:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:22:14 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:22:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:22:14 --> Model Class Initialized
INFO - 2016-01-04 20:22:14 --> Model Class Initialized
INFO - 2016-01-04 20:22:14 --> Final output sent to browser
DEBUG - 2016-01-04 20:22:14 --> Total execution time: 0.0813
INFO - 2016-01-04 20:22:17 --> Config Class Initialized
INFO - 2016-01-04 20:22:17 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:22:17 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:22:17 --> Utf8 Class Initialized
INFO - 2016-01-04 20:22:17 --> URI Class Initialized
INFO - 2016-01-04 20:22:17 --> Router Class Initialized
INFO - 2016-01-04 20:22:17 --> Output Class Initialized
INFO - 2016-01-04 20:22:17 --> Security Class Initialized
DEBUG - 2016-01-04 20:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:22:17 --> Input Class Initialized
INFO - 2016-01-04 20:22:17 --> Language Class Initialized
INFO - 2016-01-04 20:22:17 --> Loader Class Initialized
INFO - 2016-01-04 20:22:17 --> Helper loaded: url_helper
INFO - 2016-01-04 20:22:17 --> Database Driver Class Initialized
INFO - 2016-01-04 20:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:22:17 --> Controller Class Initialized
DEBUG - 2016-01-04 20:22:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:22:17 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:22:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:22:17 --> Model Class Initialized
INFO - 2016-01-04 20:22:17 --> Model Class Initialized
INFO - 2016-01-04 20:22:17 --> Final output sent to browser
DEBUG - 2016-01-04 20:22:17 --> Total execution time: 0.0706
INFO - 2016-01-04 20:22:18 --> Config Class Initialized
INFO - 2016-01-04 20:22:18 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:22:18 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:22:18 --> Utf8 Class Initialized
INFO - 2016-01-04 20:22:18 --> URI Class Initialized
INFO - 2016-01-04 20:22:18 --> Router Class Initialized
INFO - 2016-01-04 20:22:18 --> Output Class Initialized
INFO - 2016-01-04 20:22:18 --> Security Class Initialized
DEBUG - 2016-01-04 20:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:22:18 --> Input Class Initialized
INFO - 2016-01-04 20:22:18 --> Language Class Initialized
INFO - 2016-01-04 20:22:18 --> Loader Class Initialized
INFO - 2016-01-04 20:22:18 --> Helper loaded: url_helper
INFO - 2016-01-04 20:22:18 --> Database Driver Class Initialized
INFO - 2016-01-04 20:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:22:19 --> Controller Class Initialized
DEBUG - 2016-01-04 20:22:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:22:19 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:22:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:22:19 --> Model Class Initialized
INFO - 2016-01-04 20:22:19 --> Model Class Initialized
INFO - 2016-01-04 20:22:19 --> Final output sent to browser
DEBUG - 2016-01-04 20:22:19 --> Total execution time: 0.0708
INFO - 2016-01-04 20:23:19 --> Config Class Initialized
INFO - 2016-01-04 20:23:19 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:23:19 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:23:19 --> Utf8 Class Initialized
INFO - 2016-01-04 20:23:19 --> URI Class Initialized
INFO - 2016-01-04 20:23:19 --> Router Class Initialized
INFO - 2016-01-04 20:23:20 --> Output Class Initialized
INFO - 2016-01-04 20:23:20 --> Security Class Initialized
DEBUG - 2016-01-04 20:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:23:20 --> Input Class Initialized
INFO - 2016-01-04 20:23:20 --> Language Class Initialized
INFO - 2016-01-04 20:23:20 --> Loader Class Initialized
INFO - 2016-01-04 20:23:20 --> Helper loaded: url_helper
INFO - 2016-01-04 20:23:20 --> Database Driver Class Initialized
INFO - 2016-01-04 20:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:23:20 --> Controller Class Initialized
DEBUG - 2016-01-04 20:23:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:23:20 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:23:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:23:20 --> Model Class Initialized
INFO - 2016-01-04 20:23:20 --> Model Class Initialized
INFO - 2016-01-04 20:23:20 --> Final output sent to browser
DEBUG - 2016-01-04 20:23:20 --> Total execution time: 0.1321
INFO - 2016-01-04 20:29:15 --> Config Class Initialized
INFO - 2016-01-04 20:29:15 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:15 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:15 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:15 --> URI Class Initialized
INFO - 2016-01-04 20:29:15 --> Router Class Initialized
INFO - 2016-01-04 20:29:15 --> Output Class Initialized
INFO - 2016-01-04 20:29:15 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:15 --> Input Class Initialized
INFO - 2016-01-04 20:29:15 --> Language Class Initialized
INFO - 2016-01-04 20:29:15 --> Loader Class Initialized
INFO - 2016-01-04 20:29:15 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:15 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:15 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:15 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:15 --> Model Class Initialized
INFO - 2016-01-04 20:29:15 --> Model Class Initialized
INFO - 2016-01-04 20:29:15 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:15 --> Total execution time: 0.1201
INFO - 2016-01-04 20:29:21 --> Config Class Initialized
INFO - 2016-01-04 20:29:21 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:21 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:21 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:21 --> URI Class Initialized
INFO - 2016-01-04 20:29:21 --> Router Class Initialized
INFO - 2016-01-04 20:29:21 --> Output Class Initialized
INFO - 2016-01-04 20:29:21 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:21 --> Input Class Initialized
INFO - 2016-01-04 20:29:21 --> Language Class Initialized
INFO - 2016-01-04 20:29:21 --> Loader Class Initialized
INFO - 2016-01-04 20:29:21 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:21 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:21 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:21 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:21 --> Model Class Initialized
INFO - 2016-01-04 20:29:21 --> Model Class Initialized
INFO - 2016-01-04 20:29:21 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:21 --> Total execution time: 0.1091
INFO - 2016-01-04 20:29:23 --> Config Class Initialized
INFO - 2016-01-04 20:29:23 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:23 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:23 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:23 --> URI Class Initialized
INFO - 2016-01-04 20:29:23 --> Router Class Initialized
INFO - 2016-01-04 20:29:23 --> Output Class Initialized
INFO - 2016-01-04 20:29:23 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:23 --> Input Class Initialized
INFO - 2016-01-04 20:29:23 --> Language Class Initialized
INFO - 2016-01-04 20:29:23 --> Loader Class Initialized
INFO - 2016-01-04 20:29:23 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:23 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:23 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:23 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:23 --> Model Class Initialized
INFO - 2016-01-04 20:29:23 --> Model Class Initialized
INFO - 2016-01-04 20:29:23 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:23 --> Total execution time: 0.0836
INFO - 2016-01-04 20:29:26 --> Config Class Initialized
INFO - 2016-01-04 20:29:26 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:26 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:26 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:26 --> URI Class Initialized
INFO - 2016-01-04 20:29:26 --> Router Class Initialized
INFO - 2016-01-04 20:29:26 --> Output Class Initialized
INFO - 2016-01-04 20:29:26 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:26 --> Input Class Initialized
INFO - 2016-01-04 20:29:26 --> Language Class Initialized
INFO - 2016-01-04 20:29:26 --> Loader Class Initialized
INFO - 2016-01-04 20:29:26 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:26 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:26 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:26 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:26 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:26 --> Model Class Initialized
INFO - 2016-01-04 20:29:26 --> Model Class Initialized
INFO - 2016-01-04 20:29:26 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:26 --> Total execution time: 0.0679
INFO - 2016-01-04 20:29:26 --> Config Class Initialized
INFO - 2016-01-04 20:29:26 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:26 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:26 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:26 --> URI Class Initialized
INFO - 2016-01-04 20:29:26 --> Router Class Initialized
INFO - 2016-01-04 20:29:26 --> Output Class Initialized
INFO - 2016-01-04 20:29:26 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:26 --> Input Class Initialized
INFO - 2016-01-04 20:29:26 --> Language Class Initialized
INFO - 2016-01-04 20:29:26 --> Loader Class Initialized
INFO - 2016-01-04 20:29:27 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:27 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:27 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:27 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:27 --> Model Class Initialized
INFO - 2016-01-04 20:29:27 --> Model Class Initialized
INFO - 2016-01-04 20:29:27 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:27 --> Total execution time: 0.0781
INFO - 2016-01-04 20:29:30 --> Config Class Initialized
INFO - 2016-01-04 20:29:30 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:30 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:30 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:30 --> URI Class Initialized
INFO - 2016-01-04 20:29:30 --> Router Class Initialized
INFO - 2016-01-04 20:29:30 --> Output Class Initialized
INFO - 2016-01-04 20:29:30 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:30 --> Input Class Initialized
INFO - 2016-01-04 20:29:30 --> Language Class Initialized
INFO - 2016-01-04 20:29:30 --> Loader Class Initialized
INFO - 2016-01-04 20:29:30 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:30 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:30 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:30 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:30 --> Model Class Initialized
INFO - 2016-01-04 20:29:30 --> Model Class Initialized
INFO - 2016-01-04 20:29:30 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:30 --> Total execution time: 0.1217
INFO - 2016-01-04 20:29:30 --> Config Class Initialized
INFO - 2016-01-04 20:29:30 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:30 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:30 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:30 --> URI Class Initialized
INFO - 2016-01-04 20:29:30 --> Router Class Initialized
INFO - 2016-01-04 20:29:30 --> Output Class Initialized
INFO - 2016-01-04 20:29:30 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:30 --> Input Class Initialized
INFO - 2016-01-04 20:29:30 --> Language Class Initialized
INFO - 2016-01-04 20:29:30 --> Loader Class Initialized
INFO - 2016-01-04 20:29:30 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:30 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:30 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:30 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:30 --> Model Class Initialized
INFO - 2016-01-04 20:29:30 --> Model Class Initialized
INFO - 2016-01-04 20:29:30 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:30 --> Total execution time: 0.1120
INFO - 2016-01-04 20:29:32 --> Config Class Initialized
INFO - 2016-01-04 20:29:32 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:32 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:32 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:32 --> URI Class Initialized
INFO - 2016-01-04 20:29:32 --> Router Class Initialized
INFO - 2016-01-04 20:29:32 --> Output Class Initialized
INFO - 2016-01-04 20:29:32 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:32 --> Input Class Initialized
INFO - 2016-01-04 20:29:32 --> Language Class Initialized
INFO - 2016-01-04 20:29:32 --> Loader Class Initialized
INFO - 2016-01-04 20:29:32 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:32 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:32 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:32 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:32 --> Model Class Initialized
INFO - 2016-01-04 20:29:32 --> Model Class Initialized
INFO - 2016-01-04 20:29:32 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:32 --> Total execution time: 0.1212
INFO - 2016-01-04 20:29:32 --> Config Class Initialized
INFO - 2016-01-04 20:29:32 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:32 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:32 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:32 --> URI Class Initialized
INFO - 2016-01-04 20:29:32 --> Router Class Initialized
INFO - 2016-01-04 20:29:32 --> Output Class Initialized
INFO - 2016-01-04 20:29:32 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:32 --> Input Class Initialized
INFO - 2016-01-04 20:29:32 --> Language Class Initialized
INFO - 2016-01-04 20:29:32 --> Loader Class Initialized
INFO - 2016-01-04 20:29:32 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:32 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:32 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:32 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:32 --> Model Class Initialized
INFO - 2016-01-04 20:29:32 --> Model Class Initialized
INFO - 2016-01-04 20:29:32 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:32 --> Total execution time: 0.1187
INFO - 2016-01-04 20:29:53 --> Config Class Initialized
INFO - 2016-01-04 20:29:53 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:53 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:53 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:53 --> URI Class Initialized
INFO - 2016-01-04 20:29:53 --> Router Class Initialized
INFO - 2016-01-04 20:29:54 --> Output Class Initialized
INFO - 2016-01-04 20:29:54 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:54 --> Input Class Initialized
INFO - 2016-01-04 20:29:54 --> Language Class Initialized
INFO - 2016-01-04 20:29:54 --> Loader Class Initialized
INFO - 2016-01-04 20:29:54 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:54 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:54 --> Controller Class Initialized
INFO - 2016-01-04 20:29:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 20:29:54 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:54 --> Total execution time: 0.1046
INFO - 2016-01-04 20:29:54 --> Config Class Initialized
INFO - 2016-01-04 20:29:54 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:54 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:54 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:54 --> URI Class Initialized
INFO - 2016-01-04 20:29:54 --> Router Class Initialized
INFO - 2016-01-04 20:29:54 --> Output Class Initialized
INFO - 2016-01-04 20:29:54 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:54 --> Input Class Initialized
INFO - 2016-01-04 20:29:54 --> Language Class Initialized
INFO - 2016-01-04 20:29:54 --> Loader Class Initialized
INFO - 2016-01-04 20:29:54 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:54 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:54 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:54 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:54 --> Model Class Initialized
INFO - 2016-01-04 20:29:54 --> Model Class Initialized
INFO - 2016-01-04 20:29:54 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:54 --> Total execution time: 0.1307
INFO - 2016-01-04 20:29:58 --> Config Class Initialized
INFO - 2016-01-04 20:29:58 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:58 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:58 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:58 --> URI Class Initialized
INFO - 2016-01-04 20:29:58 --> Router Class Initialized
INFO - 2016-01-04 20:29:58 --> Output Class Initialized
INFO - 2016-01-04 20:29:58 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:58 --> Input Class Initialized
INFO - 2016-01-04 20:29:58 --> Language Class Initialized
INFO - 2016-01-04 20:29:58 --> Loader Class Initialized
INFO - 2016-01-04 20:29:58 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:58 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:58 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:58 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:58 --> Model Class Initialized
INFO - 2016-01-04 20:29:58 --> Model Class Initialized
INFO - 2016-01-04 20:29:58 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:58 --> Total execution time: 0.0688
INFO - 2016-01-04 20:29:59 --> Config Class Initialized
INFO - 2016-01-04 20:29:59 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:29:59 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:29:59 --> Utf8 Class Initialized
INFO - 2016-01-04 20:29:59 --> URI Class Initialized
INFO - 2016-01-04 20:29:59 --> Router Class Initialized
INFO - 2016-01-04 20:29:59 --> Output Class Initialized
INFO - 2016-01-04 20:29:59 --> Security Class Initialized
DEBUG - 2016-01-04 20:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:29:59 --> Input Class Initialized
INFO - 2016-01-04 20:29:59 --> Language Class Initialized
INFO - 2016-01-04 20:29:59 --> Loader Class Initialized
INFO - 2016-01-04 20:29:59 --> Helper loaded: url_helper
INFO - 2016-01-04 20:29:59 --> Database Driver Class Initialized
INFO - 2016-01-04 20:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:29:59 --> Controller Class Initialized
DEBUG - 2016-01-04 20:29:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:29:59 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:29:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:29:59 --> Model Class Initialized
INFO - 2016-01-04 20:29:59 --> Model Class Initialized
INFO - 2016-01-04 20:29:59 --> Final output sent to browser
DEBUG - 2016-01-04 20:29:59 --> Total execution time: 0.0912
INFO - 2016-01-04 20:30:02 --> Config Class Initialized
INFO - 2016-01-04 20:30:02 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:30:02 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:30:02 --> Utf8 Class Initialized
INFO - 2016-01-04 20:30:02 --> URI Class Initialized
INFO - 2016-01-04 20:30:02 --> Router Class Initialized
INFO - 2016-01-04 20:30:02 --> Output Class Initialized
INFO - 2016-01-04 20:30:02 --> Security Class Initialized
DEBUG - 2016-01-04 20:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:30:02 --> Input Class Initialized
INFO - 2016-01-04 20:30:02 --> Language Class Initialized
INFO - 2016-01-04 20:30:02 --> Loader Class Initialized
INFO - 2016-01-04 20:30:02 --> Helper loaded: url_helper
INFO - 2016-01-04 20:30:02 --> Database Driver Class Initialized
INFO - 2016-01-04 20:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:30:02 --> Controller Class Initialized
DEBUG - 2016-01-04 20:30:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:30:02 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:30:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:30:02 --> Model Class Initialized
INFO - 2016-01-04 20:30:02 --> Model Class Initialized
INFO - 2016-01-04 20:30:02 --> Final output sent to browser
DEBUG - 2016-01-04 20:30:02 --> Total execution time: 0.0818
INFO - 2016-01-04 20:30:03 --> Config Class Initialized
INFO - 2016-01-04 20:30:03 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:30:03 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:30:03 --> Utf8 Class Initialized
INFO - 2016-01-04 20:30:03 --> URI Class Initialized
INFO - 2016-01-04 20:30:03 --> Router Class Initialized
INFO - 2016-01-04 20:30:03 --> Output Class Initialized
INFO - 2016-01-04 20:30:03 --> Security Class Initialized
DEBUG - 2016-01-04 20:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:30:03 --> Input Class Initialized
INFO - 2016-01-04 20:30:03 --> Language Class Initialized
INFO - 2016-01-04 20:30:03 --> Loader Class Initialized
INFO - 2016-01-04 20:30:03 --> Helper loaded: url_helper
INFO - 2016-01-04 20:30:03 --> Database Driver Class Initialized
INFO - 2016-01-04 20:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:30:03 --> Controller Class Initialized
DEBUG - 2016-01-04 20:30:03 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:30:03 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:30:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:30:03 --> Model Class Initialized
INFO - 2016-01-04 20:30:03 --> Model Class Initialized
INFO - 2016-01-04 20:30:03 --> Final output sent to browser
DEBUG - 2016-01-04 20:30:03 --> Total execution time: 0.1037
INFO - 2016-01-04 20:30:16 --> Config Class Initialized
INFO - 2016-01-04 20:30:16 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:30:16 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:30:16 --> Utf8 Class Initialized
INFO - 2016-01-04 20:30:16 --> URI Class Initialized
INFO - 2016-01-04 20:30:16 --> Router Class Initialized
INFO - 2016-01-04 20:30:16 --> Output Class Initialized
INFO - 2016-01-04 20:30:16 --> Security Class Initialized
DEBUG - 2016-01-04 20:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:30:16 --> Input Class Initialized
INFO - 2016-01-04 20:30:16 --> Language Class Initialized
INFO - 2016-01-04 20:30:16 --> Loader Class Initialized
INFO - 2016-01-04 20:30:16 --> Helper loaded: url_helper
INFO - 2016-01-04 20:30:16 --> Database Driver Class Initialized
INFO - 2016-01-04 20:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:30:16 --> Controller Class Initialized
DEBUG - 2016-01-04 20:30:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:30:16 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:30:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:30:16 --> Model Class Initialized
INFO - 2016-01-04 20:30:16 --> Model Class Initialized
INFO - 2016-01-04 20:30:16 --> Final output sent to browser
DEBUG - 2016-01-04 20:30:16 --> Total execution time: 0.0869
INFO - 2016-01-04 20:30:17 --> Config Class Initialized
INFO - 2016-01-04 20:30:17 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:30:17 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:30:17 --> Utf8 Class Initialized
INFO - 2016-01-04 20:30:17 --> URI Class Initialized
INFO - 2016-01-04 20:30:17 --> Router Class Initialized
INFO - 2016-01-04 20:30:17 --> Output Class Initialized
INFO - 2016-01-04 20:30:17 --> Security Class Initialized
DEBUG - 2016-01-04 20:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:30:17 --> Input Class Initialized
INFO - 2016-01-04 20:30:17 --> Language Class Initialized
INFO - 2016-01-04 20:30:17 --> Loader Class Initialized
INFO - 2016-01-04 20:30:17 --> Helper loaded: url_helper
INFO - 2016-01-04 20:30:17 --> Database Driver Class Initialized
INFO - 2016-01-04 20:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:30:17 --> Controller Class Initialized
DEBUG - 2016-01-04 20:30:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:30:17 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:30:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:30:17 --> Model Class Initialized
INFO - 2016-01-04 20:30:17 --> Model Class Initialized
INFO - 2016-01-04 20:30:17 --> Final output sent to browser
DEBUG - 2016-01-04 20:30:17 --> Total execution time: 0.0684
INFO - 2016-01-04 20:30:17 --> Config Class Initialized
INFO - 2016-01-04 20:30:17 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:30:17 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:30:17 --> Utf8 Class Initialized
INFO - 2016-01-04 20:30:17 --> URI Class Initialized
INFO - 2016-01-04 20:30:17 --> Router Class Initialized
INFO - 2016-01-04 20:30:17 --> Output Class Initialized
INFO - 2016-01-04 20:30:17 --> Security Class Initialized
DEBUG - 2016-01-04 20:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:30:17 --> Input Class Initialized
INFO - 2016-01-04 20:30:17 --> Language Class Initialized
INFO - 2016-01-04 20:30:17 --> Loader Class Initialized
INFO - 2016-01-04 20:30:17 --> Helper loaded: url_helper
INFO - 2016-01-04 20:30:17 --> Database Driver Class Initialized
INFO - 2016-01-04 20:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:30:17 --> Controller Class Initialized
DEBUG - 2016-01-04 20:30:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:30:17 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:30:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:30:17 --> Model Class Initialized
INFO - 2016-01-04 20:30:17 --> Model Class Initialized
INFO - 2016-01-04 20:30:17 --> Final output sent to browser
DEBUG - 2016-01-04 20:30:17 --> Total execution time: 0.1229
INFO - 2016-01-04 20:30:18 --> Config Class Initialized
INFO - 2016-01-04 20:30:18 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:30:18 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:30:18 --> Utf8 Class Initialized
INFO - 2016-01-04 20:30:18 --> URI Class Initialized
INFO - 2016-01-04 20:30:18 --> Router Class Initialized
INFO - 2016-01-04 20:30:18 --> Output Class Initialized
INFO - 2016-01-04 20:30:18 --> Security Class Initialized
DEBUG - 2016-01-04 20:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:30:18 --> Input Class Initialized
INFO - 2016-01-04 20:30:18 --> Language Class Initialized
INFO - 2016-01-04 20:30:18 --> Loader Class Initialized
INFO - 2016-01-04 20:30:18 --> Helper loaded: url_helper
INFO - 2016-01-04 20:30:18 --> Database Driver Class Initialized
INFO - 2016-01-04 20:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:30:18 --> Controller Class Initialized
DEBUG - 2016-01-04 20:30:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:30:18 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:30:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:30:18 --> Model Class Initialized
INFO - 2016-01-04 20:30:18 --> Model Class Initialized
INFO - 2016-01-04 20:30:18 --> Final output sent to browser
DEBUG - 2016-01-04 20:30:18 --> Total execution time: 0.0667
INFO - 2016-01-04 20:30:18 --> Config Class Initialized
INFO - 2016-01-04 20:30:18 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:30:18 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:30:19 --> Utf8 Class Initialized
INFO - 2016-01-04 20:30:19 --> URI Class Initialized
INFO - 2016-01-04 20:30:19 --> Router Class Initialized
INFO - 2016-01-04 20:30:19 --> Output Class Initialized
INFO - 2016-01-04 20:30:19 --> Security Class Initialized
DEBUG - 2016-01-04 20:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:30:19 --> Input Class Initialized
INFO - 2016-01-04 20:30:19 --> Language Class Initialized
INFO - 2016-01-04 20:30:19 --> Loader Class Initialized
INFO - 2016-01-04 20:30:19 --> Helper loaded: url_helper
INFO - 2016-01-04 20:30:19 --> Database Driver Class Initialized
INFO - 2016-01-04 20:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:30:19 --> Controller Class Initialized
DEBUG - 2016-01-04 20:30:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:30:19 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:30:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:30:19 --> Model Class Initialized
INFO - 2016-01-04 20:30:19 --> Model Class Initialized
INFO - 2016-01-04 20:30:19 --> Final output sent to browser
DEBUG - 2016-01-04 20:30:19 --> Total execution time: 0.1015
INFO - 2016-01-04 20:30:19 --> Config Class Initialized
INFO - 2016-01-04 20:30:19 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:30:19 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:30:19 --> Utf8 Class Initialized
INFO - 2016-01-04 20:30:19 --> URI Class Initialized
INFO - 2016-01-04 20:30:19 --> Router Class Initialized
INFO - 2016-01-04 20:30:19 --> Output Class Initialized
INFO - 2016-01-04 20:30:19 --> Security Class Initialized
DEBUG - 2016-01-04 20:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:30:19 --> Input Class Initialized
INFO - 2016-01-04 20:30:19 --> Language Class Initialized
INFO - 2016-01-04 20:30:19 --> Loader Class Initialized
INFO - 2016-01-04 20:30:19 --> Helper loaded: url_helper
INFO - 2016-01-04 20:30:19 --> Database Driver Class Initialized
INFO - 2016-01-04 20:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:30:19 --> Controller Class Initialized
DEBUG - 2016-01-04 20:30:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:30:19 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:30:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:30:19 --> Model Class Initialized
INFO - 2016-01-04 20:30:19 --> Model Class Initialized
INFO - 2016-01-04 20:30:19 --> Final output sent to browser
DEBUG - 2016-01-04 20:30:19 --> Total execution time: 0.1161
INFO - 2016-01-04 20:31:20 --> Config Class Initialized
INFO - 2016-01-04 20:31:20 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:31:20 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:31:20 --> Utf8 Class Initialized
INFO - 2016-01-04 20:31:20 --> URI Class Initialized
INFO - 2016-01-04 20:31:20 --> Router Class Initialized
INFO - 2016-01-04 20:31:20 --> Output Class Initialized
INFO - 2016-01-04 20:31:20 --> Security Class Initialized
DEBUG - 2016-01-04 20:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:31:20 --> Input Class Initialized
INFO - 2016-01-04 20:31:20 --> Language Class Initialized
INFO - 2016-01-04 20:31:20 --> Loader Class Initialized
INFO - 2016-01-04 20:31:20 --> Helper loaded: url_helper
INFO - 2016-01-04 20:31:20 --> Database Driver Class Initialized
INFO - 2016-01-04 20:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:31:20 --> Controller Class Initialized
DEBUG - 2016-01-04 20:31:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:31:20 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:31:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:31:20 --> Model Class Initialized
INFO - 2016-01-04 20:31:20 --> Model Class Initialized
INFO - 2016-01-04 20:31:20 --> Final output sent to browser
DEBUG - 2016-01-04 20:31:20 --> Total execution time: 0.0949
INFO - 2016-01-04 20:31:29 --> Config Class Initialized
INFO - 2016-01-04 20:31:29 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:31:29 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:31:29 --> Utf8 Class Initialized
INFO - 2016-01-04 20:31:29 --> URI Class Initialized
INFO - 2016-01-04 20:31:29 --> Router Class Initialized
INFO - 2016-01-04 20:31:29 --> Output Class Initialized
INFO - 2016-01-04 20:31:29 --> Security Class Initialized
DEBUG - 2016-01-04 20:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:31:29 --> Input Class Initialized
INFO - 2016-01-04 20:31:29 --> Language Class Initialized
INFO - 2016-01-04 20:31:29 --> Loader Class Initialized
INFO - 2016-01-04 20:31:29 --> Helper loaded: url_helper
INFO - 2016-01-04 20:31:29 --> Database Driver Class Initialized
INFO - 2016-01-04 20:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:31:29 --> Controller Class Initialized
DEBUG - 2016-01-04 20:31:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:31:29 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:31:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:31:29 --> Model Class Initialized
INFO - 2016-01-04 20:31:29 --> Model Class Initialized
INFO - 2016-01-04 20:31:29 --> Final output sent to browser
DEBUG - 2016-01-04 20:31:29 --> Total execution time: 0.0714
INFO - 2016-01-04 20:31:30 --> Config Class Initialized
INFO - 2016-01-04 20:31:30 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:31:30 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:31:30 --> Utf8 Class Initialized
INFO - 2016-01-04 20:31:30 --> URI Class Initialized
INFO - 2016-01-04 20:31:30 --> Router Class Initialized
INFO - 2016-01-04 20:31:30 --> Output Class Initialized
INFO - 2016-01-04 20:31:30 --> Security Class Initialized
DEBUG - 2016-01-04 20:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:31:30 --> Input Class Initialized
INFO - 2016-01-04 20:31:30 --> Language Class Initialized
INFO - 2016-01-04 20:31:30 --> Loader Class Initialized
INFO - 2016-01-04 20:31:30 --> Helper loaded: url_helper
INFO - 2016-01-04 20:31:30 --> Database Driver Class Initialized
INFO - 2016-01-04 20:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:31:30 --> Controller Class Initialized
DEBUG - 2016-01-04 20:31:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:31:30 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:31:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:31:30 --> Model Class Initialized
INFO - 2016-01-04 20:31:30 --> Model Class Initialized
INFO - 2016-01-04 20:31:30 --> Final output sent to browser
DEBUG - 2016-01-04 20:31:30 --> Total execution time: 0.1218
INFO - 2016-01-04 20:31:31 --> Config Class Initialized
INFO - 2016-01-04 20:31:31 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:31:31 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:31:31 --> Utf8 Class Initialized
INFO - 2016-01-04 20:31:31 --> URI Class Initialized
INFO - 2016-01-04 20:31:31 --> Router Class Initialized
INFO - 2016-01-04 20:31:31 --> Output Class Initialized
INFO - 2016-01-04 20:31:31 --> Security Class Initialized
DEBUG - 2016-01-04 20:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:31:31 --> Input Class Initialized
INFO - 2016-01-04 20:31:31 --> Language Class Initialized
INFO - 2016-01-04 20:31:31 --> Loader Class Initialized
INFO - 2016-01-04 20:31:31 --> Helper loaded: url_helper
INFO - 2016-01-04 20:31:31 --> Database Driver Class Initialized
INFO - 2016-01-04 20:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:31:31 --> Controller Class Initialized
DEBUG - 2016-01-04 20:31:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:31:31 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:31:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:31:31 --> Model Class Initialized
INFO - 2016-01-04 20:31:31 --> Model Class Initialized
INFO - 2016-01-04 20:31:31 --> Final output sent to browser
DEBUG - 2016-01-04 20:31:31 --> Total execution time: 0.1139
INFO - 2016-01-04 20:31:31 --> Config Class Initialized
INFO - 2016-01-04 20:31:31 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:31:31 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:31:31 --> Utf8 Class Initialized
INFO - 2016-01-04 20:31:31 --> URI Class Initialized
INFO - 2016-01-04 20:31:31 --> Router Class Initialized
INFO - 2016-01-04 20:31:31 --> Output Class Initialized
INFO - 2016-01-04 20:31:31 --> Security Class Initialized
DEBUG - 2016-01-04 20:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:31:31 --> Input Class Initialized
INFO - 2016-01-04 20:31:31 --> Language Class Initialized
INFO - 2016-01-04 20:31:32 --> Loader Class Initialized
INFO - 2016-01-04 20:31:32 --> Helper loaded: url_helper
INFO - 2016-01-04 20:31:32 --> Database Driver Class Initialized
INFO - 2016-01-04 20:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:31:32 --> Controller Class Initialized
DEBUG - 2016-01-04 20:31:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:31:32 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:31:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:31:32 --> Model Class Initialized
INFO - 2016-01-04 20:31:32 --> Model Class Initialized
INFO - 2016-01-04 20:31:32 --> Final output sent to browser
DEBUG - 2016-01-04 20:31:32 --> Total execution time: 0.1199
INFO - 2016-01-04 20:31:32 --> Config Class Initialized
INFO - 2016-01-04 20:31:32 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:31:32 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:31:32 --> Utf8 Class Initialized
INFO - 2016-01-04 20:31:32 --> URI Class Initialized
INFO - 2016-01-04 20:31:32 --> Router Class Initialized
INFO - 2016-01-04 20:31:32 --> Output Class Initialized
INFO - 2016-01-04 20:31:32 --> Security Class Initialized
DEBUG - 2016-01-04 20:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:31:32 --> Input Class Initialized
INFO - 2016-01-04 20:31:32 --> Language Class Initialized
INFO - 2016-01-04 20:31:32 --> Loader Class Initialized
INFO - 2016-01-04 20:31:32 --> Helper loaded: url_helper
INFO - 2016-01-04 20:31:32 --> Database Driver Class Initialized
INFO - 2016-01-04 20:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:31:32 --> Controller Class Initialized
DEBUG - 2016-01-04 20:31:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:31:32 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:31:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:31:32 --> Model Class Initialized
INFO - 2016-01-04 20:31:32 --> Model Class Initialized
INFO - 2016-01-04 20:31:32 --> Final output sent to browser
DEBUG - 2016-01-04 20:31:32 --> Total execution time: 0.1284
INFO - 2016-01-04 20:46:00 --> Config Class Initialized
INFO - 2016-01-04 20:46:00 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:46:00 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:46:00 --> Utf8 Class Initialized
INFO - 2016-01-04 20:46:00 --> URI Class Initialized
DEBUG - 2016-01-04 20:46:00 --> No URI present. Default controller set.
INFO - 2016-01-04 20:46:00 --> Router Class Initialized
INFO - 2016-01-04 20:46:00 --> Output Class Initialized
INFO - 2016-01-04 20:46:00 --> Security Class Initialized
DEBUG - 2016-01-04 20:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:46:00 --> Input Class Initialized
INFO - 2016-01-04 20:46:00 --> Language Class Initialized
INFO - 2016-01-04 20:46:00 --> Loader Class Initialized
INFO - 2016-01-04 20:46:00 --> Helper loaded: url_helper
INFO - 2016-01-04 20:46:00 --> Database Driver Class Initialized
INFO - 2016-01-04 20:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:46:00 --> Controller Class Initialized
INFO - 2016-01-04 20:46:00 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 20:46:00 --> Final output sent to browser
DEBUG - 2016-01-04 20:46:00 --> Total execution time: 0.1495
INFO - 2016-01-04 20:46:38 --> Config Class Initialized
INFO - 2016-01-04 20:46:38 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:46:38 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:46:38 --> Utf8 Class Initialized
INFO - 2016-01-04 20:46:38 --> URI Class Initialized
DEBUG - 2016-01-04 20:46:38 --> No URI present. Default controller set.
INFO - 2016-01-04 20:46:38 --> Router Class Initialized
INFO - 2016-01-04 20:46:38 --> Output Class Initialized
INFO - 2016-01-04 20:46:38 --> Security Class Initialized
DEBUG - 2016-01-04 20:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:46:38 --> Input Class Initialized
INFO - 2016-01-04 20:46:38 --> Language Class Initialized
INFO - 2016-01-04 20:46:38 --> Loader Class Initialized
INFO - 2016-01-04 20:46:38 --> Helper loaded: url_helper
INFO - 2016-01-04 20:46:38 --> Database Driver Class Initialized
INFO - 2016-01-04 20:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:46:38 --> Controller Class Initialized
INFO - 2016-01-04 20:46:38 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 20:46:38 --> Final output sent to browser
DEBUG - 2016-01-04 20:46:38 --> Total execution time: 0.0882
INFO - 2016-01-04 20:46:40 --> Config Class Initialized
INFO - 2016-01-04 20:46:40 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:46:40 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:46:40 --> Utf8 Class Initialized
INFO - 2016-01-04 20:46:40 --> URI Class Initialized
INFO - 2016-01-04 20:46:40 --> Router Class Initialized
INFO - 2016-01-04 20:46:40 --> Output Class Initialized
INFO - 2016-01-04 20:46:40 --> Security Class Initialized
DEBUG - 2016-01-04 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:46:40 --> Input Class Initialized
INFO - 2016-01-04 20:46:40 --> Language Class Initialized
INFO - 2016-01-04 20:46:40 --> Loader Class Initialized
INFO - 2016-01-04 20:46:40 --> Helper loaded: url_helper
INFO - 2016-01-04 20:46:40 --> Database Driver Class Initialized
INFO - 2016-01-04 20:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:46:40 --> Controller Class Initialized
INFO - 2016-01-04 20:46:40 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 20:46:40 --> Final output sent to browser
DEBUG - 2016-01-04 20:46:40 --> Total execution time: 0.0856
INFO - 2016-01-04 20:46:40 --> Config Class Initialized
INFO - 2016-01-04 20:46:40 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:46:40 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:46:40 --> Utf8 Class Initialized
INFO - 2016-01-04 20:46:40 --> URI Class Initialized
INFO - 2016-01-04 20:46:40 --> Router Class Initialized
INFO - 2016-01-04 20:46:40 --> Output Class Initialized
INFO - 2016-01-04 20:46:40 --> Security Class Initialized
DEBUG - 2016-01-04 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:46:40 --> Input Class Initialized
INFO - 2016-01-04 20:46:40 --> Language Class Initialized
INFO - 2016-01-04 20:46:40 --> Loader Class Initialized
INFO - 2016-01-04 20:46:40 --> Helper loaded: url_helper
INFO - 2016-01-04 20:46:40 --> Database Driver Class Initialized
INFO - 2016-01-04 20:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:46:41 --> Controller Class Initialized
DEBUG - 2016-01-04 20:46:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:46:41 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:46:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:46:41 --> Model Class Initialized
INFO - 2016-01-04 20:46:41 --> Model Class Initialized
INFO - 2016-01-04 20:46:41 --> Final output sent to browser
DEBUG - 2016-01-04 20:46:41 --> Total execution time: 0.1312
INFO - 2016-01-04 20:46:43 --> Config Class Initialized
INFO - 2016-01-04 20:46:43 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:46:43 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:46:43 --> Utf8 Class Initialized
INFO - 2016-01-04 20:46:43 --> URI Class Initialized
INFO - 2016-01-04 20:46:43 --> Router Class Initialized
INFO - 2016-01-04 20:46:43 --> Output Class Initialized
INFO - 2016-01-04 20:46:43 --> Security Class Initialized
DEBUG - 2016-01-04 20:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:46:43 --> Input Class Initialized
INFO - 2016-01-04 20:46:43 --> Language Class Initialized
INFO - 2016-01-04 20:46:43 --> Loader Class Initialized
INFO - 2016-01-04 20:46:43 --> Helper loaded: url_helper
INFO - 2016-01-04 20:46:43 --> Database Driver Class Initialized
INFO - 2016-01-04 20:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:46:43 --> Controller Class Initialized
DEBUG - 2016-01-04 20:46:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:46:43 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:46:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:46:44 --> Model Class Initialized
INFO - 2016-01-04 20:46:44 --> Model Class Initialized
INFO - 2016-01-04 20:46:44 --> Final output sent to browser
DEBUG - 2016-01-04 20:46:44 --> Total execution time: 0.1204
INFO - 2016-01-04 20:46:45 --> Config Class Initialized
INFO - 2016-01-04 20:46:45 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:46:45 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:46:45 --> Utf8 Class Initialized
INFO - 2016-01-04 20:46:45 --> URI Class Initialized
INFO - 2016-01-04 20:46:45 --> Router Class Initialized
INFO - 2016-01-04 20:46:46 --> Output Class Initialized
INFO - 2016-01-04 20:46:46 --> Security Class Initialized
DEBUG - 2016-01-04 20:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:46:46 --> Input Class Initialized
INFO - 2016-01-04 20:46:46 --> Language Class Initialized
INFO - 2016-01-04 20:46:46 --> Loader Class Initialized
INFO - 2016-01-04 20:46:46 --> Helper loaded: url_helper
INFO - 2016-01-04 20:46:46 --> Database Driver Class Initialized
INFO - 2016-01-04 20:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:46:46 --> Controller Class Initialized
DEBUG - 2016-01-04 20:46:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:46:46 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:46:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:46:46 --> Model Class Initialized
INFO - 2016-01-04 20:46:46 --> Model Class Initialized
INFO - 2016-01-04 20:46:46 --> Final output sent to browser
DEBUG - 2016-01-04 20:46:46 --> Total execution time: 0.1153
INFO - 2016-01-04 20:46:51 --> Config Class Initialized
INFO - 2016-01-04 20:46:51 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:46:51 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:46:51 --> Utf8 Class Initialized
INFO - 2016-01-04 20:46:51 --> URI Class Initialized
DEBUG - 2016-01-04 20:46:51 --> No URI present. Default controller set.
INFO - 2016-01-04 20:46:51 --> Router Class Initialized
INFO - 2016-01-04 20:46:51 --> Output Class Initialized
INFO - 2016-01-04 20:46:51 --> Security Class Initialized
DEBUG - 2016-01-04 20:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:46:51 --> Input Class Initialized
INFO - 2016-01-04 20:46:51 --> Language Class Initialized
INFO - 2016-01-04 20:46:51 --> Loader Class Initialized
INFO - 2016-01-04 20:46:51 --> Helper loaded: url_helper
INFO - 2016-01-04 20:46:51 --> Database Driver Class Initialized
INFO - 2016-01-04 20:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:46:51 --> Controller Class Initialized
INFO - 2016-01-04 20:46:51 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 20:46:51 --> Final output sent to browser
DEBUG - 2016-01-04 20:46:51 --> Total execution time: 0.0969
INFO - 2016-01-04 20:46:52 --> Config Class Initialized
INFO - 2016-01-04 20:46:52 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:46:52 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:46:52 --> Utf8 Class Initialized
INFO - 2016-01-04 20:46:52 --> URI Class Initialized
INFO - 2016-01-04 20:46:52 --> Router Class Initialized
INFO - 2016-01-04 20:46:52 --> Output Class Initialized
INFO - 2016-01-04 20:46:52 --> Security Class Initialized
DEBUG - 2016-01-04 20:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:46:52 --> Input Class Initialized
INFO - 2016-01-04 20:46:52 --> Language Class Initialized
INFO - 2016-01-04 20:46:52 --> Loader Class Initialized
INFO - 2016-01-04 20:46:52 --> Helper loaded: url_helper
INFO - 2016-01-04 20:46:52 --> Database Driver Class Initialized
INFO - 2016-01-04 20:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:46:52 --> Controller Class Initialized
INFO - 2016-01-04 20:46:52 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 20:46:52 --> Final output sent to browser
DEBUG - 2016-01-04 20:46:52 --> Total execution time: 0.0904
INFO - 2016-01-04 20:46:53 --> Config Class Initialized
INFO - 2016-01-04 20:46:53 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:46:53 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:46:53 --> Utf8 Class Initialized
INFO - 2016-01-04 20:46:53 --> URI Class Initialized
INFO - 2016-01-04 20:46:53 --> Router Class Initialized
INFO - 2016-01-04 20:46:53 --> Output Class Initialized
INFO - 2016-01-04 20:46:53 --> Security Class Initialized
DEBUG - 2016-01-04 20:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:46:53 --> Input Class Initialized
INFO - 2016-01-04 20:46:53 --> Language Class Initialized
INFO - 2016-01-04 20:46:53 --> Loader Class Initialized
INFO - 2016-01-04 20:46:53 --> Helper loaded: url_helper
INFO - 2016-01-04 20:46:53 --> Database Driver Class Initialized
INFO - 2016-01-04 20:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:46:53 --> Controller Class Initialized
DEBUG - 2016-01-04 20:46:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:46:53 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:46:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:46:53 --> Model Class Initialized
INFO - 2016-01-04 20:46:53 --> Model Class Initialized
INFO - 2016-01-04 20:46:53 --> Final output sent to browser
DEBUG - 2016-01-04 20:46:53 --> Total execution time: 0.1191
INFO - 2016-01-04 20:46:56 --> Config Class Initialized
INFO - 2016-01-04 20:46:56 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:46:56 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:46:56 --> Utf8 Class Initialized
INFO - 2016-01-04 20:46:56 --> URI Class Initialized
INFO - 2016-01-04 20:46:56 --> Router Class Initialized
INFO - 2016-01-04 20:46:56 --> Output Class Initialized
INFO - 2016-01-04 20:46:56 --> Security Class Initialized
DEBUG - 2016-01-04 20:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:46:56 --> Input Class Initialized
INFO - 2016-01-04 20:46:56 --> Language Class Initialized
INFO - 2016-01-04 20:46:56 --> Loader Class Initialized
INFO - 2016-01-04 20:46:56 --> Helper loaded: url_helper
INFO - 2016-01-04 20:46:56 --> Database Driver Class Initialized
INFO - 2016-01-04 20:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:46:56 --> Controller Class Initialized
DEBUG - 2016-01-04 20:46:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:46:56 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:46:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:46:56 --> Model Class Initialized
INFO - 2016-01-04 20:46:56 --> Model Class Initialized
INFO - 2016-01-04 20:46:56 --> Final output sent to browser
DEBUG - 2016-01-04 20:46:56 --> Total execution time: 0.1074
INFO - 2016-01-04 20:46:58 --> Config Class Initialized
INFO - 2016-01-04 20:46:58 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:46:58 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:46:58 --> Utf8 Class Initialized
INFO - 2016-01-04 20:46:58 --> URI Class Initialized
INFO - 2016-01-04 20:46:58 --> Router Class Initialized
INFO - 2016-01-04 20:46:58 --> Output Class Initialized
INFO - 2016-01-04 20:46:58 --> Security Class Initialized
DEBUG - 2016-01-04 20:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:46:58 --> Input Class Initialized
INFO - 2016-01-04 20:46:58 --> Language Class Initialized
INFO - 2016-01-04 20:46:58 --> Loader Class Initialized
INFO - 2016-01-04 20:46:58 --> Helper loaded: url_helper
INFO - 2016-01-04 20:46:58 --> Database Driver Class Initialized
INFO - 2016-01-04 20:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:46:58 --> Controller Class Initialized
DEBUG - 2016-01-04 20:46:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:46:58 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:46:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:46:58 --> Model Class Initialized
INFO - 2016-01-04 20:46:58 --> Model Class Initialized
INFO - 2016-01-04 20:46:58 --> Final output sent to browser
DEBUG - 2016-01-04 20:46:58 --> Total execution time: 0.1150
INFO - 2016-01-04 20:47:46 --> Config Class Initialized
INFO - 2016-01-04 20:47:46 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:47:46 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:47:46 --> Utf8 Class Initialized
INFO - 2016-01-04 20:47:46 --> URI Class Initialized
INFO - 2016-01-04 20:47:46 --> Router Class Initialized
INFO - 2016-01-04 20:47:46 --> Output Class Initialized
INFO - 2016-01-04 20:47:46 --> Security Class Initialized
DEBUG - 2016-01-04 20:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:47:46 --> Input Class Initialized
INFO - 2016-01-04 20:47:46 --> Language Class Initialized
INFO - 2016-01-04 20:47:46 --> Loader Class Initialized
INFO - 2016-01-04 20:47:46 --> Helper loaded: url_helper
INFO - 2016-01-04 20:47:46 --> Database Driver Class Initialized
INFO - 2016-01-04 20:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:47:46 --> Controller Class Initialized
INFO - 2016-01-04 20:47:46 --> Helper loaded: form_helper
INFO - 2016-01-04 20:47:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 20:47:46 --> Final output sent to browser
DEBUG - 2016-01-04 20:47:46 --> Total execution time: 0.1101
INFO - 2016-01-04 20:47:54 --> Config Class Initialized
INFO - 2016-01-04 20:47:54 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:47:54 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:47:54 --> Utf8 Class Initialized
INFO - 2016-01-04 20:47:54 --> URI Class Initialized
INFO - 2016-01-04 20:47:54 --> Router Class Initialized
INFO - 2016-01-04 20:47:54 --> Output Class Initialized
INFO - 2016-01-04 20:47:54 --> Security Class Initialized
DEBUG - 2016-01-04 20:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:47:54 --> Input Class Initialized
INFO - 2016-01-04 20:47:54 --> Language Class Initialized
INFO - 2016-01-04 20:47:54 --> Loader Class Initialized
INFO - 2016-01-04 20:47:54 --> Helper loaded: url_helper
INFO - 2016-01-04 20:47:54 --> Database Driver Class Initialized
INFO - 2016-01-04 20:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:47:54 --> Controller Class Initialized
INFO - 2016-01-04 20:47:54 --> Model Class Initialized
INFO - 2016-01-04 20:47:54 --> Model Class Initialized
INFO - 2016-01-04 20:47:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 20:47:54 --> Final output sent to browser
DEBUG - 2016-01-04 20:47:54 --> Total execution time: 0.0730
INFO - 2016-01-04 20:47:54 --> Config Class Initialized
INFO - 2016-01-04 20:47:54 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:47:54 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:47:54 --> Utf8 Class Initialized
INFO - 2016-01-04 20:47:54 --> URI Class Initialized
INFO - 2016-01-04 20:47:54 --> Router Class Initialized
INFO - 2016-01-04 20:47:54 --> Output Class Initialized
INFO - 2016-01-04 20:47:54 --> Security Class Initialized
DEBUG - 2016-01-04 20:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:47:54 --> Input Class Initialized
INFO - 2016-01-04 20:47:54 --> Language Class Initialized
INFO - 2016-01-04 20:47:54 --> Loader Class Initialized
INFO - 2016-01-04 20:47:54 --> Helper loaded: url_helper
INFO - 2016-01-04 20:47:54 --> Database Driver Class Initialized
INFO - 2016-01-04 20:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:47:54 --> Controller Class Initialized
INFO - 2016-01-04 20:47:54 --> Model Class Initialized
INFO - 2016-01-04 20:47:54 --> Model Class Initialized
INFO - 2016-01-04 20:47:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 20:47:54 --> Final output sent to browser
DEBUG - 2016-01-04 20:47:54 --> Total execution time: 0.0610
INFO - 2016-01-04 20:47:54 --> Config Class Initialized
INFO - 2016-01-04 20:47:54 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:47:54 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:47:54 --> Utf8 Class Initialized
INFO - 2016-01-04 20:47:54 --> URI Class Initialized
INFO - 2016-01-04 20:47:54 --> Router Class Initialized
INFO - 2016-01-04 20:47:54 --> Output Class Initialized
INFO - 2016-01-04 20:47:54 --> Security Class Initialized
DEBUG - 2016-01-04 20:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:47:54 --> Input Class Initialized
INFO - 2016-01-04 20:47:54 --> Language Class Initialized
INFO - 2016-01-04 20:47:54 --> Loader Class Initialized
INFO - 2016-01-04 20:47:54 --> Helper loaded: url_helper
INFO - 2016-01-04 20:47:54 --> Database Driver Class Initialized
INFO - 2016-01-04 20:47:54 --> Config Class Initialized
INFO - 2016-01-04 20:47:54 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:47:54 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:47:54 --> Utf8 Class Initialized
INFO - 2016-01-04 20:47:54 --> Controller Class Initialized
INFO - 2016-01-04 20:47:54 --> URI Class Initialized
INFO - 2016-01-04 20:47:54 --> Model Class Initialized
INFO - 2016-01-04 20:47:54 --> Router Class Initialized
INFO - 2016-01-04 20:47:54 --> Model Class Initialized
INFO - 2016-01-04 20:47:54 --> Output Class Initialized
INFO - 2016-01-04 20:47:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 20:47:54 --> Final output sent to browser
INFO - 2016-01-04 20:47:54 --> Security Class Initialized
DEBUG - 2016-01-04 20:47:54 --> Total execution time: 0.0777
DEBUG - 2016-01-04 20:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:47:54 --> Input Class Initialized
INFO - 2016-01-04 20:47:54 --> Language Class Initialized
INFO - 2016-01-04 20:47:54 --> Loader Class Initialized
INFO - 2016-01-04 20:47:54 --> Helper loaded: url_helper
INFO - 2016-01-04 20:47:54 --> Database Driver Class Initialized
INFO - 2016-01-04 20:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:47:54 --> Controller Class Initialized
DEBUG - 2016-01-04 20:47:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:47:54 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:47:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:47:54 --> Model Class Initialized
INFO - 2016-01-04 20:47:54 --> Model Class Initialized
INFO - 2016-01-04 20:47:54 --> Final output sent to browser
DEBUG - 2016-01-04 20:47:54 --> Total execution time: 0.0930
INFO - 2016-01-04 20:48:01 --> Config Class Initialized
INFO - 2016-01-04 20:48:01 --> Hooks Class Initialized
DEBUG - 2016-01-04 20:48:01 --> UTF-8 Support Enabled
INFO - 2016-01-04 20:48:01 --> Utf8 Class Initialized
INFO - 2016-01-04 20:48:01 --> URI Class Initialized
INFO - 2016-01-04 20:48:01 --> Router Class Initialized
INFO - 2016-01-04 20:48:01 --> Output Class Initialized
INFO - 2016-01-04 20:48:01 --> Security Class Initialized
DEBUG - 2016-01-04 20:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 20:48:01 --> Input Class Initialized
INFO - 2016-01-04 20:48:01 --> Language Class Initialized
INFO - 2016-01-04 20:48:01 --> Loader Class Initialized
INFO - 2016-01-04 20:48:01 --> Helper loaded: url_helper
INFO - 2016-01-04 20:48:01 --> Database Driver Class Initialized
INFO - 2016-01-04 20:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 20:48:01 --> Controller Class Initialized
DEBUG - 2016-01-04 20:48:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 20:48:01 --> Helper loaded: inflector_helper
INFO - 2016-01-04 20:48:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 20:48:01 --> Model Class Initialized
INFO - 2016-01-04 20:48:01 --> Model Class Initialized
INFO - 2016-01-04 20:48:01 --> Final output sent to browser
DEBUG - 2016-01-04 20:48:01 --> Total execution time: 0.0727
INFO - 2016-01-04 21:03:27 --> Config Class Initialized
INFO - 2016-01-04 21:03:27 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:03:27 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:03:27 --> Utf8 Class Initialized
INFO - 2016-01-04 21:03:27 --> URI Class Initialized
INFO - 2016-01-04 21:03:27 --> Router Class Initialized
INFO - 2016-01-04 21:03:27 --> Output Class Initialized
INFO - 2016-01-04 21:03:27 --> Security Class Initialized
DEBUG - 2016-01-04 21:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:03:27 --> Input Class Initialized
INFO - 2016-01-04 21:03:27 --> Language Class Initialized
INFO - 2016-01-04 21:03:27 --> Loader Class Initialized
INFO - 2016-01-04 21:03:27 --> Helper loaded: url_helper
INFO - 2016-01-04 21:03:27 --> Database Driver Class Initialized
INFO - 2016-01-04 21:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:03:27 --> Controller Class Initialized
INFO - 2016-01-04 21:03:27 --> Model Class Initialized
INFO - 2016-01-04 21:03:27 --> Model Class Initialized
INFO - 2016-01-04 21:03:27 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 21:03:27 --> Final output sent to browser
DEBUG - 2016-01-04 21:03:27 --> Total execution time: 0.0975
INFO - 2016-01-04 21:03:27 --> Config Class Initialized
INFO - 2016-01-04 21:03:27 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:03:27 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:03:27 --> Utf8 Class Initialized
INFO - 2016-01-04 21:03:27 --> URI Class Initialized
INFO - 2016-01-04 21:03:27 --> Router Class Initialized
INFO - 2016-01-04 21:03:27 --> Output Class Initialized
INFO - 2016-01-04 21:03:27 --> Security Class Initialized
DEBUG - 2016-01-04 21:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:03:27 --> Input Class Initialized
INFO - 2016-01-04 21:03:27 --> Language Class Initialized
INFO - 2016-01-04 21:03:27 --> Loader Class Initialized
INFO - 2016-01-04 21:03:27 --> Helper loaded: url_helper
INFO - 2016-01-04 21:03:27 --> Database Driver Class Initialized
INFO - 2016-01-04 21:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:03:27 --> Controller Class Initialized
INFO - 2016-01-04 21:03:27 --> Model Class Initialized
INFO - 2016-01-04 21:03:27 --> Model Class Initialized
INFO - 2016-01-04 21:03:27 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 21:03:27 --> Final output sent to browser
DEBUG - 2016-01-04 21:03:27 --> Total execution time: 0.0664
INFO - 2016-01-04 21:03:27 --> Config Class Initialized
INFO - 2016-01-04 21:03:27 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:03:27 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:03:27 --> Utf8 Class Initialized
INFO - 2016-01-04 21:03:27 --> URI Class Initialized
INFO - 2016-01-04 21:03:27 --> Router Class Initialized
INFO - 2016-01-04 21:03:27 --> Output Class Initialized
INFO - 2016-01-04 21:03:27 --> Security Class Initialized
DEBUG - 2016-01-04 21:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:03:27 --> Input Class Initialized
INFO - 2016-01-04 21:03:27 --> Language Class Initialized
INFO - 2016-01-04 21:03:27 --> Loader Class Initialized
INFO - 2016-01-04 21:03:27 --> Helper loaded: url_helper
INFO - 2016-01-04 21:03:27 --> Database Driver Class Initialized
INFO - 2016-01-04 21:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:03:27 --> Controller Class Initialized
DEBUG - 2016-01-04 21:03:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:03:27 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:03:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:03:27 --> Model Class Initialized
INFO - 2016-01-04 21:03:27 --> Model Class Initialized
INFO - 2016-01-04 21:03:27 --> Final output sent to browser
DEBUG - 2016-01-04 21:03:27 --> Total execution time: 0.0851
INFO - 2016-01-04 21:03:57 --> Config Class Initialized
INFO - 2016-01-04 21:03:57 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:03:57 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:03:57 --> Utf8 Class Initialized
INFO - 2016-01-04 21:03:57 --> URI Class Initialized
INFO - 2016-01-04 21:03:57 --> Router Class Initialized
INFO - 2016-01-04 21:03:57 --> Output Class Initialized
INFO - 2016-01-04 21:03:57 --> Security Class Initialized
DEBUG - 2016-01-04 21:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:03:57 --> Input Class Initialized
INFO - 2016-01-04 21:03:57 --> Language Class Initialized
INFO - 2016-01-04 21:03:57 --> Loader Class Initialized
INFO - 2016-01-04 21:03:57 --> Helper loaded: url_helper
INFO - 2016-01-04 21:03:57 --> Database Driver Class Initialized
INFO - 2016-01-04 21:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:03:57 --> Controller Class Initialized
DEBUG - 2016-01-04 21:03:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:03:57 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:03:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:03:57 --> Model Class Initialized
INFO - 2016-01-04 21:03:57 --> Model Class Initialized
INFO - 2016-01-04 21:03:57 --> Final output sent to browser
DEBUG - 2016-01-04 21:03:57 --> Total execution time: 0.1389
INFO - 2016-01-04 21:04:00 --> Config Class Initialized
INFO - 2016-01-04 21:04:00 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:04:00 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:04:00 --> Utf8 Class Initialized
INFO - 2016-01-04 21:04:00 --> URI Class Initialized
INFO - 2016-01-04 21:04:00 --> Router Class Initialized
INFO - 2016-01-04 21:04:00 --> Output Class Initialized
INFO - 2016-01-04 21:04:00 --> Security Class Initialized
DEBUG - 2016-01-04 21:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:04:00 --> Input Class Initialized
INFO - 2016-01-04 21:04:00 --> Language Class Initialized
INFO - 2016-01-04 21:04:00 --> Loader Class Initialized
INFO - 2016-01-04 21:04:00 --> Helper loaded: url_helper
INFO - 2016-01-04 21:04:00 --> Database Driver Class Initialized
INFO - 2016-01-04 21:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:04:00 --> Controller Class Initialized
DEBUG - 2016-01-04 21:04:00 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:04:00 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:04:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:04:00 --> Model Class Initialized
INFO - 2016-01-04 21:04:00 --> Model Class Initialized
INFO - 2016-01-04 21:04:00 --> Final output sent to browser
DEBUG - 2016-01-04 21:04:00 --> Total execution time: 0.0797
INFO - 2016-01-04 21:04:03 --> Config Class Initialized
INFO - 2016-01-04 21:04:03 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:04:03 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:04:03 --> Utf8 Class Initialized
INFO - 2016-01-04 21:04:03 --> URI Class Initialized
INFO - 2016-01-04 21:04:03 --> Router Class Initialized
INFO - 2016-01-04 21:04:03 --> Output Class Initialized
INFO - 2016-01-04 21:04:03 --> Security Class Initialized
DEBUG - 2016-01-04 21:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:04:03 --> Input Class Initialized
INFO - 2016-01-04 21:04:03 --> Language Class Initialized
INFO - 2016-01-04 21:04:03 --> Loader Class Initialized
INFO - 2016-01-04 21:04:03 --> Helper loaded: url_helper
INFO - 2016-01-04 21:04:04 --> Database Driver Class Initialized
ERROR - 2016-01-04 21:04:04 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2016-01-04 21:04:04 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
ERROR - 2016-01-04 21:04:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/libraries/Session/Session.php 168
INFO - 2016-01-04 21:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:04:04 --> Controller Class Initialized
DEBUG - 2016-01-04 21:04:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:04:04 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:04:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:04:04 --> Model Class Initialized
INFO - 2016-01-04 21:04:04 --> Model Class Initialized
ERROR - 2016-01-04 21:04:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/core/Common.php 573
INFO - 2016-01-04 21:04:04 --> Final output sent to browser
DEBUG - 2016-01-04 21:04:04 --> Total execution time: 0.0803
INFO - 2016-01-04 21:04:12 --> Config Class Initialized
INFO - 2016-01-04 21:04:12 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:04:12 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:04:12 --> Utf8 Class Initialized
INFO - 2016-01-04 21:04:12 --> URI Class Initialized
INFO - 2016-01-04 21:04:12 --> Router Class Initialized
INFO - 2016-01-04 21:04:12 --> Output Class Initialized
INFO - 2016-01-04 21:04:12 --> Security Class Initialized
DEBUG - 2016-01-04 21:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:04:12 --> Input Class Initialized
INFO - 2016-01-04 21:04:12 --> Language Class Initialized
INFO - 2016-01-04 21:04:12 --> Loader Class Initialized
INFO - 2016-01-04 21:04:12 --> Helper loaded: url_helper
INFO - 2016-01-04 21:04:12 --> Database Driver Class Initialized
INFO - 2016-01-04 21:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:04:12 --> Controller Class Initialized
INFO - 2016-01-04 21:04:12 --> Model Class Initialized
INFO - 2016-01-04 21:04:12 --> Model Class Initialized
INFO - 2016-01-04 21:04:12 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 21:04:12 --> Final output sent to browser
DEBUG - 2016-01-04 21:04:12 --> Total execution time: 0.0697
INFO - 2016-01-04 21:04:12 --> Config Class Initialized
INFO - 2016-01-04 21:04:12 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:04:12 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:04:12 --> Utf8 Class Initialized
INFO - 2016-01-04 21:04:12 --> URI Class Initialized
INFO - 2016-01-04 21:04:12 --> Router Class Initialized
INFO - 2016-01-04 21:04:12 --> Output Class Initialized
INFO - 2016-01-04 21:04:12 --> Security Class Initialized
DEBUG - 2016-01-04 21:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:04:12 --> Input Class Initialized
INFO - 2016-01-04 21:04:12 --> Language Class Initialized
INFO - 2016-01-04 21:04:12 --> Loader Class Initialized
INFO - 2016-01-04 21:04:12 --> Helper loaded: url_helper
INFO - 2016-01-04 21:04:12 --> Database Driver Class Initialized
INFO - 2016-01-04 21:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:04:12 --> Controller Class Initialized
INFO - 2016-01-04 21:04:12 --> Model Class Initialized
INFO - 2016-01-04 21:04:12 --> Model Class Initialized
INFO - 2016-01-04 21:04:12 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 21:04:12 --> Final output sent to browser
DEBUG - 2016-01-04 21:04:12 --> Total execution time: 0.0599
INFO - 2016-01-04 21:04:12 --> Config Class Initialized
INFO - 2016-01-04 21:04:12 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:04:12 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:04:12 --> Utf8 Class Initialized
INFO - 2016-01-04 21:04:12 --> URI Class Initialized
INFO - 2016-01-04 21:04:12 --> Router Class Initialized
INFO - 2016-01-04 21:04:12 --> Output Class Initialized
INFO - 2016-01-04 21:04:12 --> Security Class Initialized
DEBUG - 2016-01-04 21:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:04:12 --> Input Class Initialized
INFO - 2016-01-04 21:04:12 --> Language Class Initialized
INFO - 2016-01-04 21:04:12 --> Loader Class Initialized
INFO - 2016-01-04 21:04:12 --> Helper loaded: url_helper
INFO - 2016-01-04 21:04:12 --> Database Driver Class Initialized
INFO - 2016-01-04 21:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:04:12 --> Controller Class Initialized
DEBUG - 2016-01-04 21:04:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:04:12 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:04:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:04:12 --> Model Class Initialized
INFO - 2016-01-04 21:04:12 --> Model Class Initialized
INFO - 2016-01-04 21:04:12 --> Final output sent to browser
DEBUG - 2016-01-04 21:04:12 --> Total execution time: 0.0731
INFO - 2016-01-04 21:04:17 --> Config Class Initialized
INFO - 2016-01-04 21:04:17 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:04:17 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:04:17 --> Utf8 Class Initialized
INFO - 2016-01-04 21:04:17 --> URI Class Initialized
INFO - 2016-01-04 21:04:17 --> Router Class Initialized
INFO - 2016-01-04 21:04:17 --> Output Class Initialized
INFO - 2016-01-04 21:04:17 --> Security Class Initialized
DEBUG - 2016-01-04 21:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:04:17 --> Input Class Initialized
INFO - 2016-01-04 21:04:17 --> Language Class Initialized
INFO - 2016-01-04 21:04:17 --> Loader Class Initialized
INFO - 2016-01-04 21:04:17 --> Helper loaded: url_helper
INFO - 2016-01-04 21:04:17 --> Database Driver Class Initialized
INFO - 2016-01-04 21:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:04:17 --> Controller Class Initialized
DEBUG - 2016-01-04 21:04:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:04:17 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:04:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:04:17 --> Model Class Initialized
INFO - 2016-01-04 21:04:17 --> Model Class Initialized
INFO - 2016-01-04 21:04:17 --> Final output sent to browser
DEBUG - 2016-01-04 21:04:17 --> Total execution time: 0.0703
INFO - 2016-01-04 21:12:12 --> Config Class Initialized
INFO - 2016-01-04 21:12:12 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:12 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:12 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:12 --> URI Class Initialized
DEBUG - 2016-01-04 21:12:12 --> No URI present. Default controller set.
INFO - 2016-01-04 21:12:12 --> Router Class Initialized
INFO - 2016-01-04 21:12:12 --> Output Class Initialized
INFO - 2016-01-04 21:12:12 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:12 --> Input Class Initialized
INFO - 2016-01-04 21:12:12 --> Language Class Initialized
INFO - 2016-01-04 21:12:12 --> Loader Class Initialized
INFO - 2016-01-04 21:12:12 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:12 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:12 --> Controller Class Initialized
INFO - 2016-01-04 21:12:12 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 21:12:12 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:12 --> Total execution time: 0.1152
INFO - 2016-01-04 21:12:18 --> Config Class Initialized
INFO - 2016-01-04 21:12:18 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:18 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:18 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:18 --> URI Class Initialized
INFO - 2016-01-04 21:12:18 --> Router Class Initialized
INFO - 2016-01-04 21:12:18 --> Output Class Initialized
INFO - 2016-01-04 21:12:18 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:18 --> Input Class Initialized
INFO - 2016-01-04 21:12:18 --> Language Class Initialized
INFO - 2016-01-04 21:12:18 --> Loader Class Initialized
INFO - 2016-01-04 21:12:18 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:18 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:18 --> Controller Class Initialized
INFO - 2016-01-04 21:12:18 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 21:12:18 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:18 --> Total execution time: 0.1270
INFO - 2016-01-04 21:12:19 --> Config Class Initialized
INFO - 2016-01-04 21:12:19 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:19 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:19 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:19 --> URI Class Initialized
INFO - 2016-01-04 21:12:19 --> Router Class Initialized
INFO - 2016-01-04 21:12:19 --> Output Class Initialized
INFO - 2016-01-04 21:12:19 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:19 --> Input Class Initialized
INFO - 2016-01-04 21:12:19 --> Language Class Initialized
INFO - 2016-01-04 21:12:19 --> Loader Class Initialized
INFO - 2016-01-04 21:12:19 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:19 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:19 --> Controller Class Initialized
DEBUG - 2016-01-04 21:12:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:12:19 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:12:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:12:19 --> Model Class Initialized
INFO - 2016-01-04 21:12:19 --> Model Class Initialized
INFO - 2016-01-04 21:12:19 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:19 --> Total execution time: 0.0782
INFO - 2016-01-04 21:12:49 --> Config Class Initialized
INFO - 2016-01-04 21:12:49 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:49 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:49 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:49 --> URI Class Initialized
INFO - 2016-01-04 21:12:49 --> Router Class Initialized
INFO - 2016-01-04 21:12:49 --> Output Class Initialized
INFO - 2016-01-04 21:12:49 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:49 --> Input Class Initialized
INFO - 2016-01-04 21:12:49 --> Language Class Initialized
INFO - 2016-01-04 21:12:49 --> Loader Class Initialized
INFO - 2016-01-04 21:12:49 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:49 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:49 --> Controller Class Initialized
DEBUG - 2016-01-04 21:12:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:12:49 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:12:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:12:49 --> Model Class Initialized
INFO - 2016-01-04 21:12:49 --> Model Class Initialized
INFO - 2016-01-04 21:12:49 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:49 --> Total execution time: 0.0720
INFO - 2016-01-04 21:12:50 --> Config Class Initialized
INFO - 2016-01-04 21:12:50 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:50 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:50 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:50 --> URI Class Initialized
INFO - 2016-01-04 21:12:50 --> Router Class Initialized
INFO - 2016-01-04 21:12:50 --> Output Class Initialized
INFO - 2016-01-04 21:12:50 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:50 --> Input Class Initialized
INFO - 2016-01-04 21:12:50 --> Language Class Initialized
INFO - 2016-01-04 21:12:50 --> Loader Class Initialized
INFO - 2016-01-04 21:12:50 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:50 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:50 --> Controller Class Initialized
DEBUG - 2016-01-04 21:12:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:12:50 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:12:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:12:50 --> Model Class Initialized
INFO - 2016-01-04 21:12:50 --> Model Class Initialized
INFO - 2016-01-04 21:12:50 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:50 --> Total execution time: 0.0669
INFO - 2016-01-04 21:12:53 --> Config Class Initialized
INFO - 2016-01-04 21:12:53 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:53 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:53 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:53 --> URI Class Initialized
INFO - 2016-01-04 21:12:53 --> Router Class Initialized
INFO - 2016-01-04 21:12:53 --> Output Class Initialized
INFO - 2016-01-04 21:12:53 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:53 --> Input Class Initialized
INFO - 2016-01-04 21:12:53 --> Language Class Initialized
INFO - 2016-01-04 21:12:53 --> Loader Class Initialized
INFO - 2016-01-04 21:12:53 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:53 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:53 --> Controller Class Initialized
DEBUG - 2016-01-04 21:12:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:12:53 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:12:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:12:53 --> Model Class Initialized
INFO - 2016-01-04 21:12:53 --> Model Class Initialized
INFO - 2016-01-04 21:12:53 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:53 --> Total execution time: 0.0663
INFO - 2016-01-04 21:12:53 --> Config Class Initialized
INFO - 2016-01-04 21:12:53 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:53 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:53 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:53 --> URI Class Initialized
INFO - 2016-01-04 21:12:53 --> Router Class Initialized
INFO - 2016-01-04 21:12:53 --> Output Class Initialized
INFO - 2016-01-04 21:12:53 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:53 --> Input Class Initialized
INFO - 2016-01-04 21:12:53 --> Language Class Initialized
INFO - 2016-01-04 21:12:53 --> Loader Class Initialized
INFO - 2016-01-04 21:12:53 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:53 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:53 --> Controller Class Initialized
DEBUG - 2016-01-04 21:12:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:12:53 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:12:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:12:53 --> Model Class Initialized
INFO - 2016-01-04 21:12:53 --> Model Class Initialized
INFO - 2016-01-04 21:12:53 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:53 --> Total execution time: 0.1038
INFO - 2016-01-04 21:12:54 --> Config Class Initialized
INFO - 2016-01-04 21:12:54 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:54 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:54 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:54 --> URI Class Initialized
INFO - 2016-01-04 21:12:54 --> Router Class Initialized
INFO - 2016-01-04 21:12:54 --> Output Class Initialized
INFO - 2016-01-04 21:12:55 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:55 --> Input Class Initialized
INFO - 2016-01-04 21:12:55 --> Language Class Initialized
INFO - 2016-01-04 21:12:55 --> Loader Class Initialized
INFO - 2016-01-04 21:12:55 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:55 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:55 --> Controller Class Initialized
DEBUG - 2016-01-04 21:12:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:12:55 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:12:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:12:55 --> Model Class Initialized
INFO - 2016-01-04 21:12:55 --> Model Class Initialized
INFO - 2016-01-04 21:12:55 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:55 --> Total execution time: 0.0923
INFO - 2016-01-04 21:12:55 --> Config Class Initialized
INFO - 2016-01-04 21:12:55 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:55 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:55 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:55 --> URI Class Initialized
INFO - 2016-01-04 21:12:55 --> Router Class Initialized
INFO - 2016-01-04 21:12:55 --> Output Class Initialized
INFO - 2016-01-04 21:12:55 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:55 --> Input Class Initialized
INFO - 2016-01-04 21:12:55 --> Language Class Initialized
INFO - 2016-01-04 21:12:55 --> Loader Class Initialized
INFO - 2016-01-04 21:12:55 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:55 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:55 --> Controller Class Initialized
DEBUG - 2016-01-04 21:12:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:12:55 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:12:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:12:55 --> Model Class Initialized
INFO - 2016-01-04 21:12:55 --> Model Class Initialized
INFO - 2016-01-04 21:12:55 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:55 --> Total execution time: 0.1191
INFO - 2016-01-04 21:12:56 --> Config Class Initialized
INFO - 2016-01-04 21:12:56 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:56 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:56 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:56 --> URI Class Initialized
INFO - 2016-01-04 21:12:56 --> Router Class Initialized
INFO - 2016-01-04 21:12:56 --> Output Class Initialized
INFO - 2016-01-04 21:12:56 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:56 --> Input Class Initialized
INFO - 2016-01-04 21:12:56 --> Language Class Initialized
INFO - 2016-01-04 21:12:56 --> Loader Class Initialized
INFO - 2016-01-04 21:12:56 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:56 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:56 --> Controller Class Initialized
DEBUG - 2016-01-04 21:12:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:12:56 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:12:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:12:56 --> Model Class Initialized
INFO - 2016-01-04 21:12:56 --> Model Class Initialized
INFO - 2016-01-04 21:12:56 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:56 --> Total execution time: 0.0768
INFO - 2016-01-04 21:12:57 --> Config Class Initialized
INFO - 2016-01-04 21:12:57 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:57 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:57 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:57 --> URI Class Initialized
INFO - 2016-01-04 21:12:57 --> Router Class Initialized
INFO - 2016-01-04 21:12:57 --> Output Class Initialized
INFO - 2016-01-04 21:12:57 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:57 --> Input Class Initialized
INFO - 2016-01-04 21:12:57 --> Language Class Initialized
INFO - 2016-01-04 21:12:57 --> Loader Class Initialized
INFO - 2016-01-04 21:12:57 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:57 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:57 --> Controller Class Initialized
DEBUG - 2016-01-04 21:12:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:12:57 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:12:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:12:57 --> Model Class Initialized
INFO - 2016-01-04 21:12:57 --> Model Class Initialized
INFO - 2016-01-04 21:12:57 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:57 --> Total execution time: 0.0683
INFO - 2016-01-04 21:12:58 --> Config Class Initialized
INFO - 2016-01-04 21:12:58 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:58 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:58 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:58 --> URI Class Initialized
INFO - 2016-01-04 21:12:58 --> Router Class Initialized
INFO - 2016-01-04 21:12:58 --> Output Class Initialized
INFO - 2016-01-04 21:12:58 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:58 --> Input Class Initialized
INFO - 2016-01-04 21:12:58 --> Language Class Initialized
INFO - 2016-01-04 21:12:58 --> Loader Class Initialized
INFO - 2016-01-04 21:12:58 --> Helper loaded: url_helper
INFO - 2016-01-04 21:12:58 --> Database Driver Class Initialized
INFO - 2016-01-04 21:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:12:58 --> Controller Class Initialized
DEBUG - 2016-01-04 21:12:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:12:58 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:12:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:12:58 --> Model Class Initialized
INFO - 2016-01-04 21:12:58 --> Model Class Initialized
INFO - 2016-01-04 21:12:58 --> Final output sent to browser
DEBUG - 2016-01-04 21:12:58 --> Total execution time: 0.1148
INFO - 2016-01-04 21:12:59 --> Config Class Initialized
INFO - 2016-01-04 21:12:59 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:12:59 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:12:59 --> Utf8 Class Initialized
INFO - 2016-01-04 21:12:59 --> URI Class Initialized
INFO - 2016-01-04 21:12:59 --> Router Class Initialized
INFO - 2016-01-04 21:12:59 --> Output Class Initialized
INFO - 2016-01-04 21:12:59 --> Security Class Initialized
DEBUG - 2016-01-04 21:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:12:59 --> Input Class Initialized
INFO - 2016-01-04 21:12:59 --> Language Class Initialized
INFO - 2016-01-04 21:13:00 --> Loader Class Initialized
INFO - 2016-01-04 21:13:00 --> Helper loaded: url_helper
INFO - 2016-01-04 21:13:00 --> Database Driver Class Initialized
INFO - 2016-01-04 21:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:13:00 --> Controller Class Initialized
DEBUG - 2016-01-04 21:13:00 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:13:00 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:13:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:13:00 --> Model Class Initialized
INFO - 2016-01-04 21:13:00 --> Model Class Initialized
INFO - 2016-01-04 21:13:00 --> Final output sent to browser
DEBUG - 2016-01-04 21:13:00 --> Total execution time: 0.1199
INFO - 2016-01-04 21:13:02 --> Config Class Initialized
INFO - 2016-01-04 21:13:02 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:13:02 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:13:02 --> Utf8 Class Initialized
INFO - 2016-01-04 21:13:02 --> URI Class Initialized
INFO - 2016-01-04 21:13:02 --> Router Class Initialized
INFO - 2016-01-04 21:13:02 --> Output Class Initialized
INFO - 2016-01-04 21:13:02 --> Security Class Initialized
DEBUG - 2016-01-04 21:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:13:02 --> Input Class Initialized
INFO - 2016-01-04 21:13:02 --> Language Class Initialized
INFO - 2016-01-04 21:13:02 --> Loader Class Initialized
INFO - 2016-01-04 21:13:02 --> Helper loaded: url_helper
INFO - 2016-01-04 21:13:02 --> Database Driver Class Initialized
INFO - 2016-01-04 21:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:13:02 --> Controller Class Initialized
DEBUG - 2016-01-04 21:13:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:13:02 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:13:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:13:02 --> Model Class Initialized
INFO - 2016-01-04 21:13:02 --> Model Class Initialized
INFO - 2016-01-04 21:13:02 --> Final output sent to browser
DEBUG - 2016-01-04 21:13:02 --> Total execution time: 0.0644
INFO - 2016-01-04 21:13:02 --> Config Class Initialized
INFO - 2016-01-04 21:13:02 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:13:02 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:13:02 --> Utf8 Class Initialized
INFO - 2016-01-04 21:13:02 --> URI Class Initialized
INFO - 2016-01-04 21:13:02 --> Router Class Initialized
INFO - 2016-01-04 21:13:02 --> Output Class Initialized
INFO - 2016-01-04 21:13:02 --> Security Class Initialized
DEBUG - 2016-01-04 21:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:13:02 --> Input Class Initialized
INFO - 2016-01-04 21:13:02 --> Language Class Initialized
INFO - 2016-01-04 21:13:02 --> Loader Class Initialized
INFO - 2016-01-04 21:13:02 --> Helper loaded: url_helper
INFO - 2016-01-04 21:13:02 --> Database Driver Class Initialized
INFO - 2016-01-04 21:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:13:02 --> Controller Class Initialized
DEBUG - 2016-01-04 21:13:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:13:02 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:13:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:13:02 --> Model Class Initialized
INFO - 2016-01-04 21:13:02 --> Model Class Initialized
INFO - 2016-01-04 21:13:02 --> Final output sent to browser
DEBUG - 2016-01-04 21:13:02 --> Total execution time: 0.0642
INFO - 2016-01-04 21:13:04 --> Config Class Initialized
INFO - 2016-01-04 21:13:04 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:13:04 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:13:04 --> Utf8 Class Initialized
INFO - 2016-01-04 21:13:04 --> URI Class Initialized
INFO - 2016-01-04 21:13:04 --> Router Class Initialized
INFO - 2016-01-04 21:13:04 --> Output Class Initialized
INFO - 2016-01-04 21:13:04 --> Security Class Initialized
DEBUG - 2016-01-04 21:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:13:04 --> Input Class Initialized
INFO - 2016-01-04 21:13:04 --> Language Class Initialized
INFO - 2016-01-04 21:13:04 --> Loader Class Initialized
INFO - 2016-01-04 21:13:04 --> Helper loaded: url_helper
INFO - 2016-01-04 21:13:04 --> Database Driver Class Initialized
INFO - 2016-01-04 21:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:13:04 --> Controller Class Initialized
DEBUG - 2016-01-04 21:13:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:13:04 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:13:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:13:04 --> Model Class Initialized
INFO - 2016-01-04 21:13:04 --> Model Class Initialized
INFO - 2016-01-04 21:13:04 --> Final output sent to browser
DEBUG - 2016-01-04 21:13:04 --> Total execution time: 0.0663
INFO - 2016-01-04 21:13:05 --> Config Class Initialized
INFO - 2016-01-04 21:13:05 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:13:05 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:13:05 --> Utf8 Class Initialized
INFO - 2016-01-04 21:13:05 --> URI Class Initialized
INFO - 2016-01-04 21:13:05 --> Router Class Initialized
INFO - 2016-01-04 21:13:05 --> Output Class Initialized
INFO - 2016-01-04 21:13:05 --> Security Class Initialized
DEBUG - 2016-01-04 21:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:13:05 --> Input Class Initialized
INFO - 2016-01-04 21:13:05 --> Language Class Initialized
INFO - 2016-01-04 21:13:05 --> Loader Class Initialized
INFO - 2016-01-04 21:13:05 --> Helper loaded: url_helper
INFO - 2016-01-04 21:13:05 --> Database Driver Class Initialized
INFO - 2016-01-04 21:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:13:05 --> Controller Class Initialized
DEBUG - 2016-01-04 21:13:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:13:05 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:13:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:13:05 --> Model Class Initialized
INFO - 2016-01-04 21:13:05 --> Model Class Initialized
INFO - 2016-01-04 21:13:05 --> Final output sent to browser
DEBUG - 2016-01-04 21:13:05 --> Total execution time: 0.0669
INFO - 2016-01-04 21:13:06 --> Config Class Initialized
INFO - 2016-01-04 21:13:06 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:13:06 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:13:06 --> Utf8 Class Initialized
INFO - 2016-01-04 21:13:06 --> URI Class Initialized
INFO - 2016-01-04 21:13:06 --> Router Class Initialized
INFO - 2016-01-04 21:13:06 --> Output Class Initialized
INFO - 2016-01-04 21:13:06 --> Security Class Initialized
DEBUG - 2016-01-04 21:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:13:06 --> Input Class Initialized
INFO - 2016-01-04 21:13:06 --> Language Class Initialized
INFO - 2016-01-04 21:13:06 --> Loader Class Initialized
INFO - 2016-01-04 21:13:06 --> Helper loaded: url_helper
INFO - 2016-01-04 21:13:06 --> Database Driver Class Initialized
INFO - 2016-01-04 21:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:13:06 --> Controller Class Initialized
DEBUG - 2016-01-04 21:13:06 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:13:06 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:13:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:13:06 --> Model Class Initialized
INFO - 2016-01-04 21:13:06 --> Model Class Initialized
INFO - 2016-01-04 21:13:06 --> Final output sent to browser
DEBUG - 2016-01-04 21:13:06 --> Total execution time: 0.0671
INFO - 2016-01-04 21:13:07 --> Config Class Initialized
INFO - 2016-01-04 21:13:07 --> Hooks Class Initialized
DEBUG - 2016-01-04 21:13:07 --> UTF-8 Support Enabled
INFO - 2016-01-04 21:13:07 --> Utf8 Class Initialized
INFO - 2016-01-04 21:13:07 --> URI Class Initialized
INFO - 2016-01-04 21:13:07 --> Router Class Initialized
INFO - 2016-01-04 21:13:07 --> Output Class Initialized
INFO - 2016-01-04 21:13:07 --> Security Class Initialized
DEBUG - 2016-01-04 21:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 21:13:07 --> Input Class Initialized
INFO - 2016-01-04 21:13:07 --> Language Class Initialized
INFO - 2016-01-04 21:13:07 --> Loader Class Initialized
INFO - 2016-01-04 21:13:07 --> Helper loaded: url_helper
INFO - 2016-01-04 21:13:07 --> Database Driver Class Initialized
INFO - 2016-01-04 21:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 21:13:07 --> Controller Class Initialized
DEBUG - 2016-01-04 21:13:07 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 21:13:07 --> Helper loaded: inflector_helper
INFO - 2016-01-04 21:13:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 21:13:07 --> Model Class Initialized
INFO - 2016-01-04 21:13:07 --> Model Class Initialized
INFO - 2016-01-04 21:13:07 --> Final output sent to browser
DEBUG - 2016-01-04 21:13:07 --> Total execution time: 0.1265
INFO - 2016-01-04 22:45:36 --> Config Class Initialized
INFO - 2016-01-04 22:45:36 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:45:36 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:45:36 --> Utf8 Class Initialized
INFO - 2016-01-04 22:45:36 --> URI Class Initialized
INFO - 2016-01-04 22:45:36 --> Router Class Initialized
INFO - 2016-01-04 22:45:36 --> Output Class Initialized
INFO - 2016-01-04 22:45:36 --> Security Class Initialized
DEBUG - 2016-01-04 22:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:45:36 --> Input Class Initialized
INFO - 2016-01-04 22:45:36 --> Language Class Initialized
INFO - 2016-01-04 22:45:36 --> Loader Class Initialized
INFO - 2016-01-04 22:45:36 --> Helper loaded: url_helper
INFO - 2016-01-04 22:45:36 --> Database Driver Class Initialized
INFO - 2016-01-04 22:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:45:36 --> Controller Class Initialized
INFO - 2016-01-04 22:45:36 --> Helper loaded: form_helper
INFO - 2016-01-04 22:45:36 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 22:45:36 --> Final output sent to browser
DEBUG - 2016-01-04 22:45:36 --> Total execution time: 0.0877
INFO - 2016-01-04 22:45:42 --> Config Class Initialized
INFO - 2016-01-04 22:45:42 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:45:42 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:45:42 --> Utf8 Class Initialized
INFO - 2016-01-04 22:45:42 --> URI Class Initialized
INFO - 2016-01-04 22:45:42 --> Router Class Initialized
INFO - 2016-01-04 22:45:42 --> Output Class Initialized
INFO - 2016-01-04 22:45:42 --> Security Class Initialized
DEBUG - 2016-01-04 22:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:45:42 --> Input Class Initialized
INFO - 2016-01-04 22:45:42 --> Language Class Initialized
INFO - 2016-01-04 22:45:42 --> Loader Class Initialized
INFO - 2016-01-04 22:45:42 --> Helper loaded: url_helper
INFO - 2016-01-04 22:45:42 --> Database Driver Class Initialized
INFO - 2016-01-04 22:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:45:42 --> Controller Class Initialized
INFO - 2016-01-04 22:45:42 --> Model Class Initialized
INFO - 2016-01-04 22:45:42 --> Model Class Initialized
INFO - 2016-01-04 22:45:42 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 22:45:42 --> Final output sent to browser
DEBUG - 2016-01-04 22:45:42 --> Total execution time: 0.0949
INFO - 2016-01-04 22:45:52 --> Config Class Initialized
INFO - 2016-01-04 22:45:52 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:45:52 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:45:52 --> Utf8 Class Initialized
INFO - 2016-01-04 22:45:52 --> URI Class Initialized
INFO - 2016-01-04 22:45:52 --> Router Class Initialized
INFO - 2016-01-04 22:45:52 --> Output Class Initialized
INFO - 2016-01-04 22:45:52 --> Security Class Initialized
DEBUG - 2016-01-04 22:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:45:52 --> Input Class Initialized
INFO - 2016-01-04 22:45:52 --> Language Class Initialized
INFO - 2016-01-04 22:45:52 --> Loader Class Initialized
INFO - 2016-01-04 22:45:52 --> Helper loaded: url_helper
INFO - 2016-01-04 22:45:52 --> Database Driver Class Initialized
INFO - 2016-01-04 22:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:45:52 --> Controller Class Initialized
INFO - 2016-01-04 22:45:52 --> Model Class Initialized
INFO - 2016-01-04 22:45:52 --> Model Class Initialized
INFO - 2016-01-04 22:45:52 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 22:45:52 --> Final output sent to browser
DEBUG - 2016-01-04 22:45:52 --> Total execution time: 0.0725
INFO - 2016-01-04 22:45:52 --> Config Class Initialized
INFO - 2016-01-04 22:45:52 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:45:52 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:45:52 --> Utf8 Class Initialized
INFO - 2016-01-04 22:45:52 --> URI Class Initialized
INFO - 2016-01-04 22:45:52 --> Router Class Initialized
INFO - 2016-01-04 22:45:52 --> Output Class Initialized
INFO - 2016-01-04 22:45:52 --> Security Class Initialized
DEBUG - 2016-01-04 22:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:45:52 --> Input Class Initialized
INFO - 2016-01-04 22:45:52 --> Language Class Initialized
INFO - 2016-01-04 22:45:52 --> Loader Class Initialized
INFO - 2016-01-04 22:45:52 --> Helper loaded: url_helper
INFO - 2016-01-04 22:45:52 --> Database Driver Class Initialized
INFO - 2016-01-04 22:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:45:52 --> Controller Class Initialized
INFO - 2016-01-04 22:45:52 --> Model Class Initialized
INFO - 2016-01-04 22:45:52 --> Model Class Initialized
INFO - 2016-01-04 22:45:52 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-04 22:45:52 --> Final output sent to browser
DEBUG - 2016-01-04 22:45:52 --> Total execution time: 0.0798
INFO - 2016-01-04 22:45:52 --> Config Class Initialized
INFO - 2016-01-04 22:45:52 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:45:52 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:45:52 --> Utf8 Class Initialized
INFO - 2016-01-04 22:45:52 --> URI Class Initialized
INFO - 2016-01-04 22:45:52 --> Router Class Initialized
INFO - 2016-01-04 22:45:52 --> Output Class Initialized
INFO - 2016-01-04 22:45:52 --> Security Class Initialized
DEBUG - 2016-01-04 22:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:45:52 --> Input Class Initialized
INFO - 2016-01-04 22:45:52 --> Language Class Initialized
INFO - 2016-01-04 22:45:52 --> Loader Class Initialized
INFO - 2016-01-04 22:45:52 --> Helper loaded: url_helper
INFO - 2016-01-04 22:45:52 --> Database Driver Class Initialized
INFO - 2016-01-04 22:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:45:52 --> Controller Class Initialized
DEBUG - 2016-01-04 22:45:52 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 22:45:52 --> Helper loaded: inflector_helper
INFO - 2016-01-04 22:45:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 22:45:52 --> Model Class Initialized
INFO - 2016-01-04 22:45:52 --> Model Class Initialized
INFO - 2016-01-04 22:45:52 --> Final output sent to browser
DEBUG - 2016-01-04 22:45:52 --> Total execution time: 0.0842
INFO - 2016-01-04 22:46:17 --> Config Class Initialized
INFO - 2016-01-04 22:46:17 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:46:17 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:46:17 --> Utf8 Class Initialized
INFO - 2016-01-04 22:46:17 --> URI Class Initialized
INFO - 2016-01-04 22:46:17 --> Router Class Initialized
INFO - 2016-01-04 22:46:17 --> Output Class Initialized
INFO - 2016-01-04 22:46:17 --> Security Class Initialized
DEBUG - 2016-01-04 22:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:46:17 --> Input Class Initialized
INFO - 2016-01-04 22:46:17 --> Language Class Initialized
INFO - 2016-01-04 22:46:17 --> Loader Class Initialized
INFO - 2016-01-04 22:46:17 --> Helper loaded: url_helper
INFO - 2016-01-04 22:46:17 --> Database Driver Class Initialized
INFO - 2016-01-04 22:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:46:17 --> Controller Class Initialized
INFO - 2016-01-04 22:46:17 --> Model Class Initialized
INFO - 2016-01-04 22:46:17 --> Model Class Initialized
INFO - 2016-01-04 22:46:17 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 22:46:17 --> Final output sent to browser
DEBUG - 2016-01-04 22:46:17 --> Total execution time: 0.0703
INFO - 2016-01-04 22:46:17 --> Config Class Initialized
INFO - 2016-01-04 22:46:17 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:46:17 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:46:17 --> Utf8 Class Initialized
INFO - 2016-01-04 22:46:17 --> URI Class Initialized
INFO - 2016-01-04 22:46:17 --> Router Class Initialized
INFO - 2016-01-04 22:46:17 --> Output Class Initialized
INFO - 2016-01-04 22:46:17 --> Security Class Initialized
DEBUG - 2016-01-04 22:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:46:17 --> Input Class Initialized
INFO - 2016-01-04 22:46:17 --> Language Class Initialized
INFO - 2016-01-04 22:46:17 --> Loader Class Initialized
INFO - 2016-01-04 22:46:17 --> Helper loaded: url_helper
INFO - 2016-01-04 22:46:17 --> Database Driver Class Initialized
INFO - 2016-01-04 22:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:46:17 --> Controller Class Initialized
INFO - 2016-01-04 22:46:17 --> Model Class Initialized
INFO - 2016-01-04 22:46:17 --> Model Class Initialized
INFO - 2016-01-04 22:46:17 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-04 22:46:17 --> Final output sent to browser
DEBUG - 2016-01-04 22:46:17 --> Total execution time: 0.0973
INFO - 2016-01-04 22:46:17 --> Config Class Initialized
INFO - 2016-01-04 22:46:17 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:46:17 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:46:17 --> Utf8 Class Initialized
INFO - 2016-01-04 22:46:17 --> URI Class Initialized
INFO - 2016-01-04 22:46:17 --> Router Class Initialized
INFO - 2016-01-04 22:46:17 --> Output Class Initialized
INFO - 2016-01-04 22:46:17 --> Security Class Initialized
DEBUG - 2016-01-04 22:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:46:17 --> Input Class Initialized
INFO - 2016-01-04 22:46:17 --> Language Class Initialized
INFO - 2016-01-04 22:46:17 --> Loader Class Initialized
INFO - 2016-01-04 22:46:17 --> Helper loaded: url_helper
INFO - 2016-01-04 22:46:17 --> Database Driver Class Initialized
INFO - 2016-01-04 22:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:46:17 --> Controller Class Initialized
DEBUG - 2016-01-04 22:46:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 22:46:17 --> Helper loaded: inflector_helper
INFO - 2016-01-04 22:46:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 22:46:17 --> Model Class Initialized
INFO - 2016-01-04 22:46:17 --> Model Class Initialized
INFO - 2016-01-04 22:46:17 --> Final output sent to browser
DEBUG - 2016-01-04 22:46:17 --> Total execution time: 0.0996
INFO - 2016-01-04 22:46:32 --> Config Class Initialized
INFO - 2016-01-04 22:46:32 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:46:32 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:46:32 --> Utf8 Class Initialized
INFO - 2016-01-04 22:46:32 --> URI Class Initialized
INFO - 2016-01-04 22:46:32 --> Router Class Initialized
INFO - 2016-01-04 22:46:32 --> Output Class Initialized
INFO - 2016-01-04 22:46:32 --> Security Class Initialized
DEBUG - 2016-01-04 22:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:46:32 --> Input Class Initialized
INFO - 2016-01-04 22:46:32 --> Language Class Initialized
INFO - 2016-01-04 22:46:32 --> Loader Class Initialized
INFO - 2016-01-04 22:46:32 --> Helper loaded: url_helper
INFO - 2016-01-04 22:46:32 --> Database Driver Class Initialized
INFO - 2016-01-04 22:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:46:32 --> Controller Class Initialized
DEBUG - 2016-01-04 22:46:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 22:46:32 --> Helper loaded: inflector_helper
INFO - 2016-01-04 22:46:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 22:46:32 --> Model Class Initialized
INFO - 2016-01-04 22:46:32 --> Model Class Initialized
INFO - 2016-01-04 22:46:32 --> Final output sent to browser
DEBUG - 2016-01-04 22:46:32 --> Total execution time: 0.0762
INFO - 2016-01-04 22:46:34 --> Config Class Initialized
INFO - 2016-01-04 22:46:34 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:46:34 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:46:34 --> Utf8 Class Initialized
INFO - 2016-01-04 22:46:34 --> URI Class Initialized
INFO - 2016-01-04 22:46:34 --> Router Class Initialized
INFO - 2016-01-04 22:46:34 --> Output Class Initialized
INFO - 2016-01-04 22:46:34 --> Security Class Initialized
DEBUG - 2016-01-04 22:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:46:34 --> Input Class Initialized
INFO - 2016-01-04 22:46:34 --> Language Class Initialized
INFO - 2016-01-04 22:46:34 --> Loader Class Initialized
INFO - 2016-01-04 22:46:34 --> Helper loaded: url_helper
INFO - 2016-01-04 22:46:34 --> Database Driver Class Initialized
INFO - 2016-01-04 22:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:46:34 --> Controller Class Initialized
DEBUG - 2016-01-04 22:46:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 22:46:34 --> Helper loaded: inflector_helper
INFO - 2016-01-04 22:46:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 22:46:34 --> Model Class Initialized
INFO - 2016-01-04 22:46:34 --> Model Class Initialized
INFO - 2016-01-04 22:46:34 --> Final output sent to browser
DEBUG - 2016-01-04 22:46:34 --> Total execution time: 0.0985
INFO - 2016-01-04 22:49:05 --> Config Class Initialized
INFO - 2016-01-04 22:49:05 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:49:05 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:49:05 --> Utf8 Class Initialized
INFO - 2016-01-04 22:49:05 --> URI Class Initialized
DEBUG - 2016-01-04 22:49:05 --> No URI present. Default controller set.
INFO - 2016-01-04 22:49:05 --> Router Class Initialized
INFO - 2016-01-04 22:49:05 --> Output Class Initialized
INFO - 2016-01-04 22:49:05 --> Security Class Initialized
DEBUG - 2016-01-04 22:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:49:05 --> Input Class Initialized
INFO - 2016-01-04 22:49:05 --> Language Class Initialized
INFO - 2016-01-04 22:49:05 --> Loader Class Initialized
INFO - 2016-01-04 22:49:05 --> Helper loaded: url_helper
INFO - 2016-01-04 22:49:05 --> Database Driver Class Initialized
INFO - 2016-01-04 22:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:49:05 --> Controller Class Initialized
INFO - 2016-01-04 22:49:05 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 22:49:05 --> Final output sent to browser
DEBUG - 2016-01-04 22:49:05 --> Total execution time: 0.0878
INFO - 2016-01-04 22:49:13 --> Config Class Initialized
INFO - 2016-01-04 22:49:13 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:49:13 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:49:13 --> Utf8 Class Initialized
INFO - 2016-01-04 22:49:13 --> URI Class Initialized
INFO - 2016-01-04 22:49:13 --> Router Class Initialized
INFO - 2016-01-04 22:49:13 --> Output Class Initialized
INFO - 2016-01-04 22:49:13 --> Security Class Initialized
DEBUG - 2016-01-04 22:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:49:13 --> Input Class Initialized
INFO - 2016-01-04 22:49:13 --> Language Class Initialized
INFO - 2016-01-04 22:49:13 --> Loader Class Initialized
INFO - 2016-01-04 22:49:13 --> Helper loaded: url_helper
INFO - 2016-01-04 22:49:13 --> Database Driver Class Initialized
INFO - 2016-01-04 22:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:49:13 --> Controller Class Initialized
INFO - 2016-01-04 22:49:13 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-04 22:49:13 --> Final output sent to browser
DEBUG - 2016-01-04 22:49:13 --> Total execution time: 0.0680
INFO - 2016-01-04 22:49:14 --> Config Class Initialized
INFO - 2016-01-04 22:49:14 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:49:14 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:49:14 --> Utf8 Class Initialized
INFO - 2016-01-04 22:49:14 --> URI Class Initialized
INFO - 2016-01-04 22:49:14 --> Router Class Initialized
INFO - 2016-01-04 22:49:14 --> Output Class Initialized
INFO - 2016-01-04 22:49:14 --> Security Class Initialized
DEBUG - 2016-01-04 22:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:49:14 --> Input Class Initialized
INFO - 2016-01-04 22:49:14 --> Language Class Initialized
INFO - 2016-01-04 22:49:14 --> Loader Class Initialized
INFO - 2016-01-04 22:49:14 --> Helper loaded: url_helper
INFO - 2016-01-04 22:49:14 --> Database Driver Class Initialized
INFO - 2016-01-04 22:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:49:14 --> Controller Class Initialized
DEBUG - 2016-01-04 22:49:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 22:49:14 --> Helper loaded: inflector_helper
INFO - 2016-01-04 22:49:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 22:49:14 --> Model Class Initialized
INFO - 2016-01-04 22:49:14 --> Model Class Initialized
INFO - 2016-01-04 22:49:14 --> Final output sent to browser
DEBUG - 2016-01-04 22:49:14 --> Total execution time: 0.0885
INFO - 2016-01-04 22:50:15 --> Config Class Initialized
INFO - 2016-01-04 22:50:15 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:50:15 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:50:15 --> Utf8 Class Initialized
INFO - 2016-01-04 22:50:15 --> URI Class Initialized
INFO - 2016-01-04 22:50:15 --> Router Class Initialized
INFO - 2016-01-04 22:50:15 --> Output Class Initialized
INFO - 2016-01-04 22:50:15 --> Security Class Initialized
DEBUG - 2016-01-04 22:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:50:15 --> Input Class Initialized
INFO - 2016-01-04 22:50:15 --> Language Class Initialized
INFO - 2016-01-04 22:50:15 --> Loader Class Initialized
INFO - 2016-01-04 22:50:15 --> Helper loaded: url_helper
INFO - 2016-01-04 22:50:15 --> Database Driver Class Initialized
INFO - 2016-01-04 22:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:50:15 --> Controller Class Initialized
DEBUG - 2016-01-04 22:50:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 22:50:15 --> Helper loaded: inflector_helper
INFO - 2016-01-04 22:50:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 22:50:15 --> Model Class Initialized
INFO - 2016-01-04 22:50:15 --> Model Class Initialized
INFO - 2016-01-04 22:50:15 --> Final output sent to browser
DEBUG - 2016-01-04 22:50:15 --> Total execution time: 0.1415
INFO - 2016-01-04 22:50:18 --> Config Class Initialized
INFO - 2016-01-04 22:50:18 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:50:18 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:50:18 --> Utf8 Class Initialized
INFO - 2016-01-04 22:50:18 --> URI Class Initialized
INFO - 2016-01-04 22:50:18 --> Router Class Initialized
INFO - 2016-01-04 22:50:18 --> Output Class Initialized
INFO - 2016-01-04 22:50:18 --> Security Class Initialized
DEBUG - 2016-01-04 22:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:50:18 --> Input Class Initialized
INFO - 2016-01-04 22:50:18 --> Language Class Initialized
INFO - 2016-01-04 22:50:18 --> Loader Class Initialized
INFO - 2016-01-04 22:50:18 --> Helper loaded: url_helper
INFO - 2016-01-04 22:50:18 --> Database Driver Class Initialized
INFO - 2016-01-04 22:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:50:18 --> Controller Class Initialized
DEBUG - 2016-01-04 22:50:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 22:50:18 --> Helper loaded: inflector_helper
INFO - 2016-01-04 22:50:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 22:50:18 --> Model Class Initialized
INFO - 2016-01-04 22:50:18 --> Model Class Initialized
INFO - 2016-01-04 22:50:18 --> Final output sent to browser
DEBUG - 2016-01-04 22:50:18 --> Total execution time: 0.1249
INFO - 2016-01-04 22:51:19 --> Config Class Initialized
INFO - 2016-01-04 22:51:19 --> Hooks Class Initialized
DEBUG - 2016-01-04 22:51:19 --> UTF-8 Support Enabled
INFO - 2016-01-04 22:51:19 --> Utf8 Class Initialized
INFO - 2016-01-04 22:51:19 --> URI Class Initialized
INFO - 2016-01-04 22:51:19 --> Router Class Initialized
INFO - 2016-01-04 22:51:19 --> Output Class Initialized
INFO - 2016-01-04 22:51:19 --> Security Class Initialized
DEBUG - 2016-01-04 22:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 22:51:19 --> Input Class Initialized
INFO - 2016-01-04 22:51:19 --> Language Class Initialized
INFO - 2016-01-04 22:51:19 --> Loader Class Initialized
INFO - 2016-01-04 22:51:19 --> Helper loaded: url_helper
INFO - 2016-01-04 22:51:19 --> Database Driver Class Initialized
INFO - 2016-01-04 22:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 22:51:19 --> Controller Class Initialized
DEBUG - 2016-01-04 22:51:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 22:51:19 --> Helper loaded: inflector_helper
INFO - 2016-01-04 22:51:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 22:51:19 --> Model Class Initialized
INFO - 2016-01-04 22:51:19 --> Model Class Initialized
INFO - 2016-01-04 22:51:19 --> Final output sent to browser
DEBUG - 2016-01-04 22:51:19 --> Total execution time: 0.1473
INFO - 2016-01-04 23:00:19 --> Config Class Initialized
INFO - 2016-01-04 23:00:19 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:00:19 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:00:19 --> Utf8 Class Initialized
INFO - 2016-01-04 23:00:19 --> URI Class Initialized
INFO - 2016-01-04 23:00:19 --> Router Class Initialized
INFO - 2016-01-04 23:00:19 --> Output Class Initialized
INFO - 2016-01-04 23:00:19 --> Security Class Initialized
DEBUG - 2016-01-04 23:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:00:19 --> Input Class Initialized
INFO - 2016-01-04 23:00:19 --> Language Class Initialized
INFO - 2016-01-04 23:00:19 --> Loader Class Initialized
INFO - 2016-01-04 23:00:19 --> Helper loaded: url_helper
INFO - 2016-01-04 23:00:20 --> Database Driver Class Initialized
INFO - 2016-01-04 23:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:00:20 --> Controller Class Initialized
DEBUG - 2016-01-04 23:00:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:00:20 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:00:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:00:20 --> Model Class Initialized
INFO - 2016-01-04 23:00:20 --> Model Class Initialized
INFO - 2016-01-04 23:00:20 --> Final output sent to browser
DEBUG - 2016-01-04 23:00:20 --> Total execution time: 0.1416
INFO - 2016-01-04 23:01:09 --> Config Class Initialized
INFO - 2016-01-04 23:01:09 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:09 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:09 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:09 --> URI Class Initialized
INFO - 2016-01-04 23:01:09 --> Router Class Initialized
INFO - 2016-01-04 23:01:09 --> Output Class Initialized
INFO - 2016-01-04 23:01:09 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:09 --> Input Class Initialized
INFO - 2016-01-04 23:01:09 --> Language Class Initialized
INFO - 2016-01-04 23:01:09 --> Loader Class Initialized
INFO - 2016-01-04 23:01:09 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:09 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:09 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:09 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:09 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:09 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:09 --> Model Class Initialized
INFO - 2016-01-04 23:01:09 --> Model Class Initialized
INFO - 2016-01-04 23:01:09 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:09 --> Total execution time: 0.1617
INFO - 2016-01-04 23:01:10 --> Config Class Initialized
INFO - 2016-01-04 23:01:10 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:10 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:10 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:10 --> URI Class Initialized
INFO - 2016-01-04 23:01:10 --> Router Class Initialized
INFO - 2016-01-04 23:01:10 --> Output Class Initialized
INFO - 2016-01-04 23:01:10 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:10 --> Input Class Initialized
INFO - 2016-01-04 23:01:10 --> Language Class Initialized
INFO - 2016-01-04 23:01:10 --> Loader Class Initialized
INFO - 2016-01-04 23:01:10 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:10 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:10 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:10 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:10 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:10 --> Model Class Initialized
INFO - 2016-01-04 23:01:10 --> Model Class Initialized
INFO - 2016-01-04 23:01:10 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:10 --> Total execution time: 0.0964
INFO - 2016-01-04 23:01:12 --> Config Class Initialized
INFO - 2016-01-04 23:01:12 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:12 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:12 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:12 --> URI Class Initialized
INFO - 2016-01-04 23:01:12 --> Router Class Initialized
INFO - 2016-01-04 23:01:12 --> Output Class Initialized
INFO - 2016-01-04 23:01:12 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:12 --> Input Class Initialized
INFO - 2016-01-04 23:01:12 --> Language Class Initialized
INFO - 2016-01-04 23:01:12 --> Loader Class Initialized
INFO - 2016-01-04 23:01:12 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:12 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:12 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:12 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:12 --> Model Class Initialized
INFO - 2016-01-04 23:01:12 --> Model Class Initialized
INFO - 2016-01-04 23:01:12 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:12 --> Total execution time: 0.1077
INFO - 2016-01-04 23:01:12 --> Config Class Initialized
INFO - 2016-01-04 23:01:12 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:12 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:12 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:12 --> URI Class Initialized
INFO - 2016-01-04 23:01:12 --> Router Class Initialized
INFO - 2016-01-04 23:01:12 --> Output Class Initialized
INFO - 2016-01-04 23:01:12 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:12 --> Input Class Initialized
INFO - 2016-01-04 23:01:12 --> Language Class Initialized
INFO - 2016-01-04 23:01:12 --> Loader Class Initialized
INFO - 2016-01-04 23:01:12 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:12 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:12 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:12 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:12 --> Model Class Initialized
INFO - 2016-01-04 23:01:12 --> Model Class Initialized
INFO - 2016-01-04 23:01:12 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:12 --> Total execution time: 0.1064
INFO - 2016-01-04 23:01:14 --> Config Class Initialized
INFO - 2016-01-04 23:01:14 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:14 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:14 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:14 --> URI Class Initialized
INFO - 2016-01-04 23:01:14 --> Router Class Initialized
INFO - 2016-01-04 23:01:14 --> Output Class Initialized
INFO - 2016-01-04 23:01:14 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:14 --> Input Class Initialized
INFO - 2016-01-04 23:01:14 --> Language Class Initialized
INFO - 2016-01-04 23:01:14 --> Loader Class Initialized
INFO - 2016-01-04 23:01:14 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:14 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:14 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:14 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:14 --> Model Class Initialized
INFO - 2016-01-04 23:01:14 --> Model Class Initialized
INFO - 2016-01-04 23:01:14 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:14 --> Total execution time: 0.1300
INFO - 2016-01-04 23:01:15 --> Config Class Initialized
INFO - 2016-01-04 23:01:15 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:15 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:15 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:15 --> URI Class Initialized
INFO - 2016-01-04 23:01:15 --> Router Class Initialized
INFO - 2016-01-04 23:01:15 --> Output Class Initialized
INFO - 2016-01-04 23:01:15 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:15 --> Input Class Initialized
INFO - 2016-01-04 23:01:15 --> Language Class Initialized
INFO - 2016-01-04 23:01:15 --> Loader Class Initialized
INFO - 2016-01-04 23:01:15 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:15 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:15 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:15 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:15 --> Model Class Initialized
INFO - 2016-01-04 23:01:15 --> Model Class Initialized
INFO - 2016-01-04 23:01:15 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:15 --> Total execution time: 0.0886
INFO - 2016-01-04 23:01:16 --> Config Class Initialized
INFO - 2016-01-04 23:01:16 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:16 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:16 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:16 --> URI Class Initialized
INFO - 2016-01-04 23:01:16 --> Router Class Initialized
INFO - 2016-01-04 23:01:16 --> Output Class Initialized
INFO - 2016-01-04 23:01:16 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:16 --> Input Class Initialized
INFO - 2016-01-04 23:01:16 --> Language Class Initialized
INFO - 2016-01-04 23:01:16 --> Loader Class Initialized
INFO - 2016-01-04 23:01:16 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:16 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:16 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:16 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:16 --> Model Class Initialized
INFO - 2016-01-04 23:01:16 --> Model Class Initialized
INFO - 2016-01-04 23:01:16 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:16 --> Total execution time: 0.0740
INFO - 2016-01-04 23:01:17 --> Config Class Initialized
INFO - 2016-01-04 23:01:17 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:17 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:17 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:17 --> URI Class Initialized
INFO - 2016-01-04 23:01:17 --> Router Class Initialized
INFO - 2016-01-04 23:01:17 --> Output Class Initialized
INFO - 2016-01-04 23:01:17 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:17 --> Input Class Initialized
INFO - 2016-01-04 23:01:17 --> Language Class Initialized
INFO - 2016-01-04 23:01:17 --> Loader Class Initialized
INFO - 2016-01-04 23:01:17 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:17 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:17 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:17 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:17 --> Model Class Initialized
INFO - 2016-01-04 23:01:17 --> Model Class Initialized
INFO - 2016-01-04 23:01:17 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:17 --> Total execution time: 0.1038
INFO - 2016-01-04 23:01:18 --> Config Class Initialized
INFO - 2016-01-04 23:01:18 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:18 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:18 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:18 --> URI Class Initialized
INFO - 2016-01-04 23:01:18 --> Router Class Initialized
INFO - 2016-01-04 23:01:18 --> Output Class Initialized
INFO - 2016-01-04 23:01:18 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:18 --> Input Class Initialized
INFO - 2016-01-04 23:01:18 --> Language Class Initialized
INFO - 2016-01-04 23:01:18 --> Loader Class Initialized
INFO - 2016-01-04 23:01:18 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:18 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:19 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:19 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:19 --> Model Class Initialized
INFO - 2016-01-04 23:01:19 --> Model Class Initialized
INFO - 2016-01-04 23:01:19 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:19 --> Total execution time: 0.0844
INFO - 2016-01-04 23:01:19 --> Config Class Initialized
INFO - 2016-01-04 23:01:19 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:19 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:19 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:19 --> URI Class Initialized
INFO - 2016-01-04 23:01:19 --> Router Class Initialized
INFO - 2016-01-04 23:01:19 --> Output Class Initialized
INFO - 2016-01-04 23:01:19 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:19 --> Input Class Initialized
INFO - 2016-01-04 23:01:19 --> Language Class Initialized
INFO - 2016-01-04 23:01:19 --> Loader Class Initialized
INFO - 2016-01-04 23:01:19 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:19 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:19 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:19 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:19 --> Model Class Initialized
INFO - 2016-01-04 23:01:19 --> Model Class Initialized
INFO - 2016-01-04 23:01:19 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:19 --> Total execution time: 0.0860
INFO - 2016-01-04 23:01:23 --> Config Class Initialized
INFO - 2016-01-04 23:01:23 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:23 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:23 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:23 --> URI Class Initialized
INFO - 2016-01-04 23:01:23 --> Router Class Initialized
INFO - 2016-01-04 23:01:23 --> Output Class Initialized
INFO - 2016-01-04 23:01:23 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:23 --> Input Class Initialized
INFO - 2016-01-04 23:01:23 --> Language Class Initialized
INFO - 2016-01-04 23:01:23 --> Loader Class Initialized
INFO - 2016-01-04 23:01:23 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:23 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:23 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:23 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:23 --> Model Class Initialized
INFO - 2016-01-04 23:01:23 --> Model Class Initialized
INFO - 2016-01-04 23:01:23 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:23 --> Total execution time: 0.1347
INFO - 2016-01-04 23:01:24 --> Config Class Initialized
INFO - 2016-01-04 23:01:24 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:24 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:24 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:24 --> URI Class Initialized
INFO - 2016-01-04 23:01:24 --> Router Class Initialized
INFO - 2016-01-04 23:01:24 --> Output Class Initialized
INFO - 2016-01-04 23:01:24 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:24 --> Input Class Initialized
INFO - 2016-01-04 23:01:24 --> Language Class Initialized
INFO - 2016-01-04 23:01:24 --> Loader Class Initialized
INFO - 2016-01-04 23:01:24 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:24 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:24 --> Controller Class Initialized
DEBUG - 2016-01-04 23:01:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-04 23:01:24 --> Helper loaded: inflector_helper
INFO - 2016-01-04 23:01:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-04 23:01:24 --> Model Class Initialized
INFO - 2016-01-04 23:01:24 --> Model Class Initialized
INFO - 2016-01-04 23:01:24 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:24 --> Total execution time: 0.1448
INFO - 2016-01-04 23:01:27 --> Config Class Initialized
INFO - 2016-01-04 23:01:27 --> Hooks Class Initialized
DEBUG - 2016-01-04 23:01:27 --> UTF-8 Support Enabled
INFO - 2016-01-04 23:01:27 --> Utf8 Class Initialized
INFO - 2016-01-04 23:01:27 --> URI Class Initialized
DEBUG - 2016-01-04 23:01:27 --> No URI present. Default controller set.
INFO - 2016-01-04 23:01:27 --> Router Class Initialized
INFO - 2016-01-04 23:01:27 --> Output Class Initialized
INFO - 2016-01-04 23:01:27 --> Security Class Initialized
DEBUG - 2016-01-04 23:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-04 23:01:27 --> Input Class Initialized
INFO - 2016-01-04 23:01:27 --> Language Class Initialized
INFO - 2016-01-04 23:01:27 --> Loader Class Initialized
INFO - 2016-01-04 23:01:27 --> Helper loaded: url_helper
INFO - 2016-01-04 23:01:27 --> Database Driver Class Initialized
INFO - 2016-01-04 23:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-04 23:01:27 --> Controller Class Initialized
INFO - 2016-01-04 23:01:27 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-04 23:01:27 --> Final output sent to browser
DEBUG - 2016-01-04 23:01:27 --> Total execution time: 0.0650
