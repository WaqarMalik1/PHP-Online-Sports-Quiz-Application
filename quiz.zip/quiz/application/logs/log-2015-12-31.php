<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2015-12-31 06:33:51 --> Config Class Initialized
INFO - 2015-12-31 06:33:52 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:33:52 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:33:52 --> Utf8 Class Initialized
INFO - 2015-12-31 06:33:52 --> URI Class Initialized
DEBUG - 2015-12-31 06:33:52 --> No URI present. Default controller set.
INFO - 2015-12-31 06:33:52 --> Router Class Initialized
INFO - 2015-12-31 06:33:52 --> Output Class Initialized
INFO - 2015-12-31 06:33:52 --> Security Class Initialized
DEBUG - 2015-12-31 06:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:33:52 --> Input Class Initialized
INFO - 2015-12-31 06:33:52 --> Language Class Initialized
INFO - 2015-12-31 06:33:52 --> Loader Class Initialized
INFO - 2015-12-31 06:33:52 --> Helper loaded: url_helper
INFO - 2015-12-31 06:33:52 --> Database Driver Class Initialized
INFO - 2015-12-31 06:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:33:52 --> Controller Class Initialized
INFO - 2015-12-31 06:33:52 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-31 06:33:52 --> Final output sent to browser
DEBUG - 2015-12-31 06:33:52 --> Total execution time: 0.4370
INFO - 2015-12-31 06:33:57 --> Config Class Initialized
INFO - 2015-12-31 06:33:57 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:33:57 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:33:57 --> Utf8 Class Initialized
INFO - 2015-12-31 06:33:57 --> URI Class Initialized
INFO - 2015-12-31 06:33:57 --> Router Class Initialized
INFO - 2015-12-31 06:33:57 --> Output Class Initialized
INFO - 2015-12-31 06:33:57 --> Security Class Initialized
DEBUG - 2015-12-31 06:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:33:57 --> Input Class Initialized
INFO - 2015-12-31 06:33:57 --> Language Class Initialized
INFO - 2015-12-31 06:33:57 --> Loader Class Initialized
INFO - 2015-12-31 06:33:57 --> Helper loaded: url_helper
INFO - 2015-12-31 06:33:57 --> Database Driver Class Initialized
INFO - 2015-12-31 06:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:33:57 --> Controller Class Initialized
INFO - 2015-12-31 06:33:57 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-31 06:33:57 --> Final output sent to browser
DEBUG - 2015-12-31 06:33:57 --> Total execution time: 0.1098
INFO - 2015-12-31 06:33:57 --> Config Class Initialized
INFO - 2015-12-31 06:33:57 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:33:57 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:33:57 --> Utf8 Class Initialized
INFO - 2015-12-31 06:33:57 --> URI Class Initialized
INFO - 2015-12-31 06:33:57 --> Router Class Initialized
INFO - 2015-12-31 06:33:57 --> Output Class Initialized
INFO - 2015-12-31 06:33:57 --> Security Class Initialized
DEBUG - 2015-12-31 06:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:33:57 --> Input Class Initialized
INFO - 2015-12-31 06:33:57 --> Language Class Initialized
INFO - 2015-12-31 06:33:57 --> Loader Class Initialized
INFO - 2015-12-31 06:33:57 --> Helper loaded: url_helper
INFO - 2015-12-31 06:33:57 --> Database Driver Class Initialized
INFO - 2015-12-31 06:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:33:57 --> Controller Class Initialized
DEBUG - 2015-12-31 06:33:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:33:57 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:33:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:33:58 --> Model Class Initialized
INFO - 2015-12-31 06:33:58 --> Model Class Initialized
INFO - 2015-12-31 06:33:58 --> Final output sent to browser
DEBUG - 2015-12-31 06:33:58 --> Total execution time: 0.1369
INFO - 2015-12-31 06:34:01 --> Config Class Initialized
INFO - 2015-12-31 06:34:01 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:01 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:01 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:01 --> URI Class Initialized
INFO - 2015-12-31 06:34:01 --> Router Class Initialized
INFO - 2015-12-31 06:34:01 --> Output Class Initialized
INFO - 2015-12-31 06:34:01 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:01 --> Input Class Initialized
INFO - 2015-12-31 06:34:01 --> Language Class Initialized
INFO - 2015-12-31 06:34:01 --> Loader Class Initialized
INFO - 2015-12-31 06:34:01 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:01 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:01 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:01 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:01 --> Model Class Initialized
INFO - 2015-12-31 06:34:01 --> Model Class Initialized
INFO - 2015-12-31 06:34:01 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:01 --> Total execution time: 0.1151
INFO - 2015-12-31 06:34:02 --> Config Class Initialized
INFO - 2015-12-31 06:34:02 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:02 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:02 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:02 --> URI Class Initialized
INFO - 2015-12-31 06:34:02 --> Router Class Initialized
INFO - 2015-12-31 06:34:02 --> Output Class Initialized
INFO - 2015-12-31 06:34:02 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:02 --> Input Class Initialized
INFO - 2015-12-31 06:34:02 --> Language Class Initialized
INFO - 2015-12-31 06:34:02 --> Loader Class Initialized
INFO - 2015-12-31 06:34:02 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:02 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:02 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:02 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:02 --> Model Class Initialized
INFO - 2015-12-31 06:34:02 --> Model Class Initialized
INFO - 2015-12-31 06:34:02 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:02 --> Total execution time: 0.1156
INFO - 2015-12-31 06:34:04 --> Config Class Initialized
INFO - 2015-12-31 06:34:04 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:04 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:04 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:04 --> URI Class Initialized
INFO - 2015-12-31 06:34:04 --> Router Class Initialized
INFO - 2015-12-31 06:34:04 --> Output Class Initialized
INFO - 2015-12-31 06:34:04 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:04 --> Input Class Initialized
INFO - 2015-12-31 06:34:04 --> Language Class Initialized
INFO - 2015-12-31 06:34:04 --> Loader Class Initialized
INFO - 2015-12-31 06:34:04 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:04 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:04 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:04 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:04 --> Model Class Initialized
INFO - 2015-12-31 06:34:04 --> Model Class Initialized
INFO - 2015-12-31 06:34:04 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:04 --> Total execution time: 0.1630
INFO - 2015-12-31 06:34:05 --> Config Class Initialized
INFO - 2015-12-31 06:34:05 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:05 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:05 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:05 --> URI Class Initialized
INFO - 2015-12-31 06:34:05 --> Router Class Initialized
INFO - 2015-12-31 06:34:05 --> Output Class Initialized
INFO - 2015-12-31 06:34:05 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:05 --> Input Class Initialized
INFO - 2015-12-31 06:34:05 --> Language Class Initialized
INFO - 2015-12-31 06:34:05 --> Loader Class Initialized
INFO - 2015-12-31 06:34:05 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:05 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:05 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:05 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:05 --> Model Class Initialized
INFO - 2015-12-31 06:34:05 --> Model Class Initialized
INFO - 2015-12-31 06:34:05 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:05 --> Total execution time: 0.1078
INFO - 2015-12-31 06:34:07 --> Config Class Initialized
INFO - 2015-12-31 06:34:07 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:07 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:07 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:07 --> URI Class Initialized
INFO - 2015-12-31 06:34:07 --> Router Class Initialized
INFO - 2015-12-31 06:34:07 --> Output Class Initialized
INFO - 2015-12-31 06:34:07 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:07 --> Input Class Initialized
INFO - 2015-12-31 06:34:07 --> Language Class Initialized
INFO - 2015-12-31 06:34:07 --> Loader Class Initialized
INFO - 2015-12-31 06:34:07 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:07 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:07 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:07 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:07 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:07 --> Model Class Initialized
INFO - 2015-12-31 06:34:07 --> Model Class Initialized
INFO - 2015-12-31 06:34:07 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:07 --> Total execution time: 0.1302
INFO - 2015-12-31 06:34:07 --> Config Class Initialized
INFO - 2015-12-31 06:34:07 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:07 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:07 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:07 --> URI Class Initialized
INFO - 2015-12-31 06:34:07 --> Router Class Initialized
INFO - 2015-12-31 06:34:07 --> Output Class Initialized
INFO - 2015-12-31 06:34:07 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:07 --> Input Class Initialized
INFO - 2015-12-31 06:34:07 --> Language Class Initialized
INFO - 2015-12-31 06:34:07 --> Loader Class Initialized
INFO - 2015-12-31 06:34:07 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:07 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:07 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:07 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:07 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:07 --> Model Class Initialized
INFO - 2015-12-31 06:34:07 --> Model Class Initialized
INFO - 2015-12-31 06:34:07 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:07 --> Total execution time: 0.1481
INFO - 2015-12-31 06:34:10 --> Config Class Initialized
INFO - 2015-12-31 06:34:10 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:10 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:10 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:10 --> URI Class Initialized
INFO - 2015-12-31 06:34:10 --> Router Class Initialized
INFO - 2015-12-31 06:34:10 --> Output Class Initialized
INFO - 2015-12-31 06:34:10 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:10 --> Input Class Initialized
INFO - 2015-12-31 06:34:10 --> Language Class Initialized
INFO - 2015-12-31 06:34:10 --> Loader Class Initialized
INFO - 2015-12-31 06:34:10 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:10 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:10 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:10 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:10 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:10 --> Model Class Initialized
INFO - 2015-12-31 06:34:10 --> Model Class Initialized
INFO - 2015-12-31 06:34:10 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:10 --> Total execution time: 0.1156
INFO - 2015-12-31 06:34:11 --> Config Class Initialized
INFO - 2015-12-31 06:34:11 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:11 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:11 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:11 --> URI Class Initialized
INFO - 2015-12-31 06:34:11 --> Router Class Initialized
INFO - 2015-12-31 06:34:11 --> Output Class Initialized
INFO - 2015-12-31 06:34:11 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:11 --> Input Class Initialized
INFO - 2015-12-31 06:34:11 --> Language Class Initialized
INFO - 2015-12-31 06:34:11 --> Loader Class Initialized
INFO - 2015-12-31 06:34:11 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:11 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:11 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:11 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:11 --> Model Class Initialized
INFO - 2015-12-31 06:34:11 --> Model Class Initialized
INFO - 2015-12-31 06:34:11 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:11 --> Total execution time: 0.1072
INFO - 2015-12-31 06:34:14 --> Config Class Initialized
INFO - 2015-12-31 06:34:14 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:14 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:14 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:14 --> URI Class Initialized
INFO - 2015-12-31 06:34:14 --> Router Class Initialized
INFO - 2015-12-31 06:34:14 --> Output Class Initialized
INFO - 2015-12-31 06:34:14 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:14 --> Input Class Initialized
INFO - 2015-12-31 06:34:14 --> Language Class Initialized
INFO - 2015-12-31 06:34:14 --> Loader Class Initialized
INFO - 2015-12-31 06:34:14 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:14 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:14 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:14 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:14 --> Model Class Initialized
INFO - 2015-12-31 06:34:14 --> Model Class Initialized
INFO - 2015-12-31 06:34:14 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:14 --> Total execution time: 0.1672
INFO - 2015-12-31 06:34:15 --> Config Class Initialized
INFO - 2015-12-31 06:34:15 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:15 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:15 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:15 --> URI Class Initialized
INFO - 2015-12-31 06:34:15 --> Router Class Initialized
INFO - 2015-12-31 06:34:15 --> Output Class Initialized
INFO - 2015-12-31 06:34:15 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:15 --> Input Class Initialized
INFO - 2015-12-31 06:34:15 --> Language Class Initialized
INFO - 2015-12-31 06:34:15 --> Loader Class Initialized
INFO - 2015-12-31 06:34:15 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:15 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:15 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:15 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:15 --> Model Class Initialized
INFO - 2015-12-31 06:34:15 --> Model Class Initialized
INFO - 2015-12-31 06:34:15 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:15 --> Total execution time: 0.1535
INFO - 2015-12-31 06:34:24 --> Config Class Initialized
INFO - 2015-12-31 06:34:24 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:24 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:24 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:24 --> URI Class Initialized
INFO - 2015-12-31 06:34:24 --> Router Class Initialized
INFO - 2015-12-31 06:34:24 --> Output Class Initialized
INFO - 2015-12-31 06:34:24 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:24 --> Input Class Initialized
INFO - 2015-12-31 06:34:24 --> Language Class Initialized
INFO - 2015-12-31 06:34:24 --> Loader Class Initialized
INFO - 2015-12-31 06:34:24 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:24 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:24 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:24 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:24 --> Model Class Initialized
INFO - 2015-12-31 06:34:24 --> Model Class Initialized
INFO - 2015-12-31 06:34:24 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:24 --> Total execution time: 0.1157
INFO - 2015-12-31 06:34:24 --> Config Class Initialized
INFO - 2015-12-31 06:34:24 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:24 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:24 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:24 --> URI Class Initialized
INFO - 2015-12-31 06:34:24 --> Router Class Initialized
INFO - 2015-12-31 06:34:24 --> Output Class Initialized
INFO - 2015-12-31 06:34:24 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:24 --> Input Class Initialized
INFO - 2015-12-31 06:34:24 --> Language Class Initialized
INFO - 2015-12-31 06:34:24 --> Loader Class Initialized
INFO - 2015-12-31 06:34:24 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:24 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:24 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:24 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:24 --> Model Class Initialized
INFO - 2015-12-31 06:34:24 --> Model Class Initialized
INFO - 2015-12-31 06:34:24 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:24 --> Total execution time: 0.1058
INFO - 2015-12-31 06:34:27 --> Config Class Initialized
INFO - 2015-12-31 06:34:27 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:27 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:27 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:27 --> URI Class Initialized
INFO - 2015-12-31 06:34:27 --> Router Class Initialized
INFO - 2015-12-31 06:34:27 --> Output Class Initialized
INFO - 2015-12-31 06:34:27 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:27 --> Input Class Initialized
INFO - 2015-12-31 06:34:27 --> Language Class Initialized
INFO - 2015-12-31 06:34:27 --> Loader Class Initialized
INFO - 2015-12-31 06:34:27 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:27 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:27 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:27 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:27 --> Model Class Initialized
INFO - 2015-12-31 06:34:27 --> Model Class Initialized
INFO - 2015-12-31 06:34:27 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:27 --> Total execution time: 0.1030
INFO - 2015-12-31 06:34:27 --> Config Class Initialized
INFO - 2015-12-31 06:34:28 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:28 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:28 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:28 --> URI Class Initialized
INFO - 2015-12-31 06:34:28 --> Router Class Initialized
INFO - 2015-12-31 06:34:28 --> Output Class Initialized
INFO - 2015-12-31 06:34:28 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:28 --> Input Class Initialized
INFO - 2015-12-31 06:34:28 --> Language Class Initialized
INFO - 2015-12-31 06:34:28 --> Loader Class Initialized
INFO - 2015-12-31 06:34:28 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:28 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:28 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:28 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:28 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:28 --> Model Class Initialized
INFO - 2015-12-31 06:34:28 --> Model Class Initialized
INFO - 2015-12-31 06:34:28 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:28 --> Total execution time: 0.1158
INFO - 2015-12-31 06:34:30 --> Config Class Initialized
INFO - 2015-12-31 06:34:30 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:30 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:30 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:30 --> URI Class Initialized
INFO - 2015-12-31 06:34:30 --> Router Class Initialized
INFO - 2015-12-31 06:34:30 --> Output Class Initialized
INFO - 2015-12-31 06:34:30 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:30 --> Input Class Initialized
INFO - 2015-12-31 06:34:30 --> Language Class Initialized
INFO - 2015-12-31 06:34:30 --> Loader Class Initialized
INFO - 2015-12-31 06:34:30 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:30 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:30 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:30 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:30 --> Model Class Initialized
INFO - 2015-12-31 06:34:30 --> Model Class Initialized
INFO - 2015-12-31 06:34:30 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:30 --> Total execution time: 0.1149
INFO - 2015-12-31 06:34:30 --> Config Class Initialized
INFO - 2015-12-31 06:34:30 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:30 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:30 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:30 --> URI Class Initialized
INFO - 2015-12-31 06:34:30 --> Router Class Initialized
INFO - 2015-12-31 06:34:30 --> Output Class Initialized
INFO - 2015-12-31 06:34:30 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:30 --> Input Class Initialized
INFO - 2015-12-31 06:34:30 --> Language Class Initialized
INFO - 2015-12-31 06:34:30 --> Loader Class Initialized
INFO - 2015-12-31 06:34:30 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:30 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:30 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:30 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:30 --> Model Class Initialized
INFO - 2015-12-31 06:34:30 --> Model Class Initialized
INFO - 2015-12-31 06:34:30 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:30 --> Total execution time: 0.1231
INFO - 2015-12-31 06:34:34 --> Config Class Initialized
INFO - 2015-12-31 06:34:34 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:34 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:34 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:34 --> URI Class Initialized
INFO - 2015-12-31 06:34:34 --> Router Class Initialized
INFO - 2015-12-31 06:34:34 --> Output Class Initialized
INFO - 2015-12-31 06:34:34 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:34 --> Input Class Initialized
INFO - 2015-12-31 06:34:34 --> Language Class Initialized
INFO - 2015-12-31 06:34:34 --> Loader Class Initialized
INFO - 2015-12-31 06:34:34 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:34 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:34 --> Controller Class Initialized
INFO - 2015-12-31 06:34:35 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-31 06:34:35 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:35 --> Total execution time: 0.0942
INFO - 2015-12-31 06:34:35 --> Config Class Initialized
INFO - 2015-12-31 06:34:35 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:35 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:35 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:35 --> URI Class Initialized
INFO - 2015-12-31 06:34:35 --> Router Class Initialized
INFO - 2015-12-31 06:34:35 --> Output Class Initialized
INFO - 2015-12-31 06:34:35 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:35 --> Input Class Initialized
INFO - 2015-12-31 06:34:35 --> Language Class Initialized
INFO - 2015-12-31 06:34:35 --> Loader Class Initialized
INFO - 2015-12-31 06:34:35 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:35 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:35 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:35 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:35 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:35 --> Model Class Initialized
INFO - 2015-12-31 06:34:35 --> Model Class Initialized
INFO - 2015-12-31 06:34:35 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:35 --> Total execution time: 0.1300
INFO - 2015-12-31 06:34:36 --> Config Class Initialized
INFO - 2015-12-31 06:34:36 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:36 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:36 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:36 --> URI Class Initialized
INFO - 2015-12-31 06:34:36 --> Router Class Initialized
INFO - 2015-12-31 06:34:36 --> Output Class Initialized
INFO - 2015-12-31 06:34:36 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:36 --> Input Class Initialized
INFO - 2015-12-31 06:34:36 --> Language Class Initialized
INFO - 2015-12-31 06:34:36 --> Loader Class Initialized
INFO - 2015-12-31 06:34:36 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:36 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:36 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:36 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:36 --> Model Class Initialized
INFO - 2015-12-31 06:34:36 --> Model Class Initialized
INFO - 2015-12-31 06:34:36 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:36 --> Total execution time: 0.1075
INFO - 2015-12-31 06:34:37 --> Config Class Initialized
INFO - 2015-12-31 06:34:37 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:37 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:37 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:37 --> URI Class Initialized
INFO - 2015-12-31 06:34:37 --> Router Class Initialized
INFO - 2015-12-31 06:34:37 --> Output Class Initialized
INFO - 2015-12-31 06:34:37 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:37 --> Input Class Initialized
INFO - 2015-12-31 06:34:37 --> Language Class Initialized
INFO - 2015-12-31 06:34:37 --> Loader Class Initialized
INFO - 2015-12-31 06:34:37 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:37 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:37 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:37 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:37 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:37 --> Model Class Initialized
INFO - 2015-12-31 06:34:37 --> Model Class Initialized
INFO - 2015-12-31 06:34:37 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:37 --> Total execution time: 0.1045
INFO - 2015-12-31 06:34:38 --> Config Class Initialized
INFO - 2015-12-31 06:34:38 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:39 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:39 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:39 --> URI Class Initialized
INFO - 2015-12-31 06:34:39 --> Router Class Initialized
INFO - 2015-12-31 06:34:39 --> Output Class Initialized
INFO - 2015-12-31 06:34:39 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:39 --> Input Class Initialized
INFO - 2015-12-31 06:34:39 --> Language Class Initialized
INFO - 2015-12-31 06:34:39 --> Loader Class Initialized
INFO - 2015-12-31 06:34:39 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:39 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:39 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:39 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:39 --> Model Class Initialized
INFO - 2015-12-31 06:34:39 --> Model Class Initialized
INFO - 2015-12-31 06:34:39 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:39 --> Total execution time: 0.1212
INFO - 2015-12-31 06:34:39 --> Config Class Initialized
INFO - 2015-12-31 06:34:39 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:39 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:39 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:39 --> URI Class Initialized
INFO - 2015-12-31 06:34:39 --> Router Class Initialized
INFO - 2015-12-31 06:34:39 --> Output Class Initialized
INFO - 2015-12-31 06:34:39 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:39 --> Input Class Initialized
INFO - 2015-12-31 06:34:39 --> Language Class Initialized
INFO - 2015-12-31 06:34:39 --> Loader Class Initialized
INFO - 2015-12-31 06:34:39 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:39 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:39 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:39 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:39 --> Model Class Initialized
INFO - 2015-12-31 06:34:39 --> Model Class Initialized
INFO - 2015-12-31 06:34:39 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:39 --> Total execution time: 0.1066
INFO - 2015-12-31 06:34:41 --> Config Class Initialized
INFO - 2015-12-31 06:34:41 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:41 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:41 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:41 --> URI Class Initialized
INFO - 2015-12-31 06:34:41 --> Router Class Initialized
INFO - 2015-12-31 06:34:41 --> Output Class Initialized
INFO - 2015-12-31 06:34:41 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:41 --> Input Class Initialized
INFO - 2015-12-31 06:34:41 --> Language Class Initialized
INFO - 2015-12-31 06:34:41 --> Loader Class Initialized
INFO - 2015-12-31 06:34:41 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:41 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:41 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:41 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:41 --> Model Class Initialized
INFO - 2015-12-31 06:34:41 --> Model Class Initialized
INFO - 2015-12-31 06:34:41 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:41 --> Total execution time: 0.1018
INFO - 2015-12-31 06:34:42 --> Config Class Initialized
INFO - 2015-12-31 06:34:42 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:42 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:42 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:42 --> URI Class Initialized
INFO - 2015-12-31 06:34:42 --> Router Class Initialized
INFO - 2015-12-31 06:34:42 --> Output Class Initialized
INFO - 2015-12-31 06:34:42 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:42 --> Input Class Initialized
INFO - 2015-12-31 06:34:42 --> Language Class Initialized
INFO - 2015-12-31 06:34:42 --> Loader Class Initialized
INFO - 2015-12-31 06:34:42 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:42 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:42 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:42 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:42 --> Model Class Initialized
INFO - 2015-12-31 06:34:42 --> Model Class Initialized
INFO - 2015-12-31 06:34:42 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:42 --> Total execution time: 0.1168
INFO - 2015-12-31 06:34:45 --> Config Class Initialized
INFO - 2015-12-31 06:34:45 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:45 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:45 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:45 --> URI Class Initialized
INFO - 2015-12-31 06:34:45 --> Router Class Initialized
INFO - 2015-12-31 06:34:45 --> Output Class Initialized
INFO - 2015-12-31 06:34:45 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:45 --> Input Class Initialized
INFO - 2015-12-31 06:34:45 --> Language Class Initialized
INFO - 2015-12-31 06:34:45 --> Loader Class Initialized
INFO - 2015-12-31 06:34:45 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:45 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:45 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:45 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:45 --> Model Class Initialized
INFO - 2015-12-31 06:34:45 --> Model Class Initialized
INFO - 2015-12-31 06:34:45 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:45 --> Total execution time: 0.1090
INFO - 2015-12-31 06:34:46 --> Config Class Initialized
INFO - 2015-12-31 06:34:46 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:46 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:46 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:46 --> URI Class Initialized
INFO - 2015-12-31 06:34:46 --> Router Class Initialized
INFO - 2015-12-31 06:34:46 --> Output Class Initialized
INFO - 2015-12-31 06:34:46 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:46 --> Input Class Initialized
INFO - 2015-12-31 06:34:46 --> Language Class Initialized
INFO - 2015-12-31 06:34:46 --> Loader Class Initialized
INFO - 2015-12-31 06:34:46 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:46 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:46 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:46 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:46 --> Model Class Initialized
INFO - 2015-12-31 06:34:46 --> Model Class Initialized
INFO - 2015-12-31 06:34:46 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:46 --> Total execution time: 0.1016
INFO - 2015-12-31 06:34:48 --> Config Class Initialized
INFO - 2015-12-31 06:34:48 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:48 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:48 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:48 --> URI Class Initialized
INFO - 2015-12-31 06:34:48 --> Router Class Initialized
INFO - 2015-12-31 06:34:48 --> Output Class Initialized
INFO - 2015-12-31 06:34:48 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:48 --> Input Class Initialized
INFO - 2015-12-31 06:34:48 --> Language Class Initialized
INFO - 2015-12-31 06:34:48 --> Loader Class Initialized
INFO - 2015-12-31 06:34:48 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:48 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:48 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:48 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:48 --> Model Class Initialized
INFO - 2015-12-31 06:34:48 --> Model Class Initialized
INFO - 2015-12-31 06:34:48 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:48 --> Total execution time: 0.1308
INFO - 2015-12-31 06:34:49 --> Config Class Initialized
INFO - 2015-12-31 06:34:49 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:49 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:49 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:49 --> URI Class Initialized
INFO - 2015-12-31 06:34:49 --> Router Class Initialized
INFO - 2015-12-31 06:34:49 --> Output Class Initialized
INFO - 2015-12-31 06:34:49 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:49 --> Input Class Initialized
INFO - 2015-12-31 06:34:49 --> Language Class Initialized
INFO - 2015-12-31 06:34:49 --> Loader Class Initialized
INFO - 2015-12-31 06:34:49 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:49 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:49 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:49 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:49 --> Model Class Initialized
INFO - 2015-12-31 06:34:49 --> Model Class Initialized
INFO - 2015-12-31 06:34:49 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:49 --> Total execution time: 0.1223
INFO - 2015-12-31 06:34:51 --> Config Class Initialized
INFO - 2015-12-31 06:34:51 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:51 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:51 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:51 --> URI Class Initialized
INFO - 2015-12-31 06:34:51 --> Router Class Initialized
INFO - 2015-12-31 06:34:51 --> Output Class Initialized
INFO - 2015-12-31 06:34:51 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:51 --> Input Class Initialized
INFO - 2015-12-31 06:34:51 --> Language Class Initialized
INFO - 2015-12-31 06:34:51 --> Loader Class Initialized
INFO - 2015-12-31 06:34:51 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:51 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:51 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:51 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:51 --> Model Class Initialized
INFO - 2015-12-31 06:34:51 --> Model Class Initialized
INFO - 2015-12-31 06:34:51 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:51 --> Total execution time: 0.1135
INFO - 2015-12-31 06:34:52 --> Config Class Initialized
INFO - 2015-12-31 06:34:52 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:52 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:52 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:52 --> URI Class Initialized
INFO - 2015-12-31 06:34:52 --> Router Class Initialized
INFO - 2015-12-31 06:34:52 --> Output Class Initialized
INFO - 2015-12-31 06:34:52 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:52 --> Input Class Initialized
INFO - 2015-12-31 06:34:52 --> Language Class Initialized
INFO - 2015-12-31 06:34:52 --> Loader Class Initialized
INFO - 2015-12-31 06:34:52 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:52 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:52 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:52 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:52 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:52 --> Model Class Initialized
INFO - 2015-12-31 06:34:52 --> Model Class Initialized
INFO - 2015-12-31 06:34:52 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:52 --> Total execution time: 0.1054
INFO - 2015-12-31 06:34:54 --> Config Class Initialized
INFO - 2015-12-31 06:34:54 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:54 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:54 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:54 --> URI Class Initialized
INFO - 2015-12-31 06:34:54 --> Router Class Initialized
INFO - 2015-12-31 06:34:54 --> Output Class Initialized
INFO - 2015-12-31 06:34:54 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:54 --> Input Class Initialized
INFO - 2015-12-31 06:34:54 --> Language Class Initialized
INFO - 2015-12-31 06:34:54 --> Loader Class Initialized
INFO - 2015-12-31 06:34:54 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:54 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:54 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:54 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:54 --> Model Class Initialized
INFO - 2015-12-31 06:34:54 --> Model Class Initialized
INFO - 2015-12-31 06:34:54 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:54 --> Total execution time: 0.1468
INFO - 2015-12-31 06:34:54 --> Config Class Initialized
INFO - 2015-12-31 06:34:54 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:54 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:54 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:54 --> URI Class Initialized
INFO - 2015-12-31 06:34:54 --> Router Class Initialized
INFO - 2015-12-31 06:34:54 --> Output Class Initialized
INFO - 2015-12-31 06:34:54 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:54 --> Input Class Initialized
INFO - 2015-12-31 06:34:54 --> Language Class Initialized
INFO - 2015-12-31 06:34:54 --> Loader Class Initialized
INFO - 2015-12-31 06:34:54 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:54 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:54 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:54 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:54 --> Model Class Initialized
INFO - 2015-12-31 06:34:54 --> Model Class Initialized
INFO - 2015-12-31 06:34:54 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:54 --> Total execution time: 0.1011
INFO - 2015-12-31 06:34:57 --> Config Class Initialized
INFO - 2015-12-31 06:34:57 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:34:57 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:34:57 --> Utf8 Class Initialized
INFO - 2015-12-31 06:34:57 --> URI Class Initialized
INFO - 2015-12-31 06:34:57 --> Router Class Initialized
INFO - 2015-12-31 06:34:57 --> Output Class Initialized
INFO - 2015-12-31 06:34:57 --> Security Class Initialized
DEBUG - 2015-12-31 06:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:34:57 --> Input Class Initialized
INFO - 2015-12-31 06:34:57 --> Language Class Initialized
INFO - 2015-12-31 06:34:57 --> Loader Class Initialized
INFO - 2015-12-31 06:34:57 --> Helper loaded: url_helper
INFO - 2015-12-31 06:34:57 --> Database Driver Class Initialized
INFO - 2015-12-31 06:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:34:57 --> Controller Class Initialized
DEBUG - 2015-12-31 06:34:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:34:57 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:34:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:34:57 --> Model Class Initialized
INFO - 2015-12-31 06:34:57 --> Model Class Initialized
INFO - 2015-12-31 06:34:57 --> Final output sent to browser
DEBUG - 2015-12-31 06:34:57 --> Total execution time: 0.1293
INFO - 2015-12-31 06:35:01 --> Config Class Initialized
INFO - 2015-12-31 06:35:01 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:35:01 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:35:01 --> Utf8 Class Initialized
INFO - 2015-12-31 06:35:01 --> URI Class Initialized
INFO - 2015-12-31 06:35:01 --> Router Class Initialized
INFO - 2015-12-31 06:35:01 --> Output Class Initialized
INFO - 2015-12-31 06:35:01 --> Security Class Initialized
DEBUG - 2015-12-31 06:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:35:01 --> Input Class Initialized
INFO - 2015-12-31 06:35:01 --> Language Class Initialized
INFO - 2015-12-31 06:35:01 --> Loader Class Initialized
INFO - 2015-12-31 06:35:01 --> Helper loaded: url_helper
INFO - 2015-12-31 06:35:01 --> Database Driver Class Initialized
INFO - 2015-12-31 06:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:35:01 --> Controller Class Initialized
DEBUG - 2015-12-31 06:35:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:35:01 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:35:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:35:01 --> Model Class Initialized
INFO - 2015-12-31 06:35:01 --> Model Class Initialized
INFO - 2015-12-31 06:35:01 --> Final output sent to browser
DEBUG - 2015-12-31 06:35:01 --> Total execution time: 0.1059
INFO - 2015-12-31 06:54:06 --> Config Class Initialized
INFO - 2015-12-31 06:54:06 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:06 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:06 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:06 --> URI Class Initialized
DEBUG - 2015-12-31 06:54:06 --> No URI present. Default controller set.
INFO - 2015-12-31 06:54:06 --> Router Class Initialized
INFO - 2015-12-31 06:54:06 --> Output Class Initialized
INFO - 2015-12-31 06:54:06 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:06 --> Input Class Initialized
INFO - 2015-12-31 06:54:06 --> Language Class Initialized
INFO - 2015-12-31 06:54:06 --> Loader Class Initialized
INFO - 2015-12-31 06:54:06 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:06 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:06 --> Controller Class Initialized
INFO - 2015-12-31 06:54:06 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-31 06:54:06 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:06 --> Total execution time: 0.5127
INFO - 2015-12-31 06:54:08 --> Config Class Initialized
INFO - 2015-12-31 06:54:08 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:08 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:08 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:08 --> URI Class Initialized
INFO - 2015-12-31 06:54:08 --> Router Class Initialized
INFO - 2015-12-31 06:54:08 --> Output Class Initialized
INFO - 2015-12-31 06:54:08 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:08 --> Input Class Initialized
INFO - 2015-12-31 06:54:08 --> Language Class Initialized
INFO - 2015-12-31 06:54:08 --> Loader Class Initialized
INFO - 2015-12-31 06:54:08 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:08 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:08 --> Controller Class Initialized
INFO - 2015-12-31 06:54:08 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-31 06:54:08 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:08 --> Total execution time: 0.1224
INFO - 2015-12-31 06:54:08 --> Config Class Initialized
INFO - 2015-12-31 06:54:08 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:08 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:08 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:08 --> URI Class Initialized
INFO - 2015-12-31 06:54:08 --> Router Class Initialized
INFO - 2015-12-31 06:54:08 --> Output Class Initialized
INFO - 2015-12-31 06:54:08 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:08 --> Input Class Initialized
INFO - 2015-12-31 06:54:08 --> Language Class Initialized
INFO - 2015-12-31 06:54:08 --> Loader Class Initialized
INFO - 2015-12-31 06:54:08 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:08 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:08 --> Controller Class Initialized
DEBUG - 2015-12-31 06:54:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:54:08 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:54:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:54:08 --> Model Class Initialized
INFO - 2015-12-31 06:54:08 --> Model Class Initialized
INFO - 2015-12-31 06:54:08 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:08 --> Total execution time: 0.1304
INFO - 2015-12-31 06:54:10 --> Config Class Initialized
INFO - 2015-12-31 06:54:10 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:10 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:10 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:10 --> URI Class Initialized
DEBUG - 2015-12-31 06:54:10 --> No URI present. Default controller set.
INFO - 2015-12-31 06:54:10 --> Router Class Initialized
INFO - 2015-12-31 06:54:10 --> Output Class Initialized
INFO - 2015-12-31 06:54:10 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:10 --> Input Class Initialized
INFO - 2015-12-31 06:54:10 --> Language Class Initialized
INFO - 2015-12-31 06:54:10 --> Loader Class Initialized
INFO - 2015-12-31 06:54:10 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:10 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:10 --> Controller Class Initialized
INFO - 2015-12-31 06:54:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-31 06:54:10 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:10 --> Total execution time: 0.1170
INFO - 2015-12-31 06:54:16 --> Config Class Initialized
INFO - 2015-12-31 06:54:16 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:16 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:16 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:16 --> URI Class Initialized
INFO - 2015-12-31 06:54:16 --> Router Class Initialized
INFO - 2015-12-31 06:54:16 --> Output Class Initialized
INFO - 2015-12-31 06:54:16 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:16 --> Input Class Initialized
INFO - 2015-12-31 06:54:16 --> Language Class Initialized
INFO - 2015-12-31 06:54:16 --> Loader Class Initialized
INFO - 2015-12-31 06:54:16 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:16 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:16 --> Controller Class Initialized
INFO - 2015-12-31 06:54:16 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-31 06:54:16 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:16 --> Total execution time: 0.1107
INFO - 2015-12-31 06:54:16 --> Config Class Initialized
INFO - 2015-12-31 06:54:16 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:16 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:16 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:16 --> URI Class Initialized
INFO - 2015-12-31 06:54:16 --> Router Class Initialized
INFO - 2015-12-31 06:54:16 --> Output Class Initialized
INFO - 2015-12-31 06:54:16 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:16 --> Input Class Initialized
INFO - 2015-12-31 06:54:16 --> Language Class Initialized
INFO - 2015-12-31 06:54:16 --> Loader Class Initialized
INFO - 2015-12-31 06:54:16 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:16 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:16 --> Controller Class Initialized
DEBUG - 2015-12-31 06:54:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:54:16 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:54:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:54:16 --> Model Class Initialized
INFO - 2015-12-31 06:54:16 --> Model Class Initialized
INFO - 2015-12-31 06:54:16 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:16 --> Total execution time: 0.1256
INFO - 2015-12-31 06:54:20 --> Config Class Initialized
INFO - 2015-12-31 06:54:20 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:20 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:20 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:20 --> URI Class Initialized
DEBUG - 2015-12-31 06:54:20 --> No URI present. Default controller set.
INFO - 2015-12-31 06:54:20 --> Router Class Initialized
INFO - 2015-12-31 06:54:20 --> Output Class Initialized
INFO - 2015-12-31 06:54:20 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:20 --> Input Class Initialized
INFO - 2015-12-31 06:54:20 --> Language Class Initialized
INFO - 2015-12-31 06:54:20 --> Loader Class Initialized
INFO - 2015-12-31 06:54:20 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:20 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:20 --> Controller Class Initialized
INFO - 2015-12-31 06:54:20 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-31 06:54:20 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:20 --> Total execution time: 0.1490
INFO - 2015-12-31 06:54:22 --> Config Class Initialized
INFO - 2015-12-31 06:54:22 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:22 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:22 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:22 --> URI Class Initialized
INFO - 2015-12-31 06:54:22 --> Router Class Initialized
INFO - 2015-12-31 06:54:22 --> Output Class Initialized
INFO - 2015-12-31 06:54:22 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:22 --> Input Class Initialized
INFO - 2015-12-31 06:54:22 --> Language Class Initialized
INFO - 2015-12-31 06:54:22 --> Loader Class Initialized
INFO - 2015-12-31 06:54:22 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:22 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:22 --> Controller Class Initialized
INFO - 2015-12-31 06:54:22 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-31 06:54:22 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:22 --> Total execution time: 0.0833
INFO - 2015-12-31 06:54:23 --> Config Class Initialized
INFO - 2015-12-31 06:54:23 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:23 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:23 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:23 --> URI Class Initialized
INFO - 2015-12-31 06:54:23 --> Router Class Initialized
INFO - 2015-12-31 06:54:23 --> Output Class Initialized
INFO - 2015-12-31 06:54:23 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:23 --> Input Class Initialized
INFO - 2015-12-31 06:54:23 --> Language Class Initialized
INFO - 2015-12-31 06:54:23 --> Loader Class Initialized
INFO - 2015-12-31 06:54:23 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:23 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:23 --> Controller Class Initialized
DEBUG - 2015-12-31 06:54:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:54:23 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:54:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:54:23 --> Model Class Initialized
INFO - 2015-12-31 06:54:23 --> Model Class Initialized
INFO - 2015-12-31 06:54:23 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:23 --> Total execution time: 0.1037
INFO - 2015-12-31 06:54:37 --> Config Class Initialized
INFO - 2015-12-31 06:54:37 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:37 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:37 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:37 --> URI Class Initialized
INFO - 2015-12-31 06:54:37 --> Router Class Initialized
INFO - 2015-12-31 06:54:37 --> Output Class Initialized
INFO - 2015-12-31 06:54:37 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:37 --> Input Class Initialized
INFO - 2015-12-31 06:54:37 --> Language Class Initialized
INFO - 2015-12-31 06:54:37 --> Loader Class Initialized
INFO - 2015-12-31 06:54:37 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:37 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:37 --> Controller Class Initialized
DEBUG - 2015-12-31 06:54:37 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:54:37 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:54:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:54:37 --> Model Class Initialized
INFO - 2015-12-31 06:54:37 --> Model Class Initialized
INFO - 2015-12-31 06:54:37 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:37 --> Total execution time: 0.1860
INFO - 2015-12-31 06:54:38 --> Config Class Initialized
INFO - 2015-12-31 06:54:38 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:38 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:38 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:38 --> URI Class Initialized
INFO - 2015-12-31 06:54:38 --> Router Class Initialized
INFO - 2015-12-31 06:54:38 --> Output Class Initialized
INFO - 2015-12-31 06:54:38 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:38 --> Input Class Initialized
INFO - 2015-12-31 06:54:38 --> Language Class Initialized
INFO - 2015-12-31 06:54:38 --> Loader Class Initialized
INFO - 2015-12-31 06:54:38 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:38 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:38 --> Controller Class Initialized
DEBUG - 2015-12-31 06:54:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:54:38 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:54:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:54:38 --> Model Class Initialized
INFO - 2015-12-31 06:54:38 --> Model Class Initialized
INFO - 2015-12-31 06:54:38 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:38 --> Total execution time: 0.1538
INFO - 2015-12-31 06:54:41 --> Config Class Initialized
INFO - 2015-12-31 06:54:41 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:41 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:41 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:41 --> URI Class Initialized
INFO - 2015-12-31 06:54:41 --> Router Class Initialized
INFO - 2015-12-31 06:54:41 --> Output Class Initialized
INFO - 2015-12-31 06:54:41 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:41 --> Input Class Initialized
INFO - 2015-12-31 06:54:41 --> Language Class Initialized
INFO - 2015-12-31 06:54:41 --> Loader Class Initialized
INFO - 2015-12-31 06:54:41 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:41 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:41 --> Controller Class Initialized
DEBUG - 2015-12-31 06:54:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:54:41 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:54:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:54:41 --> Model Class Initialized
INFO - 2015-12-31 06:54:41 --> Model Class Initialized
INFO - 2015-12-31 06:54:41 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:41 --> Total execution time: 0.1159
INFO - 2015-12-31 06:54:43 --> Config Class Initialized
INFO - 2015-12-31 06:54:43 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:54:43 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:54:43 --> Utf8 Class Initialized
INFO - 2015-12-31 06:54:43 --> URI Class Initialized
INFO - 2015-12-31 06:54:43 --> Router Class Initialized
INFO - 2015-12-31 06:54:43 --> Output Class Initialized
INFO - 2015-12-31 06:54:43 --> Security Class Initialized
DEBUG - 2015-12-31 06:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:54:43 --> Input Class Initialized
INFO - 2015-12-31 06:54:43 --> Language Class Initialized
INFO - 2015-12-31 06:54:43 --> Loader Class Initialized
INFO - 2015-12-31 06:54:43 --> Helper loaded: url_helper
INFO - 2015-12-31 06:54:43 --> Database Driver Class Initialized
INFO - 2015-12-31 06:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:54:43 --> Controller Class Initialized
DEBUG - 2015-12-31 06:54:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:54:43 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:54:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:54:43 --> Model Class Initialized
INFO - 2015-12-31 06:54:43 --> Model Class Initialized
INFO - 2015-12-31 06:54:43 --> Final output sent to browser
DEBUG - 2015-12-31 06:54:43 --> Total execution time: 0.1027
INFO - 2015-12-31 06:55:45 --> Config Class Initialized
INFO - 2015-12-31 06:55:45 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:55:45 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:55:45 --> Utf8 Class Initialized
INFO - 2015-12-31 06:55:45 --> URI Class Initialized
INFO - 2015-12-31 06:55:45 --> Router Class Initialized
INFO - 2015-12-31 06:55:45 --> Output Class Initialized
INFO - 2015-12-31 06:55:45 --> Security Class Initialized
DEBUG - 2015-12-31 06:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:55:45 --> Input Class Initialized
INFO - 2015-12-31 06:55:45 --> Language Class Initialized
INFO - 2015-12-31 06:55:45 --> Loader Class Initialized
INFO - 2015-12-31 06:55:45 --> Helper loaded: url_helper
INFO - 2015-12-31 06:55:45 --> Database Driver Class Initialized
INFO - 2015-12-31 06:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:55:45 --> Controller Class Initialized
DEBUG - 2015-12-31 06:55:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:55:45 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:55:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:55:45 --> Model Class Initialized
INFO - 2015-12-31 06:55:45 --> Model Class Initialized
INFO - 2015-12-31 06:55:45 --> Final output sent to browser
DEBUG - 2015-12-31 06:55:45 --> Total execution time: 0.4176
INFO - 2015-12-31 06:55:48 --> Config Class Initialized
INFO - 2015-12-31 06:55:48 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:55:48 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:55:48 --> Utf8 Class Initialized
INFO - 2015-12-31 06:55:48 --> URI Class Initialized
INFO - 2015-12-31 06:55:48 --> Router Class Initialized
INFO - 2015-12-31 06:55:48 --> Output Class Initialized
INFO - 2015-12-31 06:55:48 --> Security Class Initialized
DEBUG - 2015-12-31 06:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:55:48 --> Input Class Initialized
INFO - 2015-12-31 06:55:48 --> Language Class Initialized
INFO - 2015-12-31 06:55:48 --> Loader Class Initialized
INFO - 2015-12-31 06:55:48 --> Helper loaded: url_helper
INFO - 2015-12-31 06:55:48 --> Database Driver Class Initialized
INFO - 2015-12-31 06:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:55:48 --> Controller Class Initialized
DEBUG - 2015-12-31 06:55:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:55:48 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:55:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:55:48 --> Model Class Initialized
INFO - 2015-12-31 06:55:48 --> Model Class Initialized
INFO - 2015-12-31 06:55:48 --> Final output sent to browser
DEBUG - 2015-12-31 06:55:48 --> Total execution time: 0.1056
INFO - 2015-12-31 06:56:49 --> Config Class Initialized
INFO - 2015-12-31 06:56:49 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:56:49 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:56:49 --> Utf8 Class Initialized
INFO - 2015-12-31 06:56:49 --> URI Class Initialized
INFO - 2015-12-31 06:56:49 --> Router Class Initialized
INFO - 2015-12-31 06:56:49 --> Output Class Initialized
INFO - 2015-12-31 06:56:49 --> Security Class Initialized
DEBUG - 2015-12-31 06:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:56:49 --> Input Class Initialized
INFO - 2015-12-31 06:56:49 --> Language Class Initialized
INFO - 2015-12-31 06:56:49 --> Loader Class Initialized
INFO - 2015-12-31 06:56:49 --> Helper loaded: url_helper
INFO - 2015-12-31 06:56:49 --> Database Driver Class Initialized
INFO - 2015-12-31 06:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:56:49 --> Controller Class Initialized
DEBUG - 2015-12-31 06:56:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:56:49 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:56:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:56:49 --> Model Class Initialized
INFO - 2015-12-31 06:56:49 --> Model Class Initialized
INFO - 2015-12-31 06:56:49 --> Final output sent to browser
DEBUG - 2015-12-31 06:56:49 --> Total execution time: 0.4573
INFO - 2015-12-31 06:56:51 --> Config Class Initialized
INFO - 2015-12-31 06:56:51 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:56:51 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:56:51 --> Utf8 Class Initialized
INFO - 2015-12-31 06:56:51 --> URI Class Initialized
INFO - 2015-12-31 06:56:51 --> Router Class Initialized
INFO - 2015-12-31 06:56:51 --> Output Class Initialized
INFO - 2015-12-31 06:56:51 --> Security Class Initialized
DEBUG - 2015-12-31 06:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:56:51 --> Input Class Initialized
INFO - 2015-12-31 06:56:51 --> Language Class Initialized
INFO - 2015-12-31 06:56:51 --> Loader Class Initialized
INFO - 2015-12-31 06:56:51 --> Helper loaded: url_helper
INFO - 2015-12-31 06:56:51 --> Database Driver Class Initialized
INFO - 2015-12-31 06:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:56:51 --> Controller Class Initialized
DEBUG - 2015-12-31 06:56:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:56:51 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:56:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:56:51 --> Model Class Initialized
INFO - 2015-12-31 06:56:51 --> Model Class Initialized
INFO - 2015-12-31 06:56:51 --> Final output sent to browser
DEBUG - 2015-12-31 06:56:51 --> Total execution time: 0.1478
INFO - 2015-12-31 06:57:52 --> Config Class Initialized
INFO - 2015-12-31 06:57:52 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:57:52 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:57:52 --> Utf8 Class Initialized
INFO - 2015-12-31 06:57:52 --> URI Class Initialized
INFO - 2015-12-31 06:57:52 --> Router Class Initialized
INFO - 2015-12-31 06:57:52 --> Output Class Initialized
INFO - 2015-12-31 06:57:52 --> Security Class Initialized
DEBUG - 2015-12-31 06:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:57:52 --> Input Class Initialized
INFO - 2015-12-31 06:57:52 --> Language Class Initialized
INFO - 2015-12-31 06:57:52 --> Loader Class Initialized
INFO - 2015-12-31 06:57:52 --> Helper loaded: url_helper
INFO - 2015-12-31 06:57:52 --> Database Driver Class Initialized
INFO - 2015-12-31 06:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:57:52 --> Controller Class Initialized
DEBUG - 2015-12-31 06:57:52 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:57:52 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:57:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:57:52 --> Model Class Initialized
INFO - 2015-12-31 06:57:52 --> Model Class Initialized
INFO - 2015-12-31 06:57:52 --> Final output sent to browser
DEBUG - 2015-12-31 06:57:52 --> Total execution time: 0.3880
INFO - 2015-12-31 06:57:54 --> Config Class Initialized
INFO - 2015-12-31 06:57:54 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:57:54 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:57:54 --> Utf8 Class Initialized
INFO - 2015-12-31 06:57:54 --> URI Class Initialized
INFO - 2015-12-31 06:57:54 --> Router Class Initialized
INFO - 2015-12-31 06:57:54 --> Output Class Initialized
INFO - 2015-12-31 06:57:54 --> Security Class Initialized
DEBUG - 2015-12-31 06:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:57:54 --> Input Class Initialized
INFO - 2015-12-31 06:57:54 --> Language Class Initialized
INFO - 2015-12-31 06:57:54 --> Loader Class Initialized
INFO - 2015-12-31 06:57:54 --> Helper loaded: url_helper
INFO - 2015-12-31 06:57:54 --> Database Driver Class Initialized
INFO - 2015-12-31 06:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:57:54 --> Controller Class Initialized
DEBUG - 2015-12-31 06:57:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:57:54 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:57:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:57:54 --> Model Class Initialized
INFO - 2015-12-31 06:57:54 --> Model Class Initialized
INFO - 2015-12-31 06:57:54 --> Final output sent to browser
DEBUG - 2015-12-31 06:57:54 --> Total execution time: 0.1213
INFO - 2015-12-31 06:58:55 --> Config Class Initialized
INFO - 2015-12-31 06:58:55 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:58:55 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:58:55 --> Utf8 Class Initialized
INFO - 2015-12-31 06:58:55 --> URI Class Initialized
INFO - 2015-12-31 06:58:55 --> Router Class Initialized
INFO - 2015-12-31 06:58:55 --> Output Class Initialized
INFO - 2015-12-31 06:58:55 --> Security Class Initialized
DEBUG - 2015-12-31 06:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:58:55 --> Input Class Initialized
INFO - 2015-12-31 06:58:55 --> Language Class Initialized
INFO - 2015-12-31 06:58:55 --> Loader Class Initialized
INFO - 2015-12-31 06:58:55 --> Helper loaded: url_helper
INFO - 2015-12-31 06:58:55 --> Database Driver Class Initialized
INFO - 2015-12-31 06:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:58:55 --> Controller Class Initialized
DEBUG - 2015-12-31 06:58:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:58:55 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:58:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:58:55 --> Model Class Initialized
INFO - 2015-12-31 06:58:55 --> Model Class Initialized
INFO - 2015-12-31 06:58:55 --> Final output sent to browser
DEBUG - 2015-12-31 06:58:55 --> Total execution time: 0.4384
INFO - 2015-12-31 06:58:57 --> Config Class Initialized
INFO - 2015-12-31 06:58:57 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:58:57 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:58:57 --> Utf8 Class Initialized
INFO - 2015-12-31 06:58:57 --> URI Class Initialized
INFO - 2015-12-31 06:58:57 --> Router Class Initialized
INFO - 2015-12-31 06:58:57 --> Output Class Initialized
INFO - 2015-12-31 06:58:57 --> Security Class Initialized
DEBUG - 2015-12-31 06:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:58:57 --> Input Class Initialized
INFO - 2015-12-31 06:58:57 --> Language Class Initialized
INFO - 2015-12-31 06:58:57 --> Loader Class Initialized
INFO - 2015-12-31 06:58:57 --> Helper loaded: url_helper
INFO - 2015-12-31 06:58:57 --> Database Driver Class Initialized
INFO - 2015-12-31 06:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:58:57 --> Controller Class Initialized
DEBUG - 2015-12-31 06:58:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:58:57 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:58:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:58:57 --> Model Class Initialized
INFO - 2015-12-31 06:58:57 --> Model Class Initialized
INFO - 2015-12-31 06:58:57 --> Final output sent to browser
DEBUG - 2015-12-31 06:58:57 --> Total execution time: 0.1479
INFO - 2015-12-31 06:59:59 --> Config Class Initialized
INFO - 2015-12-31 06:59:59 --> Hooks Class Initialized
DEBUG - 2015-12-31 06:59:59 --> UTF-8 Support Enabled
INFO - 2015-12-31 06:59:59 --> Utf8 Class Initialized
INFO - 2015-12-31 06:59:59 --> URI Class Initialized
INFO - 2015-12-31 06:59:59 --> Router Class Initialized
INFO - 2015-12-31 06:59:59 --> Output Class Initialized
INFO - 2015-12-31 06:59:59 --> Security Class Initialized
DEBUG - 2015-12-31 06:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 06:59:59 --> Input Class Initialized
INFO - 2015-12-31 06:59:59 --> Language Class Initialized
INFO - 2015-12-31 06:59:59 --> Loader Class Initialized
INFO - 2015-12-31 06:59:59 --> Helper loaded: url_helper
INFO - 2015-12-31 06:59:59 --> Database Driver Class Initialized
INFO - 2015-12-31 06:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 06:59:59 --> Controller Class Initialized
DEBUG - 2015-12-31 06:59:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 06:59:59 --> Helper loaded: inflector_helper
INFO - 2015-12-31 06:59:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 06:59:59 --> Model Class Initialized
INFO - 2015-12-31 06:59:59 --> Model Class Initialized
INFO - 2015-12-31 06:59:59 --> Final output sent to browser
DEBUG - 2015-12-31 06:59:59 --> Total execution time: 0.4709
INFO - 2015-12-31 07:00:02 --> Config Class Initialized
INFO - 2015-12-31 07:00:02 --> Hooks Class Initialized
DEBUG - 2015-12-31 07:00:02 --> UTF-8 Support Enabled
INFO - 2015-12-31 07:00:02 --> Utf8 Class Initialized
INFO - 2015-12-31 07:00:02 --> URI Class Initialized
INFO - 2015-12-31 07:00:02 --> Router Class Initialized
INFO - 2015-12-31 07:00:02 --> Output Class Initialized
INFO - 2015-12-31 07:00:02 --> Security Class Initialized
DEBUG - 2015-12-31 07:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 07:00:02 --> Input Class Initialized
INFO - 2015-12-31 07:00:02 --> Language Class Initialized
INFO - 2015-12-31 07:00:02 --> Loader Class Initialized
INFO - 2015-12-31 07:00:02 --> Helper loaded: url_helper
INFO - 2015-12-31 07:00:02 --> Database Driver Class Initialized
INFO - 2015-12-31 07:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 07:00:02 --> Controller Class Initialized
DEBUG - 2015-12-31 07:00:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 07:00:02 --> Helper loaded: inflector_helper
INFO - 2015-12-31 07:00:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 07:00:02 --> Model Class Initialized
INFO - 2015-12-31 07:00:02 --> Model Class Initialized
INFO - 2015-12-31 07:00:02 --> Final output sent to browser
DEBUG - 2015-12-31 07:00:02 --> Total execution time: 0.1496
INFO - 2015-12-31 07:01:04 --> Config Class Initialized
INFO - 2015-12-31 07:01:04 --> Hooks Class Initialized
DEBUG - 2015-12-31 07:01:04 --> UTF-8 Support Enabled
INFO - 2015-12-31 07:01:04 --> Utf8 Class Initialized
INFO - 2015-12-31 07:01:04 --> URI Class Initialized
INFO - 2015-12-31 07:01:04 --> Router Class Initialized
INFO - 2015-12-31 07:01:04 --> Output Class Initialized
INFO - 2015-12-31 07:01:04 --> Security Class Initialized
DEBUG - 2015-12-31 07:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 07:01:04 --> Input Class Initialized
INFO - 2015-12-31 07:01:04 --> Language Class Initialized
INFO - 2015-12-31 07:01:04 --> Loader Class Initialized
INFO - 2015-12-31 07:01:04 --> Helper loaded: url_helper
INFO - 2015-12-31 07:01:04 --> Database Driver Class Initialized
INFO - 2015-12-31 07:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 07:01:04 --> Controller Class Initialized
DEBUG - 2015-12-31 07:01:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 07:01:04 --> Helper loaded: inflector_helper
INFO - 2015-12-31 07:01:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 07:01:04 --> Model Class Initialized
INFO - 2015-12-31 07:01:04 --> Model Class Initialized
INFO - 2015-12-31 07:01:04 --> Final output sent to browser
DEBUG - 2015-12-31 07:01:04 --> Total execution time: 0.4430
INFO - 2015-12-31 07:01:06 --> Config Class Initialized
INFO - 2015-12-31 07:01:06 --> Hooks Class Initialized
DEBUG - 2015-12-31 07:01:06 --> UTF-8 Support Enabled
INFO - 2015-12-31 07:01:06 --> Utf8 Class Initialized
INFO - 2015-12-31 07:01:06 --> URI Class Initialized
INFO - 2015-12-31 07:01:06 --> Router Class Initialized
INFO - 2015-12-31 07:01:06 --> Output Class Initialized
INFO - 2015-12-31 07:01:06 --> Security Class Initialized
DEBUG - 2015-12-31 07:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-31 07:01:06 --> Input Class Initialized
INFO - 2015-12-31 07:01:06 --> Language Class Initialized
INFO - 2015-12-31 07:01:06 --> Loader Class Initialized
INFO - 2015-12-31 07:01:06 --> Helper loaded: url_helper
INFO - 2015-12-31 07:01:06 --> Database Driver Class Initialized
INFO - 2015-12-31 07:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-31 07:01:06 --> Controller Class Initialized
DEBUG - 2015-12-31 07:01:06 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-31 07:01:06 --> Helper loaded: inflector_helper
INFO - 2015-12-31 07:01:06 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-31 07:01:06 --> Model Class Initialized
INFO - 2015-12-31 07:01:06 --> Model Class Initialized
INFO - 2015-12-31 07:01:06 --> Final output sent to browser
DEBUG - 2015-12-31 07:01:06 --> Total execution time: 0.1216
