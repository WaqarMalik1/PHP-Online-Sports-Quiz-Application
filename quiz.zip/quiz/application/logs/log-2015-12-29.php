<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2015-12-29 00:09:47 --> Config Class Initialized
INFO - 2015-12-29 00:09:48 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:09:48 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:09:48 --> Utf8 Class Initialized
INFO - 2015-12-29 00:09:48 --> URI Class Initialized
DEBUG - 2015-12-29 00:09:48 --> No URI present. Default controller set.
INFO - 2015-12-29 00:09:48 --> Router Class Initialized
INFO - 2015-12-29 00:09:48 --> Output Class Initialized
INFO - 2015-12-29 00:09:48 --> Security Class Initialized
DEBUG - 2015-12-29 00:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:09:48 --> Input Class Initialized
INFO - 2015-12-29 00:09:48 --> Language Class Initialized
INFO - 2015-12-29 00:09:48 --> Loader Class Initialized
INFO - 2015-12-29 00:09:48 --> Helper loaded: url_helper
INFO - 2015-12-29 00:09:48 --> Database Driver Class Initialized
INFO - 2015-12-29 00:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:09:48 --> Controller Class Initialized
INFO - 2015-12-29 00:09:48 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-29 00:09:48 --> Final output sent to browser
DEBUG - 2015-12-29 00:09:48 --> Total execution time: 0.4266
INFO - 2015-12-29 00:09:59 --> Config Class Initialized
INFO - 2015-12-29 00:09:59 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:09:59 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:09:59 --> Utf8 Class Initialized
INFO - 2015-12-29 00:09:59 --> URI Class Initialized
INFO - 2015-12-29 00:09:59 --> Router Class Initialized
INFO - 2015-12-29 00:09:59 --> Output Class Initialized
INFO - 2015-12-29 00:09:59 --> Security Class Initialized
DEBUG - 2015-12-29 00:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:09:59 --> Input Class Initialized
INFO - 2015-12-29 00:09:59 --> Language Class Initialized
INFO - 2015-12-29 00:09:59 --> Loader Class Initialized
INFO - 2015-12-29 00:09:59 --> Helper loaded: url_helper
INFO - 2015-12-29 00:09:59 --> Database Driver Class Initialized
INFO - 2015-12-29 00:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:09:59 --> Controller Class Initialized
INFO - 2015-12-29 00:09:59 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-29 00:09:59 --> Final output sent to browser
DEBUG - 2015-12-29 00:09:59 --> Total execution time: 0.1282
INFO - 2015-12-29 00:09:59 --> Config Class Initialized
INFO - 2015-12-29 00:09:59 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:09:59 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:09:59 --> Utf8 Class Initialized
INFO - 2015-12-29 00:09:59 --> URI Class Initialized
INFO - 2015-12-29 00:09:59 --> Router Class Initialized
INFO - 2015-12-29 00:09:59 --> Output Class Initialized
INFO - 2015-12-29 00:09:59 --> Security Class Initialized
DEBUG - 2015-12-29 00:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:09:59 --> Input Class Initialized
INFO - 2015-12-29 00:09:59 --> Language Class Initialized
INFO - 2015-12-29 00:09:59 --> Loader Class Initialized
INFO - 2015-12-29 00:09:59 --> Helper loaded: url_helper
INFO - 2015-12-29 00:09:59 --> Database Driver Class Initialized
INFO - 2015-12-29 00:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:09:59 --> Controller Class Initialized
DEBUG - 2015-12-29 00:09:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:09:59 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:10:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:10:00 --> Model Class Initialized
INFO - 2015-12-29 00:10:00 --> Model Class Initialized
INFO - 2015-12-29 00:10:00 --> Final output sent to browser
DEBUG - 2015-12-29 00:10:00 --> Total execution time: 0.1859
INFO - 2015-12-29 00:10:07 --> Config Class Initialized
INFO - 2015-12-29 00:10:07 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:10:07 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:10:07 --> Utf8 Class Initialized
INFO - 2015-12-29 00:10:07 --> URI Class Initialized
INFO - 2015-12-29 00:10:07 --> Router Class Initialized
INFO - 2015-12-29 00:10:07 --> Output Class Initialized
INFO - 2015-12-29 00:10:07 --> Security Class Initialized
DEBUG - 2015-12-29 00:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:10:07 --> Input Class Initialized
INFO - 2015-12-29 00:10:07 --> Language Class Initialized
INFO - 2015-12-29 00:10:07 --> Loader Class Initialized
INFO - 2015-12-29 00:10:07 --> Helper loaded: url_helper
INFO - 2015-12-29 00:10:07 --> Database Driver Class Initialized
INFO - 2015-12-29 00:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:10:07 --> Controller Class Initialized
DEBUG - 2015-12-29 00:10:07 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:10:07 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:10:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:10:07 --> Model Class Initialized
INFO - 2015-12-29 00:10:07 --> Model Class Initialized
INFO - 2015-12-29 00:10:07 --> Final output sent to browser
DEBUG - 2015-12-29 00:10:07 --> Total execution time: 0.2070
INFO - 2015-12-29 00:10:08 --> Config Class Initialized
INFO - 2015-12-29 00:10:08 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:10:08 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:10:08 --> Utf8 Class Initialized
INFO - 2015-12-29 00:10:08 --> URI Class Initialized
INFO - 2015-12-29 00:10:08 --> Router Class Initialized
INFO - 2015-12-29 00:10:08 --> Output Class Initialized
INFO - 2015-12-29 00:10:08 --> Security Class Initialized
DEBUG - 2015-12-29 00:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:10:08 --> Input Class Initialized
INFO - 2015-12-29 00:10:08 --> Language Class Initialized
INFO - 2015-12-29 00:10:08 --> Loader Class Initialized
INFO - 2015-12-29 00:10:08 --> Helper loaded: url_helper
INFO - 2015-12-29 00:10:08 --> Database Driver Class Initialized
INFO - 2015-12-29 00:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:10:08 --> Controller Class Initialized
DEBUG - 2015-12-29 00:10:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:10:08 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:10:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:10:08 --> Model Class Initialized
INFO - 2015-12-29 00:10:08 --> Model Class Initialized
INFO - 2015-12-29 00:10:08 --> Final output sent to browser
DEBUG - 2015-12-29 00:10:08 --> Total execution time: 0.1555
INFO - 2015-12-29 00:10:12 --> Config Class Initialized
INFO - 2015-12-29 00:10:12 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:10:12 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:10:12 --> Utf8 Class Initialized
INFO - 2015-12-29 00:10:12 --> URI Class Initialized
INFO - 2015-12-29 00:10:12 --> Router Class Initialized
INFO - 2015-12-29 00:10:12 --> Output Class Initialized
INFO - 2015-12-29 00:10:13 --> Security Class Initialized
DEBUG - 2015-12-29 00:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:10:13 --> Input Class Initialized
INFO - 2015-12-29 00:10:13 --> Language Class Initialized
INFO - 2015-12-29 00:10:13 --> Loader Class Initialized
INFO - 2015-12-29 00:10:13 --> Helper loaded: url_helper
INFO - 2015-12-29 00:10:13 --> Database Driver Class Initialized
INFO - 2015-12-29 00:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:10:13 --> Controller Class Initialized
DEBUG - 2015-12-29 00:10:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:10:13 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:10:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:10:13 --> Model Class Initialized
INFO - 2015-12-29 00:10:13 --> Model Class Initialized
INFO - 2015-12-29 00:10:13 --> Final output sent to browser
DEBUG - 2015-12-29 00:10:13 --> Total execution time: 0.1899
INFO - 2015-12-29 00:10:13 --> Config Class Initialized
INFO - 2015-12-29 00:10:13 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:10:13 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:10:13 --> Utf8 Class Initialized
INFO - 2015-12-29 00:10:13 --> URI Class Initialized
INFO - 2015-12-29 00:10:13 --> Router Class Initialized
INFO - 2015-12-29 00:10:13 --> Output Class Initialized
INFO - 2015-12-29 00:10:13 --> Security Class Initialized
DEBUG - 2015-12-29 00:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:10:13 --> Input Class Initialized
INFO - 2015-12-29 00:10:13 --> Language Class Initialized
INFO - 2015-12-29 00:10:13 --> Loader Class Initialized
INFO - 2015-12-29 00:10:13 --> Helper loaded: url_helper
INFO - 2015-12-29 00:10:13 --> Database Driver Class Initialized
INFO - 2015-12-29 00:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:10:13 --> Controller Class Initialized
DEBUG - 2015-12-29 00:10:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:10:13 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:10:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:10:13 --> Model Class Initialized
INFO - 2015-12-29 00:10:13 --> Model Class Initialized
INFO - 2015-12-29 00:10:13 --> Final output sent to browser
DEBUG - 2015-12-29 00:10:13 --> Total execution time: 0.1717
INFO - 2015-12-29 00:10:17 --> Config Class Initialized
INFO - 2015-12-29 00:10:17 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:10:17 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:10:17 --> Utf8 Class Initialized
INFO - 2015-12-29 00:10:17 --> URI Class Initialized
INFO - 2015-12-29 00:10:17 --> Router Class Initialized
INFO - 2015-12-29 00:10:17 --> Output Class Initialized
INFO - 2015-12-29 00:10:17 --> Security Class Initialized
DEBUG - 2015-12-29 00:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:10:17 --> Input Class Initialized
INFO - 2015-12-29 00:10:17 --> Language Class Initialized
INFO - 2015-12-29 00:10:17 --> Loader Class Initialized
INFO - 2015-12-29 00:10:17 --> Helper loaded: url_helper
INFO - 2015-12-29 00:10:17 --> Database Driver Class Initialized
INFO - 2015-12-29 00:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:10:17 --> Controller Class Initialized
DEBUG - 2015-12-29 00:10:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:10:17 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:10:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:10:17 --> Model Class Initialized
INFO - 2015-12-29 00:10:17 --> Model Class Initialized
INFO - 2015-12-29 00:10:17 --> Final output sent to browser
DEBUG - 2015-12-29 00:10:17 --> Total execution time: 0.1025
INFO - 2015-12-29 00:10:18 --> Config Class Initialized
INFO - 2015-12-29 00:10:18 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:10:18 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:10:18 --> Utf8 Class Initialized
INFO - 2015-12-29 00:10:18 --> URI Class Initialized
INFO - 2015-12-29 00:10:18 --> Router Class Initialized
INFO - 2015-12-29 00:10:18 --> Output Class Initialized
INFO - 2015-12-29 00:10:18 --> Security Class Initialized
DEBUG - 2015-12-29 00:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:10:18 --> Input Class Initialized
INFO - 2015-12-29 00:10:18 --> Language Class Initialized
INFO - 2015-12-29 00:10:18 --> Loader Class Initialized
INFO - 2015-12-29 00:10:18 --> Helper loaded: url_helper
INFO - 2015-12-29 00:10:18 --> Database Driver Class Initialized
INFO - 2015-12-29 00:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:10:18 --> Controller Class Initialized
DEBUG - 2015-12-29 00:10:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:10:18 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:10:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:10:18 --> Model Class Initialized
INFO - 2015-12-29 00:10:18 --> Model Class Initialized
INFO - 2015-12-29 00:10:18 --> Final output sent to browser
DEBUG - 2015-12-29 00:10:18 --> Total execution time: 0.1475
INFO - 2015-12-29 00:10:28 --> Config Class Initialized
INFO - 2015-12-29 00:10:28 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:10:28 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:10:28 --> Utf8 Class Initialized
INFO - 2015-12-29 00:10:28 --> URI Class Initialized
INFO - 2015-12-29 00:10:28 --> Router Class Initialized
INFO - 2015-12-29 00:10:28 --> Output Class Initialized
INFO - 2015-12-29 00:10:28 --> Security Class Initialized
DEBUG - 2015-12-29 00:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:10:28 --> Input Class Initialized
INFO - 2015-12-29 00:10:28 --> Language Class Initialized
INFO - 2015-12-29 00:10:28 --> Loader Class Initialized
INFO - 2015-12-29 00:10:28 --> Helper loaded: url_helper
INFO - 2015-12-29 00:10:28 --> Database Driver Class Initialized
INFO - 2015-12-29 00:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:10:28 --> Controller Class Initialized
DEBUG - 2015-12-29 00:10:28 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:10:28 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:10:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:10:28 --> Model Class Initialized
INFO - 2015-12-29 00:10:28 --> Model Class Initialized
INFO - 2015-12-29 00:10:28 --> Final output sent to browser
DEBUG - 2015-12-29 00:10:28 --> Total execution time: 0.1656
INFO - 2015-12-29 00:10:28 --> Config Class Initialized
INFO - 2015-12-29 00:10:28 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:10:28 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:10:28 --> Utf8 Class Initialized
INFO - 2015-12-29 00:10:28 --> URI Class Initialized
INFO - 2015-12-29 00:10:28 --> Router Class Initialized
INFO - 2015-12-29 00:10:28 --> Output Class Initialized
INFO - 2015-12-29 00:10:28 --> Security Class Initialized
DEBUG - 2015-12-29 00:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:10:28 --> Input Class Initialized
INFO - 2015-12-29 00:10:28 --> Language Class Initialized
INFO - 2015-12-29 00:10:28 --> Loader Class Initialized
INFO - 2015-12-29 00:10:28 --> Helper loaded: url_helper
INFO - 2015-12-29 00:10:28 --> Database Driver Class Initialized
INFO - 2015-12-29 00:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:10:29 --> Controller Class Initialized
DEBUG - 2015-12-29 00:10:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:10:29 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:10:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:10:29 --> Model Class Initialized
INFO - 2015-12-29 00:10:29 --> Model Class Initialized
INFO - 2015-12-29 00:10:29 --> Final output sent to browser
DEBUG - 2015-12-29 00:10:29 --> Total execution time: 0.1791
INFO - 2015-12-29 00:11:30 --> Config Class Initialized
INFO - 2015-12-29 00:11:30 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:30 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:30 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:30 --> URI Class Initialized
INFO - 2015-12-29 00:11:30 --> Router Class Initialized
INFO - 2015-12-29 00:11:30 --> Output Class Initialized
INFO - 2015-12-29 00:11:30 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:30 --> Input Class Initialized
INFO - 2015-12-29 00:11:30 --> Language Class Initialized
INFO - 2015-12-29 00:11:30 --> Loader Class Initialized
INFO - 2015-12-29 00:11:30 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:30 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:30 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:30 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:30 --> Model Class Initialized
INFO - 2015-12-29 00:11:30 --> Model Class Initialized
INFO - 2015-12-29 00:11:31 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:31 --> Total execution time: 0.4175
INFO - 2015-12-29 00:11:33 --> Config Class Initialized
INFO - 2015-12-29 00:11:33 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:33 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:33 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:33 --> URI Class Initialized
INFO - 2015-12-29 00:11:33 --> Router Class Initialized
INFO - 2015-12-29 00:11:33 --> Output Class Initialized
INFO - 2015-12-29 00:11:33 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:33 --> Input Class Initialized
INFO - 2015-12-29 00:11:33 --> Language Class Initialized
INFO - 2015-12-29 00:11:33 --> Loader Class Initialized
INFO - 2015-12-29 00:11:33 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:33 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:33 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:33 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:33 --> Model Class Initialized
INFO - 2015-12-29 00:11:33 --> Model Class Initialized
INFO - 2015-12-29 00:11:33 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:33 --> Total execution time: 0.1023
INFO - 2015-12-29 00:11:36 --> Config Class Initialized
INFO - 2015-12-29 00:11:36 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:36 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:36 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:36 --> URI Class Initialized
INFO - 2015-12-29 00:11:36 --> Router Class Initialized
INFO - 2015-12-29 00:11:36 --> Output Class Initialized
INFO - 2015-12-29 00:11:36 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:36 --> Input Class Initialized
INFO - 2015-12-29 00:11:36 --> Language Class Initialized
INFO - 2015-12-29 00:11:36 --> Loader Class Initialized
INFO - 2015-12-29 00:11:36 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:36 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:36 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:36 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:36 --> Model Class Initialized
INFO - 2015-12-29 00:11:36 --> Model Class Initialized
INFO - 2015-12-29 00:11:36 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:36 --> Total execution time: 0.1443
INFO - 2015-12-29 00:11:37 --> Config Class Initialized
INFO - 2015-12-29 00:11:37 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:37 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:37 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:37 --> URI Class Initialized
INFO - 2015-12-29 00:11:37 --> Router Class Initialized
INFO - 2015-12-29 00:11:37 --> Output Class Initialized
INFO - 2015-12-29 00:11:37 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:37 --> Input Class Initialized
INFO - 2015-12-29 00:11:37 --> Language Class Initialized
INFO - 2015-12-29 00:11:37 --> Loader Class Initialized
INFO - 2015-12-29 00:11:37 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:37 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:37 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:37 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:37 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:37 --> Model Class Initialized
INFO - 2015-12-29 00:11:37 --> Model Class Initialized
INFO - 2015-12-29 00:11:37 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:37 --> Total execution time: 0.1548
INFO - 2015-12-29 00:11:40 --> Config Class Initialized
INFO - 2015-12-29 00:11:40 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:40 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:40 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:40 --> URI Class Initialized
INFO - 2015-12-29 00:11:41 --> Router Class Initialized
INFO - 2015-12-29 00:11:41 --> Output Class Initialized
INFO - 2015-12-29 00:11:41 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:41 --> Input Class Initialized
INFO - 2015-12-29 00:11:41 --> Language Class Initialized
INFO - 2015-12-29 00:11:41 --> Loader Class Initialized
INFO - 2015-12-29 00:11:41 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:41 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:41 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:41 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:41 --> Model Class Initialized
INFO - 2015-12-29 00:11:41 --> Model Class Initialized
INFO - 2015-12-29 00:11:41 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:41 --> Total execution time: 0.1611
INFO - 2015-12-29 00:11:41 --> Config Class Initialized
INFO - 2015-12-29 00:11:41 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:41 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:41 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:41 --> URI Class Initialized
INFO - 2015-12-29 00:11:41 --> Router Class Initialized
INFO - 2015-12-29 00:11:41 --> Output Class Initialized
INFO - 2015-12-29 00:11:41 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:41 --> Input Class Initialized
INFO - 2015-12-29 00:11:41 --> Language Class Initialized
INFO - 2015-12-29 00:11:41 --> Loader Class Initialized
INFO - 2015-12-29 00:11:41 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:41 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:41 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:41 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:41 --> Model Class Initialized
INFO - 2015-12-29 00:11:41 --> Model Class Initialized
INFO - 2015-12-29 00:11:41 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:41 --> Total execution time: 0.1594
INFO - 2015-12-29 00:11:44 --> Config Class Initialized
INFO - 2015-12-29 00:11:44 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:44 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:44 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:44 --> URI Class Initialized
INFO - 2015-12-29 00:11:44 --> Router Class Initialized
INFO - 2015-12-29 00:11:44 --> Output Class Initialized
INFO - 2015-12-29 00:11:44 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:44 --> Input Class Initialized
INFO - 2015-12-29 00:11:44 --> Language Class Initialized
INFO - 2015-12-29 00:11:44 --> Loader Class Initialized
INFO - 2015-12-29 00:11:44 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:44 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:44 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:44 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:44 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:44 --> Model Class Initialized
INFO - 2015-12-29 00:11:44 --> Model Class Initialized
INFO - 2015-12-29 00:11:44 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:44 --> Total execution time: 0.1695
INFO - 2015-12-29 00:11:45 --> Config Class Initialized
INFO - 2015-12-29 00:11:45 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:45 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:45 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:45 --> URI Class Initialized
INFO - 2015-12-29 00:11:45 --> Router Class Initialized
INFO - 2015-12-29 00:11:45 --> Output Class Initialized
INFO - 2015-12-29 00:11:45 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:45 --> Input Class Initialized
INFO - 2015-12-29 00:11:45 --> Language Class Initialized
INFO - 2015-12-29 00:11:45 --> Loader Class Initialized
INFO - 2015-12-29 00:11:45 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:45 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:45 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:45 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:45 --> Model Class Initialized
INFO - 2015-12-29 00:11:45 --> Model Class Initialized
INFO - 2015-12-29 00:11:45 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:45 --> Total execution time: 0.1736
INFO - 2015-12-29 00:11:46 --> Config Class Initialized
INFO - 2015-12-29 00:11:46 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:46 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:46 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:46 --> URI Class Initialized
INFO - 2015-12-29 00:11:46 --> Router Class Initialized
INFO - 2015-12-29 00:11:46 --> Output Class Initialized
INFO - 2015-12-29 00:11:46 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:46 --> Input Class Initialized
INFO - 2015-12-29 00:11:46 --> Language Class Initialized
INFO - 2015-12-29 00:11:46 --> Loader Class Initialized
INFO - 2015-12-29 00:11:46 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:46 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:46 --> Controller Class Initialized
INFO - 2015-12-29 00:11:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-29 00:11:46 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:46 --> Total execution time: 0.1284
INFO - 2015-12-29 00:11:47 --> Config Class Initialized
INFO - 2015-12-29 00:11:47 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:47 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:47 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:47 --> URI Class Initialized
INFO - 2015-12-29 00:11:47 --> Router Class Initialized
INFO - 2015-12-29 00:11:47 --> Output Class Initialized
INFO - 2015-12-29 00:11:47 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:47 --> Input Class Initialized
INFO - 2015-12-29 00:11:47 --> Language Class Initialized
INFO - 2015-12-29 00:11:47 --> Loader Class Initialized
INFO - 2015-12-29 00:11:47 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:47 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:47 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:47 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:47 --> Model Class Initialized
INFO - 2015-12-29 00:11:47 --> Model Class Initialized
INFO - 2015-12-29 00:11:47 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:47 --> Total execution time: 0.1443
INFO - 2015-12-29 00:11:50 --> Config Class Initialized
INFO - 2015-12-29 00:11:50 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:50 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:50 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:50 --> URI Class Initialized
INFO - 2015-12-29 00:11:50 --> Router Class Initialized
INFO - 2015-12-29 00:11:50 --> Output Class Initialized
INFO - 2015-12-29 00:11:50 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:50 --> Input Class Initialized
INFO - 2015-12-29 00:11:50 --> Language Class Initialized
INFO - 2015-12-29 00:11:50 --> Loader Class Initialized
INFO - 2015-12-29 00:11:50 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:50 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:50 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:50 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:50 --> Model Class Initialized
INFO - 2015-12-29 00:11:50 --> Model Class Initialized
INFO - 2015-12-29 00:11:50 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:50 --> Total execution time: 0.1526
INFO - 2015-12-29 00:11:50 --> Config Class Initialized
INFO - 2015-12-29 00:11:50 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:50 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:50 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:50 --> URI Class Initialized
INFO - 2015-12-29 00:11:50 --> Router Class Initialized
INFO - 2015-12-29 00:11:50 --> Output Class Initialized
INFO - 2015-12-29 00:11:50 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:50 --> Input Class Initialized
INFO - 2015-12-29 00:11:50 --> Language Class Initialized
INFO - 2015-12-29 00:11:50 --> Loader Class Initialized
INFO - 2015-12-29 00:11:50 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:50 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:50 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:50 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:50 --> Model Class Initialized
INFO - 2015-12-29 00:11:50 --> Model Class Initialized
INFO - 2015-12-29 00:11:50 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:50 --> Total execution time: 0.1676
INFO - 2015-12-29 00:11:53 --> Config Class Initialized
INFO - 2015-12-29 00:11:53 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:53 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:53 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:53 --> URI Class Initialized
INFO - 2015-12-29 00:11:53 --> Router Class Initialized
INFO - 2015-12-29 00:11:53 --> Output Class Initialized
INFO - 2015-12-29 00:11:53 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:53 --> Input Class Initialized
INFO - 2015-12-29 00:11:53 --> Language Class Initialized
INFO - 2015-12-29 00:11:53 --> Loader Class Initialized
INFO - 2015-12-29 00:11:53 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:53 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:53 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:53 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:53 --> Model Class Initialized
INFO - 2015-12-29 00:11:53 --> Model Class Initialized
INFO - 2015-12-29 00:11:53 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:53 --> Total execution time: 0.1011
INFO - 2015-12-29 00:11:54 --> Config Class Initialized
INFO - 2015-12-29 00:11:54 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:11:54 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:11:54 --> Utf8 Class Initialized
INFO - 2015-12-29 00:11:54 --> URI Class Initialized
INFO - 2015-12-29 00:11:54 --> Router Class Initialized
INFO - 2015-12-29 00:11:54 --> Output Class Initialized
INFO - 2015-12-29 00:11:54 --> Security Class Initialized
DEBUG - 2015-12-29 00:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:11:54 --> Input Class Initialized
INFO - 2015-12-29 00:11:54 --> Language Class Initialized
INFO - 2015-12-29 00:11:54 --> Loader Class Initialized
INFO - 2015-12-29 00:11:54 --> Helper loaded: url_helper
INFO - 2015-12-29 00:11:54 --> Database Driver Class Initialized
INFO - 2015-12-29 00:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:11:54 --> Controller Class Initialized
DEBUG - 2015-12-29 00:11:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:11:54 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:11:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:11:54 --> Model Class Initialized
INFO - 2015-12-29 00:11:54 --> Model Class Initialized
INFO - 2015-12-29 00:11:54 --> Final output sent to browser
DEBUG - 2015-12-29 00:11:54 --> Total execution time: 0.0994
INFO - 2015-12-29 00:12:01 --> Config Class Initialized
INFO - 2015-12-29 00:12:01 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:12:01 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:12:01 --> Utf8 Class Initialized
INFO - 2015-12-29 00:12:01 --> URI Class Initialized
INFO - 2015-12-29 00:12:01 --> Router Class Initialized
INFO - 2015-12-29 00:12:01 --> Output Class Initialized
INFO - 2015-12-29 00:12:01 --> Security Class Initialized
DEBUG - 2015-12-29 00:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:12:01 --> Input Class Initialized
INFO - 2015-12-29 00:12:01 --> Language Class Initialized
INFO - 2015-12-29 00:12:01 --> Loader Class Initialized
INFO - 2015-12-29 00:12:01 --> Helper loaded: url_helper
INFO - 2015-12-29 00:12:01 --> Database Driver Class Initialized
INFO - 2015-12-29 00:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:12:01 --> Controller Class Initialized
DEBUG - 2015-12-29 00:12:01 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:12:01 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:12:01 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:12:01 --> Model Class Initialized
INFO - 2015-12-29 00:12:01 --> Model Class Initialized
INFO - 2015-12-29 00:12:01 --> Final output sent to browser
DEBUG - 2015-12-29 00:12:01 --> Total execution time: 0.1062
INFO - 2015-12-29 00:12:02 --> Config Class Initialized
INFO - 2015-12-29 00:12:02 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:12:02 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:12:02 --> Utf8 Class Initialized
INFO - 2015-12-29 00:12:02 --> URI Class Initialized
INFO - 2015-12-29 00:12:02 --> Router Class Initialized
INFO - 2015-12-29 00:12:02 --> Output Class Initialized
INFO - 2015-12-29 00:12:02 --> Security Class Initialized
DEBUG - 2015-12-29 00:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:12:02 --> Input Class Initialized
INFO - 2015-12-29 00:12:02 --> Language Class Initialized
INFO - 2015-12-29 00:12:02 --> Loader Class Initialized
INFO - 2015-12-29 00:12:02 --> Helper loaded: url_helper
INFO - 2015-12-29 00:12:02 --> Database Driver Class Initialized
INFO - 2015-12-29 00:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:12:02 --> Controller Class Initialized
DEBUG - 2015-12-29 00:12:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:12:02 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:12:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:12:02 --> Model Class Initialized
INFO - 2015-12-29 00:12:02 --> Model Class Initialized
INFO - 2015-12-29 00:12:02 --> Final output sent to browser
DEBUG - 2015-12-29 00:12:02 --> Total execution time: 0.1009
INFO - 2015-12-29 00:13:01 --> Config Class Initialized
INFO - 2015-12-29 00:13:02 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:13:02 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:13:02 --> Utf8 Class Initialized
INFO - 2015-12-29 00:13:02 --> URI Class Initialized
INFO - 2015-12-29 00:13:02 --> Router Class Initialized
INFO - 2015-12-29 00:13:02 --> Output Class Initialized
INFO - 2015-12-29 00:13:02 --> Security Class Initialized
DEBUG - 2015-12-29 00:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:13:02 --> Input Class Initialized
INFO - 2015-12-29 00:13:02 --> Language Class Initialized
INFO - 2015-12-29 00:13:02 --> Loader Class Initialized
INFO - 2015-12-29 00:13:02 --> Helper loaded: url_helper
INFO - 2015-12-29 00:13:02 --> Database Driver Class Initialized
INFO - 2015-12-29 00:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:13:02 --> Controller Class Initialized
DEBUG - 2015-12-29 00:13:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:13:02 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:13:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:13:02 --> Model Class Initialized
INFO - 2015-12-29 00:13:02 --> Model Class Initialized
INFO - 2015-12-29 00:13:02 --> Final output sent to browser
DEBUG - 2015-12-29 00:13:02 --> Total execution time: 0.3850
INFO - 2015-12-29 00:13:02 --> Config Class Initialized
INFO - 2015-12-29 00:13:02 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:13:02 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:13:02 --> Utf8 Class Initialized
INFO - 2015-12-29 00:13:02 --> URI Class Initialized
INFO - 2015-12-29 00:13:02 --> Router Class Initialized
INFO - 2015-12-29 00:13:02 --> Output Class Initialized
INFO - 2015-12-29 00:13:02 --> Security Class Initialized
DEBUG - 2015-12-29 00:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:13:02 --> Input Class Initialized
INFO - 2015-12-29 00:13:02 --> Language Class Initialized
INFO - 2015-12-29 00:13:02 --> Loader Class Initialized
INFO - 2015-12-29 00:13:02 --> Helper loaded: url_helper
INFO - 2015-12-29 00:13:02 --> Database Driver Class Initialized
INFO - 2015-12-29 00:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:13:02 --> Controller Class Initialized
DEBUG - 2015-12-29 00:13:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:13:02 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:13:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:13:02 --> Model Class Initialized
INFO - 2015-12-29 00:13:02 --> Model Class Initialized
INFO - 2015-12-29 00:13:03 --> Final output sent to browser
DEBUG - 2015-12-29 00:13:03 --> Total execution time: 0.1088
INFO - 2015-12-29 00:13:04 --> Config Class Initialized
INFO - 2015-12-29 00:13:04 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:13:04 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:13:04 --> Utf8 Class Initialized
INFO - 2015-12-29 00:13:04 --> URI Class Initialized
INFO - 2015-12-29 00:13:04 --> Router Class Initialized
INFO - 2015-12-29 00:13:04 --> Output Class Initialized
INFO - 2015-12-29 00:13:04 --> Security Class Initialized
DEBUG - 2015-12-29 00:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:13:04 --> Input Class Initialized
INFO - 2015-12-29 00:13:04 --> Language Class Initialized
INFO - 2015-12-29 00:13:04 --> Loader Class Initialized
INFO - 2015-12-29 00:13:04 --> Helper loaded: url_helper
INFO - 2015-12-29 00:13:04 --> Database Driver Class Initialized
INFO - 2015-12-29 00:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:13:04 --> Controller Class Initialized
DEBUG - 2015-12-29 00:13:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:13:04 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:13:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:13:04 --> Model Class Initialized
INFO - 2015-12-29 00:13:04 --> Model Class Initialized
INFO - 2015-12-29 00:13:04 --> Final output sent to browser
DEBUG - 2015-12-29 00:13:04 --> Total execution time: 0.1513
INFO - 2015-12-29 00:13:05 --> Config Class Initialized
INFO - 2015-12-29 00:13:05 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:13:05 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:13:05 --> Utf8 Class Initialized
INFO - 2015-12-29 00:13:05 --> URI Class Initialized
INFO - 2015-12-29 00:13:05 --> Router Class Initialized
INFO - 2015-12-29 00:13:05 --> Output Class Initialized
INFO - 2015-12-29 00:13:05 --> Security Class Initialized
DEBUG - 2015-12-29 00:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:13:05 --> Input Class Initialized
INFO - 2015-12-29 00:13:05 --> Language Class Initialized
INFO - 2015-12-29 00:13:05 --> Loader Class Initialized
INFO - 2015-12-29 00:13:05 --> Helper loaded: url_helper
INFO - 2015-12-29 00:13:05 --> Database Driver Class Initialized
INFO - 2015-12-29 00:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:13:05 --> Controller Class Initialized
DEBUG - 2015-12-29 00:13:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:13:05 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:13:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:13:05 --> Model Class Initialized
INFO - 2015-12-29 00:13:05 --> Model Class Initialized
INFO - 2015-12-29 00:13:05 --> Final output sent to browser
DEBUG - 2015-12-29 00:13:05 --> Total execution time: 0.1044
INFO - 2015-12-29 00:13:07 --> Config Class Initialized
INFO - 2015-12-29 00:13:07 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:13:07 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:13:07 --> Utf8 Class Initialized
INFO - 2015-12-29 00:13:07 --> URI Class Initialized
INFO - 2015-12-29 00:13:07 --> Router Class Initialized
INFO - 2015-12-29 00:13:07 --> Output Class Initialized
INFO - 2015-12-29 00:13:07 --> Security Class Initialized
DEBUG - 2015-12-29 00:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:13:07 --> Input Class Initialized
INFO - 2015-12-29 00:13:07 --> Language Class Initialized
INFO - 2015-12-29 00:13:07 --> Loader Class Initialized
INFO - 2015-12-29 00:13:07 --> Helper loaded: url_helper
INFO - 2015-12-29 00:13:07 --> Database Driver Class Initialized
INFO - 2015-12-29 00:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:13:07 --> Controller Class Initialized
DEBUG - 2015-12-29 00:13:07 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:13:07 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:13:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:13:07 --> Model Class Initialized
INFO - 2015-12-29 00:13:07 --> Model Class Initialized
INFO - 2015-12-29 00:13:07 --> Final output sent to browser
DEBUG - 2015-12-29 00:13:07 --> Total execution time: 0.1036
INFO - 2015-12-29 00:13:08 --> Config Class Initialized
INFO - 2015-12-29 00:13:08 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:13:08 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:13:08 --> Utf8 Class Initialized
INFO - 2015-12-29 00:13:08 --> URI Class Initialized
INFO - 2015-12-29 00:13:08 --> Router Class Initialized
INFO - 2015-12-29 00:13:08 --> Output Class Initialized
INFO - 2015-12-29 00:13:08 --> Security Class Initialized
DEBUG - 2015-12-29 00:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:13:08 --> Input Class Initialized
INFO - 2015-12-29 00:13:08 --> Language Class Initialized
INFO - 2015-12-29 00:13:08 --> Loader Class Initialized
INFO - 2015-12-29 00:13:08 --> Helper loaded: url_helper
INFO - 2015-12-29 00:13:08 --> Database Driver Class Initialized
INFO - 2015-12-29 00:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:13:08 --> Controller Class Initialized
DEBUG - 2015-12-29 00:13:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:13:08 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:13:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:13:08 --> Model Class Initialized
INFO - 2015-12-29 00:13:08 --> Model Class Initialized
INFO - 2015-12-29 00:13:08 --> Final output sent to browser
DEBUG - 2015-12-29 00:13:08 --> Total execution time: 0.1347
INFO - 2015-12-29 00:13:11 --> Config Class Initialized
INFO - 2015-12-29 00:13:11 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:13:11 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:13:11 --> Utf8 Class Initialized
INFO - 2015-12-29 00:13:11 --> URI Class Initialized
INFO - 2015-12-29 00:13:11 --> Router Class Initialized
INFO - 2015-12-29 00:13:11 --> Output Class Initialized
INFO - 2015-12-29 00:13:11 --> Security Class Initialized
DEBUG - 2015-12-29 00:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:13:11 --> Input Class Initialized
INFO - 2015-12-29 00:13:11 --> Language Class Initialized
INFO - 2015-12-29 00:13:11 --> Loader Class Initialized
INFO - 2015-12-29 00:13:11 --> Helper loaded: url_helper
INFO - 2015-12-29 00:13:11 --> Database Driver Class Initialized
INFO - 2015-12-29 00:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:13:11 --> Controller Class Initialized
DEBUG - 2015-12-29 00:13:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:13:11 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:13:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:13:11 --> Model Class Initialized
INFO - 2015-12-29 00:13:11 --> Model Class Initialized
INFO - 2015-12-29 00:13:11 --> Final output sent to browser
DEBUG - 2015-12-29 00:13:11 --> Total execution time: 0.1066
INFO - 2015-12-29 00:13:12 --> Config Class Initialized
INFO - 2015-12-29 00:13:12 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:13:12 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:13:12 --> Utf8 Class Initialized
INFO - 2015-12-29 00:13:12 --> URI Class Initialized
INFO - 2015-12-29 00:13:12 --> Router Class Initialized
INFO - 2015-12-29 00:13:12 --> Output Class Initialized
INFO - 2015-12-29 00:13:12 --> Security Class Initialized
DEBUG - 2015-12-29 00:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:13:12 --> Input Class Initialized
INFO - 2015-12-29 00:13:12 --> Language Class Initialized
INFO - 2015-12-29 00:13:12 --> Loader Class Initialized
INFO - 2015-12-29 00:13:12 --> Helper loaded: url_helper
INFO - 2015-12-29 00:13:12 --> Database Driver Class Initialized
INFO - 2015-12-29 00:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:13:12 --> Controller Class Initialized
DEBUG - 2015-12-29 00:13:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:13:12 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:13:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:13:12 --> Model Class Initialized
INFO - 2015-12-29 00:13:12 --> Model Class Initialized
INFO - 2015-12-29 00:13:12 --> Final output sent to browser
DEBUG - 2015-12-29 00:13:12 --> Total execution time: 0.0996
INFO - 2015-12-29 00:13:14 --> Config Class Initialized
INFO - 2015-12-29 00:13:14 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:13:14 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:13:14 --> Utf8 Class Initialized
INFO - 2015-12-29 00:13:14 --> URI Class Initialized
INFO - 2015-12-29 00:13:14 --> Router Class Initialized
INFO - 2015-12-29 00:13:14 --> Output Class Initialized
INFO - 2015-12-29 00:13:14 --> Security Class Initialized
DEBUG - 2015-12-29 00:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:13:14 --> Input Class Initialized
INFO - 2015-12-29 00:13:14 --> Language Class Initialized
INFO - 2015-12-29 00:13:14 --> Loader Class Initialized
INFO - 2015-12-29 00:13:14 --> Helper loaded: url_helper
INFO - 2015-12-29 00:13:14 --> Database Driver Class Initialized
INFO - 2015-12-29 00:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:13:14 --> Controller Class Initialized
DEBUG - 2015-12-29 00:13:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:13:14 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:13:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:13:14 --> Model Class Initialized
INFO - 2015-12-29 00:13:14 --> Model Class Initialized
INFO - 2015-12-29 00:13:14 --> Final output sent to browser
DEBUG - 2015-12-29 00:13:14 --> Total execution time: 0.1002
INFO - 2015-12-29 00:13:15 --> Config Class Initialized
INFO - 2015-12-29 00:13:15 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:13:15 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:13:15 --> Utf8 Class Initialized
INFO - 2015-12-29 00:13:15 --> URI Class Initialized
INFO - 2015-12-29 00:13:15 --> Router Class Initialized
INFO - 2015-12-29 00:13:15 --> Output Class Initialized
INFO - 2015-12-29 00:13:15 --> Security Class Initialized
DEBUG - 2015-12-29 00:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:13:15 --> Input Class Initialized
INFO - 2015-12-29 00:13:15 --> Language Class Initialized
INFO - 2015-12-29 00:13:15 --> Loader Class Initialized
INFO - 2015-12-29 00:13:15 --> Helper loaded: url_helper
INFO - 2015-12-29 00:13:15 --> Database Driver Class Initialized
INFO - 2015-12-29 00:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:13:15 --> Controller Class Initialized
DEBUG - 2015-12-29 00:13:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-29 00:13:15 --> Helper loaded: inflector_helper
INFO - 2015-12-29 00:13:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-29 00:13:15 --> Model Class Initialized
INFO - 2015-12-29 00:13:15 --> Model Class Initialized
INFO - 2015-12-29 00:13:15 --> Final output sent to browser
DEBUG - 2015-12-29 00:13:15 --> Total execution time: 0.1135
INFO - 2015-12-29 00:45:47 --> Config Class Initialized
INFO - 2015-12-29 00:45:47 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:45:47 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:45:47 --> Utf8 Class Initialized
INFO - 2015-12-29 00:45:47 --> URI Class Initialized
INFO - 2015-12-29 00:45:47 --> Router Class Initialized
INFO - 2015-12-29 00:45:47 --> Output Class Initialized
INFO - 2015-12-29 00:45:47 --> Security Class Initialized
DEBUG - 2015-12-29 00:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:45:47 --> Input Class Initialized
INFO - 2015-12-29 00:45:47 --> Language Class Initialized
INFO - 2015-12-29 00:45:47 --> Loader Class Initialized
INFO - 2015-12-29 00:45:47 --> Helper loaded: url_helper
INFO - 2015-12-29 00:45:47 --> Database Driver Class Initialized
INFO - 2015-12-29 00:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:45:47 --> Controller Class Initialized
INFO - 2015-12-29 00:45:47 --> Helper loaded: form_helper
INFO - 2015-12-29 00:45:47 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-29 00:45:47 --> Final output sent to browser
DEBUG - 2015-12-29 00:45:47 --> Total execution time: 0.3593
INFO - 2015-12-29 00:46:15 --> Config Class Initialized
INFO - 2015-12-29 00:46:15 --> Hooks Class Initialized
DEBUG - 2015-12-29 00:46:15 --> UTF-8 Support Enabled
INFO - 2015-12-29 00:46:15 --> Utf8 Class Initialized
INFO - 2015-12-29 00:46:15 --> URI Class Initialized
INFO - 2015-12-29 00:46:15 --> Router Class Initialized
INFO - 2015-12-29 00:46:15 --> Output Class Initialized
INFO - 2015-12-29 00:46:15 --> Security Class Initialized
DEBUG - 2015-12-29 00:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-29 00:46:15 --> Input Class Initialized
INFO - 2015-12-29 00:46:15 --> Language Class Initialized
INFO - 2015-12-29 00:46:16 --> Loader Class Initialized
INFO - 2015-12-29 00:46:16 --> Helper loaded: url_helper
INFO - 2015-12-29 00:46:16 --> Database Driver Class Initialized
INFO - 2015-12-29 00:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-29 00:46:16 --> Controller Class Initialized
INFO - 2015-12-29 00:46:16 --> Helper loaded: form_helper
INFO - 2015-12-29 00:46:16 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-29 00:46:16 --> Final output sent to browser
DEBUG - 2015-12-29 00:46:16 --> Total execution time: 0.0985
