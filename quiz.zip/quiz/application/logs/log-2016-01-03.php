<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-03 07:15:59 --> Config Class Initialized
INFO - 2016-01-03 07:15:59 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:15:59 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:15:59 --> Utf8 Class Initialized
INFO - 2016-01-03 07:15:59 --> URI Class Initialized
INFO - 2016-01-03 07:15:59 --> Router Class Initialized
INFO - 2016-01-03 07:15:59 --> Output Class Initialized
INFO - 2016-01-03 07:15:59 --> Security Class Initialized
DEBUG - 2016-01-03 07:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:15:59 --> Input Class Initialized
INFO - 2016-01-03 07:15:59 --> Language Class Initialized
INFO - 2016-01-03 07:15:59 --> Loader Class Initialized
INFO - 2016-01-03 07:15:59 --> Helper loaded: url_helper
INFO - 2016-01-03 07:15:59 --> Database Driver Class Initialized
INFO - 2016-01-03 07:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:15:59 --> Controller Class Initialized
INFO - 2016-01-03 07:16:00 --> Helper loaded: form_helper
INFO - 2016-01-03 07:16:00 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 07:16:00 --> Final output sent to browser
DEBUG - 2016-01-03 07:16:00 --> Total execution time: 0.5219
INFO - 2016-01-03 07:16:15 --> Config Class Initialized
INFO - 2016-01-03 07:16:15 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:16:15 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:16:15 --> Utf8 Class Initialized
INFO - 2016-01-03 07:16:15 --> URI Class Initialized
INFO - 2016-01-03 07:16:15 --> Router Class Initialized
INFO - 2016-01-03 07:16:15 --> Output Class Initialized
INFO - 2016-01-03 07:16:15 --> Security Class Initialized
DEBUG - 2016-01-03 07:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:16:15 --> Input Class Initialized
INFO - 2016-01-03 07:16:15 --> Language Class Initialized
INFO - 2016-01-03 07:16:15 --> Loader Class Initialized
INFO - 2016-01-03 07:16:15 --> Helper loaded: url_helper
INFO - 2016-01-03 07:16:15 --> Database Driver Class Initialized
INFO - 2016-01-03 07:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:16:15 --> Controller Class Initialized
INFO - 2016-01-03 07:16:15 --> Model Class Initialized
INFO - 2016-01-03 07:16:15 --> Model Class Initialized
INFO - 2016-01-03 07:16:15 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 07:16:15 --> Final output sent to browser
DEBUG - 2016-01-03 07:16:15 --> Total execution time: 0.1763
INFO - 2016-01-03 07:16:21 --> Config Class Initialized
INFO - 2016-01-03 07:16:21 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:16:21 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:16:21 --> Utf8 Class Initialized
INFO - 2016-01-03 07:16:21 --> URI Class Initialized
INFO - 2016-01-03 07:16:21 --> Router Class Initialized
INFO - 2016-01-03 07:16:21 --> Output Class Initialized
INFO - 2016-01-03 07:16:21 --> Security Class Initialized
DEBUG - 2016-01-03 07:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:16:21 --> Input Class Initialized
INFO - 2016-01-03 07:16:21 --> Language Class Initialized
INFO - 2016-01-03 07:16:21 --> Loader Class Initialized
INFO - 2016-01-03 07:16:21 --> Helper loaded: url_helper
INFO - 2016-01-03 07:16:21 --> Database Driver Class Initialized
ERROR - 2016-01-03 07:16:21 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2016-01-03 07:16:21 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
INFO - 2016-01-03 07:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:16:21 --> Controller Class Initialized
INFO - 2016-01-03 07:16:21 --> Model Class Initialized
INFO - 2016-01-03 07:16:21 --> Model Class Initialized
INFO - 2016-01-03 07:16:21 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 07:16:21 --> Final output sent to browser
DEBUG - 2016-01-03 07:16:21 --> Total execution time: 0.1403
INFO - 2016-01-03 07:16:22 --> Config Class Initialized
INFO - 2016-01-03 07:16:22 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:16:22 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:16:22 --> Utf8 Class Initialized
INFO - 2016-01-03 07:16:22 --> URI Class Initialized
INFO - 2016-01-03 07:16:22 --> Router Class Initialized
INFO - 2016-01-03 07:16:22 --> Output Class Initialized
INFO - 2016-01-03 07:16:22 --> Security Class Initialized
DEBUG - 2016-01-03 07:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:16:22 --> Input Class Initialized
INFO - 2016-01-03 07:16:22 --> Language Class Initialized
INFO - 2016-01-03 07:16:22 --> Loader Class Initialized
INFO - 2016-01-03 07:16:22 --> Helper loaded: url_helper
INFO - 2016-01-03 07:16:22 --> Database Driver Class Initialized
INFO - 2016-01-03 07:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:16:22 --> Controller Class Initialized
INFO - 2016-01-03 07:16:22 --> Config Class Initialized
INFO - 2016-01-03 07:16:22 --> Model Class Initialized
INFO - 2016-01-03 07:16:22 --> Hooks Class Initialized
INFO - 2016-01-03 07:16:22 --> Model Class Initialized
DEBUG - 2016-01-03 07:16:22 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:16:22 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 07:16:22 --> Utf8 Class Initialized
INFO - 2016-01-03 07:16:22 --> Final output sent to browser
INFO - 2016-01-03 07:16:22 --> URI Class Initialized
DEBUG - 2016-01-03 07:16:22 --> Total execution time: 0.1025
INFO - 2016-01-03 07:16:22 --> Router Class Initialized
INFO - 2016-01-03 07:16:22 --> Output Class Initialized
INFO - 2016-01-03 07:16:22 --> Security Class Initialized
DEBUG - 2016-01-03 07:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:16:22 --> Input Class Initialized
INFO - 2016-01-03 07:16:22 --> Language Class Initialized
INFO - 2016-01-03 07:16:22 --> Loader Class Initialized
INFO - 2016-01-03 07:16:22 --> Helper loaded: url_helper
INFO - 2016-01-03 07:16:22 --> Database Driver Class Initialized
INFO - 2016-01-03 07:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:16:22 --> Controller Class Initialized
DEBUG - 2016-01-03 07:16:22 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:16:22 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:16:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:16:22 --> Model Class Initialized
INFO - 2016-01-03 07:16:22 --> Model Class Initialized
INFO - 2016-01-03 07:16:22 --> Final output sent to browser
DEBUG - 2016-01-03 07:16:22 --> Total execution time: 0.1312
INFO - 2016-01-03 07:16:29 --> Config Class Initialized
INFO - 2016-01-03 07:16:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:16:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:16:29 --> Utf8 Class Initialized
INFO - 2016-01-03 07:16:29 --> URI Class Initialized
INFO - 2016-01-03 07:16:29 --> Router Class Initialized
INFO - 2016-01-03 07:16:29 --> Output Class Initialized
INFO - 2016-01-03 07:16:29 --> Security Class Initialized
DEBUG - 2016-01-03 07:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:16:29 --> Input Class Initialized
INFO - 2016-01-03 07:16:29 --> Language Class Initialized
INFO - 2016-01-03 07:16:29 --> Loader Class Initialized
INFO - 2016-01-03 07:16:29 --> Helper loaded: url_helper
INFO - 2016-01-03 07:16:29 --> Database Driver Class Initialized
INFO - 2016-01-03 07:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:16:29 --> Controller Class Initialized
INFO - 2016-01-03 07:16:29 --> Model Class Initialized
INFO - 2016-01-03 07:16:29 --> Model Class Initialized
INFO - 2016-01-03 07:16:29 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 07:16:29 --> Final output sent to browser
DEBUG - 2016-01-03 07:16:29 --> Total execution time: 0.1613
INFO - 2016-01-03 07:16:29 --> Config Class Initialized
INFO - 2016-01-03 07:16:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:16:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:16:29 --> Utf8 Class Initialized
INFO - 2016-01-03 07:16:29 --> URI Class Initialized
INFO - 2016-01-03 07:16:29 --> Router Class Initialized
INFO - 2016-01-03 07:16:29 --> Output Class Initialized
INFO - 2016-01-03 07:16:29 --> Security Class Initialized
DEBUG - 2016-01-03 07:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:16:29 --> Input Class Initialized
INFO - 2016-01-03 07:16:29 --> Language Class Initialized
INFO - 2016-01-03 07:16:29 --> Loader Class Initialized
INFO - 2016-01-03 07:16:29 --> Helper loaded: url_helper
INFO - 2016-01-03 07:16:29 --> Database Driver Class Initialized
INFO - 2016-01-03 07:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:16:29 --> Controller Class Initialized
INFO - 2016-01-03 07:16:29 --> Model Class Initialized
INFO - 2016-01-03 07:16:29 --> Model Class Initialized
INFO - 2016-01-03 07:16:29 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 07:16:29 --> Final output sent to browser
DEBUG - 2016-01-03 07:16:29 --> Total execution time: 0.1363
INFO - 2016-01-03 07:16:29 --> Config Class Initialized
INFO - 2016-01-03 07:16:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:16:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:16:29 --> Utf8 Class Initialized
INFO - 2016-01-03 07:16:29 --> URI Class Initialized
INFO - 2016-01-03 07:16:29 --> Router Class Initialized
INFO - 2016-01-03 07:16:29 --> Output Class Initialized
INFO - 2016-01-03 07:16:29 --> Security Class Initialized
DEBUG - 2016-01-03 07:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:16:29 --> Input Class Initialized
INFO - 2016-01-03 07:16:29 --> Language Class Initialized
INFO - 2016-01-03 07:16:29 --> Loader Class Initialized
INFO - 2016-01-03 07:16:29 --> Helper loaded: url_helper
INFO - 2016-01-03 07:16:29 --> Database Driver Class Initialized
INFO - 2016-01-03 07:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:16:29 --> Controller Class Initialized
DEBUG - 2016-01-03 07:16:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:16:29 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:16:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:16:29 --> Model Class Initialized
INFO - 2016-01-03 07:16:29 --> Model Class Initialized
INFO - 2016-01-03 07:16:29 --> Final output sent to browser
DEBUG - 2016-01-03 07:16:29 --> Total execution time: 0.1648
INFO - 2016-01-03 07:18:32 --> Config Class Initialized
INFO - 2016-01-03 07:18:32 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:18:32 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:18:32 --> Utf8 Class Initialized
INFO - 2016-01-03 07:18:32 --> URI Class Initialized
DEBUG - 2016-01-03 07:18:32 --> No URI present. Default controller set.
INFO - 2016-01-03 07:18:32 --> Router Class Initialized
INFO - 2016-01-03 07:18:32 --> Output Class Initialized
INFO - 2016-01-03 07:18:32 --> Security Class Initialized
DEBUG - 2016-01-03 07:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:18:32 --> Input Class Initialized
INFO - 2016-01-03 07:18:32 --> Language Class Initialized
INFO - 2016-01-03 07:18:32 --> Loader Class Initialized
INFO - 2016-01-03 07:18:32 --> Helper loaded: url_helper
INFO - 2016-01-03 07:18:32 --> Database Driver Class Initialized
INFO - 2016-01-03 07:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:18:32 --> Controller Class Initialized
INFO - 2016-01-03 07:18:32 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 07:18:32 --> Final output sent to browser
DEBUG - 2016-01-03 07:18:32 --> Total execution time: 0.4207
INFO - 2016-01-03 07:20:15 --> Config Class Initialized
INFO - 2016-01-03 07:20:16 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:20:16 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:20:16 --> Utf8 Class Initialized
INFO - 2016-01-03 07:20:16 --> URI Class Initialized
INFO - 2016-01-03 07:20:16 --> Router Class Initialized
INFO - 2016-01-03 07:20:16 --> Output Class Initialized
INFO - 2016-01-03 07:20:16 --> Security Class Initialized
DEBUG - 2016-01-03 07:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:20:16 --> Input Class Initialized
INFO - 2016-01-03 07:20:16 --> Language Class Initialized
INFO - 2016-01-03 07:20:16 --> Loader Class Initialized
INFO - 2016-01-03 07:20:16 --> Helper loaded: url_helper
INFO - 2016-01-03 07:20:16 --> Database Driver Class Initialized
INFO - 2016-01-03 07:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:20:16 --> Controller Class Initialized
INFO - 2016-01-03 07:20:16 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:20:16 --> Final output sent to browser
DEBUG - 2016-01-03 07:20:16 --> Total execution time: 0.3982
INFO - 2016-01-03 07:20:16 --> Config Class Initialized
INFO - 2016-01-03 07:20:16 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:20:16 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:20:16 --> Utf8 Class Initialized
INFO - 2016-01-03 07:20:16 --> URI Class Initialized
INFO - 2016-01-03 07:20:16 --> Router Class Initialized
INFO - 2016-01-03 07:20:16 --> Output Class Initialized
INFO - 2016-01-03 07:20:16 --> Security Class Initialized
DEBUG - 2016-01-03 07:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:20:16 --> Input Class Initialized
INFO - 2016-01-03 07:20:16 --> Language Class Initialized
INFO - 2016-01-03 07:20:16 --> Loader Class Initialized
INFO - 2016-01-03 07:20:16 --> Helper loaded: url_helper
INFO - 2016-01-03 07:20:16 --> Database Driver Class Initialized
INFO - 2016-01-03 07:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:20:16 --> Controller Class Initialized
DEBUG - 2016-01-03 07:20:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:20:16 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:20:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:20:16 --> Model Class Initialized
INFO - 2016-01-03 07:20:16 --> Model Class Initialized
INFO - 2016-01-03 07:20:16 --> Final output sent to browser
DEBUG - 2016-01-03 07:20:16 --> Total execution time: 0.1208
INFO - 2016-01-03 07:21:17 --> Config Class Initialized
INFO - 2016-01-03 07:21:17 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:21:17 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:21:17 --> Utf8 Class Initialized
INFO - 2016-01-03 07:21:17 --> URI Class Initialized
INFO - 2016-01-03 07:21:17 --> Router Class Initialized
INFO - 2016-01-03 07:21:17 --> Output Class Initialized
INFO - 2016-01-03 07:21:17 --> Security Class Initialized
DEBUG - 2016-01-03 07:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:21:17 --> Input Class Initialized
INFO - 2016-01-03 07:21:17 --> Language Class Initialized
INFO - 2016-01-03 07:21:17 --> Loader Class Initialized
INFO - 2016-01-03 07:21:17 --> Helper loaded: url_helper
INFO - 2016-01-03 07:21:17 --> Database Driver Class Initialized
INFO - 2016-01-03 07:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:21:17 --> Controller Class Initialized
DEBUG - 2016-01-03 07:21:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:21:17 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:21:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:21:17 --> Model Class Initialized
INFO - 2016-01-03 07:21:18 --> Model Class Initialized
INFO - 2016-01-03 07:21:18 --> Final output sent to browser
DEBUG - 2016-01-03 07:21:18 --> Total execution time: 0.4028
INFO - 2016-01-03 07:21:35 --> Config Class Initialized
INFO - 2016-01-03 07:21:35 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:21:35 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:21:35 --> Utf8 Class Initialized
INFO - 2016-01-03 07:21:35 --> URI Class Initialized
INFO - 2016-01-03 07:21:35 --> Router Class Initialized
INFO - 2016-01-03 07:21:35 --> Output Class Initialized
INFO - 2016-01-03 07:21:35 --> Security Class Initialized
DEBUG - 2016-01-03 07:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:21:35 --> Input Class Initialized
INFO - 2016-01-03 07:21:35 --> Language Class Initialized
INFO - 2016-01-03 07:21:35 --> Loader Class Initialized
INFO - 2016-01-03 07:21:35 --> Helper loaded: url_helper
INFO - 2016-01-03 07:21:35 --> Database Driver Class Initialized
INFO - 2016-01-03 07:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:21:35 --> Controller Class Initialized
DEBUG - 2016-01-03 07:21:35 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:21:35 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:21:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:21:35 --> Model Class Initialized
INFO - 2016-01-03 07:21:35 --> Model Class Initialized
INFO - 2016-01-03 07:21:35 --> Final output sent to browser
DEBUG - 2016-01-03 07:21:35 --> Total execution time: 0.1573
INFO - 2016-01-03 07:22:36 --> Config Class Initialized
INFO - 2016-01-03 07:22:36 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:22:36 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:22:36 --> Utf8 Class Initialized
INFO - 2016-01-03 07:22:36 --> URI Class Initialized
INFO - 2016-01-03 07:22:36 --> Router Class Initialized
INFO - 2016-01-03 07:22:36 --> Output Class Initialized
INFO - 2016-01-03 07:22:36 --> Security Class Initialized
DEBUG - 2016-01-03 07:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:22:36 --> Input Class Initialized
INFO - 2016-01-03 07:22:36 --> Language Class Initialized
INFO - 2016-01-03 07:22:36 --> Loader Class Initialized
INFO - 2016-01-03 07:22:36 --> Helper loaded: url_helper
INFO - 2016-01-03 07:22:36 --> Database Driver Class Initialized
INFO - 2016-01-03 07:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:22:36 --> Controller Class Initialized
DEBUG - 2016-01-03 07:22:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:22:36 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:22:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:22:36 --> Model Class Initialized
INFO - 2016-01-03 07:22:36 --> Model Class Initialized
INFO - 2016-01-03 07:22:36 --> Final output sent to browser
DEBUG - 2016-01-03 07:22:36 --> Total execution time: 0.1793
INFO - 2016-01-03 07:22:38 --> Config Class Initialized
INFO - 2016-01-03 07:22:38 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:22:38 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:22:38 --> Utf8 Class Initialized
INFO - 2016-01-03 07:22:38 --> URI Class Initialized
INFO - 2016-01-03 07:22:38 --> Router Class Initialized
INFO - 2016-01-03 07:22:38 --> Output Class Initialized
INFO - 2016-01-03 07:22:38 --> Security Class Initialized
DEBUG - 2016-01-03 07:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:22:38 --> Input Class Initialized
INFO - 2016-01-03 07:22:38 --> Language Class Initialized
INFO - 2016-01-03 07:22:38 --> Loader Class Initialized
INFO - 2016-01-03 07:22:38 --> Helper loaded: url_helper
INFO - 2016-01-03 07:22:38 --> Database Driver Class Initialized
INFO - 2016-01-03 07:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:22:38 --> Controller Class Initialized
DEBUG - 2016-01-03 07:22:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:22:38 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:22:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:22:38 --> Model Class Initialized
INFO - 2016-01-03 07:22:38 --> Model Class Initialized
INFO - 2016-01-03 07:22:38 --> Final output sent to browser
DEBUG - 2016-01-03 07:22:38 --> Total execution time: 0.1014
INFO - 2016-01-03 07:23:07 --> Config Class Initialized
INFO - 2016-01-03 07:23:07 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:23:07 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:23:07 --> Utf8 Class Initialized
INFO - 2016-01-03 07:23:07 --> URI Class Initialized
INFO - 2016-01-03 07:23:07 --> Router Class Initialized
INFO - 2016-01-03 07:23:07 --> Output Class Initialized
INFO - 2016-01-03 07:23:07 --> Security Class Initialized
DEBUG - 2016-01-03 07:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:23:07 --> Input Class Initialized
INFO - 2016-01-03 07:23:07 --> Language Class Initialized
INFO - 2016-01-03 07:23:07 --> Loader Class Initialized
INFO - 2016-01-03 07:23:07 --> Helper loaded: url_helper
INFO - 2016-01-03 07:23:07 --> Database Driver Class Initialized
INFO - 2016-01-03 07:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:23:07 --> Controller Class Initialized
INFO - 2016-01-03 07:23:07 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:23:07 --> Final output sent to browser
DEBUG - 2016-01-03 07:23:07 --> Total execution time: 0.1379
INFO - 2016-01-03 07:23:07 --> Config Class Initialized
INFO - 2016-01-03 07:23:07 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:23:07 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:23:07 --> Utf8 Class Initialized
INFO - 2016-01-03 07:23:07 --> URI Class Initialized
DEBUG - 2016-01-03 07:23:07 --> No URI present. Default controller set.
INFO - 2016-01-03 07:23:07 --> Router Class Initialized
INFO - 2016-01-03 07:23:07 --> Output Class Initialized
INFO - 2016-01-03 07:23:07 --> Security Class Initialized
DEBUG - 2016-01-03 07:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:23:07 --> Input Class Initialized
INFO - 2016-01-03 07:23:07 --> Language Class Initialized
INFO - 2016-01-03 07:23:07 --> Loader Class Initialized
INFO - 2016-01-03 07:23:07 --> Helper loaded: url_helper
INFO - 2016-01-03 07:23:07 --> Database Driver Class Initialized
INFO - 2016-01-03 07:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:23:07 --> Controller Class Initialized
INFO - 2016-01-03 07:23:07 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 07:23:07 --> Final output sent to browser
DEBUG - 2016-01-03 07:23:07 --> Total execution time: 0.1193
INFO - 2016-01-03 07:23:42 --> Config Class Initialized
INFO - 2016-01-03 07:23:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:23:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:23:42 --> Utf8 Class Initialized
INFO - 2016-01-03 07:23:42 --> URI Class Initialized
INFO - 2016-01-03 07:23:42 --> Router Class Initialized
INFO - 2016-01-03 07:23:42 --> Output Class Initialized
INFO - 2016-01-03 07:23:42 --> Security Class Initialized
DEBUG - 2016-01-03 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:23:42 --> Input Class Initialized
INFO - 2016-01-03 07:23:42 --> Language Class Initialized
INFO - 2016-01-03 07:23:42 --> Loader Class Initialized
INFO - 2016-01-03 07:23:42 --> Helper loaded: url_helper
INFO - 2016-01-03 07:23:42 --> Database Driver Class Initialized
INFO - 2016-01-03 07:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:23:42 --> Controller Class Initialized
INFO - 2016-01-03 07:23:42 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:23:42 --> Final output sent to browser
DEBUG - 2016-01-03 07:23:42 --> Total execution time: 0.1133
INFO - 2016-01-03 07:23:42 --> Config Class Initialized
INFO - 2016-01-03 07:23:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:23:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:23:42 --> Utf8 Class Initialized
INFO - 2016-01-03 07:23:42 --> URI Class Initialized
INFO - 2016-01-03 07:23:42 --> Router Class Initialized
INFO - 2016-01-03 07:23:42 --> Output Class Initialized
INFO - 2016-01-03 07:23:42 --> Security Class Initialized
DEBUG - 2016-01-03 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:23:42 --> Input Class Initialized
INFO - 2016-01-03 07:23:42 --> Language Class Initialized
INFO - 2016-01-03 07:23:42 --> Loader Class Initialized
INFO - 2016-01-03 07:23:42 --> Helper loaded: url_helper
INFO - 2016-01-03 07:23:42 --> Database Driver Class Initialized
INFO - 2016-01-03 07:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:23:42 --> Controller Class Initialized
DEBUG - 2016-01-03 07:23:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:23:42 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:23:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:23:42 --> Model Class Initialized
INFO - 2016-01-03 07:23:42 --> Model Class Initialized
INFO - 2016-01-03 07:23:42 --> Final output sent to browser
DEBUG - 2016-01-03 07:23:42 --> Total execution time: 0.1190
INFO - 2016-01-03 07:24:43 --> Config Class Initialized
INFO - 2016-01-03 07:24:43 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:24:43 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:24:43 --> Utf8 Class Initialized
INFO - 2016-01-03 07:24:43 --> URI Class Initialized
INFO - 2016-01-03 07:24:43 --> Router Class Initialized
INFO - 2016-01-03 07:24:43 --> Output Class Initialized
INFO - 2016-01-03 07:24:43 --> Security Class Initialized
DEBUG - 2016-01-03 07:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:24:43 --> Input Class Initialized
INFO - 2016-01-03 07:24:43 --> Language Class Initialized
INFO - 2016-01-03 07:24:43 --> Loader Class Initialized
INFO - 2016-01-03 07:24:43 --> Helper loaded: url_helper
INFO - 2016-01-03 07:24:44 --> Database Driver Class Initialized
INFO - 2016-01-03 07:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:24:44 --> Controller Class Initialized
DEBUG - 2016-01-03 07:24:44 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:24:44 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:24:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:24:44 --> Model Class Initialized
INFO - 2016-01-03 07:24:44 --> Model Class Initialized
INFO - 2016-01-03 07:24:44 --> Final output sent to browser
DEBUG - 2016-01-03 07:24:44 --> Total execution time: 0.4598
INFO - 2016-01-03 07:27:57 --> Config Class Initialized
INFO - 2016-01-03 07:27:58 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:27:58 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:27:58 --> Utf8 Class Initialized
INFO - 2016-01-03 07:27:58 --> URI Class Initialized
INFO - 2016-01-03 07:27:58 --> Router Class Initialized
INFO - 2016-01-03 07:27:58 --> Output Class Initialized
INFO - 2016-01-03 07:27:58 --> Security Class Initialized
DEBUG - 2016-01-03 07:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:27:58 --> Input Class Initialized
INFO - 2016-01-03 07:27:58 --> Language Class Initialized
INFO - 2016-01-03 07:27:58 --> Loader Class Initialized
INFO - 2016-01-03 07:27:58 --> Helper loaded: url_helper
INFO - 2016-01-03 07:27:58 --> Database Driver Class Initialized
INFO - 2016-01-03 07:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:27:58 --> Controller Class Initialized
INFO - 2016-01-03 07:27:58 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:27:58 --> Final output sent to browser
DEBUG - 2016-01-03 07:27:58 --> Total execution time: 0.3732
INFO - 2016-01-03 07:27:58 --> Config Class Initialized
INFO - 2016-01-03 07:27:58 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:27:58 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:27:58 --> Utf8 Class Initialized
INFO - 2016-01-03 07:27:58 --> URI Class Initialized
DEBUG - 2016-01-03 07:27:58 --> No URI present. Default controller set.
INFO - 2016-01-03 07:27:58 --> Router Class Initialized
INFO - 2016-01-03 07:27:58 --> Output Class Initialized
INFO - 2016-01-03 07:27:58 --> Security Class Initialized
DEBUG - 2016-01-03 07:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:27:58 --> Input Class Initialized
INFO - 2016-01-03 07:27:58 --> Language Class Initialized
INFO - 2016-01-03 07:27:58 --> Loader Class Initialized
INFO - 2016-01-03 07:27:58 --> Helper loaded: url_helper
INFO - 2016-01-03 07:27:58 --> Database Driver Class Initialized
INFO - 2016-01-03 07:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:27:58 --> Controller Class Initialized
INFO - 2016-01-03 07:27:58 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 07:27:58 --> Final output sent to browser
DEBUG - 2016-01-03 07:27:58 --> Total execution time: 0.0848
INFO - 2016-01-03 07:28:34 --> Config Class Initialized
INFO - 2016-01-03 07:28:34 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:28:34 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:28:34 --> Utf8 Class Initialized
INFO - 2016-01-03 07:28:34 --> URI Class Initialized
INFO - 2016-01-03 07:28:34 --> Router Class Initialized
INFO - 2016-01-03 07:28:34 --> Output Class Initialized
INFO - 2016-01-03 07:28:34 --> Security Class Initialized
DEBUG - 2016-01-03 07:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:28:34 --> Input Class Initialized
INFO - 2016-01-03 07:28:34 --> Language Class Initialized
INFO - 2016-01-03 07:28:34 --> Loader Class Initialized
INFO - 2016-01-03 07:28:34 --> Helper loaded: url_helper
INFO - 2016-01-03 07:28:34 --> Database Driver Class Initialized
INFO - 2016-01-03 07:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:28:34 --> Controller Class Initialized
INFO - 2016-01-03 07:28:34 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:28:34 --> Final output sent to browser
DEBUG - 2016-01-03 07:28:34 --> Total execution time: 0.1880
INFO - 2016-01-03 07:28:34 --> Config Class Initialized
INFO - 2016-01-03 07:28:34 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:28:34 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:28:34 --> Utf8 Class Initialized
INFO - 2016-01-03 07:28:34 --> URI Class Initialized
INFO - 2016-01-03 07:28:34 --> Router Class Initialized
INFO - 2016-01-03 07:28:34 --> Output Class Initialized
INFO - 2016-01-03 07:28:34 --> Security Class Initialized
DEBUG - 2016-01-03 07:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:28:34 --> Input Class Initialized
INFO - 2016-01-03 07:28:34 --> Language Class Initialized
INFO - 2016-01-03 07:28:34 --> Loader Class Initialized
INFO - 2016-01-03 07:28:34 --> Helper loaded: url_helper
INFO - 2016-01-03 07:28:34 --> Database Driver Class Initialized
INFO - 2016-01-03 07:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:28:34 --> Controller Class Initialized
DEBUG - 2016-01-03 07:28:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:28:34 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:28:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:28:34 --> Model Class Initialized
INFO - 2016-01-03 07:28:34 --> Model Class Initialized
INFO - 2016-01-03 07:28:34 --> Final output sent to browser
DEBUG - 2016-01-03 07:28:34 --> Total execution time: 0.1615
INFO - 2016-01-03 07:29:35 --> Config Class Initialized
INFO - 2016-01-03 07:29:36 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:29:36 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:29:36 --> Utf8 Class Initialized
INFO - 2016-01-03 07:29:36 --> URI Class Initialized
INFO - 2016-01-03 07:29:36 --> Router Class Initialized
INFO - 2016-01-03 07:29:36 --> Output Class Initialized
INFO - 2016-01-03 07:29:36 --> Security Class Initialized
DEBUG - 2016-01-03 07:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:29:36 --> Input Class Initialized
INFO - 2016-01-03 07:29:36 --> Language Class Initialized
INFO - 2016-01-03 07:29:36 --> Loader Class Initialized
INFO - 2016-01-03 07:29:36 --> Helper loaded: url_helper
INFO - 2016-01-03 07:29:36 --> Database Driver Class Initialized
INFO - 2016-01-03 07:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:29:36 --> Controller Class Initialized
DEBUG - 2016-01-03 07:29:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:29:36 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:29:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:29:36 --> Model Class Initialized
INFO - 2016-01-03 07:29:36 --> Model Class Initialized
INFO - 2016-01-03 07:29:36 --> Final output sent to browser
DEBUG - 2016-01-03 07:29:36 --> Total execution time: 0.3621
INFO - 2016-01-03 07:34:40 --> Config Class Initialized
INFO - 2016-01-03 07:34:40 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:34:40 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:34:40 --> Utf8 Class Initialized
INFO - 2016-01-03 07:34:40 --> URI Class Initialized
DEBUG - 2016-01-03 07:34:40 --> No URI present. Default controller set.
INFO - 2016-01-03 07:34:40 --> Router Class Initialized
INFO - 2016-01-03 07:34:40 --> Output Class Initialized
INFO - 2016-01-03 07:34:40 --> Security Class Initialized
DEBUG - 2016-01-03 07:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:34:40 --> Input Class Initialized
INFO - 2016-01-03 07:34:40 --> Language Class Initialized
INFO - 2016-01-03 07:34:40 --> Loader Class Initialized
INFO - 2016-01-03 07:34:40 --> Helper loaded: url_helper
INFO - 2016-01-03 07:34:40 --> Database Driver Class Initialized
INFO - 2016-01-03 07:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:34:40 --> Controller Class Initialized
INFO - 2016-01-03 07:34:40 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 07:34:40 --> Final output sent to browser
DEBUG - 2016-01-03 07:34:40 --> Total execution time: 0.4293
INFO - 2016-01-03 07:34:43 --> Config Class Initialized
INFO - 2016-01-03 07:34:43 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:34:43 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:34:43 --> Utf8 Class Initialized
INFO - 2016-01-03 07:34:43 --> URI Class Initialized
INFO - 2016-01-03 07:34:43 --> Router Class Initialized
INFO - 2016-01-03 07:34:43 --> Output Class Initialized
INFO - 2016-01-03 07:34:43 --> Security Class Initialized
DEBUG - 2016-01-03 07:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:34:43 --> Input Class Initialized
INFO - 2016-01-03 07:34:43 --> Language Class Initialized
INFO - 2016-01-03 07:34:43 --> Loader Class Initialized
INFO - 2016-01-03 07:34:43 --> Helper loaded: url_helper
INFO - 2016-01-03 07:34:43 --> Database Driver Class Initialized
INFO - 2016-01-03 07:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:34:43 --> Controller Class Initialized
INFO - 2016-01-03 07:34:43 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:34:43 --> Final output sent to browser
DEBUG - 2016-01-03 07:34:43 --> Total execution time: 0.1218
INFO - 2016-01-03 07:34:43 --> Config Class Initialized
INFO - 2016-01-03 07:34:43 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:34:43 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:34:43 --> Utf8 Class Initialized
INFO - 2016-01-03 07:34:43 --> URI Class Initialized
INFO - 2016-01-03 07:34:43 --> Router Class Initialized
INFO - 2016-01-03 07:34:43 --> Output Class Initialized
INFO - 2016-01-03 07:34:43 --> Security Class Initialized
DEBUG - 2016-01-03 07:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:34:43 --> Input Class Initialized
INFO - 2016-01-03 07:34:43 --> Language Class Initialized
INFO - 2016-01-03 07:34:43 --> Loader Class Initialized
INFO - 2016-01-03 07:34:43 --> Helper loaded: url_helper
INFO - 2016-01-03 07:34:43 --> Database Driver Class Initialized
INFO - 2016-01-03 07:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:34:43 --> Controller Class Initialized
DEBUG - 2016-01-03 07:34:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:34:43 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:34:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:34:43 --> Model Class Initialized
INFO - 2016-01-03 07:34:43 --> Model Class Initialized
INFO - 2016-01-03 07:34:43 --> Final output sent to browser
DEBUG - 2016-01-03 07:34:43 --> Total execution time: 0.1565
INFO - 2016-01-03 07:35:44 --> Config Class Initialized
INFO - 2016-01-03 07:35:44 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:35:44 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:35:44 --> Utf8 Class Initialized
INFO - 2016-01-03 07:35:44 --> URI Class Initialized
INFO - 2016-01-03 07:35:44 --> Router Class Initialized
INFO - 2016-01-03 07:35:44 --> Output Class Initialized
INFO - 2016-01-03 07:35:44 --> Security Class Initialized
DEBUG - 2016-01-03 07:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:35:44 --> Input Class Initialized
INFO - 2016-01-03 07:35:44 --> Language Class Initialized
INFO - 2016-01-03 07:35:44 --> Loader Class Initialized
INFO - 2016-01-03 07:35:44 --> Helper loaded: url_helper
INFO - 2016-01-03 07:35:44 --> Database Driver Class Initialized
INFO - 2016-01-03 07:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:35:44 --> Controller Class Initialized
DEBUG - 2016-01-03 07:35:44 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:35:44 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:35:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:35:44 --> Model Class Initialized
INFO - 2016-01-03 07:35:44 --> Model Class Initialized
INFO - 2016-01-03 07:35:44 --> Final output sent to browser
DEBUG - 2016-01-03 07:35:44 --> Total execution time: 0.4317
INFO - 2016-01-03 07:40:59 --> Config Class Initialized
INFO - 2016-01-03 07:40:59 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:40:59 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:40:59 --> Utf8 Class Initialized
INFO - 2016-01-03 07:40:59 --> URI Class Initialized
INFO - 2016-01-03 07:40:59 --> Router Class Initialized
INFO - 2016-01-03 07:40:59 --> Output Class Initialized
INFO - 2016-01-03 07:40:59 --> Security Class Initialized
DEBUG - 2016-01-03 07:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:40:59 --> Input Class Initialized
INFO - 2016-01-03 07:40:59 --> Language Class Initialized
INFO - 2016-01-03 07:40:59 --> Loader Class Initialized
INFO - 2016-01-03 07:40:59 --> Helper loaded: url_helper
INFO - 2016-01-03 07:40:59 --> Database Driver Class Initialized
INFO - 2016-01-03 07:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:40:59 --> Controller Class Initialized
DEBUG - 2016-01-03 07:40:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:40:59 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:40:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:40:59 --> Model Class Initialized
INFO - 2016-01-03 07:40:59 --> Model Class Initialized
INFO - 2016-01-03 07:40:59 --> Final output sent to browser
DEBUG - 2016-01-03 07:40:59 --> Total execution time: 0.4727
INFO - 2016-01-03 07:40:59 --> Config Class Initialized
INFO - 2016-01-03 07:40:59 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:40:59 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:40:59 --> Utf8 Class Initialized
INFO - 2016-01-03 07:40:59 --> URI Class Initialized
DEBUG - 2016-01-03 07:40:59 --> No URI present. Default controller set.
INFO - 2016-01-03 07:40:59 --> Router Class Initialized
INFO - 2016-01-03 07:40:59 --> Output Class Initialized
INFO - 2016-01-03 07:41:00 --> Security Class Initialized
DEBUG - 2016-01-03 07:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:41:00 --> Input Class Initialized
INFO - 2016-01-03 07:41:00 --> Language Class Initialized
INFO - 2016-01-03 07:41:00 --> Loader Class Initialized
INFO - 2016-01-03 07:41:00 --> Helper loaded: url_helper
INFO - 2016-01-03 07:41:00 --> Database Driver Class Initialized
INFO - 2016-01-03 07:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:41:00 --> Controller Class Initialized
INFO - 2016-01-03 07:41:00 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 07:41:00 --> Final output sent to browser
DEBUG - 2016-01-03 07:41:00 --> Total execution time: 0.1355
INFO - 2016-01-03 07:41:01 --> Config Class Initialized
INFO - 2016-01-03 07:41:01 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:41:01 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:41:01 --> Utf8 Class Initialized
INFO - 2016-01-03 07:41:01 --> URI Class Initialized
INFO - 2016-01-03 07:41:01 --> Router Class Initialized
INFO - 2016-01-03 07:41:01 --> Output Class Initialized
INFO - 2016-01-03 07:41:01 --> Security Class Initialized
DEBUG - 2016-01-03 07:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:41:01 --> Input Class Initialized
INFO - 2016-01-03 07:41:01 --> Language Class Initialized
INFO - 2016-01-03 07:41:01 --> Loader Class Initialized
INFO - 2016-01-03 07:41:01 --> Helper loaded: url_helper
INFO - 2016-01-03 07:41:02 --> Database Driver Class Initialized
INFO - 2016-01-03 07:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:41:02 --> Controller Class Initialized
INFO - 2016-01-03 07:41:02 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:41:02 --> Final output sent to browser
DEBUG - 2016-01-03 07:41:02 --> Total execution time: 0.1172
INFO - 2016-01-03 07:41:02 --> Config Class Initialized
INFO - 2016-01-03 07:41:02 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:41:02 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:41:02 --> Utf8 Class Initialized
INFO - 2016-01-03 07:41:02 --> URI Class Initialized
INFO - 2016-01-03 07:41:02 --> Router Class Initialized
INFO - 2016-01-03 07:41:02 --> Output Class Initialized
INFO - 2016-01-03 07:41:02 --> Security Class Initialized
DEBUG - 2016-01-03 07:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:41:02 --> Input Class Initialized
INFO - 2016-01-03 07:41:02 --> Language Class Initialized
INFO - 2016-01-03 07:41:02 --> Loader Class Initialized
INFO - 2016-01-03 07:41:02 --> Helper loaded: url_helper
INFO - 2016-01-03 07:41:02 --> Database Driver Class Initialized
INFO - 2016-01-03 07:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:41:02 --> Controller Class Initialized
DEBUG - 2016-01-03 07:41:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:41:02 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:41:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:41:02 --> Model Class Initialized
INFO - 2016-01-03 07:41:02 --> Model Class Initialized
INFO - 2016-01-03 07:41:02 --> Final output sent to browser
DEBUG - 2016-01-03 07:41:02 --> Total execution time: 0.1511
INFO - 2016-01-03 07:42:03 --> Config Class Initialized
INFO - 2016-01-03 07:42:03 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:42:03 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:42:03 --> Utf8 Class Initialized
INFO - 2016-01-03 07:42:03 --> URI Class Initialized
INFO - 2016-01-03 07:42:03 --> Router Class Initialized
INFO - 2016-01-03 07:42:03 --> Output Class Initialized
INFO - 2016-01-03 07:42:03 --> Security Class Initialized
DEBUG - 2016-01-03 07:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:42:03 --> Input Class Initialized
INFO - 2016-01-03 07:42:03 --> Language Class Initialized
INFO - 2016-01-03 07:42:03 --> Loader Class Initialized
INFO - 2016-01-03 07:42:03 --> Helper loaded: url_helper
INFO - 2016-01-03 07:42:03 --> Database Driver Class Initialized
INFO - 2016-01-03 07:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:42:03 --> Controller Class Initialized
DEBUG - 2016-01-03 07:42:03 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:42:03 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:42:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:42:03 --> Model Class Initialized
INFO - 2016-01-03 07:42:03 --> Model Class Initialized
INFO - 2016-01-03 07:42:03 --> Final output sent to browser
DEBUG - 2016-01-03 07:42:03 --> Total execution time: 0.4707
INFO - 2016-01-03 07:42:05 --> Config Class Initialized
INFO - 2016-01-03 07:42:05 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:42:05 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:42:05 --> Utf8 Class Initialized
INFO - 2016-01-03 07:42:05 --> URI Class Initialized
INFO - 2016-01-03 07:42:05 --> Router Class Initialized
INFO - 2016-01-03 07:42:05 --> Output Class Initialized
INFO - 2016-01-03 07:42:05 --> Security Class Initialized
DEBUG - 2016-01-03 07:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:42:05 --> Input Class Initialized
INFO - 2016-01-03 07:42:05 --> Language Class Initialized
INFO - 2016-01-03 07:42:05 --> Loader Class Initialized
INFO - 2016-01-03 07:42:05 --> Helper loaded: url_helper
INFO - 2016-01-03 07:42:05 --> Database Driver Class Initialized
INFO - 2016-01-03 07:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:42:05 --> Controller Class Initialized
DEBUG - 2016-01-03 07:42:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:42:05 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:42:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:42:05 --> Model Class Initialized
INFO - 2016-01-03 07:42:05 --> Model Class Initialized
INFO - 2016-01-03 07:42:05 --> Final output sent to browser
DEBUG - 2016-01-03 07:42:05 --> Total execution time: 0.0992
INFO - 2016-01-03 07:43:06 --> Config Class Initialized
INFO - 2016-01-03 07:43:07 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:43:07 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:43:07 --> Utf8 Class Initialized
INFO - 2016-01-03 07:43:07 --> URI Class Initialized
INFO - 2016-01-03 07:43:07 --> Router Class Initialized
INFO - 2016-01-03 07:43:07 --> Output Class Initialized
INFO - 2016-01-03 07:43:07 --> Security Class Initialized
DEBUG - 2016-01-03 07:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:43:07 --> Input Class Initialized
INFO - 2016-01-03 07:43:07 --> Language Class Initialized
INFO - 2016-01-03 07:43:07 --> Loader Class Initialized
INFO - 2016-01-03 07:43:07 --> Helper loaded: url_helper
INFO - 2016-01-03 07:43:07 --> Database Driver Class Initialized
INFO - 2016-01-03 07:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:43:07 --> Controller Class Initialized
DEBUG - 2016-01-03 07:43:07 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:43:07 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:43:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:43:07 --> Model Class Initialized
INFO - 2016-01-03 07:43:07 --> Model Class Initialized
INFO - 2016-01-03 07:43:07 --> Final output sent to browser
DEBUG - 2016-01-03 07:43:07 --> Total execution time: 0.4206
INFO - 2016-01-03 07:43:08 --> Config Class Initialized
INFO - 2016-01-03 07:43:08 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:43:08 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:43:08 --> Utf8 Class Initialized
INFO - 2016-01-03 07:43:08 --> URI Class Initialized
INFO - 2016-01-03 07:43:08 --> Router Class Initialized
INFO - 2016-01-03 07:43:08 --> Output Class Initialized
INFO - 2016-01-03 07:43:08 --> Security Class Initialized
DEBUG - 2016-01-03 07:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:43:08 --> Input Class Initialized
INFO - 2016-01-03 07:43:08 --> Language Class Initialized
INFO - 2016-01-03 07:43:08 --> Loader Class Initialized
INFO - 2016-01-03 07:43:08 --> Helper loaded: url_helper
INFO - 2016-01-03 07:43:08 --> Database Driver Class Initialized
INFO - 2016-01-03 07:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:43:08 --> Controller Class Initialized
DEBUG - 2016-01-03 07:43:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:43:08 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:43:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:43:08 --> Model Class Initialized
INFO - 2016-01-03 07:43:08 --> Model Class Initialized
INFO - 2016-01-03 07:43:08 --> Final output sent to browser
DEBUG - 2016-01-03 07:43:08 --> Total execution time: 0.1497
INFO - 2016-01-03 07:44:03 --> Config Class Initialized
INFO - 2016-01-03 07:44:04 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:44:04 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:44:04 --> Utf8 Class Initialized
INFO - 2016-01-03 07:44:04 --> URI Class Initialized
DEBUG - 2016-01-03 07:44:04 --> No URI present. Default controller set.
INFO - 2016-01-03 07:44:04 --> Router Class Initialized
INFO - 2016-01-03 07:44:04 --> Output Class Initialized
INFO - 2016-01-03 07:44:04 --> Security Class Initialized
DEBUG - 2016-01-03 07:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:44:04 --> Input Class Initialized
INFO - 2016-01-03 07:44:04 --> Language Class Initialized
INFO - 2016-01-03 07:44:04 --> Loader Class Initialized
INFO - 2016-01-03 07:44:04 --> Helper loaded: url_helper
INFO - 2016-01-03 07:44:04 --> Database Driver Class Initialized
INFO - 2016-01-03 07:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:44:04 --> Controller Class Initialized
INFO - 2016-01-03 07:44:04 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 07:44:04 --> Final output sent to browser
DEBUG - 2016-01-03 07:44:04 --> Total execution time: 0.3845
INFO - 2016-01-03 07:44:07 --> Config Class Initialized
INFO - 2016-01-03 07:44:07 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:44:07 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:44:07 --> Utf8 Class Initialized
INFO - 2016-01-03 07:44:07 --> URI Class Initialized
INFO - 2016-01-03 07:44:07 --> Router Class Initialized
INFO - 2016-01-03 07:44:07 --> Output Class Initialized
INFO - 2016-01-03 07:44:07 --> Security Class Initialized
DEBUG - 2016-01-03 07:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:44:07 --> Input Class Initialized
INFO - 2016-01-03 07:44:07 --> Language Class Initialized
INFO - 2016-01-03 07:44:07 --> Loader Class Initialized
INFO - 2016-01-03 07:44:07 --> Helper loaded: url_helper
INFO - 2016-01-03 07:44:07 --> Database Driver Class Initialized
INFO - 2016-01-03 07:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:44:07 --> Controller Class Initialized
INFO - 2016-01-03 07:44:07 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:44:07 --> Final output sent to browser
DEBUG - 2016-01-03 07:44:07 --> Total execution time: 0.1001
INFO - 2016-01-03 07:44:08 --> Config Class Initialized
INFO - 2016-01-03 07:44:08 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:44:08 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:44:08 --> Utf8 Class Initialized
INFO - 2016-01-03 07:44:08 --> URI Class Initialized
INFO - 2016-01-03 07:44:08 --> Router Class Initialized
INFO - 2016-01-03 07:44:08 --> Output Class Initialized
INFO - 2016-01-03 07:44:08 --> Security Class Initialized
DEBUG - 2016-01-03 07:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:44:08 --> Input Class Initialized
INFO - 2016-01-03 07:44:08 --> Language Class Initialized
INFO - 2016-01-03 07:44:08 --> Loader Class Initialized
INFO - 2016-01-03 07:44:08 --> Helper loaded: url_helper
INFO - 2016-01-03 07:44:08 --> Database Driver Class Initialized
INFO - 2016-01-03 07:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:44:08 --> Controller Class Initialized
DEBUG - 2016-01-03 07:44:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:44:08 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:44:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:44:08 --> Model Class Initialized
INFO - 2016-01-03 07:44:08 --> Model Class Initialized
INFO - 2016-01-03 07:44:08 --> Final output sent to browser
DEBUG - 2016-01-03 07:44:08 --> Total execution time: 0.1113
INFO - 2016-01-03 07:44:56 --> Config Class Initialized
INFO - 2016-01-03 07:44:56 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:44:56 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:44:56 --> Utf8 Class Initialized
INFO - 2016-01-03 07:44:56 --> URI Class Initialized
INFO - 2016-01-03 07:44:56 --> Router Class Initialized
INFO - 2016-01-03 07:44:56 --> Output Class Initialized
INFO - 2016-01-03 07:44:56 --> Security Class Initialized
DEBUG - 2016-01-03 07:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:44:56 --> Input Class Initialized
INFO - 2016-01-03 07:44:56 --> Language Class Initialized
INFO - 2016-01-03 07:44:56 --> Loader Class Initialized
INFO - 2016-01-03 07:44:56 --> Helper loaded: url_helper
INFO - 2016-01-03 07:44:56 --> Database Driver Class Initialized
INFO - 2016-01-03 07:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:44:56 --> Controller Class Initialized
INFO - 2016-01-03 07:44:56 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:44:56 --> Final output sent to browser
DEBUG - 2016-01-03 07:44:56 --> Total execution time: 0.2892
INFO - 2016-01-03 07:44:56 --> Config Class Initialized
INFO - 2016-01-03 07:44:56 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:44:56 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:44:56 --> Utf8 Class Initialized
INFO - 2016-01-03 07:44:56 --> URI Class Initialized
INFO - 2016-01-03 07:44:56 --> Router Class Initialized
INFO - 2016-01-03 07:44:56 --> Output Class Initialized
INFO - 2016-01-03 07:44:56 --> Security Class Initialized
DEBUG - 2016-01-03 07:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:44:56 --> Input Class Initialized
INFO - 2016-01-03 07:44:56 --> Language Class Initialized
INFO - 2016-01-03 07:44:56 --> Loader Class Initialized
INFO - 2016-01-03 07:44:56 --> Helper loaded: url_helper
INFO - 2016-01-03 07:44:56 --> Database Driver Class Initialized
INFO - 2016-01-03 07:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:44:56 --> Controller Class Initialized
DEBUG - 2016-01-03 07:44:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:44:56 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:44:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:44:56 --> Model Class Initialized
INFO - 2016-01-03 07:44:56 --> Model Class Initialized
INFO - 2016-01-03 07:44:56 --> Final output sent to browser
DEBUG - 2016-01-03 07:44:56 --> Total execution time: 0.1133
INFO - 2016-01-03 07:45:15 --> Config Class Initialized
INFO - 2016-01-03 07:45:15 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:45:15 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:45:15 --> Utf8 Class Initialized
INFO - 2016-01-03 07:45:15 --> URI Class Initialized
DEBUG - 2016-01-03 07:45:15 --> No URI present. Default controller set.
INFO - 2016-01-03 07:45:15 --> Router Class Initialized
INFO - 2016-01-03 07:45:15 --> Output Class Initialized
INFO - 2016-01-03 07:45:15 --> Security Class Initialized
DEBUG - 2016-01-03 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:45:15 --> Input Class Initialized
INFO - 2016-01-03 07:45:15 --> Language Class Initialized
INFO - 2016-01-03 07:45:16 --> Loader Class Initialized
INFO - 2016-01-03 07:45:16 --> Helper loaded: url_helper
INFO - 2016-01-03 07:45:16 --> Database Driver Class Initialized
INFO - 2016-01-03 07:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:45:16 --> Controller Class Initialized
INFO - 2016-01-03 07:45:16 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 07:45:16 --> Final output sent to browser
DEBUG - 2016-01-03 07:45:16 --> Total execution time: 0.1146
INFO - 2016-01-03 07:45:20 --> Config Class Initialized
INFO - 2016-01-03 07:45:20 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:45:20 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:45:21 --> Utf8 Class Initialized
INFO - 2016-01-03 07:45:21 --> URI Class Initialized
INFO - 2016-01-03 07:45:21 --> Router Class Initialized
INFO - 2016-01-03 07:45:21 --> Output Class Initialized
INFO - 2016-01-03 07:45:21 --> Security Class Initialized
DEBUG - 2016-01-03 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:45:21 --> Input Class Initialized
INFO - 2016-01-03 07:45:21 --> Language Class Initialized
INFO - 2016-01-03 07:45:21 --> Loader Class Initialized
INFO - 2016-01-03 07:45:21 --> Helper loaded: url_helper
INFO - 2016-01-03 07:45:21 --> Database Driver Class Initialized
INFO - 2016-01-03 07:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:45:21 --> Controller Class Initialized
INFO - 2016-01-03 07:45:21 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:45:21 --> Final output sent to browser
DEBUG - 2016-01-03 07:45:21 --> Total execution time: 0.0908
INFO - 2016-01-03 07:45:21 --> Config Class Initialized
INFO - 2016-01-03 07:45:21 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:45:21 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:45:21 --> Utf8 Class Initialized
INFO - 2016-01-03 07:45:21 --> URI Class Initialized
INFO - 2016-01-03 07:45:21 --> Router Class Initialized
INFO - 2016-01-03 07:45:21 --> Output Class Initialized
INFO - 2016-01-03 07:45:21 --> Security Class Initialized
DEBUG - 2016-01-03 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:45:21 --> Input Class Initialized
INFO - 2016-01-03 07:45:21 --> Language Class Initialized
INFO - 2016-01-03 07:45:21 --> Loader Class Initialized
INFO - 2016-01-03 07:45:21 --> Helper loaded: url_helper
INFO - 2016-01-03 07:45:21 --> Database Driver Class Initialized
INFO - 2016-01-03 07:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:45:21 --> Controller Class Initialized
DEBUG - 2016-01-03 07:45:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:45:21 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:45:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:45:21 --> Model Class Initialized
INFO - 2016-01-03 07:45:21 --> Model Class Initialized
INFO - 2016-01-03 07:45:21 --> Final output sent to browser
DEBUG - 2016-01-03 07:45:21 --> Total execution time: 0.1115
INFO - 2016-01-03 07:45:33 --> Config Class Initialized
INFO - 2016-01-03 07:45:33 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:45:33 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:45:33 --> Utf8 Class Initialized
INFO - 2016-01-03 07:45:33 --> URI Class Initialized
INFO - 2016-01-03 07:45:33 --> Router Class Initialized
INFO - 2016-01-03 07:45:33 --> Output Class Initialized
INFO - 2016-01-03 07:45:33 --> Security Class Initialized
DEBUG - 2016-01-03 07:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:45:33 --> Input Class Initialized
INFO - 2016-01-03 07:45:33 --> Language Class Initialized
INFO - 2016-01-03 07:45:33 --> Loader Class Initialized
INFO - 2016-01-03 07:45:33 --> Helper loaded: url_helper
INFO - 2016-01-03 07:45:33 --> Database Driver Class Initialized
INFO - 2016-01-03 07:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:45:33 --> Controller Class Initialized
INFO - 2016-01-03 07:45:33 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:45:33 --> Final output sent to browser
DEBUG - 2016-01-03 07:45:33 --> Total execution time: 0.0994
INFO - 2016-01-03 07:45:33 --> Config Class Initialized
INFO - 2016-01-03 07:45:33 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:45:33 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:45:33 --> Utf8 Class Initialized
INFO - 2016-01-03 07:45:33 --> URI Class Initialized
INFO - 2016-01-03 07:45:33 --> Router Class Initialized
INFO - 2016-01-03 07:45:33 --> Output Class Initialized
INFO - 2016-01-03 07:45:33 --> Security Class Initialized
DEBUG - 2016-01-03 07:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:45:33 --> Input Class Initialized
INFO - 2016-01-03 07:45:33 --> Language Class Initialized
INFO - 2016-01-03 07:45:33 --> Loader Class Initialized
INFO - 2016-01-03 07:45:33 --> Helper loaded: url_helper
INFO - 2016-01-03 07:45:33 --> Database Driver Class Initialized
INFO - 2016-01-03 07:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:45:33 --> Controller Class Initialized
DEBUG - 2016-01-03 07:45:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:45:33 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:45:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:45:33 --> Model Class Initialized
INFO - 2016-01-03 07:45:33 --> Model Class Initialized
INFO - 2016-01-03 07:45:33 --> Final output sent to browser
DEBUG - 2016-01-03 07:45:33 --> Total execution time: 0.1178
INFO - 2016-01-03 07:46:34 --> Config Class Initialized
INFO - 2016-01-03 07:46:34 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:46:34 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:46:34 --> Utf8 Class Initialized
INFO - 2016-01-03 07:46:34 --> URI Class Initialized
INFO - 2016-01-03 07:46:34 --> Router Class Initialized
INFO - 2016-01-03 07:46:34 --> Output Class Initialized
INFO - 2016-01-03 07:46:34 --> Security Class Initialized
DEBUG - 2016-01-03 07:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:46:34 --> Input Class Initialized
INFO - 2016-01-03 07:46:34 --> Language Class Initialized
INFO - 2016-01-03 07:46:34 --> Loader Class Initialized
INFO - 2016-01-03 07:46:34 --> Helper loaded: url_helper
INFO - 2016-01-03 07:46:34 --> Database Driver Class Initialized
ERROR - 2016-01-03 07:46:34 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2016-01-03 07:46:34 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
ERROR - 2016-01-03 07:46:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/libraries/Session/Session.php 168
INFO - 2016-01-03 07:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:46:34 --> Controller Class Initialized
DEBUG - 2016-01-03 07:46:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:46:34 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:46:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:46:34 --> Model Class Initialized
INFO - 2016-01-03 07:46:34 --> Model Class Initialized
ERROR - 2016-01-03 07:46:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/core/Common.php 573
INFO - 2016-01-03 07:46:34 --> Final output sent to browser
DEBUG - 2016-01-03 07:46:34 --> Total execution time: 0.2093
INFO - 2016-01-03 07:52:47 --> Config Class Initialized
INFO - 2016-01-03 07:52:47 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:52:47 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:52:47 --> Utf8 Class Initialized
INFO - 2016-01-03 07:52:47 --> URI Class Initialized
DEBUG - 2016-01-03 07:52:47 --> No URI present. Default controller set.
INFO - 2016-01-03 07:52:47 --> Router Class Initialized
INFO - 2016-01-03 07:52:47 --> Output Class Initialized
INFO - 2016-01-03 07:52:47 --> Security Class Initialized
DEBUG - 2016-01-03 07:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:52:47 --> Input Class Initialized
INFO - 2016-01-03 07:52:47 --> Language Class Initialized
INFO - 2016-01-03 07:52:47 --> Loader Class Initialized
INFO - 2016-01-03 07:52:47 --> Helper loaded: url_helper
INFO - 2016-01-03 07:52:47 --> Database Driver Class Initialized
INFO - 2016-01-03 07:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:52:47 --> Controller Class Initialized
INFO - 2016-01-03 07:52:47 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 07:52:47 --> Final output sent to browser
DEBUG - 2016-01-03 07:52:47 --> Total execution time: 0.4155
INFO - 2016-01-03 07:52:50 --> Config Class Initialized
INFO - 2016-01-03 07:52:50 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:52:50 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:52:50 --> Utf8 Class Initialized
INFO - 2016-01-03 07:52:50 --> URI Class Initialized
INFO - 2016-01-03 07:52:50 --> Router Class Initialized
INFO - 2016-01-03 07:52:50 --> Output Class Initialized
INFO - 2016-01-03 07:52:50 --> Security Class Initialized
DEBUG - 2016-01-03 07:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:52:50 --> Input Class Initialized
INFO - 2016-01-03 07:52:50 --> Language Class Initialized
INFO - 2016-01-03 07:52:50 --> Loader Class Initialized
INFO - 2016-01-03 07:52:50 --> Helper loaded: url_helper
INFO - 2016-01-03 07:52:50 --> Database Driver Class Initialized
INFO - 2016-01-03 07:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:52:50 --> Controller Class Initialized
INFO - 2016-01-03 07:52:50 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 07:52:50 --> Final output sent to browser
DEBUG - 2016-01-03 07:52:50 --> Total execution time: 0.0874
INFO - 2016-01-03 07:52:51 --> Config Class Initialized
INFO - 2016-01-03 07:52:51 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:52:51 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:52:51 --> Utf8 Class Initialized
INFO - 2016-01-03 07:52:51 --> URI Class Initialized
INFO - 2016-01-03 07:52:51 --> Router Class Initialized
INFO - 2016-01-03 07:52:51 --> Output Class Initialized
INFO - 2016-01-03 07:52:51 --> Security Class Initialized
DEBUG - 2016-01-03 07:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:52:51 --> Input Class Initialized
INFO - 2016-01-03 07:52:51 --> Language Class Initialized
INFO - 2016-01-03 07:52:51 --> Loader Class Initialized
INFO - 2016-01-03 07:52:51 --> Helper loaded: url_helper
INFO - 2016-01-03 07:52:51 --> Database Driver Class Initialized
INFO - 2016-01-03 07:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:52:51 --> Controller Class Initialized
DEBUG - 2016-01-03 07:52:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:52:51 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:52:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:52:51 --> Model Class Initialized
INFO - 2016-01-03 07:52:51 --> Model Class Initialized
INFO - 2016-01-03 07:52:51 --> Final output sent to browser
DEBUG - 2016-01-03 07:52:51 --> Total execution time: 0.1849
INFO - 2016-01-03 07:53:07 --> Config Class Initialized
INFO - 2016-01-03 07:53:07 --> Hooks Class Initialized
DEBUG - 2016-01-03 07:53:07 --> UTF-8 Support Enabled
INFO - 2016-01-03 07:53:07 --> Utf8 Class Initialized
INFO - 2016-01-03 07:53:07 --> URI Class Initialized
INFO - 2016-01-03 07:53:07 --> Router Class Initialized
INFO - 2016-01-03 07:53:07 --> Output Class Initialized
INFO - 2016-01-03 07:53:07 --> Security Class Initialized
DEBUG - 2016-01-03 07:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 07:53:07 --> Input Class Initialized
INFO - 2016-01-03 07:53:07 --> Language Class Initialized
INFO - 2016-01-03 07:53:07 --> Loader Class Initialized
INFO - 2016-01-03 07:53:07 --> Helper loaded: url_helper
INFO - 2016-01-03 07:53:07 --> Database Driver Class Initialized
INFO - 2016-01-03 07:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 07:53:07 --> Controller Class Initialized
DEBUG - 2016-01-03 07:53:07 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 07:53:07 --> Helper loaded: inflector_helper
INFO - 2016-01-03 07:53:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 07:53:07 --> Model Class Initialized
INFO - 2016-01-03 07:53:07 --> Model Class Initialized
INFO - 2016-01-03 07:53:07 --> Final output sent to browser
DEBUG - 2016-01-03 07:53:07 --> Total execution time: 0.2003
INFO - 2016-01-03 08:13:45 --> Config Class Initialized
INFO - 2016-01-03 08:13:46 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:13:46 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:13:46 --> Utf8 Class Initialized
INFO - 2016-01-03 08:13:46 --> URI Class Initialized
INFO - 2016-01-03 08:13:46 --> Router Class Initialized
INFO - 2016-01-03 08:13:46 --> Output Class Initialized
INFO - 2016-01-03 08:13:46 --> Security Class Initialized
DEBUG - 2016-01-03 08:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:13:46 --> Input Class Initialized
INFO - 2016-01-03 08:13:46 --> Language Class Initialized
INFO - 2016-01-03 08:13:46 --> Loader Class Initialized
INFO - 2016-01-03 08:13:46 --> Helper loaded: url_helper
INFO - 2016-01-03 08:13:46 --> Database Driver Class Initialized
INFO - 2016-01-03 08:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:13:46 --> Controller Class Initialized
DEBUG - 2016-01-03 08:13:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:13:46 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:13:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:13:46 --> Model Class Initialized
INFO - 2016-01-03 08:13:46 --> Model Class Initialized
INFO - 2016-01-03 08:13:46 --> Final output sent to browser
DEBUG - 2016-01-03 08:13:46 --> Total execution time: 0.4726
INFO - 2016-01-03 08:25:15 --> Config Class Initialized
INFO - 2016-01-03 08:25:15 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:25:15 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:25:15 --> Utf8 Class Initialized
INFO - 2016-01-03 08:25:15 --> URI Class Initialized
DEBUG - 2016-01-03 08:25:15 --> No URI present. Default controller set.
INFO - 2016-01-03 08:25:15 --> Router Class Initialized
INFO - 2016-01-03 08:25:15 --> Output Class Initialized
INFO - 2016-01-03 08:25:15 --> Security Class Initialized
DEBUG - 2016-01-03 08:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:25:15 --> Input Class Initialized
INFO - 2016-01-03 08:25:15 --> Language Class Initialized
INFO - 2016-01-03 08:25:15 --> Loader Class Initialized
INFO - 2016-01-03 08:25:15 --> Helper loaded: url_helper
INFO - 2016-01-03 08:25:15 --> Database Driver Class Initialized
INFO - 2016-01-03 08:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:25:15 --> Controller Class Initialized
INFO - 2016-01-03 08:25:15 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 08:25:15 --> Final output sent to browser
DEBUG - 2016-01-03 08:25:15 --> Total execution time: 0.4918
INFO - 2016-01-03 08:25:28 --> Config Class Initialized
INFO - 2016-01-03 08:25:28 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:25:28 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:25:28 --> Utf8 Class Initialized
INFO - 2016-01-03 08:25:28 --> URI Class Initialized
INFO - 2016-01-03 08:25:28 --> Router Class Initialized
INFO - 2016-01-03 08:25:28 --> Output Class Initialized
INFO - 2016-01-03 08:25:28 --> Security Class Initialized
DEBUG - 2016-01-03 08:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:25:28 --> Input Class Initialized
INFO - 2016-01-03 08:25:28 --> Language Class Initialized
INFO - 2016-01-03 08:25:28 --> Loader Class Initialized
INFO - 2016-01-03 08:25:28 --> Helper loaded: url_helper
INFO - 2016-01-03 08:25:28 --> Database Driver Class Initialized
INFO - 2016-01-03 08:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:25:28 --> Controller Class Initialized
INFO - 2016-01-03 08:25:28 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 08:25:28 --> Final output sent to browser
DEBUG - 2016-01-03 08:25:28 --> Total execution time: 0.1180
INFO - 2016-01-03 08:25:29 --> Config Class Initialized
INFO - 2016-01-03 08:25:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:25:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:25:29 --> Utf8 Class Initialized
INFO - 2016-01-03 08:25:29 --> URI Class Initialized
INFO - 2016-01-03 08:25:29 --> Router Class Initialized
INFO - 2016-01-03 08:25:29 --> Output Class Initialized
INFO - 2016-01-03 08:25:29 --> Security Class Initialized
DEBUG - 2016-01-03 08:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:25:29 --> Input Class Initialized
INFO - 2016-01-03 08:25:29 --> Language Class Initialized
INFO - 2016-01-03 08:25:29 --> Loader Class Initialized
INFO - 2016-01-03 08:25:29 --> Helper loaded: url_helper
INFO - 2016-01-03 08:25:29 --> Database Driver Class Initialized
INFO - 2016-01-03 08:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:25:29 --> Controller Class Initialized
DEBUG - 2016-01-03 08:25:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:25:29 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:25:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:25:29 --> Model Class Initialized
INFO - 2016-01-03 08:25:29 --> Model Class Initialized
INFO - 2016-01-03 08:25:29 --> Final output sent to browser
DEBUG - 2016-01-03 08:25:29 --> Total execution time: 0.1431
INFO - 2016-01-03 08:25:44 --> Config Class Initialized
INFO - 2016-01-03 08:25:44 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:25:44 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:25:44 --> Utf8 Class Initialized
INFO - 2016-01-03 08:25:44 --> URI Class Initialized
INFO - 2016-01-03 08:25:44 --> Router Class Initialized
INFO - 2016-01-03 08:25:44 --> Output Class Initialized
INFO - 2016-01-03 08:25:44 --> Security Class Initialized
DEBUG - 2016-01-03 08:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:25:44 --> Input Class Initialized
INFO - 2016-01-03 08:25:44 --> Language Class Initialized
INFO - 2016-01-03 08:25:45 --> Loader Class Initialized
INFO - 2016-01-03 08:25:45 --> Helper loaded: url_helper
INFO - 2016-01-03 08:25:45 --> Database Driver Class Initialized
INFO - 2016-01-03 08:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:25:45 --> Controller Class Initialized
DEBUG - 2016-01-03 08:25:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:25:45 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:25:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:25:45 --> Model Class Initialized
INFO - 2016-01-03 08:25:45 --> Model Class Initialized
INFO - 2016-01-03 08:25:45 --> Final output sent to browser
DEBUG - 2016-01-03 08:25:45 --> Total execution time: 0.2202
INFO - 2016-01-03 08:25:48 --> Config Class Initialized
INFO - 2016-01-03 08:25:48 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:25:48 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:25:48 --> Utf8 Class Initialized
INFO - 2016-01-03 08:25:48 --> URI Class Initialized
INFO - 2016-01-03 08:25:48 --> Router Class Initialized
INFO - 2016-01-03 08:25:48 --> Output Class Initialized
INFO - 2016-01-03 08:25:48 --> Security Class Initialized
DEBUG - 2016-01-03 08:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:25:48 --> Input Class Initialized
INFO - 2016-01-03 08:25:48 --> Language Class Initialized
INFO - 2016-01-03 08:25:48 --> Loader Class Initialized
INFO - 2016-01-03 08:25:48 --> Helper loaded: url_helper
INFO - 2016-01-03 08:25:48 --> Database Driver Class Initialized
INFO - 2016-01-03 08:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:25:48 --> Controller Class Initialized
DEBUG - 2016-01-03 08:25:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:25:48 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:25:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:25:48 --> Model Class Initialized
INFO - 2016-01-03 08:25:48 --> Model Class Initialized
INFO - 2016-01-03 08:25:48 --> Final output sent to browser
DEBUG - 2016-01-03 08:25:48 --> Total execution time: 0.1680
INFO - 2016-01-03 08:26:17 --> Config Class Initialized
INFO - 2016-01-03 08:26:18 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:18 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:18 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:18 --> URI Class Initialized
INFO - 2016-01-03 08:26:18 --> Router Class Initialized
INFO - 2016-01-03 08:26:18 --> Output Class Initialized
INFO - 2016-01-03 08:26:18 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:18 --> Input Class Initialized
INFO - 2016-01-03 08:26:18 --> Language Class Initialized
INFO - 2016-01-03 08:26:18 --> Loader Class Initialized
INFO - 2016-01-03 08:26:18 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:18 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:18 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:18 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:18 --> Model Class Initialized
INFO - 2016-01-03 08:26:18 --> Model Class Initialized
INFO - 2016-01-03 08:26:18 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:18 --> Total execution time: 0.4214
INFO - 2016-01-03 08:26:19 --> Config Class Initialized
INFO - 2016-01-03 08:26:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:19 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:19 --> URI Class Initialized
INFO - 2016-01-03 08:26:19 --> Router Class Initialized
INFO - 2016-01-03 08:26:19 --> Output Class Initialized
INFO - 2016-01-03 08:26:19 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:19 --> Input Class Initialized
INFO - 2016-01-03 08:26:19 --> Language Class Initialized
INFO - 2016-01-03 08:26:19 --> Loader Class Initialized
INFO - 2016-01-03 08:26:19 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:19 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:19 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:19 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:19 --> Model Class Initialized
INFO - 2016-01-03 08:26:19 --> Model Class Initialized
INFO - 2016-01-03 08:26:19 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:19 --> Total execution time: 0.1405
INFO - 2016-01-03 08:26:20 --> Config Class Initialized
INFO - 2016-01-03 08:26:20 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:20 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:20 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:20 --> URI Class Initialized
INFO - 2016-01-03 08:26:20 --> Router Class Initialized
INFO - 2016-01-03 08:26:20 --> Output Class Initialized
INFO - 2016-01-03 08:26:20 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:20 --> Input Class Initialized
INFO - 2016-01-03 08:26:20 --> Language Class Initialized
INFO - 2016-01-03 08:26:20 --> Loader Class Initialized
INFO - 2016-01-03 08:26:20 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:20 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:20 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:20 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:21 --> Model Class Initialized
INFO - 2016-01-03 08:26:21 --> Model Class Initialized
INFO - 2016-01-03 08:26:21 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:21 --> Total execution time: 0.1231
INFO - 2016-01-03 08:26:21 --> Config Class Initialized
INFO - 2016-01-03 08:26:21 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:21 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:21 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:21 --> URI Class Initialized
INFO - 2016-01-03 08:26:21 --> Router Class Initialized
INFO - 2016-01-03 08:26:21 --> Output Class Initialized
INFO - 2016-01-03 08:26:21 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:21 --> Input Class Initialized
INFO - 2016-01-03 08:26:21 --> Language Class Initialized
INFO - 2016-01-03 08:26:21 --> Loader Class Initialized
INFO - 2016-01-03 08:26:21 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:21 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:21 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:21 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:21 --> Model Class Initialized
INFO - 2016-01-03 08:26:21 --> Model Class Initialized
INFO - 2016-01-03 08:26:21 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:21 --> Total execution time: 0.1042
INFO - 2016-01-03 08:26:24 --> Config Class Initialized
INFO - 2016-01-03 08:26:24 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:24 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:24 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:24 --> URI Class Initialized
INFO - 2016-01-03 08:26:24 --> Router Class Initialized
INFO - 2016-01-03 08:26:24 --> Output Class Initialized
INFO - 2016-01-03 08:26:24 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:24 --> Input Class Initialized
INFO - 2016-01-03 08:26:24 --> Language Class Initialized
INFO - 2016-01-03 08:26:24 --> Loader Class Initialized
INFO - 2016-01-03 08:26:24 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:24 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:24 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:24 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:24 --> Model Class Initialized
INFO - 2016-01-03 08:26:24 --> Model Class Initialized
INFO - 2016-01-03 08:26:24 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:24 --> Total execution time: 0.1371
INFO - 2016-01-03 08:26:25 --> Config Class Initialized
INFO - 2016-01-03 08:26:25 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:25 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:25 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:25 --> URI Class Initialized
INFO - 2016-01-03 08:26:25 --> Router Class Initialized
INFO - 2016-01-03 08:26:25 --> Output Class Initialized
INFO - 2016-01-03 08:26:25 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:25 --> Input Class Initialized
INFO - 2016-01-03 08:26:25 --> Language Class Initialized
INFO - 2016-01-03 08:26:25 --> Loader Class Initialized
INFO - 2016-01-03 08:26:25 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:25 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:25 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:25 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:25 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:25 --> Model Class Initialized
INFO - 2016-01-03 08:26:25 --> Model Class Initialized
INFO - 2016-01-03 08:26:25 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:25 --> Total execution time: 0.1588
INFO - 2016-01-03 08:26:27 --> Config Class Initialized
INFO - 2016-01-03 08:26:27 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:27 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:27 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:27 --> URI Class Initialized
INFO - 2016-01-03 08:26:27 --> Router Class Initialized
INFO - 2016-01-03 08:26:27 --> Output Class Initialized
INFO - 2016-01-03 08:26:27 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:27 --> Input Class Initialized
INFO - 2016-01-03 08:26:27 --> Language Class Initialized
INFO - 2016-01-03 08:26:27 --> Loader Class Initialized
INFO - 2016-01-03 08:26:27 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:27 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:27 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:27 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:27 --> Model Class Initialized
INFO - 2016-01-03 08:26:27 --> Model Class Initialized
INFO - 2016-01-03 08:26:27 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:27 --> Total execution time: 0.1122
INFO - 2016-01-03 08:26:28 --> Config Class Initialized
INFO - 2016-01-03 08:26:28 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:28 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:28 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:28 --> URI Class Initialized
INFO - 2016-01-03 08:26:28 --> Router Class Initialized
INFO - 2016-01-03 08:26:28 --> Output Class Initialized
INFO - 2016-01-03 08:26:28 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:28 --> Input Class Initialized
INFO - 2016-01-03 08:26:28 --> Language Class Initialized
INFO - 2016-01-03 08:26:28 --> Loader Class Initialized
INFO - 2016-01-03 08:26:28 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:28 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:28 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:28 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:28 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:28 --> Model Class Initialized
INFO - 2016-01-03 08:26:28 --> Model Class Initialized
INFO - 2016-01-03 08:26:28 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:28 --> Total execution time: 0.1142
INFO - 2016-01-03 08:26:29 --> Config Class Initialized
INFO - 2016-01-03 08:26:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:29 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:29 --> URI Class Initialized
INFO - 2016-01-03 08:26:29 --> Router Class Initialized
INFO - 2016-01-03 08:26:29 --> Output Class Initialized
INFO - 2016-01-03 08:26:29 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:29 --> Input Class Initialized
INFO - 2016-01-03 08:26:29 --> Language Class Initialized
INFO - 2016-01-03 08:26:29 --> Loader Class Initialized
INFO - 2016-01-03 08:26:29 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:29 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:29 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:30 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:30 --> Model Class Initialized
INFO - 2016-01-03 08:26:30 --> Model Class Initialized
INFO - 2016-01-03 08:26:30 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:30 --> Total execution time: 0.1494
INFO - 2016-01-03 08:26:30 --> Config Class Initialized
INFO - 2016-01-03 08:26:30 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:30 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:30 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:30 --> URI Class Initialized
INFO - 2016-01-03 08:26:30 --> Router Class Initialized
INFO - 2016-01-03 08:26:30 --> Output Class Initialized
INFO - 2016-01-03 08:26:30 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:30 --> Input Class Initialized
INFO - 2016-01-03 08:26:30 --> Language Class Initialized
INFO - 2016-01-03 08:26:30 --> Loader Class Initialized
INFO - 2016-01-03 08:26:30 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:30 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:30 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:30 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:30 --> Model Class Initialized
INFO - 2016-01-03 08:26:30 --> Model Class Initialized
INFO - 2016-01-03 08:26:30 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:30 --> Total execution time: 0.1548
INFO - 2016-01-03 08:26:32 --> Config Class Initialized
INFO - 2016-01-03 08:26:32 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:32 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:32 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:32 --> URI Class Initialized
INFO - 2016-01-03 08:26:32 --> Router Class Initialized
INFO - 2016-01-03 08:26:32 --> Output Class Initialized
INFO - 2016-01-03 08:26:32 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:32 --> Input Class Initialized
INFO - 2016-01-03 08:26:32 --> Language Class Initialized
INFO - 2016-01-03 08:26:32 --> Loader Class Initialized
INFO - 2016-01-03 08:26:32 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:32 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:32 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:32 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:32 --> Model Class Initialized
INFO - 2016-01-03 08:26:32 --> Model Class Initialized
INFO - 2016-01-03 08:26:32 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:32 --> Total execution time: 0.1168
INFO - 2016-01-03 08:26:33 --> Config Class Initialized
INFO - 2016-01-03 08:26:33 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:33 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:33 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:33 --> URI Class Initialized
INFO - 2016-01-03 08:26:33 --> Router Class Initialized
INFO - 2016-01-03 08:26:33 --> Output Class Initialized
INFO - 2016-01-03 08:26:33 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:33 --> Input Class Initialized
INFO - 2016-01-03 08:26:33 --> Language Class Initialized
INFO - 2016-01-03 08:26:33 --> Loader Class Initialized
INFO - 2016-01-03 08:26:33 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:33 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:33 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:33 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:33 --> Model Class Initialized
INFO - 2016-01-03 08:26:33 --> Model Class Initialized
INFO - 2016-01-03 08:26:33 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:33 --> Total execution time: 0.1534
INFO - 2016-01-03 08:26:35 --> Config Class Initialized
INFO - 2016-01-03 08:26:35 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:35 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:35 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:35 --> URI Class Initialized
INFO - 2016-01-03 08:26:35 --> Router Class Initialized
INFO - 2016-01-03 08:26:35 --> Output Class Initialized
INFO - 2016-01-03 08:26:35 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:35 --> Input Class Initialized
INFO - 2016-01-03 08:26:35 --> Language Class Initialized
INFO - 2016-01-03 08:26:36 --> Loader Class Initialized
INFO - 2016-01-03 08:26:36 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:36 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:36 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:36 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:36 --> Model Class Initialized
INFO - 2016-01-03 08:26:36 --> Model Class Initialized
INFO - 2016-01-03 08:26:36 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:36 --> Total execution time: 0.1447
INFO - 2016-01-03 08:26:36 --> Config Class Initialized
INFO - 2016-01-03 08:26:36 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:26:36 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:26:36 --> Utf8 Class Initialized
INFO - 2016-01-03 08:26:36 --> URI Class Initialized
INFO - 2016-01-03 08:26:36 --> Router Class Initialized
INFO - 2016-01-03 08:26:36 --> Output Class Initialized
INFO - 2016-01-03 08:26:36 --> Security Class Initialized
DEBUG - 2016-01-03 08:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:26:36 --> Input Class Initialized
INFO - 2016-01-03 08:26:36 --> Language Class Initialized
INFO - 2016-01-03 08:26:36 --> Loader Class Initialized
INFO - 2016-01-03 08:26:36 --> Helper loaded: url_helper
INFO - 2016-01-03 08:26:36 --> Database Driver Class Initialized
INFO - 2016-01-03 08:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:26:37 --> Controller Class Initialized
DEBUG - 2016-01-03 08:26:37 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:26:37 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:26:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:26:37 --> Model Class Initialized
INFO - 2016-01-03 08:26:37 --> Model Class Initialized
INFO - 2016-01-03 08:26:37 --> Final output sent to browser
DEBUG - 2016-01-03 08:26:37 --> Total execution time: 0.1581
INFO - 2016-01-03 08:27:14 --> Config Class Initialized
INFO - 2016-01-03 08:27:14 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:27:14 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:27:14 --> Utf8 Class Initialized
INFO - 2016-01-03 08:27:14 --> URI Class Initialized
DEBUG - 2016-01-03 08:27:14 --> No URI present. Default controller set.
INFO - 2016-01-03 08:27:14 --> Router Class Initialized
INFO - 2016-01-03 08:27:15 --> Output Class Initialized
INFO - 2016-01-03 08:27:15 --> Security Class Initialized
DEBUG - 2016-01-03 08:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:27:15 --> Input Class Initialized
INFO - 2016-01-03 08:27:15 --> Language Class Initialized
INFO - 2016-01-03 08:27:15 --> Loader Class Initialized
INFO - 2016-01-03 08:27:15 --> Helper loaded: url_helper
INFO - 2016-01-03 08:27:15 --> Database Driver Class Initialized
INFO - 2016-01-03 08:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:27:15 --> Controller Class Initialized
INFO - 2016-01-03 08:27:15 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 08:27:15 --> Final output sent to browser
DEBUG - 2016-01-03 08:27:15 --> Total execution time: 0.1940
INFO - 2016-01-03 08:27:19 --> Config Class Initialized
INFO - 2016-01-03 08:27:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:27:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:27:19 --> Utf8 Class Initialized
INFO - 2016-01-03 08:27:19 --> URI Class Initialized
INFO - 2016-01-03 08:27:19 --> Router Class Initialized
INFO - 2016-01-03 08:27:19 --> Output Class Initialized
INFO - 2016-01-03 08:27:19 --> Security Class Initialized
DEBUG - 2016-01-03 08:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:27:19 --> Input Class Initialized
INFO - 2016-01-03 08:27:19 --> Language Class Initialized
INFO - 2016-01-03 08:27:19 --> Loader Class Initialized
INFO - 2016-01-03 08:27:19 --> Helper loaded: url_helper
INFO - 2016-01-03 08:27:19 --> Database Driver Class Initialized
INFO - 2016-01-03 08:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:27:19 --> Controller Class Initialized
INFO - 2016-01-03 08:27:19 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 08:27:19 --> Final output sent to browser
DEBUG - 2016-01-03 08:27:19 --> Total execution time: 0.0839
INFO - 2016-01-03 08:27:19 --> Config Class Initialized
INFO - 2016-01-03 08:27:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:27:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:27:19 --> Utf8 Class Initialized
INFO - 2016-01-03 08:27:19 --> URI Class Initialized
INFO - 2016-01-03 08:27:19 --> Router Class Initialized
INFO - 2016-01-03 08:27:19 --> Output Class Initialized
INFO - 2016-01-03 08:27:19 --> Security Class Initialized
DEBUG - 2016-01-03 08:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:27:19 --> Input Class Initialized
INFO - 2016-01-03 08:27:19 --> Language Class Initialized
INFO - 2016-01-03 08:27:19 --> Loader Class Initialized
INFO - 2016-01-03 08:27:19 --> Helper loaded: url_helper
INFO - 2016-01-03 08:27:19 --> Database Driver Class Initialized
INFO - 2016-01-03 08:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:27:19 --> Controller Class Initialized
DEBUG - 2016-01-03 08:27:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:27:19 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:27:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:27:19 --> Model Class Initialized
INFO - 2016-01-03 08:27:19 --> Model Class Initialized
INFO - 2016-01-03 08:27:19 --> Final output sent to browser
DEBUG - 2016-01-03 08:27:19 --> Total execution time: 0.1179
INFO - 2016-01-03 08:28:08 --> Config Class Initialized
INFO - 2016-01-03 08:28:08 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:28:08 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:28:08 --> Utf8 Class Initialized
INFO - 2016-01-03 08:28:08 --> URI Class Initialized
DEBUG - 2016-01-03 08:28:08 --> No URI present. Default controller set.
INFO - 2016-01-03 08:28:08 --> Router Class Initialized
INFO - 2016-01-03 08:28:08 --> Output Class Initialized
INFO - 2016-01-03 08:28:08 --> Security Class Initialized
DEBUG - 2016-01-03 08:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:28:08 --> Input Class Initialized
INFO - 2016-01-03 08:28:08 --> Language Class Initialized
INFO - 2016-01-03 08:28:08 --> Loader Class Initialized
INFO - 2016-01-03 08:28:08 --> Helper loaded: url_helper
INFO - 2016-01-03 08:28:08 --> Database Driver Class Initialized
INFO - 2016-01-03 08:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:28:08 --> Controller Class Initialized
INFO - 2016-01-03 08:28:08 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 08:28:08 --> Final output sent to browser
DEBUG - 2016-01-03 08:28:08 --> Total execution time: 0.1589
INFO - 2016-01-03 08:28:32 --> Config Class Initialized
INFO - 2016-01-03 08:28:32 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:28:32 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:28:32 --> Utf8 Class Initialized
INFO - 2016-01-03 08:28:32 --> URI Class Initialized
INFO - 2016-01-03 08:28:32 --> Router Class Initialized
INFO - 2016-01-03 08:28:32 --> Output Class Initialized
INFO - 2016-01-03 08:28:32 --> Security Class Initialized
DEBUG - 2016-01-03 08:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:28:32 --> Input Class Initialized
INFO - 2016-01-03 08:28:32 --> Language Class Initialized
INFO - 2016-01-03 08:28:32 --> Loader Class Initialized
INFO - 2016-01-03 08:28:32 --> Helper loaded: url_helper
INFO - 2016-01-03 08:28:32 --> Database Driver Class Initialized
INFO - 2016-01-03 08:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:28:32 --> Controller Class Initialized
INFO - 2016-01-03 08:28:32 --> Helper loaded: form_helper
INFO - 2016-01-03 08:28:32 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 08:28:32 --> Final output sent to browser
DEBUG - 2016-01-03 08:28:32 --> Total execution time: 0.1771
INFO - 2016-01-03 08:28:37 --> Config Class Initialized
INFO - 2016-01-03 08:28:37 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:28:37 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:28:37 --> Utf8 Class Initialized
INFO - 2016-01-03 08:28:37 --> URI Class Initialized
INFO - 2016-01-03 08:28:37 --> Router Class Initialized
INFO - 2016-01-03 08:28:37 --> Output Class Initialized
INFO - 2016-01-03 08:28:37 --> Security Class Initialized
DEBUG - 2016-01-03 08:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:28:37 --> Input Class Initialized
INFO - 2016-01-03 08:28:37 --> Language Class Initialized
INFO - 2016-01-03 08:28:37 --> Loader Class Initialized
INFO - 2016-01-03 08:28:37 --> Helper loaded: url_helper
INFO - 2016-01-03 08:28:37 --> Database Driver Class Initialized
INFO - 2016-01-03 08:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:28:37 --> Controller Class Initialized
INFO - 2016-01-03 08:28:37 --> Helper loaded: form_helper
INFO - 2016-01-03 08:28:37 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 08:28:37 --> Final output sent to browser
DEBUG - 2016-01-03 08:28:37 --> Total execution time: 0.1144
INFO - 2016-01-03 08:28:47 --> Config Class Initialized
INFO - 2016-01-03 08:28:47 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:28:47 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:28:47 --> Utf8 Class Initialized
INFO - 2016-01-03 08:28:47 --> URI Class Initialized
INFO - 2016-01-03 08:28:47 --> Router Class Initialized
INFO - 2016-01-03 08:28:47 --> Output Class Initialized
INFO - 2016-01-03 08:28:47 --> Security Class Initialized
DEBUG - 2016-01-03 08:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:28:47 --> Input Class Initialized
INFO - 2016-01-03 08:28:47 --> Language Class Initialized
INFO - 2016-01-03 08:28:47 --> Loader Class Initialized
INFO - 2016-01-03 08:28:47 --> Helper loaded: url_helper
INFO - 2016-01-03 08:28:47 --> Database Driver Class Initialized
INFO - 2016-01-03 08:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:28:47 --> Controller Class Initialized
INFO - 2016-01-03 08:28:47 --> Model Class Initialized
INFO - 2016-01-03 08:28:47 --> Model Class Initialized
INFO - 2016-01-03 08:28:47 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:28:47 --> Final output sent to browser
DEBUG - 2016-01-03 08:28:47 --> Total execution time: 0.1605
INFO - 2016-01-03 08:28:47 --> Config Class Initialized
INFO - 2016-01-03 08:28:47 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:28:47 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:28:47 --> Utf8 Class Initialized
INFO - 2016-01-03 08:28:47 --> URI Class Initialized
INFO - 2016-01-03 08:28:47 --> Router Class Initialized
INFO - 2016-01-03 08:28:47 --> Output Class Initialized
INFO - 2016-01-03 08:28:47 --> Security Class Initialized
DEBUG - 2016-01-03 08:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:28:47 --> Input Class Initialized
INFO - 2016-01-03 08:28:47 --> Language Class Initialized
INFO - 2016-01-03 08:28:47 --> Loader Class Initialized
INFO - 2016-01-03 08:28:47 --> Helper loaded: url_helper
INFO - 2016-01-03 08:28:47 --> Database Driver Class Initialized
INFO - 2016-01-03 08:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:28:47 --> Controller Class Initialized
INFO - 2016-01-03 08:28:47 --> Model Class Initialized
INFO - 2016-01-03 08:28:47 --> Model Class Initialized
INFO - 2016-01-03 08:28:47 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 08:28:47 --> Config Class Initialized
INFO - 2016-01-03 08:28:47 --> Final output sent to browser
INFO - 2016-01-03 08:28:47 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:28:47 --> Total execution time: 0.1530
DEBUG - 2016-01-03 08:28:47 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:28:47 --> Utf8 Class Initialized
INFO - 2016-01-03 08:28:47 --> URI Class Initialized
INFO - 2016-01-03 08:28:47 --> Router Class Initialized
INFO - 2016-01-03 08:28:47 --> Output Class Initialized
INFO - 2016-01-03 08:28:47 --> Security Class Initialized
DEBUG - 2016-01-03 08:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:28:47 --> Input Class Initialized
INFO - 2016-01-03 08:28:47 --> Language Class Initialized
INFO - 2016-01-03 08:28:47 --> Loader Class Initialized
INFO - 2016-01-03 08:28:47 --> Helper loaded: url_helper
INFO - 2016-01-03 08:28:47 --> Database Driver Class Initialized
INFO - 2016-01-03 08:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:28:47 --> Controller Class Initialized
DEBUG - 2016-01-03 08:28:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:28:47 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:28:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:28:47 --> Model Class Initialized
INFO - 2016-01-03 08:28:47 --> Model Class Initialized
INFO - 2016-01-03 08:28:48 --> Final output sent to browser
DEBUG - 2016-01-03 08:28:48 --> Total execution time: 0.2040
INFO - 2016-01-03 08:29:18 --> Config Class Initialized
INFO - 2016-01-03 08:29:18 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:29:18 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:29:18 --> Utf8 Class Initialized
INFO - 2016-01-03 08:29:18 --> URI Class Initialized
INFO - 2016-01-03 08:29:18 --> Router Class Initialized
INFO - 2016-01-03 08:29:18 --> Output Class Initialized
INFO - 2016-01-03 08:29:18 --> Security Class Initialized
DEBUG - 2016-01-03 08:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:29:18 --> Input Class Initialized
INFO - 2016-01-03 08:29:18 --> Language Class Initialized
INFO - 2016-01-03 08:29:18 --> Loader Class Initialized
INFO - 2016-01-03 08:29:18 --> Helper loaded: url_helper
INFO - 2016-01-03 08:29:18 --> Database Driver Class Initialized
INFO - 2016-01-03 08:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:29:18 --> Controller Class Initialized
INFO - 2016-01-03 08:29:18 --> Model Class Initialized
INFO - 2016-01-03 08:29:18 --> Model Class Initialized
INFO - 2016-01-03 08:29:18 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:29:18 --> Final output sent to browser
DEBUG - 2016-01-03 08:29:18 --> Total execution time: 0.1199
INFO - 2016-01-03 08:29:18 --> Config Class Initialized
INFO - 2016-01-03 08:29:18 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:29:18 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:29:18 --> Utf8 Class Initialized
INFO - 2016-01-03 08:29:18 --> URI Class Initialized
INFO - 2016-01-03 08:29:18 --> Router Class Initialized
INFO - 2016-01-03 08:29:18 --> Output Class Initialized
INFO - 2016-01-03 08:29:18 --> Security Class Initialized
DEBUG - 2016-01-03 08:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:29:18 --> Input Class Initialized
INFO - 2016-01-03 08:29:18 --> Language Class Initialized
INFO - 2016-01-03 08:29:18 --> Loader Class Initialized
INFO - 2016-01-03 08:29:18 --> Helper loaded: url_helper
INFO - 2016-01-03 08:29:18 --> Database Driver Class Initialized
INFO - 2016-01-03 08:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:29:18 --> Controller Class Initialized
INFO - 2016-01-03 08:29:18 --> Model Class Initialized
INFO - 2016-01-03 08:29:18 --> Model Class Initialized
INFO - 2016-01-03 08:29:18 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:29:18 --> Final output sent to browser
DEBUG - 2016-01-03 08:29:18 --> Total execution time: 0.0962
INFO - 2016-01-03 08:29:19 --> Config Class Initialized
INFO - 2016-01-03 08:29:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:29:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:29:19 --> Utf8 Class Initialized
INFO - 2016-01-03 08:29:19 --> URI Class Initialized
INFO - 2016-01-03 08:29:19 --> Router Class Initialized
INFO - 2016-01-03 08:29:19 --> Output Class Initialized
INFO - 2016-01-03 08:29:19 --> Security Class Initialized
DEBUG - 2016-01-03 08:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:29:19 --> Input Class Initialized
INFO - 2016-01-03 08:29:19 --> Language Class Initialized
INFO - 2016-01-03 08:29:19 --> Loader Class Initialized
INFO - 2016-01-03 08:29:19 --> Helper loaded: url_helper
INFO - 2016-01-03 08:29:19 --> Database Driver Class Initialized
INFO - 2016-01-03 08:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:29:19 --> Controller Class Initialized
DEBUG - 2016-01-03 08:29:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:29:19 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:29:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:29:19 --> Model Class Initialized
INFO - 2016-01-03 08:29:19 --> Model Class Initialized
INFO - 2016-01-03 08:29:19 --> Final output sent to browser
DEBUG - 2016-01-03 08:29:19 --> Total execution time: 0.1091
INFO - 2016-01-03 08:29:57 --> Config Class Initialized
INFO - 2016-01-03 08:29:57 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:29:57 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:29:57 --> Utf8 Class Initialized
INFO - 2016-01-03 08:29:57 --> URI Class Initialized
INFO - 2016-01-03 08:29:57 --> Router Class Initialized
INFO - 2016-01-03 08:29:57 --> Output Class Initialized
INFO - 2016-01-03 08:29:57 --> Security Class Initialized
DEBUG - 2016-01-03 08:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:29:57 --> Input Class Initialized
INFO - 2016-01-03 08:29:57 --> Language Class Initialized
INFO - 2016-01-03 08:29:57 --> Loader Class Initialized
INFO - 2016-01-03 08:29:57 --> Helper loaded: url_helper
INFO - 2016-01-03 08:29:57 --> Database Driver Class Initialized
INFO - 2016-01-03 08:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:29:58 --> Controller Class Initialized
DEBUG - 2016-01-03 08:29:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:29:58 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:29:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:29:58 --> Model Class Initialized
INFO - 2016-01-03 08:29:58 --> Model Class Initialized
INFO - 2016-01-03 08:29:58 --> Final output sent to browser
DEBUG - 2016-01-03 08:29:58 --> Total execution time: 0.2429
INFO - 2016-01-03 08:30:08 --> Config Class Initialized
INFO - 2016-01-03 08:30:08 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:08 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:08 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:08 --> URI Class Initialized
INFO - 2016-01-03 08:30:08 --> Router Class Initialized
INFO - 2016-01-03 08:30:08 --> Output Class Initialized
INFO - 2016-01-03 08:30:08 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:08 --> Input Class Initialized
INFO - 2016-01-03 08:30:08 --> Language Class Initialized
INFO - 2016-01-03 08:30:08 --> Loader Class Initialized
INFO - 2016-01-03 08:30:08 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:08 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:08 --> Controller Class Initialized
INFO - 2016-01-03 08:30:08 --> Helper loaded: form_helper
INFO - 2016-01-03 08:30:08 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 08:30:08 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:08 --> Total execution time: 0.1089
INFO - 2016-01-03 08:30:12 --> Config Class Initialized
INFO - 2016-01-03 08:30:12 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:12 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:12 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:12 --> URI Class Initialized
DEBUG - 2016-01-03 08:30:12 --> No URI present. Default controller set.
INFO - 2016-01-03 08:30:12 --> Router Class Initialized
INFO - 2016-01-03 08:30:12 --> Output Class Initialized
INFO - 2016-01-03 08:30:12 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:12 --> Input Class Initialized
INFO - 2016-01-03 08:30:12 --> Language Class Initialized
INFO - 2016-01-03 08:30:12 --> Loader Class Initialized
INFO - 2016-01-03 08:30:12 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:12 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:12 --> Controller Class Initialized
INFO - 2016-01-03 08:30:12 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 08:30:12 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:12 --> Total execution time: 0.1222
INFO - 2016-01-03 08:30:15 --> Config Class Initialized
INFO - 2016-01-03 08:30:15 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:15 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:15 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:15 --> URI Class Initialized
INFO - 2016-01-03 08:30:15 --> Router Class Initialized
INFO - 2016-01-03 08:30:15 --> Output Class Initialized
INFO - 2016-01-03 08:30:15 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:15 --> Input Class Initialized
INFO - 2016-01-03 08:30:15 --> Language Class Initialized
INFO - 2016-01-03 08:30:15 --> Loader Class Initialized
INFO - 2016-01-03 08:30:15 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:15 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:15 --> Controller Class Initialized
INFO - 2016-01-03 08:30:15 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 08:30:15 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:15 --> Total execution time: 0.1183
INFO - 2016-01-03 08:30:16 --> Config Class Initialized
INFO - 2016-01-03 08:30:16 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:16 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:16 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:16 --> URI Class Initialized
INFO - 2016-01-03 08:30:16 --> Router Class Initialized
INFO - 2016-01-03 08:30:16 --> Output Class Initialized
INFO - 2016-01-03 08:30:16 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:16 --> Input Class Initialized
INFO - 2016-01-03 08:30:16 --> Language Class Initialized
INFO - 2016-01-03 08:30:16 --> Loader Class Initialized
INFO - 2016-01-03 08:30:16 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:16 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:16 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:16 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:16 --> Model Class Initialized
INFO - 2016-01-03 08:30:16 --> Model Class Initialized
INFO - 2016-01-03 08:30:16 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:16 --> Total execution time: 0.1478
INFO - 2016-01-03 08:30:37 --> Config Class Initialized
INFO - 2016-01-03 08:30:37 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:37 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:37 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:37 --> URI Class Initialized
INFO - 2016-01-03 08:30:37 --> Router Class Initialized
INFO - 2016-01-03 08:30:37 --> Output Class Initialized
INFO - 2016-01-03 08:30:37 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:37 --> Input Class Initialized
INFO - 2016-01-03 08:30:37 --> Language Class Initialized
INFO - 2016-01-03 08:30:37 --> Loader Class Initialized
INFO - 2016-01-03 08:30:37 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:37 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:37 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:38 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:38 --> Model Class Initialized
INFO - 2016-01-03 08:30:38 --> Model Class Initialized
INFO - 2016-01-03 08:30:38 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:38 --> Total execution time: 0.1655
INFO - 2016-01-03 08:30:40 --> Config Class Initialized
INFO - 2016-01-03 08:30:40 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:40 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:40 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:40 --> URI Class Initialized
INFO - 2016-01-03 08:30:40 --> Router Class Initialized
INFO - 2016-01-03 08:30:40 --> Output Class Initialized
INFO - 2016-01-03 08:30:40 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:40 --> Input Class Initialized
INFO - 2016-01-03 08:30:40 --> Language Class Initialized
INFO - 2016-01-03 08:30:40 --> Loader Class Initialized
INFO - 2016-01-03 08:30:40 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:40 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:40 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:40 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:40 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:40 --> Model Class Initialized
INFO - 2016-01-03 08:30:40 --> Model Class Initialized
INFO - 2016-01-03 08:30:40 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:40 --> Total execution time: 0.1541
INFO - 2016-01-03 08:30:42 --> Config Class Initialized
INFO - 2016-01-03 08:30:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:42 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:43 --> URI Class Initialized
INFO - 2016-01-03 08:30:43 --> Router Class Initialized
INFO - 2016-01-03 08:30:43 --> Output Class Initialized
INFO - 2016-01-03 08:30:43 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:43 --> Input Class Initialized
INFO - 2016-01-03 08:30:43 --> Language Class Initialized
INFO - 2016-01-03 08:30:43 --> Loader Class Initialized
INFO - 2016-01-03 08:30:43 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:43 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:43 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:43 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:43 --> Model Class Initialized
INFO - 2016-01-03 08:30:43 --> Model Class Initialized
INFO - 2016-01-03 08:30:43 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:43 --> Total execution time: 0.1306
INFO - 2016-01-03 08:30:43 --> Config Class Initialized
INFO - 2016-01-03 08:30:43 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:43 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:43 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:43 --> URI Class Initialized
INFO - 2016-01-03 08:30:43 --> Router Class Initialized
INFO - 2016-01-03 08:30:43 --> Output Class Initialized
INFO - 2016-01-03 08:30:43 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:43 --> Input Class Initialized
INFO - 2016-01-03 08:30:43 --> Language Class Initialized
INFO - 2016-01-03 08:30:43 --> Loader Class Initialized
INFO - 2016-01-03 08:30:43 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:43 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:43 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:43 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:43 --> Model Class Initialized
INFO - 2016-01-03 08:30:43 --> Model Class Initialized
INFO - 2016-01-03 08:30:43 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:43 --> Total execution time: 0.1478
INFO - 2016-01-03 08:30:45 --> Config Class Initialized
INFO - 2016-01-03 08:30:45 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:45 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:45 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:45 --> URI Class Initialized
INFO - 2016-01-03 08:30:45 --> Router Class Initialized
INFO - 2016-01-03 08:30:45 --> Output Class Initialized
INFO - 2016-01-03 08:30:45 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:45 --> Input Class Initialized
INFO - 2016-01-03 08:30:45 --> Language Class Initialized
INFO - 2016-01-03 08:30:45 --> Loader Class Initialized
INFO - 2016-01-03 08:30:45 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:45 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:45 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:45 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:45 --> Model Class Initialized
INFO - 2016-01-03 08:30:45 --> Model Class Initialized
INFO - 2016-01-03 08:30:45 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:45 --> Total execution time: 0.1306
INFO - 2016-01-03 08:30:45 --> Config Class Initialized
INFO - 2016-01-03 08:30:45 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:45 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:45 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:45 --> URI Class Initialized
INFO - 2016-01-03 08:30:45 --> Router Class Initialized
INFO - 2016-01-03 08:30:45 --> Output Class Initialized
INFO - 2016-01-03 08:30:45 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:45 --> Input Class Initialized
INFO - 2016-01-03 08:30:45 --> Language Class Initialized
INFO - 2016-01-03 08:30:45 --> Loader Class Initialized
INFO - 2016-01-03 08:30:45 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:45 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:46 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:46 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:46 --> Model Class Initialized
INFO - 2016-01-03 08:30:46 --> Model Class Initialized
INFO - 2016-01-03 08:30:46 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:46 --> Total execution time: 0.1263
INFO - 2016-01-03 08:30:50 --> Config Class Initialized
INFO - 2016-01-03 08:30:50 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:50 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:50 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:50 --> URI Class Initialized
INFO - 2016-01-03 08:30:50 --> Router Class Initialized
INFO - 2016-01-03 08:30:50 --> Output Class Initialized
INFO - 2016-01-03 08:30:50 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:50 --> Input Class Initialized
INFO - 2016-01-03 08:30:50 --> Language Class Initialized
INFO - 2016-01-03 08:30:50 --> Loader Class Initialized
INFO - 2016-01-03 08:30:50 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:50 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:50 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:50 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:50 --> Model Class Initialized
INFO - 2016-01-03 08:30:50 --> Model Class Initialized
INFO - 2016-01-03 08:30:50 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:50 --> Total execution time: 0.1058
INFO - 2016-01-03 08:30:50 --> Config Class Initialized
INFO - 2016-01-03 08:30:50 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:50 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:50 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:50 --> URI Class Initialized
INFO - 2016-01-03 08:30:50 --> Router Class Initialized
INFO - 2016-01-03 08:30:50 --> Output Class Initialized
INFO - 2016-01-03 08:30:50 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:50 --> Input Class Initialized
INFO - 2016-01-03 08:30:50 --> Language Class Initialized
INFO - 2016-01-03 08:30:51 --> Loader Class Initialized
INFO - 2016-01-03 08:30:51 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:51 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:51 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:51 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:51 --> Model Class Initialized
INFO - 2016-01-03 08:30:51 --> Model Class Initialized
INFO - 2016-01-03 08:30:51 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:51 --> Total execution time: 0.1633
INFO - 2016-01-03 08:30:52 --> Config Class Initialized
INFO - 2016-01-03 08:30:52 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:52 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:52 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:52 --> URI Class Initialized
INFO - 2016-01-03 08:30:52 --> Router Class Initialized
INFO - 2016-01-03 08:30:52 --> Output Class Initialized
INFO - 2016-01-03 08:30:52 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:52 --> Input Class Initialized
INFO - 2016-01-03 08:30:52 --> Language Class Initialized
INFO - 2016-01-03 08:30:52 --> Loader Class Initialized
INFO - 2016-01-03 08:30:52 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:52 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:52 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:52 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:52 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:52 --> Model Class Initialized
INFO - 2016-01-03 08:30:52 --> Model Class Initialized
INFO - 2016-01-03 08:30:52 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:52 --> Total execution time: 0.1554
INFO - 2016-01-03 08:30:52 --> Config Class Initialized
INFO - 2016-01-03 08:30:52 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:52 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:52 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:52 --> URI Class Initialized
INFO - 2016-01-03 08:30:52 --> Router Class Initialized
INFO - 2016-01-03 08:30:52 --> Output Class Initialized
INFO - 2016-01-03 08:30:52 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:52 --> Input Class Initialized
INFO - 2016-01-03 08:30:52 --> Language Class Initialized
INFO - 2016-01-03 08:30:53 --> Loader Class Initialized
INFO - 2016-01-03 08:30:53 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:53 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:53 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:53 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:53 --> Model Class Initialized
INFO - 2016-01-03 08:30:53 --> Model Class Initialized
INFO - 2016-01-03 08:30:53 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:53 --> Total execution time: 0.1497
INFO - 2016-01-03 08:30:56 --> Config Class Initialized
INFO - 2016-01-03 08:30:56 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:56 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:56 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:56 --> URI Class Initialized
INFO - 2016-01-03 08:30:56 --> Router Class Initialized
INFO - 2016-01-03 08:30:56 --> Output Class Initialized
INFO - 2016-01-03 08:30:56 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:56 --> Input Class Initialized
INFO - 2016-01-03 08:30:56 --> Language Class Initialized
INFO - 2016-01-03 08:30:56 --> Loader Class Initialized
INFO - 2016-01-03 08:30:56 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:56 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:56 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:56 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:56 --> Model Class Initialized
INFO - 2016-01-03 08:30:56 --> Model Class Initialized
INFO - 2016-01-03 08:30:56 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:56 --> Total execution time: 0.1470
INFO - 2016-01-03 08:30:56 --> Config Class Initialized
INFO - 2016-01-03 08:30:56 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:56 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:56 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:56 --> URI Class Initialized
INFO - 2016-01-03 08:30:56 --> Router Class Initialized
INFO - 2016-01-03 08:30:56 --> Output Class Initialized
INFO - 2016-01-03 08:30:56 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:56 --> Input Class Initialized
INFO - 2016-01-03 08:30:56 --> Language Class Initialized
INFO - 2016-01-03 08:30:56 --> Loader Class Initialized
INFO - 2016-01-03 08:30:56 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:56 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:56 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:56 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:56 --> Model Class Initialized
INFO - 2016-01-03 08:30:56 --> Model Class Initialized
INFO - 2016-01-03 08:30:56 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:56 --> Total execution time: 0.1449
INFO - 2016-01-03 08:30:57 --> Config Class Initialized
INFO - 2016-01-03 08:30:57 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:57 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:57 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:57 --> URI Class Initialized
INFO - 2016-01-03 08:30:57 --> Router Class Initialized
INFO - 2016-01-03 08:30:57 --> Output Class Initialized
INFO - 2016-01-03 08:30:57 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:57 --> Input Class Initialized
INFO - 2016-01-03 08:30:57 --> Language Class Initialized
INFO - 2016-01-03 08:30:57 --> Loader Class Initialized
INFO - 2016-01-03 08:30:57 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:57 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:57 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:57 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:57 --> Model Class Initialized
INFO - 2016-01-03 08:30:57 --> Model Class Initialized
INFO - 2016-01-03 08:30:57 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:57 --> Total execution time: 0.1538
INFO - 2016-01-03 08:30:58 --> Config Class Initialized
INFO - 2016-01-03 08:30:58 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:58 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:58 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:58 --> URI Class Initialized
INFO - 2016-01-03 08:30:58 --> Router Class Initialized
INFO - 2016-01-03 08:30:58 --> Output Class Initialized
INFO - 2016-01-03 08:30:58 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:58 --> Input Class Initialized
INFO - 2016-01-03 08:30:58 --> Language Class Initialized
INFO - 2016-01-03 08:30:58 --> Loader Class Initialized
INFO - 2016-01-03 08:30:58 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:58 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:58 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:58 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:58 --> Model Class Initialized
INFO - 2016-01-03 08:30:58 --> Model Class Initialized
INFO - 2016-01-03 08:30:58 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:58 --> Total execution time: 0.2275
INFO - 2016-01-03 08:30:59 --> Config Class Initialized
INFO - 2016-01-03 08:30:59 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:30:59 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:30:59 --> Utf8 Class Initialized
INFO - 2016-01-03 08:30:59 --> URI Class Initialized
INFO - 2016-01-03 08:30:59 --> Router Class Initialized
INFO - 2016-01-03 08:30:59 --> Output Class Initialized
INFO - 2016-01-03 08:30:59 --> Security Class Initialized
DEBUG - 2016-01-03 08:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:30:59 --> Input Class Initialized
INFO - 2016-01-03 08:30:59 --> Language Class Initialized
INFO - 2016-01-03 08:30:59 --> Loader Class Initialized
INFO - 2016-01-03 08:30:59 --> Helper loaded: url_helper
INFO - 2016-01-03 08:30:59 --> Database Driver Class Initialized
INFO - 2016-01-03 08:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:30:59 --> Controller Class Initialized
DEBUG - 2016-01-03 08:30:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:30:59 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:30:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:30:59 --> Model Class Initialized
INFO - 2016-01-03 08:30:59 --> Model Class Initialized
INFO - 2016-01-03 08:30:59 --> Final output sent to browser
DEBUG - 2016-01-03 08:30:59 --> Total execution time: 0.1510
INFO - 2016-01-03 08:31:00 --> Config Class Initialized
INFO - 2016-01-03 08:31:00 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:00 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:00 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:00 --> URI Class Initialized
INFO - 2016-01-03 08:31:00 --> Router Class Initialized
INFO - 2016-01-03 08:31:00 --> Output Class Initialized
INFO - 2016-01-03 08:31:00 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:00 --> Input Class Initialized
INFO - 2016-01-03 08:31:00 --> Language Class Initialized
INFO - 2016-01-03 08:31:00 --> Loader Class Initialized
INFO - 2016-01-03 08:31:00 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:00 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:00 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:00 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:00 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:00 --> Model Class Initialized
INFO - 2016-01-03 08:31:00 --> Model Class Initialized
INFO - 2016-01-03 08:31:00 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:00 --> Total execution time: 0.1690
INFO - 2016-01-03 08:31:19 --> Config Class Initialized
INFO - 2016-01-03 08:31:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:19 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:19 --> URI Class Initialized
INFO - 2016-01-03 08:31:19 --> Router Class Initialized
INFO - 2016-01-03 08:31:19 --> Output Class Initialized
INFO - 2016-01-03 08:31:19 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:19 --> Input Class Initialized
INFO - 2016-01-03 08:31:19 --> Language Class Initialized
INFO - 2016-01-03 08:31:19 --> Loader Class Initialized
INFO - 2016-01-03 08:31:19 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:19 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:19 --> Controller Class Initialized
INFO - 2016-01-03 08:31:19 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 08:31:19 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:19 --> Total execution time: 0.0964
INFO - 2016-01-03 08:31:19 --> Config Class Initialized
INFO - 2016-01-03 08:31:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:19 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:19 --> URI Class Initialized
INFO - 2016-01-03 08:31:19 --> Router Class Initialized
INFO - 2016-01-03 08:31:19 --> Output Class Initialized
INFO - 2016-01-03 08:31:19 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:19 --> Input Class Initialized
INFO - 2016-01-03 08:31:19 --> Language Class Initialized
INFO - 2016-01-03 08:31:19 --> Loader Class Initialized
INFO - 2016-01-03 08:31:19 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:19 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:19 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:19 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:19 --> Model Class Initialized
INFO - 2016-01-03 08:31:19 --> Model Class Initialized
INFO - 2016-01-03 08:31:19 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:19 --> Total execution time: 0.1864
INFO - 2016-01-03 08:31:26 --> Config Class Initialized
INFO - 2016-01-03 08:31:26 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:26 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:26 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:26 --> URI Class Initialized
INFO - 2016-01-03 08:31:26 --> Router Class Initialized
INFO - 2016-01-03 08:31:26 --> Output Class Initialized
INFO - 2016-01-03 08:31:26 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:26 --> Input Class Initialized
INFO - 2016-01-03 08:31:26 --> Language Class Initialized
INFO - 2016-01-03 08:31:26 --> Loader Class Initialized
INFO - 2016-01-03 08:31:26 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:26 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:26 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:26 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:26 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:26 --> Model Class Initialized
INFO - 2016-01-03 08:31:26 --> Model Class Initialized
INFO - 2016-01-03 08:31:26 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:26 --> Total execution time: 0.1505
INFO - 2016-01-03 08:31:27 --> Config Class Initialized
INFO - 2016-01-03 08:31:27 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:27 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:27 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:27 --> URI Class Initialized
INFO - 2016-01-03 08:31:27 --> Router Class Initialized
INFO - 2016-01-03 08:31:27 --> Output Class Initialized
INFO - 2016-01-03 08:31:27 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:27 --> Input Class Initialized
INFO - 2016-01-03 08:31:27 --> Language Class Initialized
INFO - 2016-01-03 08:31:27 --> Loader Class Initialized
INFO - 2016-01-03 08:31:27 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:27 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:27 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:27 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:27 --> Model Class Initialized
INFO - 2016-01-03 08:31:27 --> Model Class Initialized
INFO - 2016-01-03 08:31:27 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:27 --> Total execution time: 0.1416
INFO - 2016-01-03 08:31:30 --> Config Class Initialized
INFO - 2016-01-03 08:31:30 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:30 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:30 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:30 --> URI Class Initialized
INFO - 2016-01-03 08:31:30 --> Router Class Initialized
INFO - 2016-01-03 08:31:30 --> Output Class Initialized
INFO - 2016-01-03 08:31:30 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:30 --> Input Class Initialized
INFO - 2016-01-03 08:31:30 --> Language Class Initialized
INFO - 2016-01-03 08:31:30 --> Loader Class Initialized
INFO - 2016-01-03 08:31:30 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:30 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:30 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:30 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:30 --> Model Class Initialized
INFO - 2016-01-03 08:31:30 --> Model Class Initialized
INFO - 2016-01-03 08:31:30 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:30 --> Total execution time: 0.1467
INFO - 2016-01-03 08:31:31 --> Config Class Initialized
INFO - 2016-01-03 08:31:31 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:31 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:31 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:31 --> URI Class Initialized
INFO - 2016-01-03 08:31:31 --> Router Class Initialized
INFO - 2016-01-03 08:31:31 --> Output Class Initialized
INFO - 2016-01-03 08:31:31 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:31 --> Input Class Initialized
INFO - 2016-01-03 08:31:31 --> Language Class Initialized
INFO - 2016-01-03 08:31:31 --> Loader Class Initialized
INFO - 2016-01-03 08:31:31 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:31 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:31 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:31 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:31 --> Model Class Initialized
INFO - 2016-01-03 08:31:31 --> Model Class Initialized
INFO - 2016-01-03 08:31:31 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:31 --> Total execution time: 0.2520
INFO - 2016-01-03 08:31:33 --> Config Class Initialized
INFO - 2016-01-03 08:31:33 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:33 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:33 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:33 --> URI Class Initialized
INFO - 2016-01-03 08:31:33 --> Router Class Initialized
INFO - 2016-01-03 08:31:33 --> Output Class Initialized
INFO - 2016-01-03 08:31:33 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:33 --> Input Class Initialized
INFO - 2016-01-03 08:31:33 --> Language Class Initialized
INFO - 2016-01-03 08:31:33 --> Loader Class Initialized
INFO - 2016-01-03 08:31:33 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:33 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:33 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:33 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:33 --> Model Class Initialized
INFO - 2016-01-03 08:31:33 --> Model Class Initialized
INFO - 2016-01-03 08:31:33 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:33 --> Total execution time: 0.1806
INFO - 2016-01-03 08:31:34 --> Config Class Initialized
INFO - 2016-01-03 08:31:34 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:34 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:34 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:34 --> URI Class Initialized
INFO - 2016-01-03 08:31:34 --> Router Class Initialized
INFO - 2016-01-03 08:31:34 --> Output Class Initialized
INFO - 2016-01-03 08:31:34 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:34 --> Input Class Initialized
INFO - 2016-01-03 08:31:34 --> Language Class Initialized
INFO - 2016-01-03 08:31:34 --> Loader Class Initialized
INFO - 2016-01-03 08:31:34 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:34 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:34 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:34 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:34 --> Model Class Initialized
INFO - 2016-01-03 08:31:34 --> Model Class Initialized
INFO - 2016-01-03 08:31:34 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:34 --> Total execution time: 0.1473
INFO - 2016-01-03 08:31:37 --> Config Class Initialized
INFO - 2016-01-03 08:31:37 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:37 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:37 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:37 --> URI Class Initialized
INFO - 2016-01-03 08:31:37 --> Router Class Initialized
INFO - 2016-01-03 08:31:37 --> Output Class Initialized
INFO - 2016-01-03 08:31:37 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:37 --> Input Class Initialized
INFO - 2016-01-03 08:31:37 --> Language Class Initialized
INFO - 2016-01-03 08:31:37 --> Loader Class Initialized
INFO - 2016-01-03 08:31:37 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:37 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:37 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:37 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:37 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:37 --> Model Class Initialized
INFO - 2016-01-03 08:31:37 --> Model Class Initialized
INFO - 2016-01-03 08:31:37 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:37 --> Total execution time: 0.1465
INFO - 2016-01-03 08:31:37 --> Config Class Initialized
INFO - 2016-01-03 08:31:37 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:37 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:37 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:37 --> URI Class Initialized
INFO - 2016-01-03 08:31:37 --> Router Class Initialized
INFO - 2016-01-03 08:31:37 --> Output Class Initialized
INFO - 2016-01-03 08:31:37 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:37 --> Input Class Initialized
INFO - 2016-01-03 08:31:37 --> Language Class Initialized
INFO - 2016-01-03 08:31:37 --> Loader Class Initialized
INFO - 2016-01-03 08:31:37 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:37 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:37 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:37 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:37 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:37 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:37 --> Model Class Initialized
INFO - 2016-01-03 08:31:37 --> Model Class Initialized
INFO - 2016-01-03 08:31:37 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:37 --> Total execution time: 0.1184
INFO - 2016-01-03 08:31:38 --> Config Class Initialized
INFO - 2016-01-03 08:31:38 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:38 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:38 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:38 --> URI Class Initialized
INFO - 2016-01-03 08:31:38 --> Router Class Initialized
INFO - 2016-01-03 08:31:38 --> Output Class Initialized
INFO - 2016-01-03 08:31:38 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:38 --> Input Class Initialized
INFO - 2016-01-03 08:31:38 --> Language Class Initialized
INFO - 2016-01-03 08:31:38 --> Loader Class Initialized
INFO - 2016-01-03 08:31:38 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:38 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:38 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:38 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:38 --> Model Class Initialized
INFO - 2016-01-03 08:31:38 --> Model Class Initialized
INFO - 2016-01-03 08:31:38 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:38 --> Total execution time: 0.1508
INFO - 2016-01-03 08:31:39 --> Config Class Initialized
INFO - 2016-01-03 08:31:39 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:39 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:39 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:39 --> URI Class Initialized
INFO - 2016-01-03 08:31:39 --> Router Class Initialized
INFO - 2016-01-03 08:31:39 --> Output Class Initialized
INFO - 2016-01-03 08:31:39 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:39 --> Input Class Initialized
INFO - 2016-01-03 08:31:39 --> Language Class Initialized
INFO - 2016-01-03 08:31:39 --> Loader Class Initialized
INFO - 2016-01-03 08:31:39 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:39 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:39 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:39 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:39 --> Model Class Initialized
INFO - 2016-01-03 08:31:39 --> Model Class Initialized
INFO - 2016-01-03 08:31:39 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:39 --> Total execution time: 0.1665
INFO - 2016-01-03 08:31:40 --> Config Class Initialized
INFO - 2016-01-03 08:31:40 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:40 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:40 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:40 --> URI Class Initialized
INFO - 2016-01-03 08:31:40 --> Router Class Initialized
INFO - 2016-01-03 08:31:40 --> Output Class Initialized
INFO - 2016-01-03 08:31:40 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:40 --> Input Class Initialized
INFO - 2016-01-03 08:31:40 --> Language Class Initialized
INFO - 2016-01-03 08:31:40 --> Loader Class Initialized
INFO - 2016-01-03 08:31:40 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:40 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:40 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:40 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:40 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:40 --> Model Class Initialized
INFO - 2016-01-03 08:31:40 --> Model Class Initialized
INFO - 2016-01-03 08:31:40 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:40 --> Total execution time: 0.1577
INFO - 2016-01-03 08:31:41 --> Config Class Initialized
INFO - 2016-01-03 08:31:41 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:41 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:41 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:41 --> URI Class Initialized
INFO - 2016-01-03 08:31:41 --> Router Class Initialized
INFO - 2016-01-03 08:31:41 --> Output Class Initialized
INFO - 2016-01-03 08:31:41 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:41 --> Input Class Initialized
INFO - 2016-01-03 08:31:41 --> Language Class Initialized
INFO - 2016-01-03 08:31:41 --> Loader Class Initialized
INFO - 2016-01-03 08:31:41 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:41 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:41 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:41 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:41 --> Model Class Initialized
INFO - 2016-01-03 08:31:41 --> Model Class Initialized
INFO - 2016-01-03 08:31:41 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:41 --> Total execution time: 0.1452
INFO - 2016-01-03 08:31:42 --> Config Class Initialized
INFO - 2016-01-03 08:31:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:42 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:42 --> URI Class Initialized
INFO - 2016-01-03 08:31:42 --> Router Class Initialized
INFO - 2016-01-03 08:31:42 --> Output Class Initialized
INFO - 2016-01-03 08:31:42 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:42 --> Input Class Initialized
INFO - 2016-01-03 08:31:42 --> Language Class Initialized
INFO - 2016-01-03 08:31:42 --> Loader Class Initialized
INFO - 2016-01-03 08:31:42 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:42 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:42 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:42 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:42 --> Model Class Initialized
INFO - 2016-01-03 08:31:42 --> Model Class Initialized
INFO - 2016-01-03 08:31:42 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:42 --> Total execution time: 0.1276
INFO - 2016-01-03 08:31:42 --> Config Class Initialized
INFO - 2016-01-03 08:31:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:42 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:42 --> URI Class Initialized
INFO - 2016-01-03 08:31:42 --> Router Class Initialized
INFO - 2016-01-03 08:31:42 --> Output Class Initialized
INFO - 2016-01-03 08:31:42 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:42 --> Input Class Initialized
INFO - 2016-01-03 08:31:42 --> Language Class Initialized
INFO - 2016-01-03 08:31:43 --> Loader Class Initialized
INFO - 2016-01-03 08:31:43 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:43 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:43 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:43 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:43 --> Model Class Initialized
INFO - 2016-01-03 08:31:43 --> Model Class Initialized
INFO - 2016-01-03 08:31:43 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:43 --> Total execution time: 0.1260
INFO - 2016-01-03 08:31:44 --> Config Class Initialized
INFO - 2016-01-03 08:31:44 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:45 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:45 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:45 --> URI Class Initialized
INFO - 2016-01-03 08:31:45 --> Router Class Initialized
INFO - 2016-01-03 08:31:45 --> Output Class Initialized
INFO - 2016-01-03 08:31:45 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:45 --> Input Class Initialized
INFO - 2016-01-03 08:31:45 --> Language Class Initialized
INFO - 2016-01-03 08:31:45 --> Loader Class Initialized
INFO - 2016-01-03 08:31:45 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:45 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:45 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:45 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:45 --> Model Class Initialized
INFO - 2016-01-03 08:31:45 --> Model Class Initialized
INFO - 2016-01-03 08:31:45 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:45 --> Total execution time: 0.1537
INFO - 2016-01-03 08:31:45 --> Config Class Initialized
INFO - 2016-01-03 08:31:45 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:31:45 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:31:45 --> Utf8 Class Initialized
INFO - 2016-01-03 08:31:45 --> URI Class Initialized
INFO - 2016-01-03 08:31:45 --> Router Class Initialized
INFO - 2016-01-03 08:31:45 --> Output Class Initialized
INFO - 2016-01-03 08:31:45 --> Security Class Initialized
DEBUG - 2016-01-03 08:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:31:45 --> Input Class Initialized
INFO - 2016-01-03 08:31:45 --> Language Class Initialized
INFO - 2016-01-03 08:31:45 --> Loader Class Initialized
INFO - 2016-01-03 08:31:45 --> Helper loaded: url_helper
INFO - 2016-01-03 08:31:45 --> Database Driver Class Initialized
INFO - 2016-01-03 08:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:31:45 --> Controller Class Initialized
DEBUG - 2016-01-03 08:31:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:31:45 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:31:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:31:45 --> Model Class Initialized
INFO - 2016-01-03 08:31:45 --> Model Class Initialized
INFO - 2016-01-03 08:31:45 --> Final output sent to browser
DEBUG - 2016-01-03 08:31:45 --> Total execution time: 0.1487
INFO - 2016-01-03 08:34:50 --> Config Class Initialized
INFO - 2016-01-03 08:34:50 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:34:50 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:34:50 --> Utf8 Class Initialized
INFO - 2016-01-03 08:34:50 --> URI Class Initialized
DEBUG - 2016-01-03 08:34:50 --> No URI present. Default controller set.
INFO - 2016-01-03 08:34:50 --> Router Class Initialized
INFO - 2016-01-03 08:34:50 --> Output Class Initialized
INFO - 2016-01-03 08:34:50 --> Security Class Initialized
DEBUG - 2016-01-03 08:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:34:50 --> Input Class Initialized
INFO - 2016-01-03 08:34:50 --> Language Class Initialized
INFO - 2016-01-03 08:34:50 --> Loader Class Initialized
INFO - 2016-01-03 08:34:50 --> Helper loaded: url_helper
INFO - 2016-01-03 08:34:50 --> Database Driver Class Initialized
INFO - 2016-01-03 08:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:34:50 --> Controller Class Initialized
INFO - 2016-01-03 08:34:50 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 08:34:50 --> Final output sent to browser
DEBUG - 2016-01-03 08:34:50 --> Total execution time: 0.4336
INFO - 2016-01-03 08:34:59 --> Config Class Initialized
INFO - 2016-01-03 08:34:59 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:34:59 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:34:59 --> Utf8 Class Initialized
INFO - 2016-01-03 08:34:59 --> URI Class Initialized
INFO - 2016-01-03 08:34:59 --> Router Class Initialized
INFO - 2016-01-03 08:34:59 --> Output Class Initialized
INFO - 2016-01-03 08:34:59 --> Security Class Initialized
DEBUG - 2016-01-03 08:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:34:59 --> Input Class Initialized
INFO - 2016-01-03 08:34:59 --> Language Class Initialized
INFO - 2016-01-03 08:34:59 --> Loader Class Initialized
INFO - 2016-01-03 08:34:59 --> Helper loaded: url_helper
INFO - 2016-01-03 08:34:59 --> Database Driver Class Initialized
INFO - 2016-01-03 08:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:34:59 --> Controller Class Initialized
INFO - 2016-01-03 08:34:59 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 08:34:59 --> Final output sent to browser
DEBUG - 2016-01-03 08:34:59 --> Total execution time: 0.0987
INFO - 2016-01-03 08:34:59 --> Config Class Initialized
INFO - 2016-01-03 08:34:59 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:34:59 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:34:59 --> Utf8 Class Initialized
INFO - 2016-01-03 08:34:59 --> URI Class Initialized
INFO - 2016-01-03 08:34:59 --> Router Class Initialized
INFO - 2016-01-03 08:34:59 --> Output Class Initialized
INFO - 2016-01-03 08:34:59 --> Security Class Initialized
DEBUG - 2016-01-03 08:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:34:59 --> Input Class Initialized
INFO - 2016-01-03 08:34:59 --> Language Class Initialized
INFO - 2016-01-03 08:34:59 --> Loader Class Initialized
INFO - 2016-01-03 08:34:59 --> Helper loaded: url_helper
INFO - 2016-01-03 08:34:59 --> Database Driver Class Initialized
INFO - 2016-01-03 08:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:34:59 --> Controller Class Initialized
DEBUG - 2016-01-03 08:34:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:34:59 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:34:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:34:59 --> Model Class Initialized
INFO - 2016-01-03 08:34:59 --> Model Class Initialized
INFO - 2016-01-03 08:34:59 --> Final output sent to browser
DEBUG - 2016-01-03 08:34:59 --> Total execution time: 0.1156
INFO - 2016-01-03 08:35:36 --> Config Class Initialized
INFO - 2016-01-03 08:35:36 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:35:36 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:35:36 --> Utf8 Class Initialized
INFO - 2016-01-03 08:35:36 --> URI Class Initialized
DEBUG - 2016-01-03 08:35:36 --> No URI present. Default controller set.
INFO - 2016-01-03 08:35:36 --> Router Class Initialized
INFO - 2016-01-03 08:35:36 --> Output Class Initialized
INFO - 2016-01-03 08:35:36 --> Security Class Initialized
DEBUG - 2016-01-03 08:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:35:36 --> Input Class Initialized
INFO - 2016-01-03 08:35:36 --> Language Class Initialized
INFO - 2016-01-03 08:35:36 --> Loader Class Initialized
INFO - 2016-01-03 08:35:36 --> Helper loaded: url_helper
INFO - 2016-01-03 08:35:36 --> Database Driver Class Initialized
INFO - 2016-01-03 08:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:35:36 --> Controller Class Initialized
INFO - 2016-01-03 08:35:36 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 08:35:36 --> Final output sent to browser
DEBUG - 2016-01-03 08:35:36 --> Total execution time: 0.3185
INFO - 2016-01-03 08:35:49 --> Config Class Initialized
INFO - 2016-01-03 08:35:49 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:35:49 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:35:49 --> Utf8 Class Initialized
INFO - 2016-01-03 08:35:49 --> URI Class Initialized
INFO - 2016-01-03 08:35:49 --> Router Class Initialized
INFO - 2016-01-03 08:35:49 --> Output Class Initialized
INFO - 2016-01-03 08:35:49 --> Security Class Initialized
DEBUG - 2016-01-03 08:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:35:49 --> Input Class Initialized
INFO - 2016-01-03 08:35:49 --> Language Class Initialized
INFO - 2016-01-03 08:35:49 --> Loader Class Initialized
INFO - 2016-01-03 08:35:49 --> Helper loaded: url_helper
INFO - 2016-01-03 08:35:49 --> Database Driver Class Initialized
INFO - 2016-01-03 08:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:35:49 --> Controller Class Initialized
INFO - 2016-01-03 08:35:49 --> Helper loaded: form_helper
INFO - 2016-01-03 08:35:49 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 08:35:49 --> Final output sent to browser
DEBUG - 2016-01-03 08:35:49 --> Total execution time: 0.1490
INFO - 2016-01-03 08:35:54 --> Config Class Initialized
INFO - 2016-01-03 08:35:54 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:35:54 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:35:54 --> Utf8 Class Initialized
INFO - 2016-01-03 08:35:54 --> URI Class Initialized
INFO - 2016-01-03 08:35:54 --> Router Class Initialized
INFO - 2016-01-03 08:35:54 --> Output Class Initialized
INFO - 2016-01-03 08:35:54 --> Security Class Initialized
DEBUG - 2016-01-03 08:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:35:54 --> Input Class Initialized
INFO - 2016-01-03 08:35:54 --> Language Class Initialized
INFO - 2016-01-03 08:35:54 --> Loader Class Initialized
INFO - 2016-01-03 08:35:54 --> Helper loaded: url_helper
INFO - 2016-01-03 08:35:54 --> Database Driver Class Initialized
INFO - 2016-01-03 08:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:35:54 --> Controller Class Initialized
INFO - 2016-01-03 08:35:54 --> Model Class Initialized
INFO - 2016-01-03 08:35:54 --> Model Class Initialized
INFO - 2016-01-03 08:35:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:35:54 --> Final output sent to browser
DEBUG - 2016-01-03 08:35:54 --> Total execution time: 0.1870
INFO - 2016-01-03 08:35:54 --> Config Class Initialized
INFO - 2016-01-03 08:35:54 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:35:54 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:35:54 --> Utf8 Class Initialized
INFO - 2016-01-03 08:35:54 --> URI Class Initialized
INFO - 2016-01-03 08:35:54 --> Router Class Initialized
INFO - 2016-01-03 08:35:54 --> Output Class Initialized
INFO - 2016-01-03 08:35:54 --> Security Class Initialized
DEBUG - 2016-01-03 08:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:35:54 --> Input Class Initialized
INFO - 2016-01-03 08:35:54 --> Language Class Initialized
INFO - 2016-01-03 08:35:54 --> Loader Class Initialized
INFO - 2016-01-03 08:35:54 --> Helper loaded: url_helper
INFO - 2016-01-03 08:35:54 --> Database Driver Class Initialized
INFO - 2016-01-03 08:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:35:54 --> Controller Class Initialized
INFO - 2016-01-03 08:35:54 --> Model Class Initialized
INFO - 2016-01-03 08:35:54 --> Model Class Initialized
INFO - 2016-01-03 08:35:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 08:35:54 --> Final output sent to browser
DEBUG - 2016-01-03 08:35:54 --> Total execution time: 0.1224
INFO - 2016-01-03 08:35:55 --> Config Class Initialized
INFO - 2016-01-03 08:35:55 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:35:55 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:35:55 --> Utf8 Class Initialized
INFO - 2016-01-03 08:35:55 --> URI Class Initialized
INFO - 2016-01-03 08:35:55 --> Router Class Initialized
INFO - 2016-01-03 08:35:55 --> Output Class Initialized
INFO - 2016-01-03 08:35:55 --> Security Class Initialized
DEBUG - 2016-01-03 08:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:35:55 --> Input Class Initialized
INFO - 2016-01-03 08:35:55 --> Language Class Initialized
INFO - 2016-01-03 08:35:55 --> Loader Class Initialized
INFO - 2016-01-03 08:35:55 --> Helper loaded: url_helper
INFO - 2016-01-03 08:35:55 --> Database Driver Class Initialized
INFO - 2016-01-03 08:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:35:55 --> Controller Class Initialized
DEBUG - 2016-01-03 08:35:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:35:55 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:35:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:35:55 --> Model Class Initialized
INFO - 2016-01-03 08:35:55 --> Model Class Initialized
INFO - 2016-01-03 08:35:55 --> Final output sent to browser
DEBUG - 2016-01-03 08:35:55 --> Total execution time: 0.1524
INFO - 2016-01-03 08:36:02 --> Config Class Initialized
INFO - 2016-01-03 08:36:02 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:36:02 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:36:02 --> Utf8 Class Initialized
INFO - 2016-01-03 08:36:02 --> URI Class Initialized
INFO - 2016-01-03 08:36:02 --> Router Class Initialized
INFO - 2016-01-03 08:36:02 --> Output Class Initialized
INFO - 2016-01-03 08:36:02 --> Security Class Initialized
DEBUG - 2016-01-03 08:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:36:02 --> Input Class Initialized
INFO - 2016-01-03 08:36:02 --> Language Class Initialized
INFO - 2016-01-03 08:36:02 --> Loader Class Initialized
INFO - 2016-01-03 08:36:02 --> Helper loaded: url_helper
INFO - 2016-01-03 08:36:02 --> Database Driver Class Initialized
INFO - 2016-01-03 08:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:36:02 --> Controller Class Initialized
INFO - 2016-01-03 08:36:02 --> Model Class Initialized
INFO - 2016-01-03 08:36:02 --> Model Class Initialized
INFO - 2016-01-03 08:36:02 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:36:02 --> Final output sent to browser
DEBUG - 2016-01-03 08:36:02 --> Total execution time: 0.0996
INFO - 2016-01-03 08:36:02 --> Config Class Initialized
INFO - 2016-01-03 08:36:02 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:36:02 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:36:02 --> Utf8 Class Initialized
INFO - 2016-01-03 08:36:02 --> URI Class Initialized
INFO - 2016-01-03 08:36:02 --> Router Class Initialized
INFO - 2016-01-03 08:36:02 --> Output Class Initialized
INFO - 2016-01-03 08:36:02 --> Security Class Initialized
DEBUG - 2016-01-03 08:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:36:02 --> Input Class Initialized
INFO - 2016-01-03 08:36:02 --> Language Class Initialized
INFO - 2016-01-03 08:36:02 --> Loader Class Initialized
INFO - 2016-01-03 08:36:02 --> Helper loaded: url_helper
INFO - 2016-01-03 08:36:02 --> Database Driver Class Initialized
INFO - 2016-01-03 08:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:36:02 --> Controller Class Initialized
INFO - 2016-01-03 08:36:02 --> Model Class Initialized
INFO - 2016-01-03 08:36:02 --> Model Class Initialized
INFO - 2016-01-03 08:36:02 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:36:02 --> Final output sent to browser
DEBUG - 2016-01-03 08:36:02 --> Total execution time: 0.1139
INFO - 2016-01-03 08:36:02 --> Config Class Initialized
INFO - 2016-01-03 08:36:02 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:36:02 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:36:02 --> Utf8 Class Initialized
INFO - 2016-01-03 08:36:02 --> URI Class Initialized
INFO - 2016-01-03 08:36:02 --> Router Class Initialized
INFO - 2016-01-03 08:36:02 --> Output Class Initialized
INFO - 2016-01-03 08:36:02 --> Security Class Initialized
DEBUG - 2016-01-03 08:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:36:02 --> Input Class Initialized
INFO - 2016-01-03 08:36:02 --> Language Class Initialized
INFO - 2016-01-03 08:36:02 --> Loader Class Initialized
INFO - 2016-01-03 08:36:02 --> Helper loaded: url_helper
INFO - 2016-01-03 08:36:02 --> Database Driver Class Initialized
INFO - 2016-01-03 08:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:36:02 --> Controller Class Initialized
DEBUG - 2016-01-03 08:36:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:36:02 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:36:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:36:02 --> Model Class Initialized
INFO - 2016-01-03 08:36:02 --> Model Class Initialized
INFO - 2016-01-03 08:36:02 --> Final output sent to browser
DEBUG - 2016-01-03 08:36:02 --> Total execution time: 0.1369
INFO - 2016-01-03 08:36:07 --> Config Class Initialized
INFO - 2016-01-03 08:36:07 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:36:07 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:36:07 --> Utf8 Class Initialized
INFO - 2016-01-03 08:36:07 --> URI Class Initialized
INFO - 2016-01-03 08:36:07 --> Router Class Initialized
INFO - 2016-01-03 08:36:07 --> Output Class Initialized
INFO - 2016-01-03 08:36:07 --> Security Class Initialized
DEBUG - 2016-01-03 08:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:36:07 --> Input Class Initialized
INFO - 2016-01-03 08:36:07 --> Language Class Initialized
INFO - 2016-01-03 08:36:07 --> Loader Class Initialized
INFO - 2016-01-03 08:36:07 --> Helper loaded: url_helper
INFO - 2016-01-03 08:36:07 --> Database Driver Class Initialized
INFO - 2016-01-03 08:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:36:08 --> Controller Class Initialized
DEBUG - 2016-01-03 08:36:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:36:08 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:36:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:36:08 --> Model Class Initialized
INFO - 2016-01-03 08:36:08 --> Model Class Initialized
INFO - 2016-01-03 08:36:08 --> Final output sent to browser
DEBUG - 2016-01-03 08:36:08 --> Total execution time: 0.1840
INFO - 2016-01-03 08:36:28 --> Config Class Initialized
INFO - 2016-01-03 08:36:28 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:36:28 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:36:28 --> Utf8 Class Initialized
INFO - 2016-01-03 08:36:28 --> URI Class Initialized
INFO - 2016-01-03 08:36:28 --> Router Class Initialized
INFO - 2016-01-03 08:36:28 --> Output Class Initialized
INFO - 2016-01-03 08:36:28 --> Security Class Initialized
DEBUG - 2016-01-03 08:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:36:28 --> Input Class Initialized
INFO - 2016-01-03 08:36:28 --> Language Class Initialized
INFO - 2016-01-03 08:36:28 --> Loader Class Initialized
INFO - 2016-01-03 08:36:28 --> Helper loaded: url_helper
INFO - 2016-01-03 08:36:28 --> Database Driver Class Initialized
INFO - 2016-01-03 08:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:36:28 --> Controller Class Initialized
INFO - 2016-01-03 08:36:28 --> Model Class Initialized
INFO - 2016-01-03 08:36:28 --> Model Class Initialized
INFO - 2016-01-03 08:36:28 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:36:28 --> Final output sent to browser
DEBUG - 2016-01-03 08:36:28 --> Total execution time: 0.1241
INFO - 2016-01-03 08:36:29 --> Config Class Initialized
INFO - 2016-01-03 08:36:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:36:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:36:29 --> Utf8 Class Initialized
INFO - 2016-01-03 08:36:29 --> URI Class Initialized
INFO - 2016-01-03 08:36:29 --> Router Class Initialized
INFO - 2016-01-03 08:36:29 --> Output Class Initialized
INFO - 2016-01-03 08:36:29 --> Security Class Initialized
DEBUG - 2016-01-03 08:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:36:29 --> Input Class Initialized
INFO - 2016-01-03 08:36:29 --> Language Class Initialized
INFO - 2016-01-03 08:36:29 --> Loader Class Initialized
INFO - 2016-01-03 08:36:29 --> Helper loaded: url_helper
INFO - 2016-01-03 08:36:29 --> Database Driver Class Initialized
INFO - 2016-01-03 08:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:36:29 --> Controller Class Initialized
INFO - 2016-01-03 08:36:29 --> Model Class Initialized
INFO - 2016-01-03 08:36:29 --> Model Class Initialized
INFO - 2016-01-03 08:36:29 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:36:29 --> Final output sent to browser
DEBUG - 2016-01-03 08:36:29 --> Total execution time: 0.1231
INFO - 2016-01-03 08:36:29 --> Config Class Initialized
INFO - 2016-01-03 08:36:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:36:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:36:29 --> Config Class Initialized
INFO - 2016-01-03 08:36:29 --> Utf8 Class Initialized
INFO - 2016-01-03 08:36:29 --> Hooks Class Initialized
INFO - 2016-01-03 08:36:29 --> URI Class Initialized
DEBUG - 2016-01-03 08:36:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:36:29 --> Router Class Initialized
INFO - 2016-01-03 08:36:29 --> Utf8 Class Initialized
INFO - 2016-01-03 08:36:29 --> URI Class Initialized
INFO - 2016-01-03 08:36:29 --> Output Class Initialized
INFO - 2016-01-03 08:36:29 --> Router Class Initialized
INFO - 2016-01-03 08:36:29 --> Security Class Initialized
INFO - 2016-01-03 08:36:29 --> Output Class Initialized
DEBUG - 2016-01-03 08:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:36:29 --> Security Class Initialized
INFO - 2016-01-03 08:36:29 --> Input Class Initialized
DEBUG - 2016-01-03 08:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:36:29 --> Language Class Initialized
INFO - 2016-01-03 08:36:29 --> Input Class Initialized
INFO - 2016-01-03 08:36:29 --> Language Class Initialized
INFO - 2016-01-03 08:36:29 --> Loader Class Initialized
INFO - 2016-01-03 08:36:29 --> Helper loaded: url_helper
INFO - 2016-01-03 08:36:29 --> Loader Class Initialized
INFO - 2016-01-03 08:36:29 --> Helper loaded: url_helper
INFO - 2016-01-03 08:36:29 --> Database Driver Class Initialized
INFO - 2016-01-03 08:36:29 --> Database Driver Class Initialized
INFO - 2016-01-03 08:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:36:29 --> Controller Class Initialized
INFO - 2016-01-03 08:36:29 --> Model Class Initialized
INFO - 2016-01-03 08:36:29 --> Model Class Initialized
INFO - 2016-01-03 08:36:29 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:36:29 --> Final output sent to browser
DEBUG - 2016-01-03 08:36:29 --> Total execution time: 0.1879
INFO - 2016-01-03 08:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:36:29 --> Controller Class Initialized
DEBUG - 2016-01-03 08:36:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:36:29 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:36:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:36:29 --> Model Class Initialized
INFO - 2016-01-03 08:36:29 --> Model Class Initialized
INFO - 2016-01-03 08:36:29 --> Final output sent to browser
DEBUG - 2016-01-03 08:36:29 --> Total execution time: 0.2096
INFO - 2016-01-03 08:37:23 --> Config Class Initialized
INFO - 2016-01-03 08:37:23 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:37:23 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:37:23 --> Utf8 Class Initialized
INFO - 2016-01-03 08:37:23 --> URI Class Initialized
INFO - 2016-01-03 08:37:23 --> Router Class Initialized
INFO - 2016-01-03 08:37:23 --> Output Class Initialized
INFO - 2016-01-03 08:37:23 --> Security Class Initialized
DEBUG - 2016-01-03 08:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:37:23 --> Input Class Initialized
INFO - 2016-01-03 08:37:23 --> Language Class Initialized
INFO - 2016-01-03 08:37:23 --> Loader Class Initialized
INFO - 2016-01-03 08:37:23 --> Helper loaded: url_helper
INFO - 2016-01-03 08:37:23 --> Database Driver Class Initialized
INFO - 2016-01-03 08:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:37:23 --> Controller Class Initialized
DEBUG - 2016-01-03 08:37:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:37:23 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:37:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:37:23 --> Model Class Initialized
INFO - 2016-01-03 08:37:23 --> Model Class Initialized
INFO - 2016-01-03 08:37:23 --> Final output sent to browser
DEBUG - 2016-01-03 08:37:23 --> Total execution time: 0.4257
INFO - 2016-01-03 08:40:43 --> Config Class Initialized
INFO - 2016-01-03 08:40:43 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:40:43 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:40:43 --> Utf8 Class Initialized
INFO - 2016-01-03 08:40:43 --> URI Class Initialized
INFO - 2016-01-03 08:40:43 --> Router Class Initialized
INFO - 2016-01-03 08:40:43 --> Output Class Initialized
INFO - 2016-01-03 08:40:43 --> Security Class Initialized
DEBUG - 2016-01-03 08:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:40:43 --> Input Class Initialized
INFO - 2016-01-03 08:40:43 --> Language Class Initialized
INFO - 2016-01-03 08:40:43 --> Loader Class Initialized
INFO - 2016-01-03 08:40:43 --> Helper loaded: url_helper
INFO - 2016-01-03 08:40:43 --> Database Driver Class Initialized
INFO - 2016-01-03 08:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:40:43 --> Controller Class Initialized
INFO - 2016-01-03 08:40:43 --> Model Class Initialized
INFO - 2016-01-03 08:40:43 --> Model Class Initialized
INFO - 2016-01-03 08:40:43 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:40:43 --> Final output sent to browser
DEBUG - 2016-01-03 08:40:43 --> Total execution time: 0.3812
INFO - 2016-01-03 08:40:43 --> Config Class Initialized
INFO - 2016-01-03 08:40:43 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:40:44 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:40:44 --> Utf8 Class Initialized
INFO - 2016-01-03 08:40:44 --> URI Class Initialized
INFO - 2016-01-03 08:40:44 --> Router Class Initialized
INFO - 2016-01-03 08:40:44 --> Output Class Initialized
INFO - 2016-01-03 08:40:44 --> Security Class Initialized
DEBUG - 2016-01-03 08:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:40:44 --> Input Class Initialized
INFO - 2016-01-03 08:40:44 --> Language Class Initialized
INFO - 2016-01-03 08:40:44 --> Loader Class Initialized
INFO - 2016-01-03 08:40:44 --> Helper loaded: url_helper
INFO - 2016-01-03 08:40:44 --> Database Driver Class Initialized
INFO - 2016-01-03 08:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:40:44 --> Controller Class Initialized
INFO - 2016-01-03 08:40:44 --> Model Class Initialized
INFO - 2016-01-03 08:40:44 --> Model Class Initialized
INFO - 2016-01-03 08:40:44 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:40:44 --> Final output sent to browser
DEBUG - 2016-01-03 08:40:44 --> Total execution time: 0.0945
INFO - 2016-01-03 08:40:44 --> Config Class Initialized
INFO - 2016-01-03 08:40:44 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:40:44 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:40:44 --> Utf8 Class Initialized
INFO - 2016-01-03 08:40:44 --> URI Class Initialized
INFO - 2016-01-03 08:40:44 --> Router Class Initialized
INFO - 2016-01-03 08:40:44 --> Output Class Initialized
INFO - 2016-01-03 08:40:44 --> Security Class Initialized
DEBUG - 2016-01-03 08:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:40:44 --> Input Class Initialized
INFO - 2016-01-03 08:40:44 --> Language Class Initialized
INFO - 2016-01-03 08:40:44 --> Loader Class Initialized
INFO - 2016-01-03 08:40:44 --> Helper loaded: url_helper
INFO - 2016-01-03 08:40:44 --> Database Driver Class Initialized
INFO - 2016-01-03 08:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:40:44 --> Controller Class Initialized
DEBUG - 2016-01-03 08:40:44 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:40:44 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:40:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:40:44 --> Model Class Initialized
INFO - 2016-01-03 08:40:44 --> Model Class Initialized
INFO - 2016-01-03 08:40:44 --> Final output sent to browser
DEBUG - 2016-01-03 08:40:44 --> Total execution time: 0.1191
INFO - 2016-01-03 08:41:19 --> Config Class Initialized
INFO - 2016-01-03 08:41:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:19 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:19 --> URI Class Initialized
INFO - 2016-01-03 08:41:19 --> Router Class Initialized
INFO - 2016-01-03 08:41:19 --> Output Class Initialized
INFO - 2016-01-03 08:41:19 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:19 --> Input Class Initialized
INFO - 2016-01-03 08:41:19 --> Language Class Initialized
INFO - 2016-01-03 08:41:19 --> Loader Class Initialized
INFO - 2016-01-03 08:41:19 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:19 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:19 --> Controller Class Initialized
INFO - 2016-01-03 08:41:19 --> Model Class Initialized
INFO - 2016-01-03 08:41:19 --> Model Class Initialized
INFO - 2016-01-03 08:41:19 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:41:19 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:19 --> Total execution time: 0.1097
INFO - 2016-01-03 08:41:19 --> Config Class Initialized
INFO - 2016-01-03 08:41:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:19 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:19 --> URI Class Initialized
INFO - 2016-01-03 08:41:19 --> Router Class Initialized
INFO - 2016-01-03 08:41:19 --> Output Class Initialized
INFO - 2016-01-03 08:41:19 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:19 --> Input Class Initialized
INFO - 2016-01-03 08:41:19 --> Language Class Initialized
INFO - 2016-01-03 08:41:19 --> Loader Class Initialized
INFO - 2016-01-03 08:41:19 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:19 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:19 --> Controller Class Initialized
INFO - 2016-01-03 08:41:19 --> Model Class Initialized
INFO - 2016-01-03 08:41:19 --> Model Class Initialized
INFO - 2016-01-03 08:41:19 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:41:19 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:19 --> Total execution time: 0.0966
INFO - 2016-01-03 08:41:19 --> Config Class Initialized
INFO - 2016-01-03 08:41:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:19 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:19 --> URI Class Initialized
INFO - 2016-01-03 08:41:19 --> Router Class Initialized
INFO - 2016-01-03 08:41:19 --> Output Class Initialized
INFO - 2016-01-03 08:41:19 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:19 --> Input Class Initialized
INFO - 2016-01-03 08:41:19 --> Language Class Initialized
INFO - 2016-01-03 08:41:19 --> Loader Class Initialized
INFO - 2016-01-03 08:41:19 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:19 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:19 --> Controller Class Initialized
DEBUG - 2016-01-03 08:41:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:41:19 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:41:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:41:20 --> Model Class Initialized
INFO - 2016-01-03 08:41:20 --> Model Class Initialized
INFO - 2016-01-03 08:41:20 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:20 --> Total execution time: 0.1125
INFO - 2016-01-03 08:41:22 --> Config Class Initialized
INFO - 2016-01-03 08:41:22 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:22 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:22 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:22 --> URI Class Initialized
INFO - 2016-01-03 08:41:22 --> Router Class Initialized
INFO - 2016-01-03 08:41:22 --> Output Class Initialized
INFO - 2016-01-03 08:41:22 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:22 --> Input Class Initialized
INFO - 2016-01-03 08:41:22 --> Language Class Initialized
INFO - 2016-01-03 08:41:22 --> Loader Class Initialized
INFO - 2016-01-03 08:41:22 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:22 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:22 --> Controller Class Initialized
INFO - 2016-01-03 08:41:22 --> Model Class Initialized
INFO - 2016-01-03 08:41:22 --> Model Class Initialized
INFO - 2016-01-03 08:41:22 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:41:22 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:22 --> Total execution time: 0.1335
INFO - 2016-01-03 08:41:23 --> Config Class Initialized
INFO - 2016-01-03 08:41:23 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:23 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:23 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:23 --> URI Class Initialized
INFO - 2016-01-03 08:41:23 --> Router Class Initialized
INFO - 2016-01-03 08:41:23 --> Output Class Initialized
INFO - 2016-01-03 08:41:23 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:23 --> Input Class Initialized
INFO - 2016-01-03 08:41:23 --> Language Class Initialized
INFO - 2016-01-03 08:41:23 --> Loader Class Initialized
INFO - 2016-01-03 08:41:23 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:23 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:23 --> Controller Class Initialized
INFO - 2016-01-03 08:41:23 --> Model Class Initialized
INFO - 2016-01-03 08:41:23 --> Model Class Initialized
INFO - 2016-01-03 08:41:23 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:41:23 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:23 --> Total execution time: 0.0989
INFO - 2016-01-03 08:41:23 --> Config Class Initialized
INFO - 2016-01-03 08:41:23 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:23 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:23 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:23 --> URI Class Initialized
INFO - 2016-01-03 08:41:23 --> Router Class Initialized
INFO - 2016-01-03 08:41:23 --> Output Class Initialized
INFO - 2016-01-03 08:41:23 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:23 --> Input Class Initialized
INFO - 2016-01-03 08:41:23 --> Language Class Initialized
INFO - 2016-01-03 08:41:23 --> Loader Class Initialized
INFO - 2016-01-03 08:41:23 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:23 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:23 --> Controller Class Initialized
DEBUG - 2016-01-03 08:41:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:41:23 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:41:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:41:23 --> Model Class Initialized
INFO - 2016-01-03 08:41:23 --> Model Class Initialized
INFO - 2016-01-03 08:41:23 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:23 --> Total execution time: 0.1194
INFO - 2016-01-03 08:41:36 --> Config Class Initialized
INFO - 2016-01-03 08:41:36 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:36 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:36 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:36 --> URI Class Initialized
INFO - 2016-01-03 08:41:36 --> Router Class Initialized
INFO - 2016-01-03 08:41:36 --> Output Class Initialized
INFO - 2016-01-03 08:41:36 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:36 --> Input Class Initialized
INFO - 2016-01-03 08:41:36 --> Language Class Initialized
INFO - 2016-01-03 08:41:36 --> Loader Class Initialized
INFO - 2016-01-03 08:41:36 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:36 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:36 --> Controller Class Initialized
DEBUG - 2016-01-03 08:41:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:41:36 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:41:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:41:36 --> Model Class Initialized
INFO - 2016-01-03 08:41:36 --> Model Class Initialized
INFO - 2016-01-03 08:41:36 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:36 --> Total execution time: 0.1564
INFO - 2016-01-03 08:41:42 --> Config Class Initialized
INFO - 2016-01-03 08:41:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:42 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:42 --> URI Class Initialized
INFO - 2016-01-03 08:41:42 --> Router Class Initialized
INFO - 2016-01-03 08:41:42 --> Output Class Initialized
INFO - 2016-01-03 08:41:42 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:42 --> Input Class Initialized
INFO - 2016-01-03 08:41:42 --> Language Class Initialized
INFO - 2016-01-03 08:41:42 --> Loader Class Initialized
INFO - 2016-01-03 08:41:42 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:42 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:42 --> Controller Class Initialized
INFO - 2016-01-03 08:41:42 --> Model Class Initialized
INFO - 2016-01-03 08:41:42 --> Model Class Initialized
INFO - 2016-01-03 08:41:42 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:41:42 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:42 --> Total execution time: 0.1305
INFO - 2016-01-03 08:41:42 --> Config Class Initialized
INFO - 2016-01-03 08:41:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:42 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:42 --> URI Class Initialized
INFO - 2016-01-03 08:41:42 --> Router Class Initialized
INFO - 2016-01-03 08:41:42 --> Output Class Initialized
INFO - 2016-01-03 08:41:42 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:42 --> Input Class Initialized
INFO - 2016-01-03 08:41:42 --> Language Class Initialized
INFO - 2016-01-03 08:41:42 --> Loader Class Initialized
INFO - 2016-01-03 08:41:42 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:42 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:42 --> Controller Class Initialized
INFO - 2016-01-03 08:41:42 --> Model Class Initialized
INFO - 2016-01-03 08:41:42 --> Model Class Initialized
INFO - 2016-01-03 08:41:42 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:41:42 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:42 --> Total execution time: 0.1372
INFO - 2016-01-03 08:41:42 --> Config Class Initialized
INFO - 2016-01-03 08:41:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:42 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:42 --> URI Class Initialized
INFO - 2016-01-03 08:41:42 --> Router Class Initialized
INFO - 2016-01-03 08:41:42 --> Output Class Initialized
INFO - 2016-01-03 08:41:42 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:42 --> Input Class Initialized
INFO - 2016-01-03 08:41:42 --> Language Class Initialized
INFO - 2016-01-03 08:41:42 --> Loader Class Initialized
INFO - 2016-01-03 08:41:42 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:42 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:42 --> Controller Class Initialized
DEBUG - 2016-01-03 08:41:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:41:42 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:41:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:41:42 --> Model Class Initialized
INFO - 2016-01-03 08:41:42 --> Model Class Initialized
INFO - 2016-01-03 08:41:42 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:42 --> Total execution time: 0.1752
INFO - 2016-01-03 08:41:52 --> Config Class Initialized
INFO - 2016-01-03 08:41:52 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:52 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:52 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:52 --> URI Class Initialized
INFO - 2016-01-03 08:41:52 --> Router Class Initialized
INFO - 2016-01-03 08:41:52 --> Output Class Initialized
INFO - 2016-01-03 08:41:52 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:52 --> Input Class Initialized
INFO - 2016-01-03 08:41:52 --> Language Class Initialized
INFO - 2016-01-03 08:41:52 --> Loader Class Initialized
INFO - 2016-01-03 08:41:52 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:52 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:52 --> Controller Class Initialized
INFO - 2016-01-03 08:41:52 --> Model Class Initialized
INFO - 2016-01-03 08:41:52 --> Model Class Initialized
INFO - 2016-01-03 08:41:52 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:41:52 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:52 --> Total execution time: 0.2027
INFO - 2016-01-03 08:41:52 --> Config Class Initialized
INFO - 2016-01-03 08:41:52 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:52 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:52 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:52 --> URI Class Initialized
INFO - 2016-01-03 08:41:52 --> Config Class Initialized
INFO - 2016-01-03 08:41:52 --> Router Class Initialized
INFO - 2016-01-03 08:41:52 --> Hooks Class Initialized
INFO - 2016-01-03 08:41:52 --> Output Class Initialized
INFO - 2016-01-03 08:41:52 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-03 08:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:52 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:52 --> Input Class Initialized
INFO - 2016-01-03 08:41:52 --> Language Class Initialized
INFO - 2016-01-03 08:41:52 --> URI Class Initialized
INFO - 2016-01-03 08:41:52 --> Loader Class Initialized
INFO - 2016-01-03 08:41:52 --> Router Class Initialized
INFO - 2016-01-03 08:41:52 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:53 --> Output Class Initialized
INFO - 2016-01-03 08:41:53 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:53 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:53 --> Input Class Initialized
INFO - 2016-01-03 08:41:53 --> Language Class Initialized
INFO - 2016-01-03 08:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:53 --> Controller Class Initialized
INFO - 2016-01-03 08:41:53 --> Model Class Initialized
INFO - 2016-01-03 08:41:53 --> Loader Class Initialized
INFO - 2016-01-03 08:41:53 --> Model Class Initialized
INFO - 2016-01-03 08:41:53 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:53 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:41:53 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:53 --> Total execution time: 0.3330
INFO - 2016-01-03 08:41:53 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:53 --> Controller Class Initialized
DEBUG - 2016-01-03 08:41:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:41:53 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:41:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:41:53 --> Model Class Initialized
INFO - 2016-01-03 08:41:53 --> Model Class Initialized
INFO - 2016-01-03 08:41:53 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:53 --> Total execution time: 0.2443
INFO - 2016-01-03 08:41:55 --> Config Class Initialized
INFO - 2016-01-03 08:41:55 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:55 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:55 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:55 --> URI Class Initialized
INFO - 2016-01-03 08:41:55 --> Router Class Initialized
INFO - 2016-01-03 08:41:55 --> Output Class Initialized
INFO - 2016-01-03 08:41:55 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:55 --> Input Class Initialized
INFO - 2016-01-03 08:41:55 --> Language Class Initialized
INFO - 2016-01-03 08:41:55 --> Loader Class Initialized
INFO - 2016-01-03 08:41:55 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:55 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:55 --> Controller Class Initialized
INFO - 2016-01-03 08:41:55 --> Model Class Initialized
INFO - 2016-01-03 08:41:55 --> Model Class Initialized
INFO - 2016-01-03 08:41:55 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:41:55 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:55 --> Total execution time: 0.1053
INFO - 2016-01-03 08:41:55 --> Config Class Initialized
INFO - 2016-01-03 08:41:55 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:55 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:55 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:55 --> URI Class Initialized
INFO - 2016-01-03 08:41:55 --> Router Class Initialized
INFO - 2016-01-03 08:41:55 --> Output Class Initialized
INFO - 2016-01-03 08:41:55 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:55 --> Input Class Initialized
INFO - 2016-01-03 08:41:55 --> Language Class Initialized
INFO - 2016-01-03 08:41:55 --> Loader Class Initialized
INFO - 2016-01-03 08:41:55 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:55 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:55 --> Controller Class Initialized
INFO - 2016-01-03 08:41:55 --> Model Class Initialized
INFO - 2016-01-03 08:41:55 --> Model Class Initialized
INFO - 2016-01-03 08:41:55 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 08:41:55 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:55 --> Total execution time: 0.1106
INFO - 2016-01-03 08:41:55 --> Config Class Initialized
INFO - 2016-01-03 08:41:55 --> Hooks Class Initialized
DEBUG - 2016-01-03 08:41:55 --> UTF-8 Support Enabled
INFO - 2016-01-03 08:41:55 --> Utf8 Class Initialized
INFO - 2016-01-03 08:41:55 --> URI Class Initialized
INFO - 2016-01-03 08:41:55 --> Router Class Initialized
INFO - 2016-01-03 08:41:55 --> Output Class Initialized
INFO - 2016-01-03 08:41:55 --> Security Class Initialized
DEBUG - 2016-01-03 08:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 08:41:55 --> Input Class Initialized
INFO - 2016-01-03 08:41:55 --> Language Class Initialized
INFO - 2016-01-03 08:41:55 --> Loader Class Initialized
INFO - 2016-01-03 08:41:55 --> Helper loaded: url_helper
INFO - 2016-01-03 08:41:55 --> Database Driver Class Initialized
INFO - 2016-01-03 08:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 08:41:55 --> Controller Class Initialized
DEBUG - 2016-01-03 08:41:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 08:41:55 --> Helper loaded: inflector_helper
INFO - 2016-01-03 08:41:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 08:41:55 --> Model Class Initialized
INFO - 2016-01-03 08:41:55 --> Model Class Initialized
INFO - 2016-01-03 08:41:55 --> Final output sent to browser
DEBUG - 2016-01-03 08:41:55 --> Total execution time: 0.1386
INFO - 2016-01-03 09:08:32 --> Config Class Initialized
INFO - 2016-01-03 09:08:32 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:08:32 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:08:32 --> Utf8 Class Initialized
INFO - 2016-01-03 09:08:32 --> URI Class Initialized
INFO - 2016-01-03 09:08:32 --> Router Class Initialized
INFO - 2016-01-03 09:08:32 --> Output Class Initialized
INFO - 2016-01-03 09:08:32 --> Security Class Initialized
DEBUG - 2016-01-03 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:08:32 --> Input Class Initialized
INFO - 2016-01-03 09:08:32 --> Language Class Initialized
INFO - 2016-01-03 09:08:32 --> Loader Class Initialized
INFO - 2016-01-03 09:08:32 --> Helper loaded: url_helper
INFO - 2016-01-03 09:08:32 --> Database Driver Class Initialized
INFO - 2016-01-03 09:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:08:32 --> Controller Class Initialized
INFO - 2016-01-03 09:08:32 --> Model Class Initialized
INFO - 2016-01-03 09:08:32 --> Model Class Initialized
INFO - 2016-01-03 09:08:32 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 09:08:32 --> Final output sent to browser
DEBUG - 2016-01-03 09:08:32 --> Total execution time: 0.4960
INFO - 2016-01-03 09:08:33 --> Config Class Initialized
INFO - 2016-01-03 09:08:33 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:08:33 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:08:33 --> Utf8 Class Initialized
INFO - 2016-01-03 09:08:33 --> URI Class Initialized
INFO - 2016-01-03 09:08:33 --> Router Class Initialized
INFO - 2016-01-03 09:08:33 --> Output Class Initialized
INFO - 2016-01-03 09:08:33 --> Security Class Initialized
DEBUG - 2016-01-03 09:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:08:33 --> Input Class Initialized
INFO - 2016-01-03 09:08:33 --> Language Class Initialized
INFO - 2016-01-03 09:08:33 --> Loader Class Initialized
INFO - 2016-01-03 09:08:33 --> Helper loaded: url_helper
INFO - 2016-01-03 09:08:33 --> Database Driver Class Initialized
INFO - 2016-01-03 09:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:08:33 --> Controller Class Initialized
INFO - 2016-01-03 09:08:33 --> Model Class Initialized
INFO - 2016-01-03 09:08:33 --> Model Class Initialized
INFO - 2016-01-03 09:08:33 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 09:08:33 --> Final output sent to browser
DEBUG - 2016-01-03 09:08:33 --> Total execution time: 0.1483
INFO - 2016-01-03 09:08:33 --> Config Class Initialized
INFO - 2016-01-03 09:08:33 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:08:33 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:08:33 --> Utf8 Class Initialized
INFO - 2016-01-03 09:08:33 --> URI Class Initialized
INFO - 2016-01-03 09:08:33 --> Router Class Initialized
INFO - 2016-01-03 09:08:33 --> Output Class Initialized
INFO - 2016-01-03 09:08:33 --> Security Class Initialized
DEBUG - 2016-01-03 09:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:08:33 --> Input Class Initialized
INFO - 2016-01-03 09:08:33 --> Language Class Initialized
INFO - 2016-01-03 09:08:33 --> Loader Class Initialized
INFO - 2016-01-03 09:08:33 --> Helper loaded: url_helper
INFO - 2016-01-03 09:08:33 --> Database Driver Class Initialized
INFO - 2016-01-03 09:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:08:33 --> Controller Class Initialized
DEBUG - 2016-01-03 09:08:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:08:33 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:08:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:08:33 --> Model Class Initialized
INFO - 2016-01-03 09:08:33 --> Model Class Initialized
INFO - 2016-01-03 09:08:33 --> Final output sent to browser
DEBUG - 2016-01-03 09:08:33 --> Total execution time: 0.1836
INFO - 2016-01-03 09:08:50 --> Config Class Initialized
INFO - 2016-01-03 09:08:50 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:08:50 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:08:50 --> Utf8 Class Initialized
INFO - 2016-01-03 09:08:50 --> URI Class Initialized
INFO - 2016-01-03 09:08:50 --> Router Class Initialized
INFO - 2016-01-03 09:08:50 --> Output Class Initialized
INFO - 2016-01-03 09:08:50 --> Security Class Initialized
DEBUG - 2016-01-03 09:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:08:50 --> Input Class Initialized
INFO - 2016-01-03 09:08:50 --> Language Class Initialized
INFO - 2016-01-03 09:08:50 --> Loader Class Initialized
INFO - 2016-01-03 09:08:50 --> Helper loaded: url_helper
INFO - 2016-01-03 09:08:50 --> Database Driver Class Initialized
INFO - 2016-01-03 09:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:08:50 --> Controller Class Initialized
INFO - 2016-01-03 09:08:50 --> Model Class Initialized
INFO - 2016-01-03 09:08:50 --> Model Class Initialized
INFO - 2016-01-03 09:08:50 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 09:08:50 --> Final output sent to browser
DEBUG - 2016-01-03 09:08:50 --> Total execution time: 0.1314
INFO - 2016-01-03 09:08:50 --> Config Class Initialized
INFO - 2016-01-03 09:08:50 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:08:50 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:08:50 --> Utf8 Class Initialized
INFO - 2016-01-03 09:08:50 --> URI Class Initialized
INFO - 2016-01-03 09:08:50 --> Router Class Initialized
INFO - 2016-01-03 09:08:50 --> Output Class Initialized
INFO - 2016-01-03 09:08:50 --> Security Class Initialized
DEBUG - 2016-01-03 09:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:08:50 --> Input Class Initialized
INFO - 2016-01-03 09:08:50 --> Language Class Initialized
INFO - 2016-01-03 09:08:50 --> Loader Class Initialized
INFO - 2016-01-03 09:08:50 --> Helper loaded: url_helper
INFO - 2016-01-03 09:08:50 --> Database Driver Class Initialized
INFO - 2016-01-03 09:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:08:50 --> Controller Class Initialized
INFO - 2016-01-03 09:08:50 --> Model Class Initialized
INFO - 2016-01-03 09:08:50 --> Model Class Initialized
INFO - 2016-01-03 09:08:50 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 09:08:50 --> Final output sent to browser
DEBUG - 2016-01-03 09:08:50 --> Total execution time: 0.1046
INFO - 2016-01-03 09:08:50 --> Config Class Initialized
INFO - 2016-01-03 09:08:50 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:08:50 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:08:50 --> Utf8 Class Initialized
INFO - 2016-01-03 09:08:50 --> URI Class Initialized
INFO - 2016-01-03 09:08:50 --> Router Class Initialized
INFO - 2016-01-03 09:08:50 --> Output Class Initialized
INFO - 2016-01-03 09:08:50 --> Security Class Initialized
DEBUG - 2016-01-03 09:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:08:50 --> Input Class Initialized
INFO - 2016-01-03 09:08:50 --> Language Class Initialized
INFO - 2016-01-03 09:08:50 --> Loader Class Initialized
INFO - 2016-01-03 09:08:50 --> Helper loaded: url_helper
INFO - 2016-01-03 09:08:50 --> Database Driver Class Initialized
INFO - 2016-01-03 09:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:08:50 --> Controller Class Initialized
DEBUG - 2016-01-03 09:08:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:08:50 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:08:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:08:50 --> Model Class Initialized
INFO - 2016-01-03 09:08:50 --> Model Class Initialized
INFO - 2016-01-03 09:08:50 --> Final output sent to browser
DEBUG - 2016-01-03 09:08:50 --> Total execution time: 0.1229
INFO - 2016-01-03 09:26:18 --> Config Class Initialized
INFO - 2016-01-03 09:26:18 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:26:18 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:26:18 --> Utf8 Class Initialized
INFO - 2016-01-03 09:26:18 --> URI Class Initialized
INFO - 2016-01-03 09:26:18 --> Router Class Initialized
INFO - 2016-01-03 09:26:18 --> Output Class Initialized
INFO - 2016-01-03 09:26:18 --> Security Class Initialized
DEBUG - 2016-01-03 09:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:26:18 --> Input Class Initialized
INFO - 2016-01-03 09:26:18 --> Language Class Initialized
INFO - 2016-01-03 09:26:18 --> Loader Class Initialized
INFO - 2016-01-03 09:26:18 --> Helper loaded: url_helper
INFO - 2016-01-03 09:26:18 --> Database Driver Class Initialized
INFO - 2016-01-03 09:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:26:18 --> Controller Class Initialized
DEBUG - 2016-01-03 09:26:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:26:18 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:26:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:26:18 --> Model Class Initialized
INFO - 2016-01-03 09:26:18 --> Model Class Initialized
INFO - 2016-01-03 09:26:18 --> Final output sent to browser
DEBUG - 2016-01-03 09:26:18 --> Total execution time: 0.3942
INFO - 2016-01-03 09:27:20 --> Config Class Initialized
INFO - 2016-01-03 09:27:20 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:27:20 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:27:20 --> Utf8 Class Initialized
INFO - 2016-01-03 09:27:20 --> URI Class Initialized
INFO - 2016-01-03 09:27:20 --> Router Class Initialized
INFO - 2016-01-03 09:27:20 --> Output Class Initialized
INFO - 2016-01-03 09:27:20 --> Security Class Initialized
DEBUG - 2016-01-03 09:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:27:20 --> Input Class Initialized
INFO - 2016-01-03 09:27:20 --> Language Class Initialized
INFO - 2016-01-03 09:27:21 --> Loader Class Initialized
INFO - 2016-01-03 09:27:21 --> Helper loaded: url_helper
INFO - 2016-01-03 09:27:21 --> Database Driver Class Initialized
INFO - 2016-01-03 09:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:27:21 --> Controller Class Initialized
DEBUG - 2016-01-03 09:27:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:27:21 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:27:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:27:21 --> Model Class Initialized
INFO - 2016-01-03 09:27:21 --> Model Class Initialized
INFO - 2016-01-03 09:27:21 --> Final output sent to browser
DEBUG - 2016-01-03 09:27:21 --> Total execution time: 0.4708
INFO - 2016-01-03 09:29:41 --> Config Class Initialized
INFO - 2016-01-03 09:29:41 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:29:41 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:29:41 --> Utf8 Class Initialized
INFO - 2016-01-03 09:29:41 --> URI Class Initialized
INFO - 2016-01-03 09:29:41 --> Router Class Initialized
INFO - 2016-01-03 09:29:41 --> Output Class Initialized
INFO - 2016-01-03 09:29:41 --> Security Class Initialized
DEBUG - 2016-01-03 09:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:29:41 --> Input Class Initialized
INFO - 2016-01-03 09:29:41 --> Language Class Initialized
INFO - 2016-01-03 09:29:41 --> Loader Class Initialized
INFO - 2016-01-03 09:29:41 --> Helper loaded: url_helper
INFO - 2016-01-03 09:29:41 --> Database Driver Class Initialized
INFO - 2016-01-03 09:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:29:41 --> Controller Class Initialized
INFO - 2016-01-03 09:29:41 --> Config Class Initialized
INFO - 2016-01-03 09:29:41 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:29:41 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:29:41 --> Utf8 Class Initialized
INFO - 2016-01-03 09:29:41 --> URI Class Initialized
INFO - 2016-01-03 09:29:41 --> Router Class Initialized
INFO - 2016-01-03 09:29:41 --> Output Class Initialized
INFO - 2016-01-03 09:29:41 --> Security Class Initialized
DEBUG - 2016-01-03 09:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:29:41 --> Input Class Initialized
INFO - 2016-01-03 09:29:41 --> Language Class Initialized
INFO - 2016-01-03 09:29:41 --> Loader Class Initialized
INFO - 2016-01-03 09:29:41 --> Helper loaded: url_helper
INFO - 2016-01-03 09:29:41 --> Database Driver Class Initialized
INFO - 2016-01-03 09:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:29:41 --> Controller Class Initialized
INFO - 2016-01-03 09:29:41 --> Helper loaded: form_helper
INFO - 2016-01-03 09:29:41 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 09:29:41 --> Final output sent to browser
DEBUG - 2016-01-03 09:29:41 --> Total execution time: 0.0936
INFO - 2016-01-03 09:29:47 --> Config Class Initialized
INFO - 2016-01-03 09:29:47 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:29:47 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:29:47 --> Utf8 Class Initialized
INFO - 2016-01-03 09:29:47 --> URI Class Initialized
INFO - 2016-01-03 09:29:47 --> Router Class Initialized
INFO - 2016-01-03 09:29:47 --> Output Class Initialized
INFO - 2016-01-03 09:29:47 --> Security Class Initialized
DEBUG - 2016-01-03 09:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:29:47 --> Input Class Initialized
INFO - 2016-01-03 09:29:47 --> Language Class Initialized
INFO - 2016-01-03 09:29:47 --> Loader Class Initialized
INFO - 2016-01-03 09:29:47 --> Helper loaded: url_helper
INFO - 2016-01-03 09:29:47 --> Database Driver Class Initialized
INFO - 2016-01-03 09:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:29:47 --> Controller Class Initialized
INFO - 2016-01-03 09:29:47 --> Model Class Initialized
INFO - 2016-01-03 09:29:47 --> Model Class Initialized
INFO - 2016-01-03 09:29:47 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 09:29:47 --> Final output sent to browser
DEBUG - 2016-01-03 09:29:47 --> Total execution time: 0.1084
INFO - 2016-01-03 09:29:47 --> Config Class Initialized
INFO - 2016-01-03 09:29:47 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:29:47 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:29:47 --> Utf8 Class Initialized
INFO - 2016-01-03 09:29:47 --> URI Class Initialized
INFO - 2016-01-03 09:29:47 --> Router Class Initialized
INFO - 2016-01-03 09:29:47 --> Output Class Initialized
INFO - 2016-01-03 09:29:47 --> Security Class Initialized
DEBUG - 2016-01-03 09:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:29:47 --> Input Class Initialized
INFO - 2016-01-03 09:29:47 --> Language Class Initialized
INFO - 2016-01-03 09:29:47 --> Loader Class Initialized
INFO - 2016-01-03 09:29:47 --> Helper loaded: url_helper
INFO - 2016-01-03 09:29:47 --> Config Class Initialized
INFO - 2016-01-03 09:29:47 --> Database Driver Class Initialized
INFO - 2016-01-03 09:29:47 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:29:47 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:29:47 --> Utf8 Class Initialized
INFO - 2016-01-03 09:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:29:47 --> URI Class Initialized
INFO - 2016-01-03 09:29:47 --> Controller Class Initialized
INFO - 2016-01-03 09:29:47 --> Router Class Initialized
INFO - 2016-01-03 09:29:47 --> Model Class Initialized
INFO - 2016-01-03 09:29:47 --> Output Class Initialized
INFO - 2016-01-03 09:29:47 --> Model Class Initialized
INFO - 2016-01-03 09:29:47 --> Security Class Initialized
DEBUG - 2016-01-03 09:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:29:47 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 09:29:47 --> Input Class Initialized
INFO - 2016-01-03 09:29:47 --> Final output sent to browser
INFO - 2016-01-03 09:29:47 --> Language Class Initialized
DEBUG - 2016-01-03 09:29:47 --> Total execution time: 0.1370
INFO - 2016-01-03 09:29:47 --> Loader Class Initialized
INFO - 2016-01-03 09:29:47 --> Helper loaded: url_helper
INFO - 2016-01-03 09:29:47 --> Database Driver Class Initialized
INFO - 2016-01-03 09:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:29:47 --> Controller Class Initialized
DEBUG - 2016-01-03 09:29:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:29:47 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:29:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:29:47 --> Model Class Initialized
INFO - 2016-01-03 09:29:47 --> Model Class Initialized
INFO - 2016-01-03 09:29:47 --> Final output sent to browser
DEBUG - 2016-01-03 09:29:47 --> Total execution time: 0.1457
INFO - 2016-01-03 09:29:50 --> Config Class Initialized
INFO - 2016-01-03 09:29:50 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:29:50 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:29:50 --> Utf8 Class Initialized
INFO - 2016-01-03 09:29:50 --> URI Class Initialized
INFO - 2016-01-03 09:29:50 --> Router Class Initialized
INFO - 2016-01-03 09:29:50 --> Output Class Initialized
INFO - 2016-01-03 09:29:50 --> Security Class Initialized
DEBUG - 2016-01-03 09:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:29:50 --> Input Class Initialized
INFO - 2016-01-03 09:29:50 --> Language Class Initialized
INFO - 2016-01-03 09:29:50 --> Loader Class Initialized
INFO - 2016-01-03 09:29:50 --> Helper loaded: url_helper
INFO - 2016-01-03 09:29:50 --> Database Driver Class Initialized
INFO - 2016-01-03 09:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:29:50 --> Controller Class Initialized
DEBUG - 2016-01-03 09:29:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:29:50 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:29:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:29:50 --> Model Class Initialized
INFO - 2016-01-03 09:29:50 --> Model Class Initialized
INFO - 2016-01-03 09:29:50 --> Final output sent to browser
DEBUG - 2016-01-03 09:29:50 --> Total execution time: 0.1014
INFO - 2016-01-03 09:29:52 --> Config Class Initialized
INFO - 2016-01-03 09:29:52 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:29:52 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:29:52 --> Utf8 Class Initialized
INFO - 2016-01-03 09:29:52 --> URI Class Initialized
INFO - 2016-01-03 09:29:52 --> Router Class Initialized
INFO - 2016-01-03 09:29:52 --> Output Class Initialized
INFO - 2016-01-03 09:29:52 --> Security Class Initialized
DEBUG - 2016-01-03 09:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:29:52 --> Input Class Initialized
INFO - 2016-01-03 09:29:52 --> Language Class Initialized
INFO - 2016-01-03 09:29:52 --> Loader Class Initialized
INFO - 2016-01-03 09:29:52 --> Helper loaded: url_helper
INFO - 2016-01-03 09:29:52 --> Database Driver Class Initialized
INFO - 2016-01-03 09:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:29:52 --> Controller Class Initialized
DEBUG - 2016-01-03 09:29:52 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:29:52 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:29:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:29:52 --> Model Class Initialized
INFO - 2016-01-03 09:29:52 --> Model Class Initialized
INFO - 2016-01-03 09:29:52 --> Final output sent to browser
DEBUG - 2016-01-03 09:29:52 --> Total execution time: 0.1063
INFO - 2016-01-03 09:29:54 --> Config Class Initialized
INFO - 2016-01-03 09:29:54 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:29:54 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:29:54 --> Utf8 Class Initialized
INFO - 2016-01-03 09:29:54 --> URI Class Initialized
INFO - 2016-01-03 09:29:54 --> Router Class Initialized
INFO - 2016-01-03 09:29:54 --> Output Class Initialized
INFO - 2016-01-03 09:29:54 --> Security Class Initialized
DEBUG - 2016-01-03 09:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:29:54 --> Input Class Initialized
INFO - 2016-01-03 09:29:54 --> Language Class Initialized
INFO - 2016-01-03 09:29:54 --> Loader Class Initialized
INFO - 2016-01-03 09:29:54 --> Helper loaded: url_helper
INFO - 2016-01-03 09:29:54 --> Database Driver Class Initialized
INFO - 2016-01-03 09:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:29:54 --> Controller Class Initialized
INFO - 2016-01-03 09:29:54 --> Model Class Initialized
INFO - 2016-01-03 09:29:54 --> Model Class Initialized
INFO - 2016-01-03 09:29:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 09:29:54 --> Final output sent to browser
DEBUG - 2016-01-03 09:29:54 --> Total execution time: 0.0916
INFO - 2016-01-03 09:29:54 --> Config Class Initialized
INFO - 2016-01-03 09:29:54 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:29:54 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:29:54 --> Utf8 Class Initialized
INFO - 2016-01-03 09:29:54 --> URI Class Initialized
INFO - 2016-01-03 09:29:54 --> Router Class Initialized
INFO - 2016-01-03 09:29:54 --> Output Class Initialized
INFO - 2016-01-03 09:29:54 --> Security Class Initialized
DEBUG - 2016-01-03 09:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:29:54 --> Input Class Initialized
INFO - 2016-01-03 09:29:54 --> Language Class Initialized
INFO - 2016-01-03 09:29:54 --> Loader Class Initialized
INFO - 2016-01-03 09:29:54 --> Helper loaded: url_helper
INFO - 2016-01-03 09:29:54 --> Database Driver Class Initialized
INFO - 2016-01-03 09:29:54 --> Config Class Initialized
INFO - 2016-01-03 09:29:54 --> Hooks Class Initialized
INFO - 2016-01-03 09:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:29:54 --> Controller Class Initialized
DEBUG - 2016-01-03 09:29:54 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:29:54 --> Model Class Initialized
INFO - 2016-01-03 09:29:54 --> Utf8 Class Initialized
INFO - 2016-01-03 09:29:54 --> Model Class Initialized
INFO - 2016-01-03 09:29:54 --> URI Class Initialized
INFO - 2016-01-03 09:29:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 09:29:54 --> Final output sent to browser
INFO - 2016-01-03 09:29:54 --> Router Class Initialized
DEBUG - 2016-01-03 09:29:54 --> Total execution time: 0.1012
INFO - 2016-01-03 09:29:54 --> Output Class Initialized
INFO - 2016-01-03 09:29:54 --> Security Class Initialized
DEBUG - 2016-01-03 09:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:29:54 --> Input Class Initialized
INFO - 2016-01-03 09:29:54 --> Language Class Initialized
INFO - 2016-01-03 09:29:54 --> Loader Class Initialized
INFO - 2016-01-03 09:29:54 --> Helper loaded: url_helper
INFO - 2016-01-03 09:29:54 --> Database Driver Class Initialized
INFO - 2016-01-03 09:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:29:54 --> Controller Class Initialized
DEBUG - 2016-01-03 09:29:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:29:54 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:29:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:29:54 --> Model Class Initialized
INFO - 2016-01-03 09:29:54 --> Model Class Initialized
INFO - 2016-01-03 09:29:54 --> Final output sent to browser
DEBUG - 2016-01-03 09:29:54 --> Total execution time: 0.1169
INFO - 2016-01-03 09:47:19 --> Config Class Initialized
INFO - 2016-01-03 09:47:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:19 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:19 --> URI Class Initialized
DEBUG - 2016-01-03 09:47:19 --> No URI present. Default controller set.
INFO - 2016-01-03 09:47:19 --> Router Class Initialized
INFO - 2016-01-03 09:47:19 --> Output Class Initialized
INFO - 2016-01-03 09:47:19 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:19 --> Input Class Initialized
INFO - 2016-01-03 09:47:19 --> Language Class Initialized
INFO - 2016-01-03 09:47:19 --> Loader Class Initialized
INFO - 2016-01-03 09:47:19 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:19 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:20 --> Controller Class Initialized
INFO - 2016-01-03 09:47:20 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 09:47:20 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:20 --> Total execution time: 0.1795
INFO - 2016-01-03 09:47:22 --> Config Class Initialized
INFO - 2016-01-03 09:47:22 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:22 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:22 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:22 --> URI Class Initialized
INFO - 2016-01-03 09:47:22 --> Router Class Initialized
INFO - 2016-01-03 09:47:22 --> Output Class Initialized
INFO - 2016-01-03 09:47:22 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:22 --> Input Class Initialized
INFO - 2016-01-03 09:47:22 --> Language Class Initialized
INFO - 2016-01-03 09:47:22 --> Loader Class Initialized
INFO - 2016-01-03 09:47:22 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:22 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:22 --> Controller Class Initialized
INFO - 2016-01-03 09:47:22 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 09:47:22 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:22 --> Total execution time: 0.1714
INFO - 2016-01-03 09:47:22 --> Config Class Initialized
INFO - 2016-01-03 09:47:22 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:22 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:22 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:22 --> URI Class Initialized
INFO - 2016-01-03 09:47:22 --> Router Class Initialized
INFO - 2016-01-03 09:47:22 --> Output Class Initialized
INFO - 2016-01-03 09:47:22 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:22 --> Input Class Initialized
INFO - 2016-01-03 09:47:22 --> Language Class Initialized
INFO - 2016-01-03 09:47:22 --> Loader Class Initialized
INFO - 2016-01-03 09:47:22 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:22 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:22 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:22 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:22 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:22 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:22 --> Model Class Initialized
INFO - 2016-01-03 09:47:22 --> Model Class Initialized
INFO - 2016-01-03 09:47:22 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:22 --> Total execution time: 0.1247
INFO - 2016-01-03 09:47:25 --> Config Class Initialized
INFO - 2016-01-03 09:47:25 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:25 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:25 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:25 --> URI Class Initialized
INFO - 2016-01-03 09:47:25 --> Router Class Initialized
INFO - 2016-01-03 09:47:25 --> Output Class Initialized
INFO - 2016-01-03 09:47:25 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:25 --> Input Class Initialized
INFO - 2016-01-03 09:47:25 --> Language Class Initialized
INFO - 2016-01-03 09:47:25 --> Loader Class Initialized
INFO - 2016-01-03 09:47:25 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:25 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:25 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:25 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:25 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:25 --> Model Class Initialized
INFO - 2016-01-03 09:47:25 --> Model Class Initialized
INFO - 2016-01-03 09:47:25 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:25 --> Total execution time: 0.1480
INFO - 2016-01-03 09:47:26 --> Config Class Initialized
INFO - 2016-01-03 09:47:26 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:26 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:26 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:26 --> URI Class Initialized
INFO - 2016-01-03 09:47:26 --> Router Class Initialized
INFO - 2016-01-03 09:47:26 --> Output Class Initialized
INFO - 2016-01-03 09:47:26 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:26 --> Input Class Initialized
INFO - 2016-01-03 09:47:26 --> Language Class Initialized
INFO - 2016-01-03 09:47:26 --> Loader Class Initialized
INFO - 2016-01-03 09:47:26 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:26 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:26 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:26 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:26 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:26 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:26 --> Model Class Initialized
INFO - 2016-01-03 09:47:26 --> Model Class Initialized
INFO - 2016-01-03 09:47:26 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:26 --> Total execution time: 0.1572
INFO - 2016-01-03 09:47:29 --> Config Class Initialized
INFO - 2016-01-03 09:47:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:29 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:29 --> URI Class Initialized
INFO - 2016-01-03 09:47:29 --> Router Class Initialized
INFO - 2016-01-03 09:47:29 --> Output Class Initialized
INFO - 2016-01-03 09:47:29 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:29 --> Input Class Initialized
INFO - 2016-01-03 09:47:29 --> Language Class Initialized
INFO - 2016-01-03 09:47:29 --> Loader Class Initialized
INFO - 2016-01-03 09:47:29 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:29 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:29 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:29 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:29 --> Model Class Initialized
INFO - 2016-01-03 09:47:29 --> Model Class Initialized
INFO - 2016-01-03 09:47:29 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:29 --> Total execution time: 0.1549
INFO - 2016-01-03 09:47:29 --> Config Class Initialized
INFO - 2016-01-03 09:47:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:29 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:29 --> URI Class Initialized
INFO - 2016-01-03 09:47:29 --> Router Class Initialized
INFO - 2016-01-03 09:47:29 --> Output Class Initialized
INFO - 2016-01-03 09:47:29 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:29 --> Input Class Initialized
INFO - 2016-01-03 09:47:29 --> Language Class Initialized
INFO - 2016-01-03 09:47:29 --> Loader Class Initialized
INFO - 2016-01-03 09:47:29 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:29 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:29 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:29 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:29 --> Model Class Initialized
INFO - 2016-01-03 09:47:29 --> Model Class Initialized
INFO - 2016-01-03 09:47:29 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:29 --> Total execution time: 0.1647
INFO - 2016-01-03 09:47:30 --> Config Class Initialized
INFO - 2016-01-03 09:47:30 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:30 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:30 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:30 --> URI Class Initialized
INFO - 2016-01-03 09:47:30 --> Router Class Initialized
INFO - 2016-01-03 09:47:30 --> Output Class Initialized
INFO - 2016-01-03 09:47:30 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:30 --> Input Class Initialized
INFO - 2016-01-03 09:47:30 --> Language Class Initialized
INFO - 2016-01-03 09:47:30 --> Loader Class Initialized
INFO - 2016-01-03 09:47:30 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:31 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:31 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:31 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:31 --> Model Class Initialized
INFO - 2016-01-03 09:47:31 --> Model Class Initialized
INFO - 2016-01-03 09:47:31 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:31 --> Total execution time: 0.1536
INFO - 2016-01-03 09:47:31 --> Config Class Initialized
INFO - 2016-01-03 09:47:31 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:31 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:31 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:31 --> URI Class Initialized
INFO - 2016-01-03 09:47:31 --> Router Class Initialized
INFO - 2016-01-03 09:47:31 --> Output Class Initialized
INFO - 2016-01-03 09:47:31 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:31 --> Input Class Initialized
INFO - 2016-01-03 09:47:31 --> Language Class Initialized
INFO - 2016-01-03 09:47:31 --> Loader Class Initialized
INFO - 2016-01-03 09:47:31 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:31 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:31 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:31 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:31 --> Model Class Initialized
INFO - 2016-01-03 09:47:31 --> Model Class Initialized
INFO - 2016-01-03 09:47:31 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:31 --> Total execution time: 0.1589
INFO - 2016-01-03 09:47:33 --> Config Class Initialized
INFO - 2016-01-03 09:47:33 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:33 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:33 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:33 --> URI Class Initialized
INFO - 2016-01-03 09:47:33 --> Router Class Initialized
INFO - 2016-01-03 09:47:33 --> Output Class Initialized
INFO - 2016-01-03 09:47:33 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:33 --> Input Class Initialized
INFO - 2016-01-03 09:47:33 --> Language Class Initialized
INFO - 2016-01-03 09:47:33 --> Loader Class Initialized
INFO - 2016-01-03 09:47:33 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:33 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:33 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:33 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:33 --> Model Class Initialized
INFO - 2016-01-03 09:47:33 --> Model Class Initialized
INFO - 2016-01-03 09:47:33 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:34 --> Total execution time: 0.1692
INFO - 2016-01-03 09:47:34 --> Config Class Initialized
INFO - 2016-01-03 09:47:34 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:34 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:34 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:34 --> URI Class Initialized
INFO - 2016-01-03 09:47:34 --> Router Class Initialized
INFO - 2016-01-03 09:47:34 --> Output Class Initialized
INFO - 2016-01-03 09:47:34 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:34 --> Input Class Initialized
INFO - 2016-01-03 09:47:34 --> Language Class Initialized
INFO - 2016-01-03 09:47:34 --> Loader Class Initialized
INFO - 2016-01-03 09:47:34 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:34 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:34 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:34 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:34 --> Model Class Initialized
INFO - 2016-01-03 09:47:34 --> Model Class Initialized
INFO - 2016-01-03 09:47:34 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:34 --> Total execution time: 0.1556
INFO - 2016-01-03 09:47:35 --> Config Class Initialized
INFO - 2016-01-03 09:47:35 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:35 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:35 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:35 --> URI Class Initialized
INFO - 2016-01-03 09:47:35 --> Router Class Initialized
INFO - 2016-01-03 09:47:35 --> Output Class Initialized
INFO - 2016-01-03 09:47:35 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:35 --> Input Class Initialized
INFO - 2016-01-03 09:47:35 --> Language Class Initialized
INFO - 2016-01-03 09:47:35 --> Loader Class Initialized
INFO - 2016-01-03 09:47:35 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:35 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:35 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:35 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:35 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:35 --> Model Class Initialized
INFO - 2016-01-03 09:47:35 --> Model Class Initialized
INFO - 2016-01-03 09:47:35 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:35 --> Total execution time: 0.1559
INFO - 2016-01-03 09:47:36 --> Config Class Initialized
INFO - 2016-01-03 09:47:36 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:36 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:36 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:36 --> URI Class Initialized
INFO - 2016-01-03 09:47:36 --> Router Class Initialized
INFO - 2016-01-03 09:47:36 --> Output Class Initialized
INFO - 2016-01-03 09:47:36 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:36 --> Input Class Initialized
INFO - 2016-01-03 09:47:36 --> Language Class Initialized
INFO - 2016-01-03 09:47:36 --> Loader Class Initialized
INFO - 2016-01-03 09:47:36 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:36 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:36 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:36 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:36 --> Model Class Initialized
INFO - 2016-01-03 09:47:36 --> Model Class Initialized
INFO - 2016-01-03 09:47:36 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:36 --> Total execution time: 0.1532
INFO - 2016-01-03 09:47:38 --> Config Class Initialized
INFO - 2016-01-03 09:47:38 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:38 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:38 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:38 --> URI Class Initialized
INFO - 2016-01-03 09:47:38 --> Router Class Initialized
INFO - 2016-01-03 09:47:38 --> Output Class Initialized
INFO - 2016-01-03 09:47:38 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:38 --> Input Class Initialized
INFO - 2016-01-03 09:47:38 --> Language Class Initialized
INFO - 2016-01-03 09:47:38 --> Loader Class Initialized
INFO - 2016-01-03 09:47:38 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:38 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:38 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:38 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:38 --> Model Class Initialized
INFO - 2016-01-03 09:47:38 --> Model Class Initialized
INFO - 2016-01-03 09:47:38 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:38 --> Total execution time: 0.1472
INFO - 2016-01-03 09:47:38 --> Config Class Initialized
INFO - 2016-01-03 09:47:38 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:38 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:38 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:38 --> URI Class Initialized
INFO - 2016-01-03 09:47:38 --> Router Class Initialized
INFO - 2016-01-03 09:47:38 --> Output Class Initialized
INFO - 2016-01-03 09:47:38 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:38 --> Input Class Initialized
INFO - 2016-01-03 09:47:38 --> Language Class Initialized
INFO - 2016-01-03 09:47:38 --> Loader Class Initialized
INFO - 2016-01-03 09:47:38 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:38 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:38 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:38 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:38 --> Model Class Initialized
INFO - 2016-01-03 09:47:38 --> Model Class Initialized
INFO - 2016-01-03 09:47:38 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:38 --> Total execution time: 0.1465
INFO - 2016-01-03 09:47:39 --> Config Class Initialized
INFO - 2016-01-03 09:47:39 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:39 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:39 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:39 --> URI Class Initialized
INFO - 2016-01-03 09:47:39 --> Router Class Initialized
INFO - 2016-01-03 09:47:39 --> Output Class Initialized
INFO - 2016-01-03 09:47:39 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:39 --> Input Class Initialized
INFO - 2016-01-03 09:47:39 --> Language Class Initialized
INFO - 2016-01-03 09:47:39 --> Loader Class Initialized
INFO - 2016-01-03 09:47:39 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:39 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:40 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:40 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:40 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:40 --> Model Class Initialized
INFO - 2016-01-03 09:47:40 --> Model Class Initialized
INFO - 2016-01-03 09:47:40 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:40 --> Total execution time: 0.1329
INFO - 2016-01-03 09:47:40 --> Config Class Initialized
INFO - 2016-01-03 09:47:40 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:40 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:40 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:40 --> URI Class Initialized
INFO - 2016-01-03 09:47:40 --> Router Class Initialized
INFO - 2016-01-03 09:47:40 --> Output Class Initialized
INFO - 2016-01-03 09:47:40 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:40 --> Input Class Initialized
INFO - 2016-01-03 09:47:40 --> Language Class Initialized
INFO - 2016-01-03 09:47:40 --> Loader Class Initialized
INFO - 2016-01-03 09:47:40 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:40 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:40 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:40 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:40 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:40 --> Model Class Initialized
INFO - 2016-01-03 09:47:40 --> Model Class Initialized
INFO - 2016-01-03 09:47:40 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:40 --> Total execution time: 0.1459
INFO - 2016-01-03 09:47:42 --> Config Class Initialized
INFO - 2016-01-03 09:47:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:42 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:42 --> URI Class Initialized
INFO - 2016-01-03 09:47:42 --> Router Class Initialized
INFO - 2016-01-03 09:47:42 --> Output Class Initialized
INFO - 2016-01-03 09:47:42 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:42 --> Input Class Initialized
INFO - 2016-01-03 09:47:42 --> Language Class Initialized
INFO - 2016-01-03 09:47:42 --> Loader Class Initialized
INFO - 2016-01-03 09:47:42 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:42 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:42 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:42 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:42 --> Model Class Initialized
INFO - 2016-01-03 09:47:42 --> Model Class Initialized
INFO - 2016-01-03 09:47:42 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:42 --> Total execution time: 0.1541
INFO - 2016-01-03 09:47:42 --> Config Class Initialized
INFO - 2016-01-03 09:47:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:42 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:42 --> URI Class Initialized
INFO - 2016-01-03 09:47:42 --> Router Class Initialized
INFO - 2016-01-03 09:47:42 --> Output Class Initialized
INFO - 2016-01-03 09:47:42 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:42 --> Input Class Initialized
INFO - 2016-01-03 09:47:42 --> Language Class Initialized
INFO - 2016-01-03 09:47:42 --> Loader Class Initialized
INFO - 2016-01-03 09:47:42 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:43 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:43 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:43 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:43 --> Model Class Initialized
INFO - 2016-01-03 09:47:43 --> Model Class Initialized
INFO - 2016-01-03 09:47:43 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:43 --> Total execution time: 0.2750
INFO - 2016-01-03 09:47:47 --> Config Class Initialized
INFO - 2016-01-03 09:47:47 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:47 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:47 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:47 --> URI Class Initialized
INFO - 2016-01-03 09:47:47 --> Router Class Initialized
INFO - 2016-01-03 09:47:47 --> Output Class Initialized
INFO - 2016-01-03 09:47:47 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:47 --> Input Class Initialized
INFO - 2016-01-03 09:47:47 --> Language Class Initialized
INFO - 2016-01-03 09:47:47 --> Loader Class Initialized
INFO - 2016-01-03 09:47:47 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:47 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:47 --> Controller Class Initialized
INFO - 2016-01-03 09:47:47 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 09:47:47 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:47 --> Total execution time: 0.0882
INFO - 2016-01-03 09:47:47 --> Config Class Initialized
INFO - 2016-01-03 09:47:47 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:47 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:47 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:47 --> URI Class Initialized
INFO - 2016-01-03 09:47:47 --> Router Class Initialized
INFO - 2016-01-03 09:47:47 --> Output Class Initialized
INFO - 2016-01-03 09:47:47 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:47 --> Input Class Initialized
INFO - 2016-01-03 09:47:47 --> Language Class Initialized
INFO - 2016-01-03 09:47:47 --> Loader Class Initialized
INFO - 2016-01-03 09:47:47 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:47 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:47 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:47 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:47 --> Model Class Initialized
INFO - 2016-01-03 09:47:47 --> Model Class Initialized
INFO - 2016-01-03 09:47:47 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:47 --> Total execution time: 0.1492
INFO - 2016-01-03 09:47:49 --> Config Class Initialized
INFO - 2016-01-03 09:47:49 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:49 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:49 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:49 --> URI Class Initialized
INFO - 2016-01-03 09:47:49 --> Router Class Initialized
INFO - 2016-01-03 09:47:49 --> Output Class Initialized
INFO - 2016-01-03 09:47:49 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:49 --> Input Class Initialized
INFO - 2016-01-03 09:47:49 --> Language Class Initialized
INFO - 2016-01-03 09:47:49 --> Loader Class Initialized
INFO - 2016-01-03 09:47:49 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:49 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:49 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:49 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:49 --> Model Class Initialized
INFO - 2016-01-03 09:47:49 --> Model Class Initialized
INFO - 2016-01-03 09:47:49 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:49 --> Total execution time: 0.1478
INFO - 2016-01-03 09:47:49 --> Config Class Initialized
INFO - 2016-01-03 09:47:49 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:49 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:49 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:49 --> URI Class Initialized
INFO - 2016-01-03 09:47:49 --> Router Class Initialized
INFO - 2016-01-03 09:47:49 --> Output Class Initialized
INFO - 2016-01-03 09:47:49 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:49 --> Input Class Initialized
INFO - 2016-01-03 09:47:49 --> Language Class Initialized
INFO - 2016-01-03 09:47:49 --> Loader Class Initialized
INFO - 2016-01-03 09:47:49 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:49 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:49 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:49 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:49 --> Model Class Initialized
INFO - 2016-01-03 09:47:49 --> Model Class Initialized
INFO - 2016-01-03 09:47:49 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:49 --> Total execution time: 0.1476
INFO - 2016-01-03 09:47:51 --> Config Class Initialized
INFO - 2016-01-03 09:47:51 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:51 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:51 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:51 --> URI Class Initialized
INFO - 2016-01-03 09:47:51 --> Router Class Initialized
INFO - 2016-01-03 09:47:51 --> Output Class Initialized
INFO - 2016-01-03 09:47:51 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:51 --> Input Class Initialized
INFO - 2016-01-03 09:47:51 --> Language Class Initialized
INFO - 2016-01-03 09:47:51 --> Loader Class Initialized
INFO - 2016-01-03 09:47:51 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:51 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:51 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:51 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:51 --> Model Class Initialized
INFO - 2016-01-03 09:47:51 --> Model Class Initialized
INFO - 2016-01-03 09:47:51 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:51 --> Total execution time: 0.1476
INFO - 2016-01-03 09:47:51 --> Config Class Initialized
INFO - 2016-01-03 09:47:51 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:51 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:51 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:51 --> URI Class Initialized
INFO - 2016-01-03 09:47:51 --> Router Class Initialized
INFO - 2016-01-03 09:47:51 --> Output Class Initialized
INFO - 2016-01-03 09:47:51 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:51 --> Input Class Initialized
INFO - 2016-01-03 09:47:51 --> Language Class Initialized
INFO - 2016-01-03 09:47:51 --> Loader Class Initialized
INFO - 2016-01-03 09:47:51 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:51 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:52 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:52 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:52 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:52 --> Model Class Initialized
INFO - 2016-01-03 09:47:52 --> Model Class Initialized
INFO - 2016-01-03 09:47:52 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:52 --> Total execution time: 0.1478
INFO - 2016-01-03 09:47:53 --> Config Class Initialized
INFO - 2016-01-03 09:47:53 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:53 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:53 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:53 --> URI Class Initialized
INFO - 2016-01-03 09:47:53 --> Router Class Initialized
INFO - 2016-01-03 09:47:53 --> Output Class Initialized
INFO - 2016-01-03 09:47:53 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:53 --> Input Class Initialized
INFO - 2016-01-03 09:47:53 --> Language Class Initialized
INFO - 2016-01-03 09:47:53 --> Loader Class Initialized
INFO - 2016-01-03 09:47:53 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:53 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:53 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:53 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:53 --> Model Class Initialized
INFO - 2016-01-03 09:47:53 --> Model Class Initialized
INFO - 2016-01-03 09:47:53 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:53 --> Total execution time: 0.1465
INFO - 2016-01-03 09:47:53 --> Config Class Initialized
INFO - 2016-01-03 09:47:53 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:53 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:53 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:53 --> URI Class Initialized
INFO - 2016-01-03 09:47:53 --> Router Class Initialized
INFO - 2016-01-03 09:47:53 --> Output Class Initialized
INFO - 2016-01-03 09:47:53 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:53 --> Input Class Initialized
INFO - 2016-01-03 09:47:53 --> Language Class Initialized
INFO - 2016-01-03 09:47:53 --> Loader Class Initialized
INFO - 2016-01-03 09:47:53 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:53 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:53 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:53 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:53 --> Model Class Initialized
INFO - 2016-01-03 09:47:53 --> Model Class Initialized
INFO - 2016-01-03 09:47:53 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:53 --> Total execution time: 0.1712
INFO - 2016-01-03 09:47:56 --> Config Class Initialized
INFO - 2016-01-03 09:47:56 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:56 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:56 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:56 --> URI Class Initialized
INFO - 2016-01-03 09:47:56 --> Router Class Initialized
INFO - 2016-01-03 09:47:56 --> Output Class Initialized
INFO - 2016-01-03 09:47:56 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:56 --> Input Class Initialized
INFO - 2016-01-03 09:47:56 --> Language Class Initialized
INFO - 2016-01-03 09:47:56 --> Loader Class Initialized
INFO - 2016-01-03 09:47:56 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:56 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:56 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:56 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:56 --> Model Class Initialized
INFO - 2016-01-03 09:47:56 --> Model Class Initialized
INFO - 2016-01-03 09:47:56 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:56 --> Total execution time: 0.1449
INFO - 2016-01-03 09:47:56 --> Config Class Initialized
INFO - 2016-01-03 09:47:56 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:56 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:56 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:56 --> URI Class Initialized
INFO - 2016-01-03 09:47:56 --> Router Class Initialized
INFO - 2016-01-03 09:47:56 --> Output Class Initialized
INFO - 2016-01-03 09:47:56 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:56 --> Input Class Initialized
INFO - 2016-01-03 09:47:56 --> Language Class Initialized
INFO - 2016-01-03 09:47:56 --> Loader Class Initialized
INFO - 2016-01-03 09:47:56 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:56 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:56 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:56 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:56 --> Model Class Initialized
INFO - 2016-01-03 09:47:56 --> Model Class Initialized
INFO - 2016-01-03 09:47:56 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:56 --> Total execution time: 0.1656
INFO - 2016-01-03 09:47:57 --> Config Class Initialized
INFO - 2016-01-03 09:47:57 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:57 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:57 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:57 --> URI Class Initialized
INFO - 2016-01-03 09:47:57 --> Router Class Initialized
INFO - 2016-01-03 09:47:57 --> Output Class Initialized
INFO - 2016-01-03 09:47:57 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:57 --> Input Class Initialized
INFO - 2016-01-03 09:47:57 --> Language Class Initialized
INFO - 2016-01-03 09:47:57 --> Loader Class Initialized
INFO - 2016-01-03 09:47:57 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:57 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:57 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:57 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:57 --> Model Class Initialized
INFO - 2016-01-03 09:47:57 --> Model Class Initialized
INFO - 2016-01-03 09:47:57 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:57 --> Total execution time: 0.1403
INFO - 2016-01-03 09:47:58 --> Config Class Initialized
INFO - 2016-01-03 09:47:58 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:58 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:58 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:58 --> URI Class Initialized
INFO - 2016-01-03 09:47:58 --> Router Class Initialized
INFO - 2016-01-03 09:47:58 --> Output Class Initialized
INFO - 2016-01-03 09:47:58 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:58 --> Input Class Initialized
INFO - 2016-01-03 09:47:58 --> Language Class Initialized
INFO - 2016-01-03 09:47:58 --> Loader Class Initialized
INFO - 2016-01-03 09:47:58 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:58 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:58 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:58 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:58 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:58 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:58 --> Model Class Initialized
INFO - 2016-01-03 09:47:58 --> Model Class Initialized
INFO - 2016-01-03 09:47:58 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:58 --> Total execution time: 0.1477
INFO - 2016-01-03 09:47:59 --> Config Class Initialized
INFO - 2016-01-03 09:47:59 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:47:59 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:47:59 --> Utf8 Class Initialized
INFO - 2016-01-03 09:47:59 --> URI Class Initialized
INFO - 2016-01-03 09:47:59 --> Router Class Initialized
INFO - 2016-01-03 09:47:59 --> Output Class Initialized
INFO - 2016-01-03 09:47:59 --> Security Class Initialized
DEBUG - 2016-01-03 09:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:47:59 --> Input Class Initialized
INFO - 2016-01-03 09:47:59 --> Language Class Initialized
INFO - 2016-01-03 09:47:59 --> Loader Class Initialized
INFO - 2016-01-03 09:47:59 --> Helper loaded: url_helper
INFO - 2016-01-03 09:47:59 --> Database Driver Class Initialized
INFO - 2016-01-03 09:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:47:59 --> Controller Class Initialized
DEBUG - 2016-01-03 09:47:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:47:59 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:47:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:47:59 --> Model Class Initialized
INFO - 2016-01-03 09:47:59 --> Model Class Initialized
INFO - 2016-01-03 09:47:59 --> Final output sent to browser
DEBUG - 2016-01-03 09:47:59 --> Total execution time: 0.1466
INFO - 2016-01-03 09:48:00 --> Config Class Initialized
INFO - 2016-01-03 09:48:00 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:00 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:00 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:00 --> URI Class Initialized
INFO - 2016-01-03 09:48:00 --> Router Class Initialized
INFO - 2016-01-03 09:48:00 --> Output Class Initialized
INFO - 2016-01-03 09:48:00 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:00 --> Input Class Initialized
INFO - 2016-01-03 09:48:00 --> Language Class Initialized
INFO - 2016-01-03 09:48:00 --> Loader Class Initialized
INFO - 2016-01-03 09:48:00 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:00 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:00 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:00 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:00 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:00 --> Model Class Initialized
INFO - 2016-01-03 09:48:00 --> Model Class Initialized
INFO - 2016-01-03 09:48:00 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:00 --> Total execution time: 0.1499
INFO - 2016-01-03 09:48:02 --> Config Class Initialized
INFO - 2016-01-03 09:48:02 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:02 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:02 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:02 --> URI Class Initialized
INFO - 2016-01-03 09:48:02 --> Router Class Initialized
INFO - 2016-01-03 09:48:02 --> Output Class Initialized
INFO - 2016-01-03 09:48:02 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:02 --> Input Class Initialized
INFO - 2016-01-03 09:48:02 --> Language Class Initialized
INFO - 2016-01-03 09:48:02 --> Loader Class Initialized
INFO - 2016-01-03 09:48:02 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:02 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:02 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:02 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:02 --> Model Class Initialized
INFO - 2016-01-03 09:48:02 --> Model Class Initialized
INFO - 2016-01-03 09:48:02 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:02 --> Total execution time: 0.1965
INFO - 2016-01-03 09:48:03 --> Config Class Initialized
INFO - 2016-01-03 09:48:03 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:03 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:03 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:03 --> URI Class Initialized
INFO - 2016-01-03 09:48:03 --> Router Class Initialized
INFO - 2016-01-03 09:48:03 --> Output Class Initialized
INFO - 2016-01-03 09:48:03 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:03 --> Input Class Initialized
INFO - 2016-01-03 09:48:03 --> Language Class Initialized
INFO - 2016-01-03 09:48:03 --> Loader Class Initialized
INFO - 2016-01-03 09:48:03 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:03 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:03 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:03 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:03 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:03 --> Model Class Initialized
INFO - 2016-01-03 09:48:03 --> Model Class Initialized
INFO - 2016-01-03 09:48:03 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:03 --> Total execution time: 0.1435
INFO - 2016-01-03 09:48:05 --> Config Class Initialized
INFO - 2016-01-03 09:48:05 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:05 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:05 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:05 --> URI Class Initialized
INFO - 2016-01-03 09:48:05 --> Router Class Initialized
INFO - 2016-01-03 09:48:05 --> Output Class Initialized
INFO - 2016-01-03 09:48:05 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:05 --> Input Class Initialized
INFO - 2016-01-03 09:48:05 --> Language Class Initialized
INFO - 2016-01-03 09:48:05 --> Loader Class Initialized
INFO - 2016-01-03 09:48:05 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:05 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:05 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:05 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:05 --> Model Class Initialized
INFO - 2016-01-03 09:48:05 --> Model Class Initialized
INFO - 2016-01-03 09:48:05 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:05 --> Total execution time: 0.1480
INFO - 2016-01-03 09:48:05 --> Config Class Initialized
INFO - 2016-01-03 09:48:05 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:05 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:05 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:05 --> URI Class Initialized
INFO - 2016-01-03 09:48:05 --> Router Class Initialized
INFO - 2016-01-03 09:48:05 --> Output Class Initialized
INFO - 2016-01-03 09:48:05 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:05 --> Input Class Initialized
INFO - 2016-01-03 09:48:05 --> Language Class Initialized
INFO - 2016-01-03 09:48:05 --> Loader Class Initialized
INFO - 2016-01-03 09:48:05 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:05 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:05 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:05 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:05 --> Model Class Initialized
INFO - 2016-01-03 09:48:05 --> Model Class Initialized
INFO - 2016-01-03 09:48:05 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:05 --> Total execution time: 0.1686
INFO - 2016-01-03 09:48:08 --> Config Class Initialized
INFO - 2016-01-03 09:48:08 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:08 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:08 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:08 --> URI Class Initialized
DEBUG - 2016-01-03 09:48:08 --> No URI present. Default controller set.
INFO - 2016-01-03 09:48:08 --> Router Class Initialized
INFO - 2016-01-03 09:48:08 --> Output Class Initialized
INFO - 2016-01-03 09:48:08 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:08 --> Input Class Initialized
INFO - 2016-01-03 09:48:08 --> Language Class Initialized
INFO - 2016-01-03 09:48:08 --> Loader Class Initialized
INFO - 2016-01-03 09:48:08 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:08 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:08 --> Controller Class Initialized
INFO - 2016-01-03 09:48:08 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 09:48:08 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:08 --> Total execution time: 0.1217
INFO - 2016-01-03 09:48:10 --> Config Class Initialized
INFO - 2016-01-03 09:48:10 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:10 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:10 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:10 --> URI Class Initialized
INFO - 2016-01-03 09:48:10 --> Router Class Initialized
INFO - 2016-01-03 09:48:10 --> Output Class Initialized
INFO - 2016-01-03 09:48:10 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:10 --> Input Class Initialized
INFO - 2016-01-03 09:48:10 --> Language Class Initialized
INFO - 2016-01-03 09:48:10 --> Loader Class Initialized
INFO - 2016-01-03 09:48:10 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:10 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:10 --> Controller Class Initialized
INFO - 2016-01-03 09:48:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 09:48:10 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:10 --> Total execution time: 0.1190
INFO - 2016-01-03 09:48:10 --> Config Class Initialized
INFO - 2016-01-03 09:48:10 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:10 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:10 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:10 --> URI Class Initialized
INFO - 2016-01-03 09:48:10 --> Router Class Initialized
INFO - 2016-01-03 09:48:10 --> Output Class Initialized
INFO - 2016-01-03 09:48:10 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:10 --> Input Class Initialized
INFO - 2016-01-03 09:48:10 --> Language Class Initialized
INFO - 2016-01-03 09:48:10 --> Loader Class Initialized
INFO - 2016-01-03 09:48:10 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:10 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:10 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:10 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:10 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:10 --> Model Class Initialized
INFO - 2016-01-03 09:48:10 --> Model Class Initialized
INFO - 2016-01-03 09:48:10 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:10 --> Total execution time: 0.1479
INFO - 2016-01-03 09:48:11 --> Config Class Initialized
INFO - 2016-01-03 09:48:11 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:11 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:11 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:11 --> URI Class Initialized
INFO - 2016-01-03 09:48:11 --> Router Class Initialized
INFO - 2016-01-03 09:48:11 --> Output Class Initialized
INFO - 2016-01-03 09:48:11 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:11 --> Input Class Initialized
INFO - 2016-01-03 09:48:11 --> Language Class Initialized
INFO - 2016-01-03 09:48:11 --> Loader Class Initialized
INFO - 2016-01-03 09:48:11 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:11 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:11 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:11 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:11 --> Model Class Initialized
INFO - 2016-01-03 09:48:11 --> Model Class Initialized
INFO - 2016-01-03 09:48:11 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:11 --> Total execution time: 0.1569
INFO - 2016-01-03 09:48:11 --> Config Class Initialized
INFO - 2016-01-03 09:48:11 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:11 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:11 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:11 --> URI Class Initialized
INFO - 2016-01-03 09:48:11 --> Router Class Initialized
INFO - 2016-01-03 09:48:11 --> Output Class Initialized
INFO - 2016-01-03 09:48:11 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:11 --> Input Class Initialized
INFO - 2016-01-03 09:48:11 --> Language Class Initialized
INFO - 2016-01-03 09:48:11 --> Loader Class Initialized
INFO - 2016-01-03 09:48:11 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:11 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:11 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:11 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:11 --> Model Class Initialized
INFO - 2016-01-03 09:48:11 --> Model Class Initialized
INFO - 2016-01-03 09:48:11 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:11 --> Total execution time: 0.1595
INFO - 2016-01-03 09:48:12 --> Config Class Initialized
INFO - 2016-01-03 09:48:12 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:12 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:12 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:12 --> URI Class Initialized
INFO - 2016-01-03 09:48:12 --> Router Class Initialized
INFO - 2016-01-03 09:48:12 --> Output Class Initialized
INFO - 2016-01-03 09:48:12 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:12 --> Input Class Initialized
INFO - 2016-01-03 09:48:12 --> Language Class Initialized
INFO - 2016-01-03 09:48:12 --> Loader Class Initialized
INFO - 2016-01-03 09:48:12 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:12 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:12 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:12 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:12 --> Model Class Initialized
INFO - 2016-01-03 09:48:12 --> Model Class Initialized
INFO - 2016-01-03 09:48:12 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:12 --> Total execution time: 0.1485
INFO - 2016-01-03 09:48:12 --> Config Class Initialized
INFO - 2016-01-03 09:48:12 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:12 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:12 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:12 --> URI Class Initialized
INFO - 2016-01-03 09:48:12 --> Router Class Initialized
INFO - 2016-01-03 09:48:12 --> Output Class Initialized
INFO - 2016-01-03 09:48:12 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:12 --> Input Class Initialized
INFO - 2016-01-03 09:48:12 --> Language Class Initialized
INFO - 2016-01-03 09:48:12 --> Loader Class Initialized
INFO - 2016-01-03 09:48:12 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:12 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:12 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:12 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:12 --> Model Class Initialized
INFO - 2016-01-03 09:48:12 --> Model Class Initialized
INFO - 2016-01-03 09:48:12 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:12 --> Total execution time: 0.1439
INFO - 2016-01-03 09:48:13 --> Config Class Initialized
INFO - 2016-01-03 09:48:13 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:13 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:13 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:13 --> URI Class Initialized
INFO - 2016-01-03 09:48:13 --> Router Class Initialized
INFO - 2016-01-03 09:48:13 --> Output Class Initialized
INFO - 2016-01-03 09:48:13 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:13 --> Input Class Initialized
INFO - 2016-01-03 09:48:13 --> Language Class Initialized
INFO - 2016-01-03 09:48:13 --> Loader Class Initialized
INFO - 2016-01-03 09:48:13 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:13 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:13 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:13 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:13 --> Model Class Initialized
INFO - 2016-01-03 09:48:13 --> Model Class Initialized
INFO - 2016-01-03 09:48:13 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:13 --> Total execution time: 0.1221
INFO - 2016-01-03 09:48:13 --> Config Class Initialized
INFO - 2016-01-03 09:48:13 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:13 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:13 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:13 --> URI Class Initialized
INFO - 2016-01-03 09:48:13 --> Router Class Initialized
INFO - 2016-01-03 09:48:13 --> Output Class Initialized
INFO - 2016-01-03 09:48:13 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:13 --> Input Class Initialized
INFO - 2016-01-03 09:48:13 --> Language Class Initialized
INFO - 2016-01-03 09:48:13 --> Loader Class Initialized
INFO - 2016-01-03 09:48:13 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:13 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:13 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:13 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:13 --> Model Class Initialized
INFO - 2016-01-03 09:48:13 --> Model Class Initialized
INFO - 2016-01-03 09:48:13 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:13 --> Total execution time: 0.1498
INFO - 2016-01-03 09:48:14 --> Config Class Initialized
INFO - 2016-01-03 09:48:14 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:14 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:14 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:14 --> URI Class Initialized
INFO - 2016-01-03 09:48:14 --> Router Class Initialized
INFO - 2016-01-03 09:48:14 --> Output Class Initialized
INFO - 2016-01-03 09:48:14 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:14 --> Input Class Initialized
INFO - 2016-01-03 09:48:14 --> Language Class Initialized
INFO - 2016-01-03 09:48:14 --> Loader Class Initialized
INFO - 2016-01-03 09:48:14 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:14 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:14 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:14 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:14 --> Model Class Initialized
INFO - 2016-01-03 09:48:14 --> Model Class Initialized
INFO - 2016-01-03 09:48:14 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:14 --> Total execution time: 0.1308
INFO - 2016-01-03 09:48:14 --> Config Class Initialized
INFO - 2016-01-03 09:48:14 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:14 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:14 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:14 --> URI Class Initialized
INFO - 2016-01-03 09:48:14 --> Router Class Initialized
INFO - 2016-01-03 09:48:14 --> Output Class Initialized
INFO - 2016-01-03 09:48:14 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:14 --> Input Class Initialized
INFO - 2016-01-03 09:48:14 --> Language Class Initialized
INFO - 2016-01-03 09:48:14 --> Loader Class Initialized
INFO - 2016-01-03 09:48:14 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:14 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:14 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:14 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:14 --> Model Class Initialized
INFO - 2016-01-03 09:48:14 --> Model Class Initialized
INFO - 2016-01-03 09:48:14 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:14 --> Total execution time: 0.1495
INFO - 2016-01-03 09:48:15 --> Config Class Initialized
INFO - 2016-01-03 09:48:15 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:15 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:15 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:15 --> URI Class Initialized
INFO - 2016-01-03 09:48:15 --> Router Class Initialized
INFO - 2016-01-03 09:48:15 --> Output Class Initialized
INFO - 2016-01-03 09:48:15 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:15 --> Input Class Initialized
INFO - 2016-01-03 09:48:15 --> Language Class Initialized
INFO - 2016-01-03 09:48:15 --> Loader Class Initialized
INFO - 2016-01-03 09:48:15 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:15 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:15 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:15 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:15 --> Model Class Initialized
INFO - 2016-01-03 09:48:15 --> Model Class Initialized
INFO - 2016-01-03 09:48:15 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:15 --> Total execution time: 0.1486
INFO - 2016-01-03 09:48:15 --> Config Class Initialized
INFO - 2016-01-03 09:48:15 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:15 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:15 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:15 --> URI Class Initialized
INFO - 2016-01-03 09:48:15 --> Router Class Initialized
INFO - 2016-01-03 09:48:15 --> Output Class Initialized
INFO - 2016-01-03 09:48:15 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:15 --> Input Class Initialized
INFO - 2016-01-03 09:48:15 --> Language Class Initialized
INFO - 2016-01-03 09:48:15 --> Loader Class Initialized
INFO - 2016-01-03 09:48:15 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:15 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:15 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:15 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:15 --> Model Class Initialized
INFO - 2016-01-03 09:48:15 --> Model Class Initialized
INFO - 2016-01-03 09:48:15 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:15 --> Total execution time: 0.1443
INFO - 2016-01-03 09:48:16 --> Config Class Initialized
INFO - 2016-01-03 09:48:16 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:16 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:16 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:16 --> URI Class Initialized
INFO - 2016-01-03 09:48:16 --> Router Class Initialized
INFO - 2016-01-03 09:48:16 --> Output Class Initialized
INFO - 2016-01-03 09:48:16 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:16 --> Input Class Initialized
INFO - 2016-01-03 09:48:16 --> Language Class Initialized
INFO - 2016-01-03 09:48:16 --> Loader Class Initialized
INFO - 2016-01-03 09:48:16 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:16 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:16 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:16 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:16 --> Model Class Initialized
INFO - 2016-01-03 09:48:16 --> Model Class Initialized
INFO - 2016-01-03 09:48:16 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:16 --> Total execution time: 0.1438
INFO - 2016-01-03 09:48:16 --> Config Class Initialized
INFO - 2016-01-03 09:48:16 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:17 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:17 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:17 --> URI Class Initialized
INFO - 2016-01-03 09:48:17 --> Router Class Initialized
INFO - 2016-01-03 09:48:17 --> Output Class Initialized
INFO - 2016-01-03 09:48:17 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:17 --> Input Class Initialized
INFO - 2016-01-03 09:48:17 --> Language Class Initialized
INFO - 2016-01-03 09:48:17 --> Loader Class Initialized
INFO - 2016-01-03 09:48:17 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:17 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:17 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:17 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:17 --> Model Class Initialized
INFO - 2016-01-03 09:48:17 --> Model Class Initialized
INFO - 2016-01-03 09:48:17 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:17 --> Total execution time: 0.1464
INFO - 2016-01-03 09:48:17 --> Config Class Initialized
INFO - 2016-01-03 09:48:17 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:17 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:17 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:17 --> URI Class Initialized
INFO - 2016-01-03 09:48:17 --> Router Class Initialized
INFO - 2016-01-03 09:48:17 --> Output Class Initialized
INFO - 2016-01-03 09:48:17 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:17 --> Input Class Initialized
INFO - 2016-01-03 09:48:17 --> Language Class Initialized
INFO - 2016-01-03 09:48:17 --> Loader Class Initialized
INFO - 2016-01-03 09:48:17 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:17 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:17 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:17 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:17 --> Model Class Initialized
INFO - 2016-01-03 09:48:17 --> Model Class Initialized
INFO - 2016-01-03 09:48:17 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:17 --> Total execution time: 0.1422
INFO - 2016-01-03 09:48:18 --> Config Class Initialized
INFO - 2016-01-03 09:48:18 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:18 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:18 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:18 --> URI Class Initialized
INFO - 2016-01-03 09:48:18 --> Router Class Initialized
INFO - 2016-01-03 09:48:18 --> Output Class Initialized
INFO - 2016-01-03 09:48:18 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:18 --> Input Class Initialized
INFO - 2016-01-03 09:48:18 --> Language Class Initialized
INFO - 2016-01-03 09:48:18 --> Loader Class Initialized
INFO - 2016-01-03 09:48:18 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:18 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:18 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:18 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:18 --> Model Class Initialized
INFO - 2016-01-03 09:48:18 --> Model Class Initialized
INFO - 2016-01-03 09:48:18 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:18 --> Total execution time: 0.1362
INFO - 2016-01-03 09:48:19 --> Config Class Initialized
INFO - 2016-01-03 09:48:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:19 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:19 --> URI Class Initialized
INFO - 2016-01-03 09:48:19 --> Router Class Initialized
INFO - 2016-01-03 09:48:19 --> Output Class Initialized
INFO - 2016-01-03 09:48:19 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:19 --> Input Class Initialized
INFO - 2016-01-03 09:48:19 --> Language Class Initialized
INFO - 2016-01-03 09:48:19 --> Loader Class Initialized
INFO - 2016-01-03 09:48:19 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:19 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:19 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:19 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:19 --> Model Class Initialized
INFO - 2016-01-03 09:48:19 --> Model Class Initialized
INFO - 2016-01-03 09:48:19 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:19 --> Total execution time: 0.1465
INFO - 2016-01-03 09:48:19 --> Config Class Initialized
INFO - 2016-01-03 09:48:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:48:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:48:19 --> Utf8 Class Initialized
INFO - 2016-01-03 09:48:19 --> URI Class Initialized
INFO - 2016-01-03 09:48:19 --> Router Class Initialized
INFO - 2016-01-03 09:48:19 --> Output Class Initialized
INFO - 2016-01-03 09:48:19 --> Security Class Initialized
DEBUG - 2016-01-03 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:48:19 --> Input Class Initialized
INFO - 2016-01-03 09:48:19 --> Language Class Initialized
INFO - 2016-01-03 09:48:19 --> Loader Class Initialized
INFO - 2016-01-03 09:48:19 --> Helper loaded: url_helper
INFO - 2016-01-03 09:48:19 --> Database Driver Class Initialized
INFO - 2016-01-03 09:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:48:19 --> Controller Class Initialized
DEBUG - 2016-01-03 09:48:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:48:19 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:48:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:48:19 --> Model Class Initialized
INFO - 2016-01-03 09:48:19 --> Model Class Initialized
INFO - 2016-01-03 09:48:19 --> Final output sent to browser
DEBUG - 2016-01-03 09:48:19 --> Total execution time: 0.1569
INFO - 2016-01-03 09:55:08 --> Config Class Initialized
INFO - 2016-01-03 09:55:08 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:08 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:08 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:08 --> URI Class Initialized
DEBUG - 2016-01-03 09:55:08 --> No URI present. Default controller set.
INFO - 2016-01-03 09:55:08 --> Router Class Initialized
INFO - 2016-01-03 09:55:08 --> Output Class Initialized
INFO - 2016-01-03 09:55:08 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:08 --> Input Class Initialized
INFO - 2016-01-03 09:55:08 --> Language Class Initialized
INFO - 2016-01-03 09:55:08 --> Loader Class Initialized
INFO - 2016-01-03 09:55:09 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:09 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:09 --> Controller Class Initialized
INFO - 2016-01-03 09:55:09 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 09:55:09 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:09 --> Total execution time: 0.2203
INFO - 2016-01-03 09:55:13 --> Config Class Initialized
INFO - 2016-01-03 09:55:13 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:13 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:13 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:13 --> URI Class Initialized
INFO - 2016-01-03 09:55:13 --> Router Class Initialized
INFO - 2016-01-03 09:55:13 --> Output Class Initialized
INFO - 2016-01-03 09:55:13 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:13 --> Input Class Initialized
INFO - 2016-01-03 09:55:13 --> Language Class Initialized
INFO - 2016-01-03 09:55:13 --> Loader Class Initialized
INFO - 2016-01-03 09:55:13 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:13 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:13 --> Controller Class Initialized
INFO - 2016-01-03 09:55:13 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 09:55:13 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:13 --> Total execution time: 0.0834
INFO - 2016-01-03 09:55:14 --> Config Class Initialized
INFO - 2016-01-03 09:55:14 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:14 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:14 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:14 --> URI Class Initialized
INFO - 2016-01-03 09:55:14 --> Router Class Initialized
INFO - 2016-01-03 09:55:14 --> Output Class Initialized
INFO - 2016-01-03 09:55:14 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:14 --> Input Class Initialized
INFO - 2016-01-03 09:55:14 --> Language Class Initialized
INFO - 2016-01-03 09:55:14 --> Loader Class Initialized
INFO - 2016-01-03 09:55:14 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:14 --> Database Driver Class Initialized
ERROR - 2016-01-03 09:55:14 --> Severity: Warning --> opendir(/var/lib/php5): failed to open dir: Permission denied /home/student/571/w1373571/public_html/quiz/system/libraries/Session/drivers/Session_files_driver.php 329
DEBUG - 2016-01-03 09:55:14 --> Session: Garbage collector couldn't list files under directory '/var/lib/php5'.
ERROR - 2016-01-03 09:55:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/libraries/Session/Session.php 168
INFO - 2016-01-03 09:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:14 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:14 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:14 --> Model Class Initialized
INFO - 2016-01-03 09:55:14 --> Model Class Initialized
ERROR - 2016-01-03 09:55:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/student/571/w1373571/public_html/quiz/system/core/Exceptions.php:272) /home/student/571/w1373571/public_html/quiz/system/core/Common.php 573
INFO - 2016-01-03 09:55:14 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:14 --> Total execution time: 0.1422
INFO - 2016-01-03 09:55:25 --> Config Class Initialized
INFO - 2016-01-03 09:55:25 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:25 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:25 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:25 --> URI Class Initialized
DEBUG - 2016-01-03 09:55:25 --> No URI present. Default controller set.
INFO - 2016-01-03 09:55:25 --> Router Class Initialized
INFO - 2016-01-03 09:55:25 --> Output Class Initialized
INFO - 2016-01-03 09:55:25 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:25 --> Input Class Initialized
INFO - 2016-01-03 09:55:25 --> Language Class Initialized
INFO - 2016-01-03 09:55:25 --> Loader Class Initialized
INFO - 2016-01-03 09:55:25 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:25 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:25 --> Controller Class Initialized
INFO - 2016-01-03 09:55:25 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 09:55:25 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:25 --> Total execution time: 0.1310
INFO - 2016-01-03 09:55:28 --> Config Class Initialized
INFO - 2016-01-03 09:55:28 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:28 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:28 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:28 --> URI Class Initialized
INFO - 2016-01-03 09:55:28 --> Router Class Initialized
INFO - 2016-01-03 09:55:28 --> Output Class Initialized
INFO - 2016-01-03 09:55:28 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:28 --> Input Class Initialized
INFO - 2016-01-03 09:55:28 --> Language Class Initialized
INFO - 2016-01-03 09:55:28 --> Loader Class Initialized
INFO - 2016-01-03 09:55:28 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:28 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:28 --> Controller Class Initialized
INFO - 2016-01-03 09:55:28 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 09:55:28 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:28 --> Total execution time: 0.1221
INFO - 2016-01-03 09:55:28 --> Config Class Initialized
INFO - 2016-01-03 09:55:28 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:28 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:28 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:28 --> URI Class Initialized
INFO - 2016-01-03 09:55:28 --> Router Class Initialized
INFO - 2016-01-03 09:55:28 --> Output Class Initialized
INFO - 2016-01-03 09:55:28 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:28 --> Input Class Initialized
INFO - 2016-01-03 09:55:28 --> Language Class Initialized
INFO - 2016-01-03 09:55:28 --> Loader Class Initialized
INFO - 2016-01-03 09:55:28 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:28 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:28 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:28 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:28 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:28 --> Model Class Initialized
INFO - 2016-01-03 09:55:28 --> Model Class Initialized
INFO - 2016-01-03 09:55:28 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:28 --> Total execution time: 0.1266
INFO - 2016-01-03 09:55:32 --> Config Class Initialized
INFO - 2016-01-03 09:55:32 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:32 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:32 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:32 --> URI Class Initialized
INFO - 2016-01-03 09:55:32 --> Router Class Initialized
INFO - 2016-01-03 09:55:32 --> Output Class Initialized
INFO - 2016-01-03 09:55:32 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:33 --> Input Class Initialized
INFO - 2016-01-03 09:55:33 --> Language Class Initialized
INFO - 2016-01-03 09:55:33 --> Loader Class Initialized
INFO - 2016-01-03 09:55:33 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:33 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:33 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:33 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:33 --> Model Class Initialized
INFO - 2016-01-03 09:55:33 --> Model Class Initialized
INFO - 2016-01-03 09:55:33 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:33 --> Total execution time: 0.1546
INFO - 2016-01-03 09:55:33 --> Config Class Initialized
INFO - 2016-01-03 09:55:33 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:33 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:33 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:33 --> URI Class Initialized
INFO - 2016-01-03 09:55:33 --> Router Class Initialized
INFO - 2016-01-03 09:55:33 --> Output Class Initialized
INFO - 2016-01-03 09:55:33 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:33 --> Input Class Initialized
INFO - 2016-01-03 09:55:33 --> Language Class Initialized
INFO - 2016-01-03 09:55:33 --> Loader Class Initialized
INFO - 2016-01-03 09:55:33 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:33 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:33 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:33 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:33 --> Model Class Initialized
INFO - 2016-01-03 09:55:33 --> Model Class Initialized
INFO - 2016-01-03 09:55:33 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:33 --> Total execution time: 0.1472
INFO - 2016-01-03 09:55:41 --> Config Class Initialized
INFO - 2016-01-03 09:55:41 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:41 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:42 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:42 --> URI Class Initialized
INFO - 2016-01-03 09:55:42 --> Router Class Initialized
INFO - 2016-01-03 09:55:42 --> Output Class Initialized
INFO - 2016-01-03 09:55:42 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:42 --> Input Class Initialized
INFO - 2016-01-03 09:55:42 --> Language Class Initialized
INFO - 2016-01-03 09:55:42 --> Loader Class Initialized
INFO - 2016-01-03 09:55:42 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:42 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:42 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:42 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:42 --> Model Class Initialized
INFO - 2016-01-03 09:55:42 --> Model Class Initialized
INFO - 2016-01-03 09:55:42 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:42 --> Total execution time: 0.1767
INFO - 2016-01-03 09:55:42 --> Config Class Initialized
INFO - 2016-01-03 09:55:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:42 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:42 --> URI Class Initialized
INFO - 2016-01-03 09:55:42 --> Router Class Initialized
INFO - 2016-01-03 09:55:42 --> Output Class Initialized
INFO - 2016-01-03 09:55:42 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:42 --> Input Class Initialized
INFO - 2016-01-03 09:55:42 --> Language Class Initialized
INFO - 2016-01-03 09:55:42 --> Loader Class Initialized
INFO - 2016-01-03 09:55:42 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:42 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:43 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:43 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:43 --> Model Class Initialized
INFO - 2016-01-03 09:55:43 --> Model Class Initialized
INFO - 2016-01-03 09:55:43 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:43 --> Total execution time: 0.3953
INFO - 2016-01-03 09:55:45 --> Config Class Initialized
INFO - 2016-01-03 09:55:45 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:45 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:45 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:45 --> URI Class Initialized
INFO - 2016-01-03 09:55:45 --> Router Class Initialized
INFO - 2016-01-03 09:55:45 --> Output Class Initialized
INFO - 2016-01-03 09:55:45 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:45 --> Input Class Initialized
INFO - 2016-01-03 09:55:45 --> Language Class Initialized
INFO - 2016-01-03 09:55:45 --> Loader Class Initialized
INFO - 2016-01-03 09:55:45 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:45 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:45 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:45 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:45 --> Model Class Initialized
INFO - 2016-01-03 09:55:45 --> Model Class Initialized
INFO - 2016-01-03 09:55:45 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:45 --> Total execution time: 0.1391
INFO - 2016-01-03 09:55:45 --> Config Class Initialized
INFO - 2016-01-03 09:55:45 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:45 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:45 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:45 --> URI Class Initialized
INFO - 2016-01-03 09:55:45 --> Router Class Initialized
INFO - 2016-01-03 09:55:45 --> Output Class Initialized
INFO - 2016-01-03 09:55:45 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:45 --> Input Class Initialized
INFO - 2016-01-03 09:55:45 --> Language Class Initialized
INFO - 2016-01-03 09:55:45 --> Loader Class Initialized
INFO - 2016-01-03 09:55:45 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:45 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:45 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:45 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:45 --> Model Class Initialized
INFO - 2016-01-03 09:55:45 --> Model Class Initialized
INFO - 2016-01-03 09:55:45 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:45 --> Total execution time: 0.1648
INFO - 2016-01-03 09:55:47 --> Config Class Initialized
INFO - 2016-01-03 09:55:47 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:47 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:47 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:47 --> URI Class Initialized
INFO - 2016-01-03 09:55:47 --> Router Class Initialized
INFO - 2016-01-03 09:55:47 --> Output Class Initialized
INFO - 2016-01-03 09:55:47 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:47 --> Input Class Initialized
INFO - 2016-01-03 09:55:47 --> Language Class Initialized
INFO - 2016-01-03 09:55:47 --> Loader Class Initialized
INFO - 2016-01-03 09:55:47 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:47 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:47 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:47 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:47 --> Model Class Initialized
INFO - 2016-01-03 09:55:47 --> Model Class Initialized
INFO - 2016-01-03 09:55:47 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:47 --> Total execution time: 0.1575
INFO - 2016-01-03 09:55:48 --> Config Class Initialized
INFO - 2016-01-03 09:55:48 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:48 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:48 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:48 --> URI Class Initialized
INFO - 2016-01-03 09:55:48 --> Router Class Initialized
INFO - 2016-01-03 09:55:48 --> Output Class Initialized
INFO - 2016-01-03 09:55:48 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:48 --> Input Class Initialized
INFO - 2016-01-03 09:55:48 --> Language Class Initialized
INFO - 2016-01-03 09:55:48 --> Loader Class Initialized
INFO - 2016-01-03 09:55:48 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:48 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:48 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:48 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:48 --> Model Class Initialized
INFO - 2016-01-03 09:55:48 --> Model Class Initialized
INFO - 2016-01-03 09:55:48 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:48 --> Total execution time: 0.1118
INFO - 2016-01-03 09:55:49 --> Config Class Initialized
INFO - 2016-01-03 09:55:49 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:49 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:49 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:49 --> URI Class Initialized
INFO - 2016-01-03 09:55:49 --> Router Class Initialized
INFO - 2016-01-03 09:55:49 --> Output Class Initialized
INFO - 2016-01-03 09:55:49 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:49 --> Input Class Initialized
INFO - 2016-01-03 09:55:49 --> Language Class Initialized
INFO - 2016-01-03 09:55:49 --> Loader Class Initialized
INFO - 2016-01-03 09:55:49 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:49 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:49 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:49 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:49 --> Model Class Initialized
INFO - 2016-01-03 09:55:49 --> Model Class Initialized
INFO - 2016-01-03 09:55:49 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:49 --> Total execution time: 0.1391
INFO - 2016-01-03 09:55:50 --> Config Class Initialized
INFO - 2016-01-03 09:55:50 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:50 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:50 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:50 --> URI Class Initialized
INFO - 2016-01-03 09:55:50 --> Router Class Initialized
INFO - 2016-01-03 09:55:50 --> Output Class Initialized
INFO - 2016-01-03 09:55:50 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:50 --> Input Class Initialized
INFO - 2016-01-03 09:55:50 --> Language Class Initialized
INFO - 2016-01-03 09:55:50 --> Loader Class Initialized
INFO - 2016-01-03 09:55:50 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:50 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:50 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:50 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:50 --> Model Class Initialized
INFO - 2016-01-03 09:55:50 --> Model Class Initialized
INFO - 2016-01-03 09:55:50 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:50 --> Total execution time: 0.1222
INFO - 2016-01-03 09:55:53 --> Config Class Initialized
INFO - 2016-01-03 09:55:53 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:53 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:53 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:53 --> URI Class Initialized
INFO - 2016-01-03 09:55:53 --> Router Class Initialized
INFO - 2016-01-03 09:55:53 --> Output Class Initialized
INFO - 2016-01-03 09:55:53 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:53 --> Input Class Initialized
INFO - 2016-01-03 09:55:53 --> Language Class Initialized
INFO - 2016-01-03 09:55:53 --> Loader Class Initialized
INFO - 2016-01-03 09:55:53 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:53 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:53 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:53 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:53 --> Model Class Initialized
INFO - 2016-01-03 09:55:53 --> Model Class Initialized
INFO - 2016-01-03 09:55:53 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:53 --> Total execution time: 0.1028
INFO - 2016-01-03 09:55:54 --> Config Class Initialized
INFO - 2016-01-03 09:55:54 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:54 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:54 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:54 --> URI Class Initialized
INFO - 2016-01-03 09:55:54 --> Router Class Initialized
INFO - 2016-01-03 09:55:54 --> Output Class Initialized
INFO - 2016-01-03 09:55:54 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:54 --> Input Class Initialized
INFO - 2016-01-03 09:55:54 --> Language Class Initialized
INFO - 2016-01-03 09:55:54 --> Loader Class Initialized
INFO - 2016-01-03 09:55:54 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:54 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:54 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:54 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:54 --> Model Class Initialized
INFO - 2016-01-03 09:55:54 --> Model Class Initialized
INFO - 2016-01-03 09:55:54 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:54 --> Total execution time: 0.1030
INFO - 2016-01-03 09:55:56 --> Config Class Initialized
INFO - 2016-01-03 09:55:56 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:56 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:56 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:56 --> URI Class Initialized
INFO - 2016-01-03 09:55:56 --> Router Class Initialized
INFO - 2016-01-03 09:55:56 --> Output Class Initialized
INFO - 2016-01-03 09:55:56 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:56 --> Input Class Initialized
INFO - 2016-01-03 09:55:56 --> Language Class Initialized
INFO - 2016-01-03 09:55:56 --> Loader Class Initialized
INFO - 2016-01-03 09:55:56 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:56 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:56 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:56 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:56 --> Model Class Initialized
INFO - 2016-01-03 09:55:56 --> Model Class Initialized
INFO - 2016-01-03 09:55:56 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:56 --> Total execution time: 0.1525
INFO - 2016-01-03 09:55:56 --> Config Class Initialized
INFO - 2016-01-03 09:55:56 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:56 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:56 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:56 --> URI Class Initialized
INFO - 2016-01-03 09:55:56 --> Router Class Initialized
INFO - 2016-01-03 09:55:56 --> Output Class Initialized
INFO - 2016-01-03 09:55:56 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:56 --> Input Class Initialized
INFO - 2016-01-03 09:55:56 --> Language Class Initialized
INFO - 2016-01-03 09:55:56 --> Loader Class Initialized
INFO - 2016-01-03 09:55:56 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:56 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:56 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:56 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:56 --> Model Class Initialized
INFO - 2016-01-03 09:55:56 --> Model Class Initialized
INFO - 2016-01-03 09:55:56 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:56 --> Total execution time: 0.1059
INFO - 2016-01-03 09:55:59 --> Config Class Initialized
INFO - 2016-01-03 09:55:59 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:59 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:59 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:59 --> URI Class Initialized
INFO - 2016-01-03 09:55:59 --> Router Class Initialized
INFO - 2016-01-03 09:55:59 --> Output Class Initialized
INFO - 2016-01-03 09:55:59 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:59 --> Input Class Initialized
INFO - 2016-01-03 09:55:59 --> Language Class Initialized
INFO - 2016-01-03 09:55:59 --> Loader Class Initialized
INFO - 2016-01-03 09:55:59 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:59 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:59 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:59 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:59 --> Model Class Initialized
INFO - 2016-01-03 09:55:59 --> Model Class Initialized
INFO - 2016-01-03 09:55:59 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:59 --> Total execution time: 0.1046
INFO - 2016-01-03 09:55:59 --> Config Class Initialized
INFO - 2016-01-03 09:55:59 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:55:59 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:55:59 --> Utf8 Class Initialized
INFO - 2016-01-03 09:55:59 --> URI Class Initialized
INFO - 2016-01-03 09:55:59 --> Router Class Initialized
INFO - 2016-01-03 09:55:59 --> Output Class Initialized
INFO - 2016-01-03 09:55:59 --> Security Class Initialized
DEBUG - 2016-01-03 09:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:55:59 --> Input Class Initialized
INFO - 2016-01-03 09:55:59 --> Language Class Initialized
INFO - 2016-01-03 09:55:59 --> Loader Class Initialized
INFO - 2016-01-03 09:55:59 --> Helper loaded: url_helper
INFO - 2016-01-03 09:55:59 --> Database Driver Class Initialized
INFO - 2016-01-03 09:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:55:59 --> Controller Class Initialized
DEBUG - 2016-01-03 09:55:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:55:59 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:55:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:55:59 --> Model Class Initialized
INFO - 2016-01-03 09:55:59 --> Model Class Initialized
INFO - 2016-01-03 09:55:59 --> Final output sent to browser
DEBUG - 2016-01-03 09:55:59 --> Total execution time: 0.1194
INFO - 2016-01-03 09:56:24 --> Config Class Initialized
INFO - 2016-01-03 09:56:24 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:24 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:24 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:24 --> URI Class Initialized
DEBUG - 2016-01-03 09:56:24 --> No URI present. Default controller set.
INFO - 2016-01-03 09:56:24 --> Router Class Initialized
INFO - 2016-01-03 09:56:24 --> Output Class Initialized
INFO - 2016-01-03 09:56:24 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:24 --> Input Class Initialized
INFO - 2016-01-03 09:56:24 --> Language Class Initialized
INFO - 2016-01-03 09:56:24 --> Loader Class Initialized
INFO - 2016-01-03 09:56:24 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:24 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:24 --> Controller Class Initialized
INFO - 2016-01-03 09:56:24 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 09:56:24 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:24 --> Total execution time: 0.1720
INFO - 2016-01-03 09:56:27 --> Config Class Initialized
INFO - 2016-01-03 09:56:27 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:27 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:27 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:27 --> URI Class Initialized
INFO - 2016-01-03 09:56:27 --> Router Class Initialized
INFO - 2016-01-03 09:56:27 --> Output Class Initialized
INFO - 2016-01-03 09:56:27 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:27 --> Input Class Initialized
INFO - 2016-01-03 09:56:27 --> Language Class Initialized
INFO - 2016-01-03 09:56:27 --> Loader Class Initialized
INFO - 2016-01-03 09:56:27 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:27 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:27 --> Controller Class Initialized
INFO - 2016-01-03 09:56:27 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 09:56:27 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:27 --> Total execution time: 0.0947
INFO - 2016-01-03 09:56:27 --> Config Class Initialized
INFO - 2016-01-03 09:56:27 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:27 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:27 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:27 --> URI Class Initialized
INFO - 2016-01-03 09:56:27 --> Router Class Initialized
INFO - 2016-01-03 09:56:27 --> Output Class Initialized
INFO - 2016-01-03 09:56:27 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:27 --> Input Class Initialized
INFO - 2016-01-03 09:56:27 --> Language Class Initialized
INFO - 2016-01-03 09:56:27 --> Loader Class Initialized
INFO - 2016-01-03 09:56:27 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:27 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:27 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:27 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:27 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:27 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:27 --> Model Class Initialized
INFO - 2016-01-03 09:56:27 --> Model Class Initialized
INFO - 2016-01-03 09:56:27 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:27 --> Total execution time: 0.1630
INFO - 2016-01-03 09:56:29 --> Config Class Initialized
INFO - 2016-01-03 09:56:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:29 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:29 --> URI Class Initialized
INFO - 2016-01-03 09:56:29 --> Router Class Initialized
INFO - 2016-01-03 09:56:29 --> Output Class Initialized
INFO - 2016-01-03 09:56:29 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:29 --> Input Class Initialized
INFO - 2016-01-03 09:56:29 --> Language Class Initialized
INFO - 2016-01-03 09:56:29 --> Loader Class Initialized
INFO - 2016-01-03 09:56:29 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:29 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:29 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:29 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:29 --> Model Class Initialized
INFO - 2016-01-03 09:56:29 --> Model Class Initialized
INFO - 2016-01-03 09:56:29 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:29 --> Total execution time: 0.1513
INFO - 2016-01-03 09:56:30 --> Config Class Initialized
INFO - 2016-01-03 09:56:30 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:30 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:30 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:30 --> URI Class Initialized
INFO - 2016-01-03 09:56:30 --> Router Class Initialized
INFO - 2016-01-03 09:56:30 --> Output Class Initialized
INFO - 2016-01-03 09:56:30 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:30 --> Input Class Initialized
INFO - 2016-01-03 09:56:30 --> Language Class Initialized
INFO - 2016-01-03 09:56:30 --> Loader Class Initialized
INFO - 2016-01-03 09:56:30 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:30 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:30 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:30 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:30 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:30 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:30 --> Model Class Initialized
INFO - 2016-01-03 09:56:30 --> Model Class Initialized
INFO - 2016-01-03 09:56:30 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:30 --> Total execution time: 0.1133
INFO - 2016-01-03 09:56:32 --> Config Class Initialized
INFO - 2016-01-03 09:56:32 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:32 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:32 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:32 --> URI Class Initialized
INFO - 2016-01-03 09:56:32 --> Router Class Initialized
INFO - 2016-01-03 09:56:32 --> Output Class Initialized
INFO - 2016-01-03 09:56:32 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:32 --> Input Class Initialized
INFO - 2016-01-03 09:56:32 --> Language Class Initialized
INFO - 2016-01-03 09:56:32 --> Loader Class Initialized
INFO - 2016-01-03 09:56:32 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:32 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:32 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:32 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:32 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:32 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:32 --> Model Class Initialized
INFO - 2016-01-03 09:56:32 --> Model Class Initialized
INFO - 2016-01-03 09:56:32 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:32 --> Total execution time: 0.1532
INFO - 2016-01-03 09:56:33 --> Config Class Initialized
INFO - 2016-01-03 09:56:33 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:33 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:33 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:33 --> URI Class Initialized
INFO - 2016-01-03 09:56:33 --> Router Class Initialized
INFO - 2016-01-03 09:56:33 --> Output Class Initialized
INFO - 2016-01-03 09:56:33 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:33 --> Input Class Initialized
INFO - 2016-01-03 09:56:33 --> Language Class Initialized
INFO - 2016-01-03 09:56:33 --> Loader Class Initialized
INFO - 2016-01-03 09:56:33 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:33 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:33 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:33 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:33 --> Model Class Initialized
INFO - 2016-01-03 09:56:33 --> Model Class Initialized
INFO - 2016-01-03 09:56:33 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:33 --> Total execution time: 0.1522
INFO - 2016-01-03 09:56:36 --> Config Class Initialized
INFO - 2016-01-03 09:56:36 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:36 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:36 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:36 --> URI Class Initialized
INFO - 2016-01-03 09:56:36 --> Router Class Initialized
INFO - 2016-01-03 09:56:36 --> Output Class Initialized
INFO - 2016-01-03 09:56:36 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:36 --> Input Class Initialized
INFO - 2016-01-03 09:56:36 --> Language Class Initialized
INFO - 2016-01-03 09:56:36 --> Loader Class Initialized
INFO - 2016-01-03 09:56:36 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:36 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:36 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:36 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:36 --> Model Class Initialized
INFO - 2016-01-03 09:56:36 --> Model Class Initialized
INFO - 2016-01-03 09:56:36 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:36 --> Total execution time: 0.1639
INFO - 2016-01-03 09:56:36 --> Config Class Initialized
INFO - 2016-01-03 09:56:36 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:36 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:36 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:36 --> URI Class Initialized
INFO - 2016-01-03 09:56:36 --> Router Class Initialized
INFO - 2016-01-03 09:56:36 --> Output Class Initialized
INFO - 2016-01-03 09:56:36 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:36 --> Input Class Initialized
INFO - 2016-01-03 09:56:36 --> Language Class Initialized
INFO - 2016-01-03 09:56:36 --> Loader Class Initialized
INFO - 2016-01-03 09:56:36 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:36 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:36 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:36 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:36 --> Model Class Initialized
INFO - 2016-01-03 09:56:36 --> Model Class Initialized
INFO - 2016-01-03 09:56:36 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:36 --> Total execution time: 0.1512
INFO - 2016-01-03 09:56:39 --> Config Class Initialized
INFO - 2016-01-03 09:56:39 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:39 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:39 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:39 --> URI Class Initialized
INFO - 2016-01-03 09:56:39 --> Router Class Initialized
INFO - 2016-01-03 09:56:39 --> Output Class Initialized
INFO - 2016-01-03 09:56:39 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:39 --> Input Class Initialized
INFO - 2016-01-03 09:56:39 --> Language Class Initialized
INFO - 2016-01-03 09:56:39 --> Loader Class Initialized
INFO - 2016-01-03 09:56:39 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:39 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:39 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:39 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:39 --> Model Class Initialized
INFO - 2016-01-03 09:56:39 --> Model Class Initialized
INFO - 2016-01-03 09:56:39 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:39 --> Total execution time: 0.1577
INFO - 2016-01-03 09:56:40 --> Config Class Initialized
INFO - 2016-01-03 09:56:40 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:40 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:40 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:40 --> URI Class Initialized
INFO - 2016-01-03 09:56:40 --> Router Class Initialized
INFO - 2016-01-03 09:56:40 --> Output Class Initialized
INFO - 2016-01-03 09:56:40 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:40 --> Input Class Initialized
INFO - 2016-01-03 09:56:40 --> Language Class Initialized
INFO - 2016-01-03 09:56:40 --> Loader Class Initialized
INFO - 2016-01-03 09:56:40 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:40 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:40 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:40 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:40 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:40 --> Model Class Initialized
INFO - 2016-01-03 09:56:40 --> Model Class Initialized
INFO - 2016-01-03 09:56:40 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:40 --> Total execution time: 0.1072
INFO - 2016-01-03 09:56:42 --> Config Class Initialized
INFO - 2016-01-03 09:56:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:42 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:42 --> URI Class Initialized
INFO - 2016-01-03 09:56:42 --> Router Class Initialized
INFO - 2016-01-03 09:56:42 --> Output Class Initialized
INFO - 2016-01-03 09:56:42 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:42 --> Input Class Initialized
INFO - 2016-01-03 09:56:42 --> Language Class Initialized
INFO - 2016-01-03 09:56:42 --> Loader Class Initialized
INFO - 2016-01-03 09:56:42 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:42 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:42 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:42 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:42 --> Model Class Initialized
INFO - 2016-01-03 09:56:42 --> Model Class Initialized
INFO - 2016-01-03 09:56:42 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:42 --> Total execution time: 0.1498
INFO - 2016-01-03 09:56:42 --> Config Class Initialized
INFO - 2016-01-03 09:56:42 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:42 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:42 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:42 --> URI Class Initialized
INFO - 2016-01-03 09:56:42 --> Router Class Initialized
INFO - 2016-01-03 09:56:42 --> Output Class Initialized
INFO - 2016-01-03 09:56:42 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:42 --> Input Class Initialized
INFO - 2016-01-03 09:56:42 --> Language Class Initialized
INFO - 2016-01-03 09:56:42 --> Loader Class Initialized
INFO - 2016-01-03 09:56:42 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:42 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:43 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:43 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:43 --> Model Class Initialized
INFO - 2016-01-03 09:56:43 --> Model Class Initialized
INFO - 2016-01-03 09:56:43 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:43 --> Total execution time: 0.1721
INFO - 2016-01-03 09:56:47 --> Config Class Initialized
INFO - 2016-01-03 09:56:47 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:47 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:47 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:47 --> URI Class Initialized
INFO - 2016-01-03 09:56:47 --> Router Class Initialized
INFO - 2016-01-03 09:56:47 --> Output Class Initialized
INFO - 2016-01-03 09:56:47 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:47 --> Input Class Initialized
INFO - 2016-01-03 09:56:47 --> Language Class Initialized
INFO - 2016-01-03 09:56:47 --> Loader Class Initialized
INFO - 2016-01-03 09:56:47 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:47 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:47 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:47 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:47 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:47 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:47 --> Model Class Initialized
INFO - 2016-01-03 09:56:47 --> Model Class Initialized
INFO - 2016-01-03 09:56:47 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:47 --> Total execution time: 0.1496
INFO - 2016-01-03 09:56:48 --> Config Class Initialized
INFO - 2016-01-03 09:56:48 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:48 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:48 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:48 --> URI Class Initialized
INFO - 2016-01-03 09:56:48 --> Router Class Initialized
INFO - 2016-01-03 09:56:48 --> Output Class Initialized
INFO - 2016-01-03 09:56:48 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:48 --> Input Class Initialized
INFO - 2016-01-03 09:56:48 --> Language Class Initialized
INFO - 2016-01-03 09:56:48 --> Loader Class Initialized
INFO - 2016-01-03 09:56:48 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:48 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:48 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:48 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:48 --> Model Class Initialized
INFO - 2016-01-03 09:56:48 --> Model Class Initialized
INFO - 2016-01-03 09:56:48 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:48 --> Total execution time: 0.1495
INFO - 2016-01-03 09:56:51 --> Config Class Initialized
INFO - 2016-01-03 09:56:51 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:51 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:51 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:51 --> URI Class Initialized
INFO - 2016-01-03 09:56:51 --> Router Class Initialized
INFO - 2016-01-03 09:56:51 --> Output Class Initialized
INFO - 2016-01-03 09:56:51 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:51 --> Input Class Initialized
INFO - 2016-01-03 09:56:51 --> Language Class Initialized
INFO - 2016-01-03 09:56:51 --> Loader Class Initialized
INFO - 2016-01-03 09:56:51 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:51 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:51 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:51 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:51 --> Model Class Initialized
INFO - 2016-01-03 09:56:51 --> Model Class Initialized
INFO - 2016-01-03 09:56:51 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:51 --> Total execution time: 0.1086
INFO - 2016-01-03 09:56:52 --> Config Class Initialized
INFO - 2016-01-03 09:56:52 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:52 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:52 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:52 --> URI Class Initialized
INFO - 2016-01-03 09:56:52 --> Router Class Initialized
INFO - 2016-01-03 09:56:52 --> Output Class Initialized
INFO - 2016-01-03 09:56:52 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:52 --> Input Class Initialized
INFO - 2016-01-03 09:56:52 --> Language Class Initialized
INFO - 2016-01-03 09:56:52 --> Loader Class Initialized
INFO - 2016-01-03 09:56:52 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:52 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:52 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:52 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:52 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:52 --> Model Class Initialized
INFO - 2016-01-03 09:56:52 --> Model Class Initialized
INFO - 2016-01-03 09:56:52 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:52 --> Total execution time: 0.1065
INFO - 2016-01-03 09:56:54 --> Config Class Initialized
INFO - 2016-01-03 09:56:54 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:54 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:54 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:54 --> URI Class Initialized
INFO - 2016-01-03 09:56:54 --> Router Class Initialized
INFO - 2016-01-03 09:56:54 --> Output Class Initialized
INFO - 2016-01-03 09:56:54 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:54 --> Input Class Initialized
INFO - 2016-01-03 09:56:54 --> Language Class Initialized
INFO - 2016-01-03 09:56:54 --> Loader Class Initialized
INFO - 2016-01-03 09:56:54 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:54 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:54 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:54 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:54 --> Model Class Initialized
INFO - 2016-01-03 09:56:54 --> Model Class Initialized
INFO - 2016-01-03 09:56:54 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:54 --> Total execution time: 0.1048
INFO - 2016-01-03 09:56:55 --> Config Class Initialized
INFO - 2016-01-03 09:56:55 --> Hooks Class Initialized
DEBUG - 2016-01-03 09:56:55 --> UTF-8 Support Enabled
INFO - 2016-01-03 09:56:55 --> Utf8 Class Initialized
INFO - 2016-01-03 09:56:55 --> URI Class Initialized
INFO - 2016-01-03 09:56:55 --> Router Class Initialized
INFO - 2016-01-03 09:56:55 --> Output Class Initialized
INFO - 2016-01-03 09:56:55 --> Security Class Initialized
DEBUG - 2016-01-03 09:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 09:56:55 --> Input Class Initialized
INFO - 2016-01-03 09:56:55 --> Language Class Initialized
INFO - 2016-01-03 09:56:55 --> Loader Class Initialized
INFO - 2016-01-03 09:56:55 --> Helper loaded: url_helper
INFO - 2016-01-03 09:56:55 --> Database Driver Class Initialized
INFO - 2016-01-03 09:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 09:56:55 --> Controller Class Initialized
DEBUG - 2016-01-03 09:56:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 09:56:55 --> Helper loaded: inflector_helper
INFO - 2016-01-03 09:56:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 09:56:55 --> Model Class Initialized
INFO - 2016-01-03 09:56:55 --> Model Class Initialized
INFO - 2016-01-03 09:56:55 --> Final output sent to browser
DEBUG - 2016-01-03 09:56:55 --> Total execution time: 0.1252
INFO - 2016-01-03 22:38:21 --> Config Class Initialized
INFO - 2016-01-03 22:38:21 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:38:21 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:38:21 --> Utf8 Class Initialized
INFO - 2016-01-03 22:38:21 --> URI Class Initialized
INFO - 2016-01-03 22:38:21 --> Router Class Initialized
INFO - 2016-01-03 22:38:21 --> Output Class Initialized
INFO - 2016-01-03 22:38:21 --> Security Class Initialized
DEBUG - 2016-01-03 22:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:38:21 --> Input Class Initialized
INFO - 2016-01-03 22:38:21 --> Language Class Initialized
INFO - 2016-01-03 22:38:21 --> Loader Class Initialized
INFO - 2016-01-03 22:38:21 --> Helper loaded: url_helper
INFO - 2016-01-03 22:38:21 --> Database Driver Class Initialized
INFO - 2016-01-03 22:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:38:21 --> Controller Class Initialized
INFO - 2016-01-03 22:38:21 --> Model Class Initialized
INFO - 2016-01-03 22:38:21 --> Model Class Initialized
ERROR - 2016-01-03 22:38:21 --> Severity: Notice --> Undefined variable: username /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php 30
INFO - 2016-01-03 22:38:21 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:38:21 --> Final output sent to browser
DEBUG - 2016-01-03 22:38:21 --> Total execution time: 0.3422
INFO - 2016-01-03 22:38:21 --> Config Class Initialized
INFO - 2016-01-03 22:38:21 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:38:21 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:38:21 --> Utf8 Class Initialized
INFO - 2016-01-03 22:38:21 --> URI Class Initialized
INFO - 2016-01-03 22:38:21 --> Router Class Initialized
INFO - 2016-01-03 22:38:21 --> Output Class Initialized
INFO - 2016-01-03 22:38:21 --> Security Class Initialized
DEBUG - 2016-01-03 22:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:38:21 --> Input Class Initialized
INFO - 2016-01-03 22:38:21 --> Language Class Initialized
INFO - 2016-01-03 22:38:21 --> Loader Class Initialized
INFO - 2016-01-03 22:38:21 --> Helper loaded: url_helper
INFO - 2016-01-03 22:38:21 --> Database Driver Class Initialized
INFO - 2016-01-03 22:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:38:21 --> Controller Class Initialized
INFO - 2016-01-03 22:38:21 --> Helper loaded: form_helper
INFO - 2016-01-03 22:38:21 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 22:38:21 --> Final output sent to browser
DEBUG - 2016-01-03 22:38:21 --> Total execution time: 0.1116
INFO - 2016-01-03 22:38:33 --> Config Class Initialized
INFO - 2016-01-03 22:38:33 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:38:33 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:38:33 --> Utf8 Class Initialized
INFO - 2016-01-03 22:38:33 --> URI Class Initialized
INFO - 2016-01-03 22:38:33 --> Router Class Initialized
INFO - 2016-01-03 22:38:33 --> Output Class Initialized
INFO - 2016-01-03 22:38:33 --> Security Class Initialized
DEBUG - 2016-01-03 22:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:38:34 --> Input Class Initialized
INFO - 2016-01-03 22:38:34 --> Language Class Initialized
INFO - 2016-01-03 22:38:34 --> Loader Class Initialized
INFO - 2016-01-03 22:38:34 --> Helper loaded: url_helper
INFO - 2016-01-03 22:38:34 --> Database Driver Class Initialized
INFO - 2016-01-03 22:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:38:34 --> Controller Class Initialized
INFO - 2016-01-03 22:38:34 --> Model Class Initialized
INFO - 2016-01-03 22:38:34 --> Model Class Initialized
INFO - 2016-01-03 22:38:34 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:38:34 --> Final output sent to browser
DEBUG - 2016-01-03 22:38:34 --> Total execution time: 0.0984
INFO - 2016-01-03 22:38:34 --> Config Class Initialized
INFO - 2016-01-03 22:38:34 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:38:34 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:38:34 --> Utf8 Class Initialized
INFO - 2016-01-03 22:38:34 --> URI Class Initialized
INFO - 2016-01-03 22:38:34 --> Router Class Initialized
INFO - 2016-01-03 22:38:34 --> Output Class Initialized
INFO - 2016-01-03 22:38:34 --> Security Class Initialized
DEBUG - 2016-01-03 22:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:38:34 --> Input Class Initialized
INFO - 2016-01-03 22:38:34 --> Language Class Initialized
INFO - 2016-01-03 22:38:34 --> Loader Class Initialized
INFO - 2016-01-03 22:38:34 --> Helper loaded: url_helper
INFO - 2016-01-03 22:38:34 --> Database Driver Class Initialized
INFO - 2016-01-03 22:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:38:34 --> Controller Class Initialized
INFO - 2016-01-03 22:38:34 --> Model Class Initialized
INFO - 2016-01-03 22:38:34 --> Model Class Initialized
INFO - 2016-01-03 22:38:34 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 22:38:34 --> Final output sent to browser
DEBUG - 2016-01-03 22:38:34 --> Total execution time: 0.0934
INFO - 2016-01-03 22:38:34 --> Config Class Initialized
INFO - 2016-01-03 22:38:34 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:38:34 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:38:34 --> Utf8 Class Initialized
INFO - 2016-01-03 22:38:34 --> URI Class Initialized
INFO - 2016-01-03 22:38:34 --> Router Class Initialized
INFO - 2016-01-03 22:38:34 --> Output Class Initialized
INFO - 2016-01-03 22:38:34 --> Security Class Initialized
DEBUG - 2016-01-03 22:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:38:34 --> Input Class Initialized
INFO - 2016-01-03 22:38:34 --> Language Class Initialized
INFO - 2016-01-03 22:38:34 --> Loader Class Initialized
INFO - 2016-01-03 22:38:34 --> Helper loaded: url_helper
INFO - 2016-01-03 22:38:34 --> Database Driver Class Initialized
INFO - 2016-01-03 22:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:38:34 --> Controller Class Initialized
DEBUG - 2016-01-03 22:38:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:38:34 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:38:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:38:34 --> Model Class Initialized
INFO - 2016-01-03 22:38:34 --> Model Class Initialized
INFO - 2016-01-03 22:38:34 --> Final output sent to browser
DEBUG - 2016-01-03 22:38:34 --> Total execution time: 0.1531
INFO - 2016-01-03 22:38:39 --> Config Class Initialized
INFO - 2016-01-03 22:38:39 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:38:39 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:38:39 --> Utf8 Class Initialized
INFO - 2016-01-03 22:38:39 --> URI Class Initialized
INFO - 2016-01-03 22:38:39 --> Router Class Initialized
INFO - 2016-01-03 22:38:39 --> Output Class Initialized
INFO - 2016-01-03 22:38:39 --> Security Class Initialized
DEBUG - 2016-01-03 22:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:38:39 --> Input Class Initialized
INFO - 2016-01-03 22:38:39 --> Language Class Initialized
INFO - 2016-01-03 22:38:39 --> Loader Class Initialized
INFO - 2016-01-03 22:38:39 --> Helper loaded: url_helper
INFO - 2016-01-03 22:38:39 --> Database Driver Class Initialized
INFO - 2016-01-03 22:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:38:39 --> Controller Class Initialized
DEBUG - 2016-01-03 22:38:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:38:39 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:38:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:38:39 --> Model Class Initialized
INFO - 2016-01-03 22:38:39 --> Model Class Initialized
INFO - 2016-01-03 22:38:39 --> Final output sent to browser
DEBUG - 2016-01-03 22:38:39 --> Total execution time: 0.0895
INFO - 2016-01-03 22:39:34 --> Config Class Initialized
INFO - 2016-01-03 22:39:34 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:39:34 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:39:34 --> Utf8 Class Initialized
INFO - 2016-01-03 22:39:34 --> URI Class Initialized
INFO - 2016-01-03 22:39:34 --> Router Class Initialized
INFO - 2016-01-03 22:39:34 --> Output Class Initialized
INFO - 2016-01-03 22:39:34 --> Security Class Initialized
DEBUG - 2016-01-03 22:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:39:34 --> Input Class Initialized
INFO - 2016-01-03 22:39:34 --> Language Class Initialized
INFO - 2016-01-03 22:39:34 --> Loader Class Initialized
INFO - 2016-01-03 22:39:34 --> Helper loaded: url_helper
INFO - 2016-01-03 22:39:34 --> Database Driver Class Initialized
INFO - 2016-01-03 22:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:39:34 --> Controller Class Initialized
INFO - 2016-01-03 22:39:34 --> Model Class Initialized
INFO - 2016-01-03 22:39:34 --> Model Class Initialized
INFO - 2016-01-03 22:39:34 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:39:34 --> Final output sent to browser
DEBUG - 2016-01-03 22:39:34 --> Total execution time: 0.1879
INFO - 2016-01-03 22:39:34 --> Config Class Initialized
INFO - 2016-01-03 22:39:34 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:39:34 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:39:34 --> Utf8 Class Initialized
INFO - 2016-01-03 22:39:34 --> URI Class Initialized
INFO - 2016-01-03 22:39:34 --> Router Class Initialized
INFO - 2016-01-03 22:39:34 --> Output Class Initialized
INFO - 2016-01-03 22:39:34 --> Security Class Initialized
DEBUG - 2016-01-03 22:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:39:34 --> Input Class Initialized
INFO - 2016-01-03 22:39:34 --> Language Class Initialized
INFO - 2016-01-03 22:39:34 --> Loader Class Initialized
INFO - 2016-01-03 22:39:34 --> Helper loaded: url_helper
INFO - 2016-01-03 22:39:34 --> Database Driver Class Initialized
INFO - 2016-01-03 22:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:39:34 --> Controller Class Initialized
INFO - 2016-01-03 22:39:34 --> Model Class Initialized
INFO - 2016-01-03 22:39:34 --> Model Class Initialized
INFO - 2016-01-03 22:39:34 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:39:34 --> Final output sent to browser
DEBUG - 2016-01-03 22:39:34 --> Total execution time: 0.1164
INFO - 2016-01-03 22:39:35 --> Config Class Initialized
INFO - 2016-01-03 22:39:35 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:39:35 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:39:35 --> Utf8 Class Initialized
INFO - 2016-01-03 22:39:35 --> URI Class Initialized
INFO - 2016-01-03 22:39:35 --> Router Class Initialized
INFO - 2016-01-03 22:39:35 --> Output Class Initialized
INFO - 2016-01-03 22:39:35 --> Security Class Initialized
DEBUG - 2016-01-03 22:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:39:35 --> Input Class Initialized
INFO - 2016-01-03 22:39:35 --> Language Class Initialized
INFO - 2016-01-03 22:39:35 --> Loader Class Initialized
INFO - 2016-01-03 22:39:35 --> Helper loaded: url_helper
INFO - 2016-01-03 22:39:35 --> Database Driver Class Initialized
INFO - 2016-01-03 22:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:39:35 --> Controller Class Initialized
DEBUG - 2016-01-03 22:39:35 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:39:35 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:39:35 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:39:35 --> Model Class Initialized
INFO - 2016-01-03 22:39:35 --> Model Class Initialized
INFO - 2016-01-03 22:39:35 --> Final output sent to browser
DEBUG - 2016-01-03 22:39:35 --> Total execution time: 0.1498
INFO - 2016-01-03 22:39:38 --> Config Class Initialized
INFO - 2016-01-03 22:39:39 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:39:39 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:39:39 --> Utf8 Class Initialized
INFO - 2016-01-03 22:39:39 --> URI Class Initialized
INFO - 2016-01-03 22:39:39 --> Router Class Initialized
INFO - 2016-01-03 22:39:39 --> Output Class Initialized
INFO - 2016-01-03 22:39:39 --> Security Class Initialized
DEBUG - 2016-01-03 22:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:39:39 --> Input Class Initialized
INFO - 2016-01-03 22:39:39 --> Language Class Initialized
INFO - 2016-01-03 22:39:39 --> Loader Class Initialized
INFO - 2016-01-03 22:39:39 --> Helper loaded: url_helper
INFO - 2016-01-03 22:39:39 --> Database Driver Class Initialized
INFO - 2016-01-03 22:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:39:39 --> Controller Class Initialized
DEBUG - 2016-01-03 22:39:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:39:39 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:39:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:39:39 --> Model Class Initialized
INFO - 2016-01-03 22:39:39 --> Model Class Initialized
INFO - 2016-01-03 22:39:39 --> Final output sent to browser
DEBUG - 2016-01-03 22:39:39 --> Total execution time: 0.0731
INFO - 2016-01-03 22:40:09 --> Config Class Initialized
INFO - 2016-01-03 22:40:09 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:40:09 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:40:09 --> Utf8 Class Initialized
INFO - 2016-01-03 22:40:09 --> URI Class Initialized
INFO - 2016-01-03 22:40:09 --> Router Class Initialized
INFO - 2016-01-03 22:40:09 --> Output Class Initialized
INFO - 2016-01-03 22:40:09 --> Security Class Initialized
DEBUG - 2016-01-03 22:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:40:09 --> Input Class Initialized
INFO - 2016-01-03 22:40:09 --> Language Class Initialized
INFO - 2016-01-03 22:40:09 --> Loader Class Initialized
INFO - 2016-01-03 22:40:09 --> Helper loaded: url_helper
INFO - 2016-01-03 22:40:09 --> Database Driver Class Initialized
INFO - 2016-01-03 22:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:40:09 --> Controller Class Initialized
INFO - 2016-01-03 22:40:09 --> Model Class Initialized
INFO - 2016-01-03 22:40:09 --> Model Class Initialized
INFO - 2016-01-03 22:40:09 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:40:10 --> Final output sent to browser
DEBUG - 2016-01-03 22:40:10 --> Total execution time: 0.1721
INFO - 2016-01-03 22:40:10 --> Config Class Initialized
INFO - 2016-01-03 22:40:10 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:40:10 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:40:10 --> Utf8 Class Initialized
INFO - 2016-01-03 22:40:10 --> URI Class Initialized
INFO - 2016-01-03 22:40:10 --> Router Class Initialized
INFO - 2016-01-03 22:40:10 --> Output Class Initialized
INFO - 2016-01-03 22:40:10 --> Security Class Initialized
DEBUG - 2016-01-03 22:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:40:10 --> Input Class Initialized
INFO - 2016-01-03 22:40:10 --> Language Class Initialized
INFO - 2016-01-03 22:40:10 --> Loader Class Initialized
INFO - 2016-01-03 22:40:10 --> Helper loaded: url_helper
INFO - 2016-01-03 22:40:10 --> Database Driver Class Initialized
INFO - 2016-01-03 22:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:40:10 --> Controller Class Initialized
INFO - 2016-01-03 22:40:10 --> Model Class Initialized
INFO - 2016-01-03 22:40:10 --> Model Class Initialized
INFO - 2016-01-03 22:40:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:40:10 --> Final output sent to browser
DEBUG - 2016-01-03 22:40:10 --> Total execution time: 0.1115
INFO - 2016-01-03 22:40:10 --> Config Class Initialized
INFO - 2016-01-03 22:40:10 --> Hooks Class Initialized
INFO - 2016-01-03 22:40:10 --> Config Class Initialized
DEBUG - 2016-01-03 22:40:10 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:40:10 --> Hooks Class Initialized
INFO - 2016-01-03 22:40:10 --> Utf8 Class Initialized
INFO - 2016-01-03 22:40:10 --> URI Class Initialized
DEBUG - 2016-01-03 22:40:10 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:40:10 --> Router Class Initialized
INFO - 2016-01-03 22:40:14 --> Config Class Initialized
INFO - 2016-01-03 22:40:15 --> Config Class Initialized
INFO - 2016-01-03 22:40:20 --> Config Class Initialized
INFO - 2016-01-03 22:40:22 --> Config Class Initialized
INFO - 2016-01-03 22:40:29 --> Config Class Initialized
INFO - 2016-01-03 22:40:32 --> Config Class Initialized
INFO - 2016-01-03 22:40:37 --> Config Class Initialized
INFO - 2016-01-03 22:40:40 --> Utf8 Class Initialized
INFO - 2016-01-03 22:40:40 --> Output Class Initialized
INFO - 2016-01-03 22:40:43 --> Config Class Initialized
INFO - 2016-01-03 22:40:44 --> Hooks Class Initialized
INFO - 2016-01-03 22:40:45 --> Hooks Class Initialized
INFO - 2016-01-03 22:40:50 --> Hooks Class Initialized
INFO - 2016-01-03 22:40:52 --> Hooks Class Initialized
INFO - 2016-01-03 22:40:59 --> Hooks Class Initialized
INFO - 2016-01-03 22:41:02 --> Hooks Class Initialized
INFO - 2016-01-03 22:41:07 --> Hooks Class Initialized
INFO - 2016-01-03 22:41:10 --> URI Class Initialized
INFO - 2016-01-03 22:41:10 --> Security Class Initialized
INFO - 2016-01-03 22:41:13 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:41:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-03 22:41:15 --> UTF-8 Support Enabled
DEBUG - 2016-01-03 22:41:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-03 22:41:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-03 22:41:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-03 22:41:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-03 22:41:37 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:41:40 --> Router Class Initialized
DEBUG - 2016-01-03 22:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-01-03 22:41:43 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:41:44 --> Utf8 Class Initialized
INFO - 2016-01-03 22:41:45 --> Utf8 Class Initialized
INFO - 2016-01-03 22:41:50 --> Utf8 Class Initialized
INFO - 2016-01-03 22:41:52 --> Utf8 Class Initialized
INFO - 2016-01-03 22:41:59 --> Utf8 Class Initialized
INFO - 2016-01-03 22:42:02 --> Utf8 Class Initialized
INFO - 2016-01-03 22:42:07 --> Utf8 Class Initialized
INFO - 2016-01-03 22:42:10 --> Output Class Initialized
INFO - 2016-01-03 22:42:10 --> Input Class Initialized
INFO - 2016-01-03 22:42:13 --> Utf8 Class Initialized
INFO - 2016-01-03 22:42:14 --> URI Class Initialized
INFO - 2016-01-03 22:42:15 --> URI Class Initialized
INFO - 2016-01-03 22:42:20 --> URI Class Initialized
INFO - 2016-01-03 22:42:22 --> URI Class Initialized
INFO - 2016-01-03 22:42:29 --> URI Class Initialized
INFO - 2016-01-03 22:42:32 --> URI Class Initialized
INFO - 2016-01-03 22:42:37 --> URI Class Initialized
INFO - 2016-01-03 22:42:40 --> Security Class Initialized
INFO - 2016-01-03 22:43:10 --> Language Class Initialized
INFO - 2016-01-03 22:43:13 --> URI Class Initialized
INFO - 2016-01-03 22:43:14 --> Router Class Initialized
INFO - 2016-01-03 22:43:15 --> Router Class Initialized
INFO - 2016-01-03 22:43:20 --> Router Class Initialized
INFO - 2016-01-03 22:43:22 --> Router Class Initialized
INFO - 2016-01-03 22:43:29 --> Router Class Initialized
INFO - 2016-01-03 22:43:32 --> Router Class Initialized
INFO - 2016-01-03 22:43:37 --> Router Class Initialized
DEBUG - 2016-01-03 22:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:43:40 --> Loader Class Initialized
INFO - 2016-01-03 22:43:43 --> Router Class Initialized
INFO - 2016-01-03 22:43:44 --> Output Class Initialized
INFO - 2016-01-03 22:43:45 --> Output Class Initialized
INFO - 2016-01-03 22:43:50 --> Output Class Initialized
INFO - 2016-01-03 22:43:52 --> Output Class Initialized
INFO - 2016-01-03 22:43:59 --> Output Class Initialized
INFO - 2016-01-03 22:44:02 --> Output Class Initialized
INFO - 2016-01-03 22:44:07 --> Output Class Initialized
INFO - 2016-01-03 22:44:10 --> Input Class Initialized
INFO - 2016-01-03 22:44:10 --> Helper loaded: url_helper
INFO - 2016-01-03 22:44:13 --> Output Class Initialized
INFO - 2016-01-03 22:44:14 --> Security Class Initialized
INFO - 2016-01-03 22:44:15 --> Security Class Initialized
INFO - 2016-01-03 22:44:20 --> Security Class Initialized
INFO - 2016-01-03 22:44:22 --> Security Class Initialized
INFO - 2016-01-03 22:44:29 --> Security Class Initialized
INFO - 2016-01-03 22:44:32 --> Security Class Initialized
INFO - 2016-01-03 22:44:37 --> Security Class Initialized
INFO - 2016-01-03 22:44:40 --> Language Class Initialized
INFO - 2016-01-03 22:44:40 --> Database Driver Class Initialized
INFO - 2016-01-03 22:44:43 --> Security Class Initialized
DEBUG - 2016-01-03 22:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-01-03 22:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-01-03 22:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-01-03 22:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-01-03 22:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-01-03 22:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-01-03 22:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:45:10 --> Loader Class Initialized
INFO - 2016-01-03 22:45:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-01-03 22:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:45:14 --> Input Class Initialized
INFO - 2016-01-03 22:45:15 --> Input Class Initialized
INFO - 2016-01-03 22:45:20 --> Input Class Initialized
INFO - 2016-01-03 22:45:22 --> Input Class Initialized
INFO - 2016-01-03 22:45:29 --> Input Class Initialized
INFO - 2016-01-03 22:45:32 --> Input Class Initialized
INFO - 2016-01-03 22:45:37 --> Input Class Initialized
INFO - 2016-01-03 22:45:40 --> Helper loaded: url_helper
INFO - 2016-01-03 22:45:40 --> Controller Class Initialized
INFO - 2016-01-03 22:45:43 --> Input Class Initialized
INFO - 2016-01-03 22:45:44 --> Language Class Initialized
INFO - 2016-01-03 22:45:45 --> Language Class Initialized
INFO - 2016-01-03 22:45:50 --> Language Class Initialized
INFO - 2016-01-03 22:45:52 --> Language Class Initialized
INFO - 2016-01-03 22:45:59 --> Language Class Initialized
INFO - 2016-01-03 22:46:02 --> Language Class Initialized
INFO - 2016-01-03 22:46:07 --> Language Class Initialized
INFO - 2016-01-03 22:46:10 --> Database Driver Class Initialized
INFO - 2016-01-03 22:46:10 --> Model Class Initialized
INFO - 2016-01-03 22:46:13 --> Language Class Initialized
INFO - 2016-01-03 22:46:14 --> Loader Class Initialized
INFO - 2016-01-03 22:46:15 --> Loader Class Initialized
INFO - 2016-01-03 22:46:20 --> Loader Class Initialized
INFO - 2016-01-03 22:46:22 --> Loader Class Initialized
INFO - 2016-01-03 22:46:29 --> Loader Class Initialized
INFO - 2016-01-03 22:46:32 --> Loader Class Initialized
INFO - 2016-01-03 22:46:37 --> Loader Class Initialized
INFO - 2016-01-03 22:46:40 --> Model Class Initialized
INFO - 2016-01-03 22:46:43 --> Loader Class Initialized
INFO - 2016-01-03 22:46:44 --> Helper loaded: url_helper
INFO - 2016-01-03 22:46:45 --> Helper loaded: url_helper
INFO - 2016-01-03 22:46:50 --> Helper loaded: url_helper
INFO - 2016-01-03 22:46:52 --> Helper loaded: url_helper
INFO - 2016-01-03 22:46:59 --> Helper loaded: url_helper
INFO - 2016-01-03 22:47:02 --> Helper loaded: url_helper
INFO - 2016-01-03 22:47:07 --> Helper loaded: url_helper
INFO - 2016-01-03 22:47:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:47:13 --> Helper loaded: url_helper
INFO - 2016-01-03 22:47:14 --> Database Driver Class Initialized
INFO - 2016-01-03 22:47:15 --> Database Driver Class Initialized
INFO - 2016-01-03 22:47:20 --> Database Driver Class Initialized
INFO - 2016-01-03 22:47:22 --> Database Driver Class Initialized
INFO - 2016-01-03 22:47:29 --> Database Driver Class Initialized
INFO - 2016-01-03 22:47:32 --> Database Driver Class Initialized
INFO - 2016-01-03 22:47:37 --> Database Driver Class Initialized
INFO - 2016-01-03 22:47:40 --> Final output sent to browser
INFO - 2016-01-03 22:47:43 --> Database Driver Class Initialized
DEBUG - 2016-01-03 22:48:10 --> Total execution time: 450.1562
INFO - 2016-01-03 22:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:48:40 --> Controller Class Initialized
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:48:40 --> Final output sent to browser
DEBUG - 2016-01-03 22:48:40 --> Total execution time: 477.1878
INFO - 2016-01-03 22:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:48:40 --> Controller Class Initialized
DEBUG - 2016-01-03 22:48:40 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:48:40 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:48:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> Final output sent to browser
DEBUG - 2016-01-03 22:48:40 --> Total execution time: 510.2570
INFO - 2016-01-03 22:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:48:40 --> Controller Class Initialized
INFO - 2016-01-03 22:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:48:40 --> Controller Class Initialized
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:48:40 --> Final output sent to browser
DEBUG - 2016-01-03 22:48:40 --> Total execution time: 498.4084
INFO - 2016-01-03 22:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:48:40 --> Controller Class Initialized
INFO - 2016-01-03 22:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:48:40 --> Controller Class Initialized
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:48:40 --> Final output sent to browser
DEBUG - 2016-01-03 22:48:40 --> Total execution time: 490.9866
INFO - 2016-01-03 22:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:48:40 --> Controller Class Initialized
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:48:40 --> Final output sent to browser
DEBUG - 2016-01-03 22:48:40 --> Total execution time: 500.6653
INFO - 2016-01-03 22:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:48:40 --> Controller Class Initialized
INFO - 2016-01-03 22:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:48:40 --> Controller Class Initialized
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> Model Class Initialized
INFO - 2016-01-03 22:48:40 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-03 22:48:40 --> Final output sent to browser
DEBUG - 2016-01-03 22:48:40 --> Total execution time: 483.0242
INFO - 2016-01-03 22:50:10 --> Config Class Initialized
INFO - 2016-01-03 22:50:10 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:50:10 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:50:10 --> Utf8 Class Initialized
INFO - 2016-01-03 22:50:10 --> URI Class Initialized
DEBUG - 2016-01-03 22:50:10 --> No URI present. Default controller set.
INFO - 2016-01-03 22:50:10 --> Router Class Initialized
INFO - 2016-01-03 22:50:10 --> Output Class Initialized
INFO - 2016-01-03 22:50:10 --> Security Class Initialized
DEBUG - 2016-01-03 22:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:50:10 --> Input Class Initialized
INFO - 2016-01-03 22:50:10 --> Language Class Initialized
INFO - 2016-01-03 22:50:10 --> Loader Class Initialized
INFO - 2016-01-03 22:50:10 --> Helper loaded: url_helper
INFO - 2016-01-03 22:50:10 --> Database Driver Class Initialized
INFO - 2016-01-03 22:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:50:10 --> Controller Class Initialized
INFO - 2016-01-03 22:50:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 22:50:10 --> Final output sent to browser
DEBUG - 2016-01-03 22:50:10 --> Total execution time: 0.1335
INFO - 2016-01-03 22:50:50 --> Config Class Initialized
INFO - 2016-01-03 22:50:50 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:50:50 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:50:50 --> Utf8 Class Initialized
INFO - 2016-01-03 22:50:50 --> URI Class Initialized
INFO - 2016-01-03 22:50:50 --> Router Class Initialized
INFO - 2016-01-03 22:50:50 --> Output Class Initialized
INFO - 2016-01-03 22:50:50 --> Security Class Initialized
DEBUG - 2016-01-03 22:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:50:50 --> Input Class Initialized
INFO - 2016-01-03 22:50:50 --> Language Class Initialized
INFO - 2016-01-03 22:50:50 --> Loader Class Initialized
INFO - 2016-01-03 22:50:50 --> Helper loaded: url_helper
INFO - 2016-01-03 22:50:50 --> Database Driver Class Initialized
INFO - 2016-01-03 22:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:50:50 --> Controller Class Initialized
INFO - 2016-01-03 22:50:50 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 22:50:50 --> Final output sent to browser
DEBUG - 2016-01-03 22:50:50 --> Total execution time: 0.1397
INFO - 2016-01-03 22:50:50 --> Config Class Initialized
INFO - 2016-01-03 22:50:50 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:50:50 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:50:50 --> Utf8 Class Initialized
INFO - 2016-01-03 22:50:50 --> URI Class Initialized
INFO - 2016-01-03 22:50:50 --> Router Class Initialized
INFO - 2016-01-03 22:50:50 --> Output Class Initialized
INFO - 2016-01-03 22:50:50 --> Security Class Initialized
DEBUG - 2016-01-03 22:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:50:50 --> Input Class Initialized
INFO - 2016-01-03 22:50:50 --> Language Class Initialized
INFO - 2016-01-03 22:50:50 --> Loader Class Initialized
INFO - 2016-01-03 22:50:50 --> Helper loaded: url_helper
INFO - 2016-01-03 22:50:50 --> Database Driver Class Initialized
INFO - 2016-01-03 22:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:50:50 --> Controller Class Initialized
DEBUG - 2016-01-03 22:50:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:50:50 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:50:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:50:50 --> Model Class Initialized
INFO - 2016-01-03 22:50:50 --> Model Class Initialized
INFO - 2016-01-03 22:50:50 --> Final output sent to browser
DEBUG - 2016-01-03 22:50:50 --> Total execution time: 0.1666
INFO - 2016-01-03 22:50:53 --> Config Class Initialized
INFO - 2016-01-03 22:50:53 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:50:53 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:50:53 --> Utf8 Class Initialized
INFO - 2016-01-03 22:50:53 --> URI Class Initialized
DEBUG - 2016-01-03 22:50:53 --> No URI present. Default controller set.
INFO - 2016-01-03 22:50:53 --> Router Class Initialized
INFO - 2016-01-03 22:50:53 --> Output Class Initialized
INFO - 2016-01-03 22:50:53 --> Security Class Initialized
DEBUG - 2016-01-03 22:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:50:53 --> Input Class Initialized
INFO - 2016-01-03 22:50:53 --> Language Class Initialized
INFO - 2016-01-03 22:50:53 --> Loader Class Initialized
INFO - 2016-01-03 22:50:53 --> Helper loaded: url_helper
INFO - 2016-01-03 22:50:53 --> Database Driver Class Initialized
INFO - 2016-01-03 22:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:50:53 --> Controller Class Initialized
INFO - 2016-01-03 22:50:53 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 22:50:53 --> Final output sent to browser
DEBUG - 2016-01-03 22:50:53 --> Total execution time: 0.0839
INFO - 2016-01-03 22:50:54 --> Config Class Initialized
INFO - 2016-01-03 22:50:54 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:50:54 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:50:54 --> Utf8 Class Initialized
INFO - 2016-01-03 22:50:54 --> URI Class Initialized
INFO - 2016-01-03 22:50:54 --> Router Class Initialized
INFO - 2016-01-03 22:50:54 --> Output Class Initialized
INFO - 2016-01-03 22:50:54 --> Security Class Initialized
DEBUG - 2016-01-03 22:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:50:54 --> Input Class Initialized
INFO - 2016-01-03 22:50:54 --> Language Class Initialized
INFO - 2016-01-03 22:50:54 --> Loader Class Initialized
INFO - 2016-01-03 22:50:54 --> Helper loaded: url_helper
INFO - 2016-01-03 22:50:54 --> Database Driver Class Initialized
INFO - 2016-01-03 22:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:50:54 --> Controller Class Initialized
INFO - 2016-01-03 22:50:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 22:50:54 --> Final output sent to browser
DEBUG - 2016-01-03 22:50:54 --> Total execution time: 0.0618
INFO - 2016-01-03 22:50:54 --> Config Class Initialized
INFO - 2016-01-03 22:50:54 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:50:54 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:50:54 --> Utf8 Class Initialized
INFO - 2016-01-03 22:50:54 --> URI Class Initialized
INFO - 2016-01-03 22:50:54 --> Router Class Initialized
INFO - 2016-01-03 22:50:54 --> Output Class Initialized
INFO - 2016-01-03 22:50:54 --> Security Class Initialized
DEBUG - 2016-01-03 22:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:50:54 --> Input Class Initialized
INFO - 2016-01-03 22:50:54 --> Language Class Initialized
INFO - 2016-01-03 22:50:54 --> Loader Class Initialized
INFO - 2016-01-03 22:50:54 --> Helper loaded: url_helper
INFO - 2016-01-03 22:50:54 --> Database Driver Class Initialized
INFO - 2016-01-03 22:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:50:54 --> Controller Class Initialized
DEBUG - 2016-01-03 22:50:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:50:54 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:50:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:50:54 --> Model Class Initialized
INFO - 2016-01-03 22:50:54 --> Model Class Initialized
INFO - 2016-01-03 22:50:54 --> Final output sent to browser
DEBUG - 2016-01-03 22:50:54 --> Total execution time: 0.0675
INFO - 2016-01-03 22:50:56 --> Config Class Initialized
INFO - 2016-01-03 22:50:56 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:50:56 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:50:56 --> Utf8 Class Initialized
INFO - 2016-01-03 22:50:56 --> URI Class Initialized
INFO - 2016-01-03 22:50:56 --> Router Class Initialized
INFO - 2016-01-03 22:50:56 --> Output Class Initialized
INFO - 2016-01-03 22:50:56 --> Security Class Initialized
DEBUG - 2016-01-03 22:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:50:56 --> Input Class Initialized
INFO - 2016-01-03 22:50:56 --> Language Class Initialized
INFO - 2016-01-03 22:50:56 --> Loader Class Initialized
INFO - 2016-01-03 22:50:56 --> Helper loaded: url_helper
INFO - 2016-01-03 22:50:56 --> Database Driver Class Initialized
INFO - 2016-01-03 22:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:50:56 --> Controller Class Initialized
DEBUG - 2016-01-03 22:50:56 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:50:56 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:50:56 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:50:56 --> Model Class Initialized
INFO - 2016-01-03 22:50:56 --> Model Class Initialized
INFO - 2016-01-03 22:50:56 --> Final output sent to browser
DEBUG - 2016-01-03 22:50:56 --> Total execution time: 0.0701
INFO - 2016-01-03 22:50:57 --> Config Class Initialized
INFO - 2016-01-03 22:50:57 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:50:57 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:50:57 --> Utf8 Class Initialized
INFO - 2016-01-03 22:50:57 --> URI Class Initialized
INFO - 2016-01-03 22:50:57 --> Router Class Initialized
INFO - 2016-01-03 22:50:57 --> Output Class Initialized
INFO - 2016-01-03 22:50:57 --> Security Class Initialized
DEBUG - 2016-01-03 22:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:50:57 --> Input Class Initialized
INFO - 2016-01-03 22:50:57 --> Language Class Initialized
INFO - 2016-01-03 22:50:57 --> Loader Class Initialized
INFO - 2016-01-03 22:50:57 --> Helper loaded: url_helper
INFO - 2016-01-03 22:50:57 --> Database Driver Class Initialized
INFO - 2016-01-03 22:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:50:57 --> Controller Class Initialized
DEBUG - 2016-01-03 22:50:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:50:57 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:50:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:50:57 --> Model Class Initialized
INFO - 2016-01-03 22:50:57 --> Model Class Initialized
INFO - 2016-01-03 22:50:57 --> Final output sent to browser
DEBUG - 2016-01-03 22:50:57 --> Total execution time: 0.1036
INFO - 2016-01-03 22:50:59 --> Config Class Initialized
INFO - 2016-01-03 22:50:59 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:50:59 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:50:59 --> Utf8 Class Initialized
INFO - 2016-01-03 22:50:59 --> URI Class Initialized
INFO - 2016-01-03 22:50:59 --> Router Class Initialized
INFO - 2016-01-03 22:50:59 --> Output Class Initialized
INFO - 2016-01-03 22:50:59 --> Security Class Initialized
DEBUG - 2016-01-03 22:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:50:59 --> Input Class Initialized
INFO - 2016-01-03 22:50:59 --> Language Class Initialized
INFO - 2016-01-03 22:50:59 --> Loader Class Initialized
INFO - 2016-01-03 22:50:59 --> Helper loaded: url_helper
INFO - 2016-01-03 22:50:59 --> Database Driver Class Initialized
INFO - 2016-01-03 22:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:50:59 --> Controller Class Initialized
DEBUG - 2016-01-03 22:50:59 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:50:59 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:50:59 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:50:59 --> Model Class Initialized
INFO - 2016-01-03 22:50:59 --> Model Class Initialized
INFO - 2016-01-03 22:50:59 --> Final output sent to browser
DEBUG - 2016-01-03 22:50:59 --> Total execution time: 0.0675
INFO - 2016-01-03 22:51:00 --> Config Class Initialized
INFO - 2016-01-03 22:51:00 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:00 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:00 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:00 --> URI Class Initialized
INFO - 2016-01-03 22:51:00 --> Router Class Initialized
INFO - 2016-01-03 22:51:00 --> Output Class Initialized
INFO - 2016-01-03 22:51:00 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:00 --> Input Class Initialized
INFO - 2016-01-03 22:51:00 --> Language Class Initialized
INFO - 2016-01-03 22:51:00 --> Loader Class Initialized
INFO - 2016-01-03 22:51:00 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:00 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:00 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:00 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:00 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:00 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:00 --> Model Class Initialized
INFO - 2016-01-03 22:51:00 --> Model Class Initialized
INFO - 2016-01-03 22:51:00 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:00 --> Total execution time: 0.0638
INFO - 2016-01-03 22:51:02 --> Config Class Initialized
INFO - 2016-01-03 22:51:02 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:02 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:02 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:02 --> URI Class Initialized
INFO - 2016-01-03 22:51:02 --> Router Class Initialized
INFO - 2016-01-03 22:51:02 --> Output Class Initialized
INFO - 2016-01-03 22:51:02 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:02 --> Input Class Initialized
INFO - 2016-01-03 22:51:02 --> Language Class Initialized
INFO - 2016-01-03 22:51:02 --> Loader Class Initialized
INFO - 2016-01-03 22:51:02 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:02 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:02 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:02 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:02 --> Model Class Initialized
INFO - 2016-01-03 22:51:02 --> Model Class Initialized
INFO - 2016-01-03 22:51:02 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:02 --> Total execution time: 0.1113
INFO - 2016-01-03 22:51:03 --> Config Class Initialized
INFO - 2016-01-03 22:51:03 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:03 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:03 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:03 --> URI Class Initialized
INFO - 2016-01-03 22:51:03 --> Router Class Initialized
INFO - 2016-01-03 22:51:03 --> Output Class Initialized
INFO - 2016-01-03 22:51:03 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:03 --> Input Class Initialized
INFO - 2016-01-03 22:51:03 --> Language Class Initialized
INFO - 2016-01-03 22:51:03 --> Loader Class Initialized
INFO - 2016-01-03 22:51:03 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:03 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:03 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:03 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:03 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:03 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:03 --> Model Class Initialized
INFO - 2016-01-03 22:51:03 --> Model Class Initialized
INFO - 2016-01-03 22:51:03 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:03 --> Total execution time: 0.1016
INFO - 2016-01-03 22:51:05 --> Config Class Initialized
INFO - 2016-01-03 22:51:05 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:05 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:05 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:05 --> URI Class Initialized
INFO - 2016-01-03 22:51:05 --> Router Class Initialized
INFO - 2016-01-03 22:51:05 --> Output Class Initialized
INFO - 2016-01-03 22:51:05 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:05 --> Input Class Initialized
INFO - 2016-01-03 22:51:05 --> Language Class Initialized
INFO - 2016-01-03 22:51:05 --> Loader Class Initialized
INFO - 2016-01-03 22:51:05 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:05 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:05 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:05 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:05 --> Model Class Initialized
INFO - 2016-01-03 22:51:05 --> Model Class Initialized
INFO - 2016-01-03 22:51:05 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:05 --> Total execution time: 0.1138
INFO - 2016-01-03 22:51:05 --> Config Class Initialized
INFO - 2016-01-03 22:51:05 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:05 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:05 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:05 --> URI Class Initialized
INFO - 2016-01-03 22:51:05 --> Router Class Initialized
INFO - 2016-01-03 22:51:05 --> Output Class Initialized
INFO - 2016-01-03 22:51:05 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:05 --> Input Class Initialized
INFO - 2016-01-03 22:51:05 --> Language Class Initialized
INFO - 2016-01-03 22:51:05 --> Loader Class Initialized
INFO - 2016-01-03 22:51:05 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:05 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:05 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:05 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:05 --> Model Class Initialized
INFO - 2016-01-03 22:51:05 --> Model Class Initialized
INFO - 2016-01-03 22:51:05 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:05 --> Total execution time: 0.1113
INFO - 2016-01-03 22:51:07 --> Config Class Initialized
INFO - 2016-01-03 22:51:07 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:07 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:07 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:07 --> URI Class Initialized
INFO - 2016-01-03 22:51:07 --> Router Class Initialized
INFO - 2016-01-03 22:51:07 --> Output Class Initialized
INFO - 2016-01-03 22:51:07 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:07 --> Input Class Initialized
INFO - 2016-01-03 22:51:07 --> Language Class Initialized
INFO - 2016-01-03 22:51:07 --> Loader Class Initialized
INFO - 2016-01-03 22:51:07 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:07 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:07 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:07 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:07 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:07 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:07 --> Model Class Initialized
INFO - 2016-01-03 22:51:07 --> Model Class Initialized
INFO - 2016-01-03 22:51:07 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:07 --> Total execution time: 0.0638
INFO - 2016-01-03 22:51:07 --> Config Class Initialized
INFO - 2016-01-03 22:51:07 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:07 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:07 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:07 --> URI Class Initialized
INFO - 2016-01-03 22:51:07 --> Router Class Initialized
INFO - 2016-01-03 22:51:07 --> Output Class Initialized
INFO - 2016-01-03 22:51:07 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:07 --> Input Class Initialized
INFO - 2016-01-03 22:51:07 --> Language Class Initialized
INFO - 2016-01-03 22:51:08 --> Loader Class Initialized
INFO - 2016-01-03 22:51:08 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:08 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:08 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:08 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:08 --> Model Class Initialized
INFO - 2016-01-03 22:51:08 --> Model Class Initialized
INFO - 2016-01-03 22:51:08 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:08 --> Total execution time: 0.1093
INFO - 2016-01-03 22:51:12 --> Config Class Initialized
INFO - 2016-01-03 22:51:12 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:12 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:12 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:12 --> URI Class Initialized
INFO - 2016-01-03 22:51:12 --> Router Class Initialized
INFO - 2016-01-03 22:51:12 --> Output Class Initialized
INFO - 2016-01-03 22:51:12 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:12 --> Input Class Initialized
INFO - 2016-01-03 22:51:12 --> Language Class Initialized
INFO - 2016-01-03 22:51:12 --> Loader Class Initialized
INFO - 2016-01-03 22:51:12 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:12 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:12 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:12 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:12 --> Model Class Initialized
INFO - 2016-01-03 22:51:12 --> Model Class Initialized
INFO - 2016-01-03 22:51:12 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:12 --> Total execution time: 0.1248
INFO - 2016-01-03 22:51:12 --> Config Class Initialized
INFO - 2016-01-03 22:51:12 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:12 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:12 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:12 --> URI Class Initialized
INFO - 2016-01-03 22:51:12 --> Router Class Initialized
INFO - 2016-01-03 22:51:12 --> Output Class Initialized
INFO - 2016-01-03 22:51:12 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:12 --> Input Class Initialized
INFO - 2016-01-03 22:51:12 --> Language Class Initialized
INFO - 2016-01-03 22:51:12 --> Loader Class Initialized
INFO - 2016-01-03 22:51:12 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:12 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:12 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:12 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:12 --> Model Class Initialized
INFO - 2016-01-03 22:51:12 --> Model Class Initialized
INFO - 2016-01-03 22:51:12 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:12 --> Total execution time: 0.1042
INFO - 2016-01-03 22:51:14 --> Config Class Initialized
INFO - 2016-01-03 22:51:14 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:14 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:14 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:14 --> URI Class Initialized
INFO - 2016-01-03 22:51:14 --> Router Class Initialized
INFO - 2016-01-03 22:51:14 --> Output Class Initialized
INFO - 2016-01-03 22:51:14 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:14 --> Input Class Initialized
INFO - 2016-01-03 22:51:14 --> Language Class Initialized
INFO - 2016-01-03 22:51:14 --> Loader Class Initialized
INFO - 2016-01-03 22:51:14 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:14 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:14 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:14 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:14 --> Model Class Initialized
INFO - 2016-01-03 22:51:14 --> Model Class Initialized
INFO - 2016-01-03 22:51:14 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:14 --> Total execution time: 0.0706
INFO - 2016-01-03 22:51:15 --> Config Class Initialized
INFO - 2016-01-03 22:51:15 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:15 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:15 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:15 --> URI Class Initialized
INFO - 2016-01-03 22:51:15 --> Router Class Initialized
INFO - 2016-01-03 22:51:15 --> Output Class Initialized
INFO - 2016-01-03 22:51:15 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:15 --> Input Class Initialized
INFO - 2016-01-03 22:51:15 --> Language Class Initialized
INFO - 2016-01-03 22:51:15 --> Loader Class Initialized
INFO - 2016-01-03 22:51:15 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:15 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:15 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:15 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:15 --> Model Class Initialized
INFO - 2016-01-03 22:51:15 --> Model Class Initialized
INFO - 2016-01-03 22:51:15 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:15 --> Total execution time: 0.1174
INFO - 2016-01-03 22:51:18 --> Config Class Initialized
INFO - 2016-01-03 22:51:18 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:18 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:18 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:18 --> URI Class Initialized
INFO - 2016-01-03 22:51:18 --> Router Class Initialized
INFO - 2016-01-03 22:51:18 --> Output Class Initialized
INFO - 2016-01-03 22:51:18 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:18 --> Input Class Initialized
INFO - 2016-01-03 22:51:18 --> Language Class Initialized
INFO - 2016-01-03 22:51:18 --> Loader Class Initialized
INFO - 2016-01-03 22:51:18 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:18 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:18 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:18 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:18 --> Model Class Initialized
INFO - 2016-01-03 22:51:18 --> Model Class Initialized
INFO - 2016-01-03 22:51:18 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:18 --> Total execution time: 0.1188
INFO - 2016-01-03 22:51:18 --> Config Class Initialized
INFO - 2016-01-03 22:51:18 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:18 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:18 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:18 --> URI Class Initialized
INFO - 2016-01-03 22:51:18 --> Router Class Initialized
INFO - 2016-01-03 22:51:18 --> Output Class Initialized
INFO - 2016-01-03 22:51:18 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:18 --> Input Class Initialized
INFO - 2016-01-03 22:51:18 --> Language Class Initialized
INFO - 2016-01-03 22:51:18 --> Loader Class Initialized
INFO - 2016-01-03 22:51:18 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:18 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:18 --> Controller Class Initialized
DEBUG - 2016-01-03 22:51:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:51:18 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:51:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:51:18 --> Model Class Initialized
INFO - 2016-01-03 22:51:18 --> Model Class Initialized
INFO - 2016-01-03 22:51:18 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:18 --> Total execution time: 0.1193
INFO - 2016-01-03 22:51:57 --> Config Class Initialized
INFO - 2016-01-03 22:51:57 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:51:57 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:51:57 --> Utf8 Class Initialized
INFO - 2016-01-03 22:51:57 --> URI Class Initialized
INFO - 2016-01-03 22:51:57 --> Router Class Initialized
INFO - 2016-01-03 22:51:57 --> Output Class Initialized
INFO - 2016-01-03 22:51:57 --> Security Class Initialized
DEBUG - 2016-01-03 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:51:57 --> Input Class Initialized
INFO - 2016-01-03 22:51:57 --> Language Class Initialized
INFO - 2016-01-03 22:51:57 --> Loader Class Initialized
INFO - 2016-01-03 22:51:57 --> Helper loaded: url_helper
INFO - 2016-01-03 22:51:57 --> Database Driver Class Initialized
INFO - 2016-01-03 22:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:51:57 --> Controller Class Initialized
INFO - 2016-01-03 22:51:57 --> Helper loaded: form_helper
INFO - 2016-01-03 22:51:57 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 22:51:57 --> Final output sent to browser
DEBUG - 2016-01-03 22:51:57 --> Total execution time: 0.1128
INFO - 2016-01-03 22:52:17 --> Config Class Initialized
INFO - 2016-01-03 22:52:17 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:52:17 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:52:17 --> Utf8 Class Initialized
INFO - 2016-01-03 22:52:17 --> URI Class Initialized
INFO - 2016-01-03 22:52:17 --> Router Class Initialized
INFO - 2016-01-03 22:52:17 --> Output Class Initialized
INFO - 2016-01-03 22:52:17 --> Security Class Initialized
DEBUG - 2016-01-03 22:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:52:17 --> Input Class Initialized
INFO - 2016-01-03 22:52:17 --> Language Class Initialized
INFO - 2016-01-03 22:52:17 --> Loader Class Initialized
INFO - 2016-01-03 22:52:17 --> Helper loaded: url_helper
INFO - 2016-01-03 22:52:17 --> Database Driver Class Initialized
INFO - 2016-01-03 22:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:52:17 --> Controller Class Initialized
INFO - 2016-01-03 22:52:17 --> Helper loaded: form_helper
INFO - 2016-01-03 22:52:17 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-03 22:52:17 --> Final output sent to browser
DEBUG - 2016-01-03 22:52:17 --> Total execution time: 0.0706
INFO - 2016-01-03 22:52:28 --> Config Class Initialized
INFO - 2016-01-03 22:52:28 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:52:28 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:52:28 --> Utf8 Class Initialized
INFO - 2016-01-03 22:52:28 --> URI Class Initialized
DEBUG - 2016-01-03 22:52:28 --> No URI present. Default controller set.
INFO - 2016-01-03 22:52:28 --> Router Class Initialized
INFO - 2016-01-03 22:52:28 --> Output Class Initialized
INFO - 2016-01-03 22:52:28 --> Security Class Initialized
DEBUG - 2016-01-03 22:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:52:28 --> Input Class Initialized
INFO - 2016-01-03 22:52:28 --> Language Class Initialized
INFO - 2016-01-03 22:52:28 --> Loader Class Initialized
INFO - 2016-01-03 22:52:28 --> Helper loaded: url_helper
INFO - 2016-01-03 22:52:28 --> Database Driver Class Initialized
INFO - 2016-01-03 22:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:52:28 --> Controller Class Initialized
INFO - 2016-01-03 22:52:28 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 22:52:28 --> Final output sent to browser
DEBUG - 2016-01-03 22:52:28 --> Total execution time: 0.0883
INFO - 2016-01-03 22:52:32 --> Config Class Initialized
INFO - 2016-01-03 22:52:32 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:52:32 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:52:32 --> Utf8 Class Initialized
INFO - 2016-01-03 22:52:32 --> URI Class Initialized
INFO - 2016-01-03 22:52:32 --> Router Class Initialized
INFO - 2016-01-03 22:52:32 --> Output Class Initialized
INFO - 2016-01-03 22:52:32 --> Security Class Initialized
DEBUG - 2016-01-03 22:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:52:32 --> Input Class Initialized
INFO - 2016-01-03 22:52:32 --> Language Class Initialized
INFO - 2016-01-03 22:52:32 --> Loader Class Initialized
INFO - 2016-01-03 22:52:32 --> Helper loaded: url_helper
INFO - 2016-01-03 22:52:32 --> Database Driver Class Initialized
INFO - 2016-01-03 22:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:52:32 --> Controller Class Initialized
INFO - 2016-01-03 22:52:32 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 22:52:32 --> Final output sent to browser
DEBUG - 2016-01-03 22:52:32 --> Total execution time: 0.1122
INFO - 2016-01-03 22:52:32 --> Config Class Initialized
INFO - 2016-01-03 22:52:32 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:52:32 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:52:32 --> Utf8 Class Initialized
INFO - 2016-01-03 22:52:32 --> URI Class Initialized
INFO - 2016-01-03 22:52:32 --> Router Class Initialized
INFO - 2016-01-03 22:52:32 --> Output Class Initialized
INFO - 2016-01-03 22:52:32 --> Security Class Initialized
DEBUG - 2016-01-03 22:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:52:32 --> Input Class Initialized
INFO - 2016-01-03 22:52:32 --> Language Class Initialized
INFO - 2016-01-03 22:52:33 --> Loader Class Initialized
INFO - 2016-01-03 22:52:33 --> Helper loaded: url_helper
INFO - 2016-01-03 22:52:33 --> Database Driver Class Initialized
INFO - 2016-01-03 22:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:52:33 --> Controller Class Initialized
DEBUG - 2016-01-03 22:52:33 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:52:33 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:52:33 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:52:33 --> Model Class Initialized
INFO - 2016-01-03 22:52:33 --> Model Class Initialized
INFO - 2016-01-03 22:52:33 --> Final output sent to browser
DEBUG - 2016-01-03 22:52:33 --> Total execution time: 0.0935
INFO - 2016-01-03 22:52:54 --> Config Class Initialized
INFO - 2016-01-03 22:52:54 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:52:54 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:52:54 --> Utf8 Class Initialized
INFO - 2016-01-03 22:52:54 --> URI Class Initialized
DEBUG - 2016-01-03 22:52:54 --> No URI present. Default controller set.
INFO - 2016-01-03 22:52:54 --> Router Class Initialized
INFO - 2016-01-03 22:52:54 --> Output Class Initialized
INFO - 2016-01-03 22:52:54 --> Security Class Initialized
DEBUG - 2016-01-03 22:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:52:54 --> Input Class Initialized
INFO - 2016-01-03 22:52:54 --> Language Class Initialized
INFO - 2016-01-03 22:52:54 --> Loader Class Initialized
INFO - 2016-01-03 22:52:54 --> Helper loaded: url_helper
INFO - 2016-01-03 22:52:54 --> Database Driver Class Initialized
INFO - 2016-01-03 22:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:52:54 --> Controller Class Initialized
INFO - 2016-01-03 22:52:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 22:52:54 --> Final output sent to browser
DEBUG - 2016-01-03 22:52:54 --> Total execution time: 0.0575
INFO - 2016-01-03 22:53:14 --> Config Class Initialized
INFO - 2016-01-03 22:53:14 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:53:14 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:53:14 --> Utf8 Class Initialized
INFO - 2016-01-03 22:53:14 --> URI Class Initialized
INFO - 2016-01-03 22:53:14 --> Router Class Initialized
INFO - 2016-01-03 22:53:14 --> Output Class Initialized
INFO - 2016-01-03 22:53:14 --> Security Class Initialized
DEBUG - 2016-01-03 22:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:53:14 --> Input Class Initialized
INFO - 2016-01-03 22:53:14 --> Language Class Initialized
INFO - 2016-01-03 22:53:14 --> Loader Class Initialized
INFO - 2016-01-03 22:53:14 --> Helper loaded: url_helper
INFO - 2016-01-03 22:53:14 --> Database Driver Class Initialized
INFO - 2016-01-03 22:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:53:14 --> Controller Class Initialized
INFO - 2016-01-03 22:53:14 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 22:53:14 --> Final output sent to browser
DEBUG - 2016-01-03 22:53:14 --> Total execution time: 0.0807
INFO - 2016-01-03 22:53:15 --> Config Class Initialized
INFO - 2016-01-03 22:53:15 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:53:15 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:53:15 --> Utf8 Class Initialized
INFO - 2016-01-03 22:53:15 --> URI Class Initialized
INFO - 2016-01-03 22:53:15 --> Router Class Initialized
INFO - 2016-01-03 22:53:15 --> Output Class Initialized
INFO - 2016-01-03 22:53:15 --> Security Class Initialized
DEBUG - 2016-01-03 22:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:53:15 --> Input Class Initialized
INFO - 2016-01-03 22:53:15 --> Language Class Initialized
INFO - 2016-01-03 22:53:15 --> Loader Class Initialized
INFO - 2016-01-03 22:53:15 --> Helper loaded: url_helper
INFO - 2016-01-03 22:53:15 --> Database Driver Class Initialized
INFO - 2016-01-03 22:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:53:15 --> Controller Class Initialized
DEBUG - 2016-01-03 22:53:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:53:15 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:53:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:53:15 --> Model Class Initialized
INFO - 2016-01-03 22:53:15 --> Model Class Initialized
INFO - 2016-01-03 22:53:15 --> Final output sent to browser
DEBUG - 2016-01-03 22:53:15 --> Total execution time: 0.1089
INFO - 2016-01-03 22:54:16 --> Config Class Initialized
INFO - 2016-01-03 22:54:16 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:54:16 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:54:16 --> Utf8 Class Initialized
INFO - 2016-01-03 22:54:16 --> URI Class Initialized
INFO - 2016-01-03 22:54:16 --> Router Class Initialized
INFO - 2016-01-03 22:54:16 --> Output Class Initialized
INFO - 2016-01-03 22:54:16 --> Security Class Initialized
DEBUG - 2016-01-03 22:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:54:16 --> Input Class Initialized
INFO - 2016-01-03 22:54:16 --> Language Class Initialized
INFO - 2016-01-03 22:54:16 --> Loader Class Initialized
INFO - 2016-01-03 22:54:16 --> Helper loaded: url_helper
INFO - 2016-01-03 22:54:16 --> Database Driver Class Initialized
INFO - 2016-01-03 22:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:54:16 --> Controller Class Initialized
DEBUG - 2016-01-03 22:54:16 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:54:16 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:54:16 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:54:16 --> Model Class Initialized
INFO - 2016-01-03 22:54:16 --> Model Class Initialized
INFO - 2016-01-03 22:54:16 --> Final output sent to browser
DEBUG - 2016-01-03 22:54:16 --> Total execution time: 0.1752
INFO - 2016-01-03 22:54:19 --> Config Class Initialized
INFO - 2016-01-03 22:54:19 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:54:19 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:54:19 --> Utf8 Class Initialized
INFO - 2016-01-03 22:54:19 --> URI Class Initialized
INFO - 2016-01-03 22:54:19 --> Router Class Initialized
INFO - 2016-01-03 22:54:19 --> Output Class Initialized
INFO - 2016-01-03 22:54:19 --> Security Class Initialized
DEBUG - 2016-01-03 22:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:54:19 --> Input Class Initialized
INFO - 2016-01-03 22:54:19 --> Language Class Initialized
INFO - 2016-01-03 22:54:19 --> Loader Class Initialized
INFO - 2016-01-03 22:54:19 --> Helper loaded: url_helper
INFO - 2016-01-03 22:54:19 --> Database Driver Class Initialized
INFO - 2016-01-03 22:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:54:19 --> Controller Class Initialized
DEBUG - 2016-01-03 22:54:19 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 22:54:19 --> Helper loaded: inflector_helper
INFO - 2016-01-03 22:54:19 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 22:54:19 --> Model Class Initialized
INFO - 2016-01-03 22:54:19 --> Model Class Initialized
INFO - 2016-01-03 22:54:19 --> Final output sent to browser
DEBUG - 2016-01-03 22:54:19 --> Total execution time: 0.0643
INFO - 2016-01-03 22:54:20 --> Config Class Initialized
INFO - 2016-01-03 22:54:20 --> Hooks Class Initialized
DEBUG - 2016-01-03 22:54:20 --> UTF-8 Support Enabled
INFO - 2016-01-03 22:54:20 --> Utf8 Class Initialized
INFO - 2016-01-03 22:54:20 --> URI Class Initialized
DEBUG - 2016-01-03 22:54:20 --> No URI present. Default controller set.
INFO - 2016-01-03 22:54:20 --> Router Class Initialized
INFO - 2016-01-03 22:54:20 --> Output Class Initialized
INFO - 2016-01-03 22:54:20 --> Security Class Initialized
DEBUG - 2016-01-03 22:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 22:54:20 --> Input Class Initialized
INFO - 2016-01-03 22:54:20 --> Language Class Initialized
INFO - 2016-01-03 22:54:20 --> Loader Class Initialized
INFO - 2016-01-03 22:54:20 --> Helper loaded: url_helper
INFO - 2016-01-03 22:54:20 --> Database Driver Class Initialized
INFO - 2016-01-03 22:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 22:54:20 --> Controller Class Initialized
INFO - 2016-01-03 22:54:20 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 22:54:20 --> Final output sent to browser
DEBUG - 2016-01-03 22:54:20 --> Total execution time: 0.0915
INFO - 2016-01-03 23:01:29 --> Config Class Initialized
INFO - 2016-01-03 23:01:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:01:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:01:29 --> Utf8 Class Initialized
INFO - 2016-01-03 23:01:29 --> URI Class Initialized
INFO - 2016-01-03 23:01:29 --> Router Class Initialized
INFO - 2016-01-03 23:01:29 --> Output Class Initialized
INFO - 2016-01-03 23:01:29 --> Security Class Initialized
DEBUG - 2016-01-03 23:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:01:29 --> Input Class Initialized
INFO - 2016-01-03 23:01:29 --> Language Class Initialized
INFO - 2016-01-03 23:01:29 --> Loader Class Initialized
INFO - 2016-01-03 23:01:29 --> Helper loaded: url_helper
INFO - 2016-01-03 23:01:29 --> Database Driver Class Initialized
INFO - 2016-01-03 23:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:01:29 --> Controller Class Initialized
INFO - 2016-01-03 23:01:29 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 23:01:29 --> Final output sent to browser
DEBUG - 2016-01-03 23:01:29 --> Total execution time: 0.0735
INFO - 2016-01-03 23:01:29 --> Config Class Initialized
INFO - 2016-01-03 23:01:29 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:01:29 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:01:29 --> Utf8 Class Initialized
INFO - 2016-01-03 23:01:29 --> URI Class Initialized
INFO - 2016-01-03 23:01:29 --> Router Class Initialized
INFO - 2016-01-03 23:01:29 --> Output Class Initialized
INFO - 2016-01-03 23:01:29 --> Security Class Initialized
DEBUG - 2016-01-03 23:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:01:29 --> Input Class Initialized
INFO - 2016-01-03 23:01:29 --> Language Class Initialized
INFO - 2016-01-03 23:01:29 --> Loader Class Initialized
INFO - 2016-01-03 23:01:29 --> Helper loaded: url_helper
INFO - 2016-01-03 23:01:29 --> Database Driver Class Initialized
INFO - 2016-01-03 23:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:01:29 --> Controller Class Initialized
DEBUG - 2016-01-03 23:01:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 23:01:29 --> Helper loaded: inflector_helper
INFO - 2016-01-03 23:01:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 23:01:29 --> Model Class Initialized
INFO - 2016-01-03 23:01:29 --> Model Class Initialized
INFO - 2016-01-03 23:01:29 --> Final output sent to browser
DEBUG - 2016-01-03 23:01:29 --> Total execution time: 0.0715
INFO - 2016-01-03 23:01:43 --> Config Class Initialized
INFO - 2016-01-03 23:01:43 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:01:43 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:01:43 --> Utf8 Class Initialized
INFO - 2016-01-03 23:01:43 --> URI Class Initialized
DEBUG - 2016-01-03 23:01:43 --> No URI present. Default controller set.
INFO - 2016-01-03 23:01:43 --> Router Class Initialized
INFO - 2016-01-03 23:01:43 --> Output Class Initialized
INFO - 2016-01-03 23:01:43 --> Security Class Initialized
DEBUG - 2016-01-03 23:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:01:43 --> Input Class Initialized
INFO - 2016-01-03 23:01:43 --> Language Class Initialized
INFO - 2016-01-03 23:01:43 --> Loader Class Initialized
INFO - 2016-01-03 23:01:43 --> Helper loaded: url_helper
INFO - 2016-01-03 23:01:43 --> Database Driver Class Initialized
INFO - 2016-01-03 23:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:01:43 --> Controller Class Initialized
INFO - 2016-01-03 23:01:43 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 23:01:43 --> Final output sent to browser
DEBUG - 2016-01-03 23:01:43 --> Total execution time: 0.0687
INFO - 2016-01-03 23:01:45 --> Config Class Initialized
INFO - 2016-01-03 23:01:45 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:01:45 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:01:45 --> Utf8 Class Initialized
INFO - 2016-01-03 23:01:45 --> URI Class Initialized
INFO - 2016-01-03 23:01:45 --> Router Class Initialized
INFO - 2016-01-03 23:01:45 --> Output Class Initialized
INFO - 2016-01-03 23:01:45 --> Security Class Initialized
DEBUG - 2016-01-03 23:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:01:45 --> Input Class Initialized
INFO - 2016-01-03 23:01:45 --> Language Class Initialized
INFO - 2016-01-03 23:01:45 --> Loader Class Initialized
INFO - 2016-01-03 23:01:45 --> Helper loaded: url_helper
INFO - 2016-01-03 23:01:45 --> Database Driver Class Initialized
INFO - 2016-01-03 23:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:01:45 --> Controller Class Initialized
INFO - 2016-01-03 23:01:45 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 23:01:45 --> Final output sent to browser
DEBUG - 2016-01-03 23:01:45 --> Total execution time: 0.0611
INFO - 2016-01-03 23:01:45 --> Config Class Initialized
INFO - 2016-01-03 23:01:45 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:01:45 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:01:45 --> Utf8 Class Initialized
INFO - 2016-01-03 23:01:45 --> URI Class Initialized
INFO - 2016-01-03 23:01:45 --> Router Class Initialized
INFO - 2016-01-03 23:01:45 --> Output Class Initialized
INFO - 2016-01-03 23:01:45 --> Security Class Initialized
DEBUG - 2016-01-03 23:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:01:45 --> Input Class Initialized
INFO - 2016-01-03 23:01:45 --> Language Class Initialized
INFO - 2016-01-03 23:01:45 --> Loader Class Initialized
INFO - 2016-01-03 23:01:45 --> Helper loaded: url_helper
INFO - 2016-01-03 23:01:45 --> Database Driver Class Initialized
INFO - 2016-01-03 23:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:01:45 --> Controller Class Initialized
DEBUG - 2016-01-03 23:01:45 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 23:01:45 --> Helper loaded: inflector_helper
INFO - 2016-01-03 23:01:45 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 23:01:45 --> Model Class Initialized
INFO - 2016-01-03 23:01:45 --> Model Class Initialized
INFO - 2016-01-03 23:01:45 --> Final output sent to browser
DEBUG - 2016-01-03 23:01:45 --> Total execution time: 0.0691
INFO - 2016-01-03 23:02:46 --> Config Class Initialized
INFO - 2016-01-03 23:02:46 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:02:46 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:02:46 --> Utf8 Class Initialized
INFO - 2016-01-03 23:02:46 --> URI Class Initialized
INFO - 2016-01-03 23:02:46 --> Router Class Initialized
INFO - 2016-01-03 23:02:46 --> Output Class Initialized
INFO - 2016-01-03 23:02:46 --> Security Class Initialized
DEBUG - 2016-01-03 23:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:02:46 --> Input Class Initialized
INFO - 2016-01-03 23:02:46 --> Language Class Initialized
INFO - 2016-01-03 23:02:46 --> Loader Class Initialized
INFO - 2016-01-03 23:02:46 --> Helper loaded: url_helper
INFO - 2016-01-03 23:02:46 --> Database Driver Class Initialized
INFO - 2016-01-03 23:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:02:46 --> Controller Class Initialized
DEBUG - 2016-01-03 23:02:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 23:02:46 --> Helper loaded: inflector_helper
INFO - 2016-01-03 23:02:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 23:02:46 --> Model Class Initialized
INFO - 2016-01-03 23:02:46 --> Model Class Initialized
INFO - 2016-01-03 23:02:46 --> Final output sent to browser
DEBUG - 2016-01-03 23:02:46 --> Total execution time: 0.1819
INFO - 2016-01-03 23:02:48 --> Config Class Initialized
INFO - 2016-01-03 23:02:48 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:02:48 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:02:48 --> Utf8 Class Initialized
INFO - 2016-01-03 23:02:48 --> URI Class Initialized
INFO - 2016-01-03 23:02:48 --> Router Class Initialized
INFO - 2016-01-03 23:02:48 --> Output Class Initialized
INFO - 2016-01-03 23:02:48 --> Security Class Initialized
DEBUG - 2016-01-03 23:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:02:48 --> Input Class Initialized
INFO - 2016-01-03 23:02:48 --> Language Class Initialized
INFO - 2016-01-03 23:02:48 --> Loader Class Initialized
INFO - 2016-01-03 23:02:48 --> Helper loaded: url_helper
INFO - 2016-01-03 23:02:48 --> Database Driver Class Initialized
INFO - 2016-01-03 23:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:02:48 --> Controller Class Initialized
DEBUG - 2016-01-03 23:02:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 23:02:48 --> Helper loaded: inflector_helper
INFO - 2016-01-03 23:02:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 23:02:48 --> Model Class Initialized
INFO - 2016-01-03 23:02:48 --> Model Class Initialized
INFO - 2016-01-03 23:02:48 --> Final output sent to browser
DEBUG - 2016-01-03 23:02:48 --> Total execution time: 0.1259
INFO - 2016-01-03 23:02:51 --> Config Class Initialized
INFO - 2016-01-03 23:02:51 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:02:51 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:02:51 --> Utf8 Class Initialized
INFO - 2016-01-03 23:02:51 --> URI Class Initialized
INFO - 2016-01-03 23:02:51 --> Router Class Initialized
INFO - 2016-01-03 23:02:51 --> Output Class Initialized
INFO - 2016-01-03 23:02:51 --> Security Class Initialized
DEBUG - 2016-01-03 23:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:02:51 --> Input Class Initialized
INFO - 2016-01-03 23:02:51 --> Language Class Initialized
INFO - 2016-01-03 23:02:51 --> Loader Class Initialized
INFO - 2016-01-03 23:02:51 --> Helper loaded: url_helper
INFO - 2016-01-03 23:02:51 --> Database Driver Class Initialized
INFO - 2016-01-03 23:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:02:51 --> Controller Class Initialized
DEBUG - 2016-01-03 23:02:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 23:02:51 --> Helper loaded: inflector_helper
INFO - 2016-01-03 23:02:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 23:02:51 --> Model Class Initialized
INFO - 2016-01-03 23:02:51 --> Model Class Initialized
INFO - 2016-01-03 23:02:51 --> Final output sent to browser
DEBUG - 2016-01-03 23:02:51 --> Total execution time: 0.0650
INFO - 2016-01-03 23:02:52 --> Config Class Initialized
INFO - 2016-01-03 23:02:52 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:02:52 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:02:52 --> Utf8 Class Initialized
INFO - 2016-01-03 23:02:52 --> URI Class Initialized
INFO - 2016-01-03 23:02:52 --> Router Class Initialized
INFO - 2016-01-03 23:02:52 --> Output Class Initialized
INFO - 2016-01-03 23:02:52 --> Security Class Initialized
DEBUG - 2016-01-03 23:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:02:52 --> Input Class Initialized
INFO - 2016-01-03 23:02:52 --> Language Class Initialized
INFO - 2016-01-03 23:02:52 --> Loader Class Initialized
INFO - 2016-01-03 23:02:52 --> Helper loaded: url_helper
INFO - 2016-01-03 23:02:52 --> Database Driver Class Initialized
INFO - 2016-01-03 23:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:02:52 --> Controller Class Initialized
DEBUG - 2016-01-03 23:02:52 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 23:02:52 --> Helper loaded: inflector_helper
INFO - 2016-01-03 23:02:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 23:02:52 --> Model Class Initialized
INFO - 2016-01-03 23:02:52 --> Model Class Initialized
INFO - 2016-01-03 23:02:52 --> Final output sent to browser
DEBUG - 2016-01-03 23:02:52 --> Total execution time: 0.1142
INFO - 2016-01-03 23:03:09 --> Config Class Initialized
INFO - 2016-01-03 23:03:09 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:03:09 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:03:09 --> Utf8 Class Initialized
INFO - 2016-01-03 23:03:09 --> URI Class Initialized
DEBUG - 2016-01-03 23:03:09 --> No URI present. Default controller set.
INFO - 2016-01-03 23:03:09 --> Router Class Initialized
INFO - 2016-01-03 23:03:09 --> Output Class Initialized
INFO - 2016-01-03 23:03:09 --> Security Class Initialized
DEBUG - 2016-01-03 23:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:03:09 --> Input Class Initialized
INFO - 2016-01-03 23:03:09 --> Language Class Initialized
INFO - 2016-01-03 23:03:09 --> Loader Class Initialized
INFO - 2016-01-03 23:03:09 --> Helper loaded: url_helper
INFO - 2016-01-03 23:03:09 --> Database Driver Class Initialized
INFO - 2016-01-03 23:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:03:09 --> Controller Class Initialized
INFO - 2016-01-03 23:03:09 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 23:03:09 --> Final output sent to browser
DEBUG - 2016-01-03 23:03:09 --> Total execution time: 0.0852
INFO - 2016-01-03 23:03:11 --> Config Class Initialized
INFO - 2016-01-03 23:03:11 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:03:11 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:03:11 --> Utf8 Class Initialized
INFO - 2016-01-03 23:03:11 --> URI Class Initialized
INFO - 2016-01-03 23:03:11 --> Router Class Initialized
INFO - 2016-01-03 23:03:11 --> Output Class Initialized
INFO - 2016-01-03 23:03:11 --> Security Class Initialized
DEBUG - 2016-01-03 23:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:03:11 --> Input Class Initialized
INFO - 2016-01-03 23:03:11 --> Language Class Initialized
INFO - 2016-01-03 23:03:11 --> Loader Class Initialized
INFO - 2016-01-03 23:03:11 --> Helper loaded: url_helper
INFO - 2016-01-03 23:03:11 --> Database Driver Class Initialized
INFO - 2016-01-03 23:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:03:11 --> Controller Class Initialized
INFO - 2016-01-03 23:03:11 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 23:03:11 --> Final output sent to browser
DEBUG - 2016-01-03 23:03:11 --> Total execution time: 0.0895
INFO - 2016-01-03 23:03:11 --> Config Class Initialized
INFO - 2016-01-03 23:03:11 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:03:11 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:03:11 --> Utf8 Class Initialized
INFO - 2016-01-03 23:03:11 --> URI Class Initialized
INFO - 2016-01-03 23:03:11 --> Router Class Initialized
INFO - 2016-01-03 23:03:11 --> Output Class Initialized
INFO - 2016-01-03 23:03:11 --> Security Class Initialized
DEBUG - 2016-01-03 23:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:03:11 --> Input Class Initialized
INFO - 2016-01-03 23:03:11 --> Language Class Initialized
INFO - 2016-01-03 23:03:11 --> Loader Class Initialized
INFO - 2016-01-03 23:03:11 --> Helper loaded: url_helper
INFO - 2016-01-03 23:03:11 --> Database Driver Class Initialized
INFO - 2016-01-03 23:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:03:11 --> Controller Class Initialized
DEBUG - 2016-01-03 23:03:11 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 23:03:11 --> Helper loaded: inflector_helper
INFO - 2016-01-03 23:03:11 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 23:03:11 --> Model Class Initialized
INFO - 2016-01-03 23:03:11 --> Model Class Initialized
INFO - 2016-01-03 23:03:11 --> Final output sent to browser
DEBUG - 2016-01-03 23:03:11 --> Total execution time: 0.0728
INFO - 2016-01-03 23:03:34 --> Config Class Initialized
INFO - 2016-01-03 23:03:34 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:03:34 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:03:34 --> Utf8 Class Initialized
INFO - 2016-01-03 23:03:34 --> URI Class Initialized
DEBUG - 2016-01-03 23:03:34 --> No URI present. Default controller set.
INFO - 2016-01-03 23:03:34 --> Router Class Initialized
INFO - 2016-01-03 23:03:34 --> Output Class Initialized
INFO - 2016-01-03 23:03:34 --> Security Class Initialized
DEBUG - 2016-01-03 23:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:03:34 --> Input Class Initialized
INFO - 2016-01-03 23:03:34 --> Language Class Initialized
INFO - 2016-01-03 23:03:34 --> Loader Class Initialized
INFO - 2016-01-03 23:03:34 --> Helper loaded: url_helper
INFO - 2016-01-03 23:03:34 --> Database Driver Class Initialized
INFO - 2016-01-03 23:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:03:34 --> Controller Class Initialized
INFO - 2016-01-03 23:03:34 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 23:03:34 --> Final output sent to browser
DEBUG - 2016-01-03 23:03:34 --> Total execution time: 0.1177
INFO - 2016-01-03 23:03:40 --> Config Class Initialized
INFO - 2016-01-03 23:03:40 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:03:40 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:03:40 --> Utf8 Class Initialized
INFO - 2016-01-03 23:03:40 --> URI Class Initialized
DEBUG - 2016-01-03 23:03:40 --> No URI present. Default controller set.
INFO - 2016-01-03 23:03:40 --> Router Class Initialized
INFO - 2016-01-03 23:03:40 --> Output Class Initialized
INFO - 2016-01-03 23:03:40 --> Security Class Initialized
DEBUG - 2016-01-03 23:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:03:40 --> Input Class Initialized
INFO - 2016-01-03 23:03:40 --> Language Class Initialized
INFO - 2016-01-03 23:03:40 --> Loader Class Initialized
INFO - 2016-01-03 23:03:40 --> Helper loaded: url_helper
INFO - 2016-01-03 23:03:40 --> Database Driver Class Initialized
INFO - 2016-01-03 23:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:03:40 --> Controller Class Initialized
INFO - 2016-01-03 23:03:40 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 23:03:40 --> Final output sent to browser
DEBUG - 2016-01-03 23:03:40 --> Total execution time: 0.1064
INFO - 2016-01-03 23:03:43 --> Config Class Initialized
INFO - 2016-01-03 23:03:43 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:03:43 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:03:43 --> Utf8 Class Initialized
INFO - 2016-01-03 23:03:43 --> URI Class Initialized
INFO - 2016-01-03 23:03:43 --> Router Class Initialized
INFO - 2016-01-03 23:03:43 --> Output Class Initialized
INFO - 2016-01-03 23:03:43 --> Security Class Initialized
DEBUG - 2016-01-03 23:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:03:43 --> Input Class Initialized
INFO - 2016-01-03 23:03:43 --> Language Class Initialized
INFO - 2016-01-03 23:03:43 --> Loader Class Initialized
INFO - 2016-01-03 23:03:43 --> Helper loaded: url_helper
INFO - 2016-01-03 23:03:43 --> Database Driver Class Initialized
INFO - 2016-01-03 23:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:03:43 --> Controller Class Initialized
INFO - 2016-01-03 23:03:43 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 23:03:43 --> Final output sent to browser
DEBUG - 2016-01-03 23:03:43 --> Total execution time: 0.1007
INFO - 2016-01-03 23:03:44 --> Config Class Initialized
INFO - 2016-01-03 23:03:44 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:03:44 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:03:44 --> Utf8 Class Initialized
INFO - 2016-01-03 23:03:44 --> URI Class Initialized
INFO - 2016-01-03 23:03:44 --> Router Class Initialized
INFO - 2016-01-03 23:03:44 --> Output Class Initialized
INFO - 2016-01-03 23:03:44 --> Security Class Initialized
DEBUG - 2016-01-03 23:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:03:44 --> Input Class Initialized
INFO - 2016-01-03 23:03:44 --> Language Class Initialized
INFO - 2016-01-03 23:03:44 --> Loader Class Initialized
INFO - 2016-01-03 23:03:44 --> Helper loaded: url_helper
INFO - 2016-01-03 23:03:44 --> Database Driver Class Initialized
INFO - 2016-01-03 23:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:03:44 --> Controller Class Initialized
DEBUG - 2016-01-03 23:03:44 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 23:03:44 --> Helper loaded: inflector_helper
INFO - 2016-01-03 23:03:44 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 23:03:44 --> Model Class Initialized
INFO - 2016-01-03 23:03:44 --> Model Class Initialized
INFO - 2016-01-03 23:03:44 --> Final output sent to browser
DEBUG - 2016-01-03 23:03:44 --> Total execution time: 0.1371
INFO - 2016-01-03 23:04:17 --> Config Class Initialized
INFO - 2016-01-03 23:04:17 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:04:17 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:04:17 --> Utf8 Class Initialized
INFO - 2016-01-03 23:04:17 --> URI Class Initialized
INFO - 2016-01-03 23:04:17 --> Router Class Initialized
INFO - 2016-01-03 23:04:17 --> Output Class Initialized
INFO - 2016-01-03 23:04:17 --> Security Class Initialized
DEBUG - 2016-01-03 23:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:04:17 --> Input Class Initialized
INFO - 2016-01-03 23:04:17 --> Language Class Initialized
INFO - 2016-01-03 23:04:17 --> Loader Class Initialized
INFO - 2016-01-03 23:04:17 --> Helper loaded: url_helper
INFO - 2016-01-03 23:04:17 --> Database Driver Class Initialized
INFO - 2016-01-03 23:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:04:17 --> Controller Class Initialized
INFO - 2016-01-03 23:04:17 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 23:04:17 --> Final output sent to browser
DEBUG - 2016-01-03 23:04:17 --> Total execution time: 0.0703
INFO - 2016-01-03 23:04:18 --> Config Class Initialized
INFO - 2016-01-03 23:04:18 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:04:18 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:04:18 --> Utf8 Class Initialized
INFO - 2016-01-03 23:04:18 --> URI Class Initialized
INFO - 2016-01-03 23:04:18 --> Router Class Initialized
INFO - 2016-01-03 23:04:18 --> Output Class Initialized
INFO - 2016-01-03 23:04:18 --> Security Class Initialized
DEBUG - 2016-01-03 23:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:04:18 --> Input Class Initialized
INFO - 2016-01-03 23:04:18 --> Language Class Initialized
INFO - 2016-01-03 23:04:18 --> Loader Class Initialized
INFO - 2016-01-03 23:04:18 --> Helper loaded: url_helper
INFO - 2016-01-03 23:04:18 --> Database Driver Class Initialized
INFO - 2016-01-03 23:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:04:18 --> Controller Class Initialized
DEBUG - 2016-01-03 23:04:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 23:04:18 --> Helper loaded: inflector_helper
INFO - 2016-01-03 23:04:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 23:04:18 --> Model Class Initialized
INFO - 2016-01-03 23:04:18 --> Model Class Initialized
INFO - 2016-01-03 23:04:18 --> Final output sent to browser
DEBUG - 2016-01-03 23:04:18 --> Total execution time: 0.0961
INFO - 2016-01-03 23:05:31 --> Config Class Initialized
INFO - 2016-01-03 23:05:31 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:05:31 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:05:31 --> Utf8 Class Initialized
INFO - 2016-01-03 23:05:31 --> URI Class Initialized
DEBUG - 2016-01-03 23:05:31 --> No URI present. Default controller set.
INFO - 2016-01-03 23:05:31 --> Router Class Initialized
INFO - 2016-01-03 23:05:31 --> Output Class Initialized
INFO - 2016-01-03 23:05:31 --> Security Class Initialized
DEBUG - 2016-01-03 23:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:05:31 --> Input Class Initialized
INFO - 2016-01-03 23:05:31 --> Language Class Initialized
INFO - 2016-01-03 23:05:31 --> Loader Class Initialized
INFO - 2016-01-03 23:05:31 --> Helper loaded: url_helper
INFO - 2016-01-03 23:05:31 --> Database Driver Class Initialized
INFO - 2016-01-03 23:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:05:31 --> Controller Class Initialized
INFO - 2016-01-03 23:05:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-03 23:05:31 --> Final output sent to browser
DEBUG - 2016-01-03 23:05:31 --> Total execution time: 0.1016
INFO - 2016-01-03 23:05:38 --> Config Class Initialized
INFO - 2016-01-03 23:05:38 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:05:38 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:05:38 --> Utf8 Class Initialized
INFO - 2016-01-03 23:05:38 --> URI Class Initialized
INFO - 2016-01-03 23:05:38 --> Router Class Initialized
INFO - 2016-01-03 23:05:38 --> Output Class Initialized
INFO - 2016-01-03 23:05:38 --> Security Class Initialized
DEBUG - 2016-01-03 23:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:05:38 --> Input Class Initialized
INFO - 2016-01-03 23:05:38 --> Language Class Initialized
INFO - 2016-01-03 23:05:38 --> Loader Class Initialized
INFO - 2016-01-03 23:05:38 --> Helper loaded: url_helper
INFO - 2016-01-03 23:05:38 --> Database Driver Class Initialized
INFO - 2016-01-03 23:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:05:38 --> Controller Class Initialized
INFO - 2016-01-03 23:05:38 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-03 23:05:38 --> Final output sent to browser
DEBUG - 2016-01-03 23:05:38 --> Total execution time: 0.0557
INFO - 2016-01-03 23:05:39 --> Config Class Initialized
INFO - 2016-01-03 23:05:39 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:05:39 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:05:39 --> Utf8 Class Initialized
INFO - 2016-01-03 23:05:39 --> URI Class Initialized
INFO - 2016-01-03 23:05:39 --> Router Class Initialized
INFO - 2016-01-03 23:05:39 --> Output Class Initialized
INFO - 2016-01-03 23:05:39 --> Security Class Initialized
DEBUG - 2016-01-03 23:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:05:39 --> Input Class Initialized
INFO - 2016-01-03 23:05:39 --> Language Class Initialized
INFO - 2016-01-03 23:05:39 --> Loader Class Initialized
INFO - 2016-01-03 23:05:39 --> Helper loaded: url_helper
INFO - 2016-01-03 23:05:39 --> Database Driver Class Initialized
INFO - 2016-01-03 23:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:05:39 --> Controller Class Initialized
DEBUG - 2016-01-03 23:05:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 23:05:39 --> Helper loaded: inflector_helper
INFO - 2016-01-03 23:05:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 23:05:39 --> Model Class Initialized
INFO - 2016-01-03 23:05:39 --> Model Class Initialized
INFO - 2016-01-03 23:05:39 --> Final output sent to browser
DEBUG - 2016-01-03 23:05:39 --> Total execution time: 0.0756
INFO - 2016-01-03 23:06:40 --> Config Class Initialized
INFO - 2016-01-03 23:06:40 --> Hooks Class Initialized
DEBUG - 2016-01-03 23:06:40 --> UTF-8 Support Enabled
INFO - 2016-01-03 23:06:40 --> Utf8 Class Initialized
INFO - 2016-01-03 23:06:40 --> URI Class Initialized
INFO - 2016-01-03 23:06:40 --> Router Class Initialized
INFO - 2016-01-03 23:06:40 --> Output Class Initialized
INFO - 2016-01-03 23:06:40 --> Security Class Initialized
DEBUG - 2016-01-03 23:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-03 23:06:40 --> Input Class Initialized
INFO - 2016-01-03 23:06:40 --> Language Class Initialized
INFO - 2016-01-03 23:06:40 --> Loader Class Initialized
INFO - 2016-01-03 23:06:40 --> Helper loaded: url_helper
INFO - 2016-01-03 23:06:40 --> Database Driver Class Initialized
INFO - 2016-01-03 23:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-03 23:06:40 --> Controller Class Initialized
DEBUG - 2016-01-03 23:06:40 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-03 23:06:40 --> Helper loaded: inflector_helper
INFO - 2016-01-03 23:06:40 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-03 23:06:40 --> Model Class Initialized
INFO - 2016-01-03 23:06:40 --> Model Class Initialized
INFO - 2016-01-03 23:06:40 --> Final output sent to browser
DEBUG - 2016-01-03 23:06:40 --> Total execution time: 0.1439
