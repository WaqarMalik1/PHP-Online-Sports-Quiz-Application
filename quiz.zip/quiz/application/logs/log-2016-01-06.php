<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-06 01:20:50 --> Config Class Initialized
INFO - 2016-01-06 01:20:50 --> Hooks Class Initialized
DEBUG - 2016-01-06 01:20:50 --> UTF-8 Support Enabled
INFO - 2016-01-06 01:20:50 --> Utf8 Class Initialized
INFO - 2016-01-06 01:20:50 --> URI Class Initialized
INFO - 2016-01-06 01:20:50 --> Router Class Initialized
INFO - 2016-01-06 01:20:50 --> Output Class Initialized
INFO - 2016-01-06 01:20:50 --> Security Class Initialized
DEBUG - 2016-01-06 01:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-06 01:20:50 --> Input Class Initialized
INFO - 2016-01-06 01:20:50 --> Language Class Initialized
INFO - 2016-01-06 01:20:50 --> Loader Class Initialized
INFO - 2016-01-06 01:20:50 --> Helper loaded: url_helper
INFO - 2016-01-06 01:20:50 --> Database Driver Class Initialized
INFO - 2016-01-06 01:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-06 01:20:50 --> Controller Class Initialized
INFO - 2016-01-06 01:20:50 --> Helper loaded: form_helper
INFO - 2016-01-06 01:20:50 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-06 01:20:50 --> Final output sent to browser
DEBUG - 2016-01-06 01:20:50 --> Total execution time: 0.2127
INFO - 2016-01-06 01:21:10 --> Config Class Initialized
INFO - 2016-01-06 01:21:10 --> Hooks Class Initialized
DEBUG - 2016-01-06 01:21:10 --> UTF-8 Support Enabled
INFO - 2016-01-06 01:21:10 --> Utf8 Class Initialized
INFO - 2016-01-06 01:21:10 --> URI Class Initialized
INFO - 2016-01-06 01:21:10 --> Router Class Initialized
INFO - 2016-01-06 01:21:10 --> Output Class Initialized
INFO - 2016-01-06 01:21:10 --> Security Class Initialized
DEBUG - 2016-01-06 01:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-06 01:21:10 --> Input Class Initialized
INFO - 2016-01-06 01:21:10 --> Language Class Initialized
INFO - 2016-01-06 01:21:10 --> Loader Class Initialized
INFO - 2016-01-06 01:21:10 --> Helper loaded: url_helper
INFO - 2016-01-06 01:21:10 --> Database Driver Class Initialized
INFO - 2016-01-06 01:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-06 01:21:10 --> Controller Class Initialized
INFO - 2016-01-06 01:21:10 --> Helper loaded: form_helper
INFO - 2016-01-06 01:21:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-06 01:21:10 --> Final output sent to browser
DEBUG - 2016-01-06 01:21:10 --> Total execution time: 0.1092
INFO - 2016-01-06 01:21:16 --> Config Class Initialized
INFO - 2016-01-06 01:21:16 --> Hooks Class Initialized
DEBUG - 2016-01-06 01:21:16 --> UTF-8 Support Enabled
INFO - 2016-01-06 01:21:16 --> Utf8 Class Initialized
INFO - 2016-01-06 01:21:16 --> URI Class Initialized
INFO - 2016-01-06 01:21:16 --> Router Class Initialized
INFO - 2016-01-06 01:21:16 --> Output Class Initialized
INFO - 2016-01-06 01:21:16 --> Security Class Initialized
DEBUG - 2016-01-06 01:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-06 01:21:16 --> Input Class Initialized
INFO - 2016-01-06 01:21:16 --> Language Class Initialized
INFO - 2016-01-06 01:21:16 --> Loader Class Initialized
INFO - 2016-01-06 01:21:16 --> Helper loaded: url_helper
INFO - 2016-01-06 01:21:16 --> Database Driver Class Initialized
INFO - 2016-01-06 01:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-06 01:21:16 --> Controller Class Initialized
INFO - 2016-01-06 01:21:16 --> Helper loaded: form_helper
INFO - 2016-01-06 01:21:16 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-06 01:21:16 --> Final output sent to browser
DEBUG - 2016-01-06 01:21:16 --> Total execution time: 0.0644
