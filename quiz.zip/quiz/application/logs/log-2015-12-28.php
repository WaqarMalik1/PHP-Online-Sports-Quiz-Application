<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2015-12-28 07:00:59 --> Config Class Initialized
INFO - 2015-12-28 07:00:59 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:00:59 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:00:59 --> Utf8 Class Initialized
INFO - 2015-12-28 07:00:59 --> URI Class Initialized
INFO - 2015-12-28 07:00:59 --> Router Class Initialized
INFO - 2015-12-28 07:00:59 --> Output Class Initialized
INFO - 2015-12-28 07:00:59 --> Security Class Initialized
DEBUG - 2015-12-28 07:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:00:59 --> Input Class Initialized
INFO - 2015-12-28 07:00:59 --> Language Class Initialized
INFO - 2015-12-28 07:00:59 --> Loader Class Initialized
INFO - 2015-12-28 07:01:00 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:00 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:00 --> Controller Class Initialized
INFO - 2015-12-28 07:01:00 --> Helper loaded: form_helper
INFO - 2015-12-28 07:01:00 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-28 07:01:00 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:00 --> Total execution time: 0.4044
INFO - 2015-12-28 07:01:04 --> Config Class Initialized
INFO - 2015-12-28 07:01:04 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:04 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:04 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:04 --> URI Class Initialized
INFO - 2015-12-28 07:01:04 --> Router Class Initialized
INFO - 2015-12-28 07:01:04 --> Output Class Initialized
INFO - 2015-12-28 07:01:04 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:04 --> Input Class Initialized
INFO - 2015-12-28 07:01:05 --> Language Class Initialized
INFO - 2015-12-28 07:01:05 --> Loader Class Initialized
INFO - 2015-12-28 07:01:05 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:05 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:05 --> Controller Class Initialized
INFO - 2015-12-28 07:01:05 --> Model Class Initialized
INFO - 2015-12-28 07:01:05 --> Model Class Initialized
INFO - 2015-12-28 07:01:05 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-28 07:01:05 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:05 --> Total execution time: 0.1272
INFO - 2015-12-28 07:01:05 --> Config Class Initialized
INFO - 2015-12-28 07:01:05 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:05 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:05 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:05 --> URI Class Initialized
INFO - 2015-12-28 07:01:05 --> Router Class Initialized
INFO - 2015-12-28 07:01:05 --> Output Class Initialized
INFO - 2015-12-28 07:01:05 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:05 --> Input Class Initialized
INFO - 2015-12-28 07:01:05 --> Language Class Initialized
INFO - 2015-12-28 07:01:05 --> Loader Class Initialized
INFO - 2015-12-28 07:01:05 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:05 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:05 --> Controller Class Initialized
INFO - 2015-12-28 07:01:05 --> Model Class Initialized
INFO - 2015-12-28 07:01:05 --> Model Class Initialized
INFO - 2015-12-28 07:01:05 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-28 07:01:05 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:05 --> Total execution time: 0.1032
INFO - 2015-12-28 07:01:05 --> Config Class Initialized
INFO - 2015-12-28 07:01:05 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:05 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:05 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:05 --> URI Class Initialized
INFO - 2015-12-28 07:01:05 --> Router Class Initialized
INFO - 2015-12-28 07:01:05 --> Output Class Initialized
INFO - 2015-12-28 07:01:05 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:05 --> Input Class Initialized
INFO - 2015-12-28 07:01:05 --> Language Class Initialized
INFO - 2015-12-28 07:01:05 --> Loader Class Initialized
INFO - 2015-12-28 07:01:05 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:05 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:05 --> Controller Class Initialized
DEBUG - 2015-12-28 07:01:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 07:01:05 --> Helper loaded: inflector_helper
INFO - 2015-12-28 07:01:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 07:01:05 --> Model Class Initialized
INFO - 2015-12-28 07:01:05 --> Model Class Initialized
INFO - 2015-12-28 07:01:05 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:05 --> Total execution time: 0.1370
INFO - 2015-12-28 07:01:08 --> Config Class Initialized
INFO - 2015-12-28 07:01:08 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:08 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:08 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:08 --> URI Class Initialized
INFO - 2015-12-28 07:01:08 --> Router Class Initialized
INFO - 2015-12-28 07:01:08 --> Output Class Initialized
INFO - 2015-12-28 07:01:08 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:08 --> Input Class Initialized
INFO - 2015-12-28 07:01:08 --> Language Class Initialized
INFO - 2015-12-28 07:01:08 --> Loader Class Initialized
INFO - 2015-12-28 07:01:08 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:08 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:08 --> Controller Class Initialized
DEBUG - 2015-12-28 07:01:08 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 07:01:08 --> Helper loaded: inflector_helper
INFO - 2015-12-28 07:01:08 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 07:01:08 --> Model Class Initialized
INFO - 2015-12-28 07:01:08 --> Model Class Initialized
INFO - 2015-12-28 07:01:09 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:09 --> Total execution time: 0.1704
INFO - 2015-12-28 07:01:10 --> Config Class Initialized
INFO - 2015-12-28 07:01:10 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:10 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:10 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:10 --> URI Class Initialized
INFO - 2015-12-28 07:01:10 --> Router Class Initialized
INFO - 2015-12-28 07:01:10 --> Output Class Initialized
INFO - 2015-12-28 07:01:10 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:10 --> Input Class Initialized
INFO - 2015-12-28 07:01:10 --> Language Class Initialized
INFO - 2015-12-28 07:01:10 --> Loader Class Initialized
INFO - 2015-12-28 07:01:10 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:10 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:10 --> Controller Class Initialized
DEBUG - 2015-12-28 07:01:10 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 07:01:10 --> Helper loaded: inflector_helper
INFO - 2015-12-28 07:01:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 07:01:10 --> Model Class Initialized
INFO - 2015-12-28 07:01:10 --> Model Class Initialized
INFO - 2015-12-28 07:01:10 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:10 --> Total execution time: 0.1543
INFO - 2015-12-28 07:01:11 --> Config Class Initialized
INFO - 2015-12-28 07:01:11 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:11 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:11 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:11 --> URI Class Initialized
INFO - 2015-12-28 07:01:11 --> Router Class Initialized
INFO - 2015-12-28 07:01:11 --> Output Class Initialized
INFO - 2015-12-28 07:01:11 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:11 --> Input Class Initialized
INFO - 2015-12-28 07:01:11 --> Language Class Initialized
INFO - 2015-12-28 07:01:12 --> Loader Class Initialized
INFO - 2015-12-28 07:01:12 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:12 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:12 --> Controller Class Initialized
DEBUG - 2015-12-28 07:01:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 07:01:12 --> Helper loaded: inflector_helper
INFO - 2015-12-28 07:01:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 07:01:12 --> Model Class Initialized
INFO - 2015-12-28 07:01:12 --> Model Class Initialized
INFO - 2015-12-28 07:01:12 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:12 --> Total execution time: 0.1051
INFO - 2015-12-28 07:01:18 --> Config Class Initialized
INFO - 2015-12-28 07:01:18 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:18 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:18 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:18 --> URI Class Initialized
INFO - 2015-12-28 07:01:18 --> Router Class Initialized
INFO - 2015-12-28 07:01:18 --> Output Class Initialized
INFO - 2015-12-28 07:01:18 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:18 --> Input Class Initialized
INFO - 2015-12-28 07:01:18 --> Language Class Initialized
INFO - 2015-12-28 07:01:18 --> Loader Class Initialized
INFO - 2015-12-28 07:01:18 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:18 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:18 --> Controller Class Initialized
INFO - 2015-12-28 07:01:18 --> Model Class Initialized
INFO - 2015-12-28 07:01:18 --> Model Class Initialized
INFO - 2015-12-28 07:01:18 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-28 07:01:18 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:18 --> Total execution time: 0.1158
INFO - 2015-12-28 07:01:18 --> Config Class Initialized
INFO - 2015-12-28 07:01:18 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:18 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:18 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:18 --> URI Class Initialized
INFO - 2015-12-28 07:01:18 --> Router Class Initialized
INFO - 2015-12-28 07:01:18 --> Output Class Initialized
INFO - 2015-12-28 07:01:18 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:18 --> Input Class Initialized
INFO - 2015-12-28 07:01:18 --> Language Class Initialized
INFO - 2015-12-28 07:01:18 --> Loader Class Initialized
INFO - 2015-12-28 07:01:18 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:18 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:18 --> Controller Class Initialized
INFO - 2015-12-28 07:01:18 --> Model Class Initialized
INFO - 2015-12-28 07:01:18 --> Model Class Initialized
INFO - 2015-12-28 07:01:18 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-28 07:01:18 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:18 --> Total execution time: 0.1241
INFO - 2015-12-28 07:01:18 --> Config Class Initialized
INFO - 2015-12-28 07:01:18 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:18 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:18 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:18 --> URI Class Initialized
INFO - 2015-12-28 07:01:18 --> Router Class Initialized
INFO - 2015-12-28 07:01:18 --> Output Class Initialized
INFO - 2015-12-28 07:01:18 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:18 --> Input Class Initialized
INFO - 2015-12-28 07:01:18 --> Language Class Initialized
INFO - 2015-12-28 07:01:18 --> Loader Class Initialized
INFO - 2015-12-28 07:01:18 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:18 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:18 --> Controller Class Initialized
DEBUG - 2015-12-28 07:01:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 07:01:18 --> Helper loaded: inflector_helper
INFO - 2015-12-28 07:01:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 07:01:18 --> Model Class Initialized
INFO - 2015-12-28 07:01:18 --> Model Class Initialized
INFO - 2015-12-28 07:01:18 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:18 --> Total execution time: 0.1363
INFO - 2015-12-28 07:01:25 --> Config Class Initialized
INFO - 2015-12-28 07:01:25 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:25 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:25 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:25 --> URI Class Initialized
INFO - 2015-12-28 07:01:25 --> Router Class Initialized
INFO - 2015-12-28 07:01:25 --> Output Class Initialized
INFO - 2015-12-28 07:01:25 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:25 --> Input Class Initialized
INFO - 2015-12-28 07:01:25 --> Language Class Initialized
INFO - 2015-12-28 07:01:25 --> Loader Class Initialized
INFO - 2015-12-28 07:01:25 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:25 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:25 --> Controller Class Initialized
DEBUG - 2015-12-28 07:01:25 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 07:01:25 --> Helper loaded: inflector_helper
INFO - 2015-12-28 07:01:25 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 07:01:25 --> Model Class Initialized
INFO - 2015-12-28 07:01:25 --> Model Class Initialized
INFO - 2015-12-28 07:01:25 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:25 --> Total execution time: 0.1659
INFO - 2015-12-28 07:01:27 --> Config Class Initialized
INFO - 2015-12-28 07:01:27 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:28 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:28 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:28 --> URI Class Initialized
INFO - 2015-12-28 07:01:28 --> Router Class Initialized
INFO - 2015-12-28 07:01:28 --> Output Class Initialized
INFO - 2015-12-28 07:01:28 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:28 --> Input Class Initialized
INFO - 2015-12-28 07:01:28 --> Language Class Initialized
INFO - 2015-12-28 07:01:28 --> Loader Class Initialized
INFO - 2015-12-28 07:01:28 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:28 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:28 --> Controller Class Initialized
INFO - 2015-12-28 07:01:28 --> Model Class Initialized
INFO - 2015-12-28 07:01:28 --> Model Class Initialized
INFO - 2015-12-28 07:01:28 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-28 07:01:28 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:28 --> Total execution time: 0.1167
INFO - 2015-12-28 07:01:28 --> Config Class Initialized
INFO - 2015-12-28 07:01:28 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:01:28 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:28 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:28 --> URI Class Initialized
INFO - 2015-12-28 07:01:28 --> Router Class Initialized
INFO - 2015-12-28 07:01:28 --> Output Class Initialized
INFO - 2015-12-28 07:01:28 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:28 --> Input Class Initialized
INFO - 2015-12-28 07:01:28 --> Language Class Initialized
INFO - 2015-12-28 07:01:28 --> Loader Class Initialized
INFO - 2015-12-28 07:01:28 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:28 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:28 --> Controller Class Initialized
INFO - 2015-12-28 07:01:28 --> Model Class Initialized
INFO - 2015-12-28 07:01:28 --> Model Class Initialized
INFO - 2015-12-28 07:01:28 --> Config Class Initialized
INFO - 2015-12-28 07:01:28 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-28 07:01:28 --> Hooks Class Initialized
INFO - 2015-12-28 07:01:28 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:28 --> Total execution time: 0.1216
DEBUG - 2015-12-28 07:01:28 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:01:28 --> Utf8 Class Initialized
INFO - 2015-12-28 07:01:28 --> URI Class Initialized
INFO - 2015-12-28 07:01:28 --> Router Class Initialized
INFO - 2015-12-28 07:01:28 --> Output Class Initialized
INFO - 2015-12-28 07:01:28 --> Security Class Initialized
DEBUG - 2015-12-28 07:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:01:28 --> Input Class Initialized
INFO - 2015-12-28 07:01:28 --> Language Class Initialized
INFO - 2015-12-28 07:01:28 --> Loader Class Initialized
INFO - 2015-12-28 07:01:28 --> Helper loaded: url_helper
INFO - 2015-12-28 07:01:28 --> Database Driver Class Initialized
INFO - 2015-12-28 07:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:01:28 --> Controller Class Initialized
DEBUG - 2015-12-28 07:01:28 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 07:01:28 --> Helper loaded: inflector_helper
INFO - 2015-12-28 07:01:28 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 07:01:28 --> Model Class Initialized
INFO - 2015-12-28 07:01:28 --> Model Class Initialized
INFO - 2015-12-28 07:01:28 --> Final output sent to browser
DEBUG - 2015-12-28 07:01:28 --> Total execution time: 0.1501
INFO - 2015-12-28 07:02:26 --> Config Class Initialized
INFO - 2015-12-28 07:02:26 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:02:26 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:02:26 --> Utf8 Class Initialized
INFO - 2015-12-28 07:02:26 --> URI Class Initialized
INFO - 2015-12-28 07:02:26 --> Router Class Initialized
INFO - 2015-12-28 07:02:26 --> Output Class Initialized
INFO - 2015-12-28 07:02:26 --> Security Class Initialized
DEBUG - 2015-12-28 07:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:02:26 --> Input Class Initialized
INFO - 2015-12-28 07:02:26 --> Language Class Initialized
INFO - 2015-12-28 07:02:26 --> Loader Class Initialized
INFO - 2015-12-28 07:02:26 --> Helper loaded: url_helper
INFO - 2015-12-28 07:02:27 --> Database Driver Class Initialized
INFO - 2015-12-28 07:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:02:27 --> Controller Class Initialized
INFO - 2015-12-28 07:02:27 --> Helper loaded: form_helper
INFO - 2015-12-28 07:02:27 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-28 07:02:27 --> Final output sent to browser
DEBUG - 2015-12-28 07:02:27 --> Total execution time: 0.3907
INFO - 2015-12-28 07:02:30 --> Config Class Initialized
INFO - 2015-12-28 07:02:30 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:02:30 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:02:30 --> Utf8 Class Initialized
INFO - 2015-12-28 07:02:30 --> URI Class Initialized
INFO - 2015-12-28 07:02:30 --> Router Class Initialized
INFO - 2015-12-28 07:02:30 --> Output Class Initialized
INFO - 2015-12-28 07:02:30 --> Security Class Initialized
DEBUG - 2015-12-28 07:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:02:30 --> Input Class Initialized
INFO - 2015-12-28 07:02:30 --> Language Class Initialized
INFO - 2015-12-28 07:02:30 --> Loader Class Initialized
INFO - 2015-12-28 07:02:30 --> Helper loaded: url_helper
INFO - 2015-12-28 07:02:30 --> Database Driver Class Initialized
INFO - 2015-12-28 07:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:02:30 --> Controller Class Initialized
INFO - 2015-12-28 07:02:30 --> Model Class Initialized
INFO - 2015-12-28 07:02:30 --> Model Class Initialized
INFO - 2015-12-28 07:02:30 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-28 07:02:30 --> Final output sent to browser
DEBUG - 2015-12-28 07:02:30 --> Total execution time: 0.1303
INFO - 2015-12-28 07:02:31 --> Config Class Initialized
INFO - 2015-12-28 07:02:31 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:02:31 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:02:31 --> Utf8 Class Initialized
INFO - 2015-12-28 07:02:31 --> URI Class Initialized
INFO - 2015-12-28 07:02:31 --> Router Class Initialized
INFO - 2015-12-28 07:02:31 --> Output Class Initialized
INFO - 2015-12-28 07:02:31 --> Security Class Initialized
DEBUG - 2015-12-28 07:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:02:31 --> Input Class Initialized
INFO - 2015-12-28 07:02:31 --> Language Class Initialized
INFO - 2015-12-28 07:02:31 --> Loader Class Initialized
INFO - 2015-12-28 07:02:31 --> Helper loaded: url_helper
INFO - 2015-12-28 07:02:31 --> Database Driver Class Initialized
INFO - 2015-12-28 07:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:02:31 --> Controller Class Initialized
INFO - 2015-12-28 07:02:31 --> Model Class Initialized
INFO - 2015-12-28 07:02:31 --> Model Class Initialized
INFO - 2015-12-28 07:02:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-28 07:02:31 --> Final output sent to browser
INFO - 2015-12-28 07:02:31 --> Config Class Initialized
DEBUG - 2015-12-28 07:02:31 --> Total execution time: 0.0936
INFO - 2015-12-28 07:02:31 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:02:31 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:02:31 --> Utf8 Class Initialized
INFO - 2015-12-28 07:02:31 --> URI Class Initialized
INFO - 2015-12-28 07:02:31 --> Router Class Initialized
INFO - 2015-12-28 07:02:31 --> Output Class Initialized
INFO - 2015-12-28 07:02:31 --> Security Class Initialized
DEBUG - 2015-12-28 07:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:02:31 --> Input Class Initialized
INFO - 2015-12-28 07:02:31 --> Language Class Initialized
INFO - 2015-12-28 07:02:31 --> Loader Class Initialized
INFO - 2015-12-28 07:02:31 --> Helper loaded: url_helper
INFO - 2015-12-28 07:02:31 --> Database Driver Class Initialized
INFO - 2015-12-28 07:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:02:31 --> Controller Class Initialized
DEBUG - 2015-12-28 07:02:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 07:02:31 --> Helper loaded: inflector_helper
INFO - 2015-12-28 07:02:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 07:02:31 --> Model Class Initialized
INFO - 2015-12-28 07:02:31 --> Model Class Initialized
INFO - 2015-12-28 07:02:31 --> Final output sent to browser
DEBUG - 2015-12-28 07:02:31 --> Total execution time: 0.1219
INFO - 2015-12-28 07:06:39 --> Config Class Initialized
INFO - 2015-12-28 07:06:39 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:06:39 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:06:39 --> Utf8 Class Initialized
INFO - 2015-12-28 07:06:39 --> URI Class Initialized
INFO - 2015-12-28 07:06:39 --> Router Class Initialized
INFO - 2015-12-28 07:06:39 --> Output Class Initialized
INFO - 2015-12-28 07:06:39 --> Security Class Initialized
DEBUG - 2015-12-28 07:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:06:39 --> Input Class Initialized
INFO - 2015-12-28 07:06:39 --> Language Class Initialized
INFO - 2015-12-28 07:06:39 --> Loader Class Initialized
INFO - 2015-12-28 07:06:39 --> Helper loaded: url_helper
INFO - 2015-12-28 07:06:39 --> Database Driver Class Initialized
INFO - 2015-12-28 07:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:06:39 --> Controller Class Initialized
DEBUG - 2015-12-28 07:06:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 07:06:39 --> Helper loaded: inflector_helper
INFO - 2015-12-28 07:06:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 07:06:39 --> Model Class Initialized
INFO - 2015-12-28 07:06:39 --> Model Class Initialized
INFO - 2015-12-28 07:06:39 --> Final output sent to browser
DEBUG - 2015-12-28 07:06:39 --> Total execution time: 0.4638
INFO - 2015-12-28 07:06:43 --> Config Class Initialized
INFO - 2015-12-28 07:06:43 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:06:43 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:06:43 --> Utf8 Class Initialized
INFO - 2015-12-28 07:06:43 --> URI Class Initialized
INFO - 2015-12-28 07:06:43 --> Router Class Initialized
INFO - 2015-12-28 07:06:43 --> Output Class Initialized
INFO - 2015-12-28 07:06:43 --> Security Class Initialized
DEBUG - 2015-12-28 07:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:06:43 --> Input Class Initialized
INFO - 2015-12-28 07:06:43 --> Language Class Initialized
INFO - 2015-12-28 07:06:43 --> Loader Class Initialized
INFO - 2015-12-28 07:06:43 --> Helper loaded: url_helper
INFO - 2015-12-28 07:06:43 --> Database Driver Class Initialized
INFO - 2015-12-28 07:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:06:43 --> Controller Class Initialized
INFO - 2015-12-28 07:06:43 --> Model Class Initialized
INFO - 2015-12-28 07:06:43 --> Model Class Initialized
INFO - 2015-12-28 07:06:43 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-28 07:06:43 --> Final output sent to browser
DEBUG - 2015-12-28 07:06:43 --> Total execution time: 0.1188
INFO - 2015-12-28 07:06:43 --> Config Class Initialized
INFO - 2015-12-28 07:06:43 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:06:43 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:06:43 --> Utf8 Class Initialized
INFO - 2015-12-28 07:06:43 --> URI Class Initialized
INFO - 2015-12-28 07:06:43 --> Router Class Initialized
INFO - 2015-12-28 07:06:43 --> Output Class Initialized
INFO - 2015-12-28 07:06:43 --> Security Class Initialized
DEBUG - 2015-12-28 07:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:06:43 --> Input Class Initialized
INFO - 2015-12-28 07:06:43 --> Language Class Initialized
INFO - 2015-12-28 07:06:43 --> Loader Class Initialized
INFO - 2015-12-28 07:06:43 --> Helper loaded: url_helper
INFO - 2015-12-28 07:06:43 --> Database Driver Class Initialized
INFO - 2015-12-28 07:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:06:43 --> Controller Class Initialized
INFO - 2015-12-28 07:06:43 --> Model Class Initialized
INFO - 2015-12-28 07:06:43 --> Model Class Initialized
INFO - 2015-12-28 07:06:43 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-28 07:06:43 --> Final output sent to browser
DEBUG - 2015-12-28 07:06:43 --> Total execution time: 0.1031
INFO - 2015-12-28 07:06:43 --> Config Class Initialized
INFO - 2015-12-28 07:06:43 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:06:43 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:06:43 --> Utf8 Class Initialized
INFO - 2015-12-28 07:06:43 --> URI Class Initialized
INFO - 2015-12-28 07:06:43 --> Router Class Initialized
INFO - 2015-12-28 07:06:43 --> Output Class Initialized
INFO - 2015-12-28 07:06:43 --> Security Class Initialized
DEBUG - 2015-12-28 07:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:06:43 --> Input Class Initialized
INFO - 2015-12-28 07:06:43 --> Language Class Initialized
INFO - 2015-12-28 07:06:43 --> Loader Class Initialized
INFO - 2015-12-28 07:06:43 --> Helper loaded: url_helper
INFO - 2015-12-28 07:06:43 --> Database Driver Class Initialized
INFO - 2015-12-28 07:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:06:43 --> Controller Class Initialized
DEBUG - 2015-12-28 07:06:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 07:06:43 --> Helper loaded: inflector_helper
INFO - 2015-12-28 07:06:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 07:06:43 --> Model Class Initialized
INFO - 2015-12-28 07:06:43 --> Model Class Initialized
INFO - 2015-12-28 07:06:43 --> Final output sent to browser
DEBUG - 2015-12-28 07:06:43 --> Total execution time: 0.1242
INFO - 2015-12-28 07:24:48 --> Config Class Initialized
INFO - 2015-12-28 07:24:48 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:24:48 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:24:48 --> Utf8 Class Initialized
INFO - 2015-12-28 07:24:48 --> URI Class Initialized
INFO - 2015-12-28 07:24:48 --> Router Class Initialized
INFO - 2015-12-28 07:24:48 --> Output Class Initialized
INFO - 2015-12-28 07:24:48 --> Security Class Initialized
DEBUG - 2015-12-28 07:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:24:48 --> Input Class Initialized
INFO - 2015-12-28 07:24:48 --> Language Class Initialized
INFO - 2015-12-28 07:24:48 --> Loader Class Initialized
INFO - 2015-12-28 07:24:48 --> Helper loaded: url_helper
INFO - 2015-12-28 07:24:48 --> Database Driver Class Initialized
INFO - 2015-12-28 07:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:24:48 --> Controller Class Initialized
INFO - 2015-12-28 07:24:48 --> Model Class Initialized
INFO - 2015-12-28 07:24:48 --> Model Class Initialized
INFO - 2015-12-28 07:24:48 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-28 07:24:48 --> Final output sent to browser
DEBUG - 2015-12-28 07:24:48 --> Total execution time: 0.4097
INFO - 2015-12-28 07:24:49 --> Config Class Initialized
INFO - 2015-12-28 07:24:49 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:24:49 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:24:49 --> Utf8 Class Initialized
INFO - 2015-12-28 07:24:49 --> URI Class Initialized
INFO - 2015-12-28 07:24:49 --> Router Class Initialized
INFO - 2015-12-28 07:24:49 --> Output Class Initialized
INFO - 2015-12-28 07:24:49 --> Security Class Initialized
DEBUG - 2015-12-28 07:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:24:49 --> Input Class Initialized
INFO - 2015-12-28 07:24:49 --> Language Class Initialized
INFO - 2015-12-28 07:24:49 --> Loader Class Initialized
INFO - 2015-12-28 07:24:49 --> Helper loaded: url_helper
INFO - 2015-12-28 07:24:49 --> Database Driver Class Initialized
INFO - 2015-12-28 07:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:24:49 --> Controller Class Initialized
INFO - 2015-12-28 07:24:49 --> Model Class Initialized
INFO - 2015-12-28 07:24:49 --> Model Class Initialized
INFO - 2015-12-28 07:24:49 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2015-12-28 07:24:49 --> Final output sent to browser
DEBUG - 2015-12-28 07:24:49 --> Total execution time: 0.0894
INFO - 2015-12-28 07:24:49 --> Config Class Initialized
INFO - 2015-12-28 07:24:49 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:24:49 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:24:49 --> Utf8 Class Initialized
INFO - 2015-12-28 07:24:49 --> URI Class Initialized
INFO - 2015-12-28 07:24:49 --> Router Class Initialized
INFO - 2015-12-28 07:24:49 --> Output Class Initialized
INFO - 2015-12-28 07:24:49 --> Security Class Initialized
DEBUG - 2015-12-28 07:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:24:49 --> Input Class Initialized
INFO - 2015-12-28 07:24:49 --> Language Class Initialized
INFO - 2015-12-28 07:24:49 --> Loader Class Initialized
INFO - 2015-12-28 07:24:49 --> Helper loaded: url_helper
INFO - 2015-12-28 07:24:49 --> Database Driver Class Initialized
INFO - 2015-12-28 07:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:24:49 --> Controller Class Initialized
DEBUG - 2015-12-28 07:24:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 07:24:49 --> Helper loaded: inflector_helper
INFO - 2015-12-28 07:24:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 07:24:49 --> Model Class Initialized
INFO - 2015-12-28 07:24:49 --> Model Class Initialized
INFO - 2015-12-28 07:24:49 --> Final output sent to browser
DEBUG - 2015-12-28 07:24:49 --> Total execution time: 0.1379
INFO - 2015-12-28 07:24:50 --> Config Class Initialized
INFO - 2015-12-28 07:24:50 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:24:50 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:24:50 --> Utf8 Class Initialized
INFO - 2015-12-28 07:24:50 --> URI Class Initialized
INFO - 2015-12-28 07:24:50 --> Router Class Initialized
INFO - 2015-12-28 07:24:50 --> Output Class Initialized
INFO - 2015-12-28 07:24:50 --> Security Class Initialized
DEBUG - 2015-12-28 07:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:24:50 --> Input Class Initialized
INFO - 2015-12-28 07:24:50 --> Language Class Initialized
INFO - 2015-12-28 07:24:50 --> Loader Class Initialized
INFO - 2015-12-28 07:24:50 --> Helper loaded: url_helper
INFO - 2015-12-28 07:24:50 --> Database Driver Class Initialized
INFO - 2015-12-28 07:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:24:50 --> Controller Class Initialized
INFO - 2015-12-28 07:24:50 --> Config Class Initialized
INFO - 2015-12-28 07:24:50 --> Hooks Class Initialized
DEBUG - 2015-12-28 07:24:50 --> UTF-8 Support Enabled
INFO - 2015-12-28 07:24:50 --> Utf8 Class Initialized
INFO - 2015-12-28 07:24:50 --> URI Class Initialized
INFO - 2015-12-28 07:24:50 --> Router Class Initialized
INFO - 2015-12-28 07:24:50 --> Output Class Initialized
INFO - 2015-12-28 07:24:50 --> Security Class Initialized
DEBUG - 2015-12-28 07:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 07:24:50 --> Input Class Initialized
INFO - 2015-12-28 07:24:50 --> Language Class Initialized
INFO - 2015-12-28 07:24:50 --> Loader Class Initialized
INFO - 2015-12-28 07:24:50 --> Helper loaded: url_helper
INFO - 2015-12-28 07:24:50 --> Database Driver Class Initialized
INFO - 2015-12-28 07:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 07:24:50 --> Controller Class Initialized
INFO - 2015-12-28 07:24:50 --> Helper loaded: form_helper
INFO - 2015-12-28 07:24:50 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2015-12-28 07:24:50 --> Final output sent to browser
DEBUG - 2015-12-28 07:24:50 --> Total execution time: 0.0926
INFO - 2015-12-28 09:34:43 --> Config Class Initialized
INFO - 2015-12-28 09:34:44 --> Hooks Class Initialized
DEBUG - 2015-12-28 09:34:44 --> UTF-8 Support Enabled
INFO - 2015-12-28 09:34:44 --> Utf8 Class Initialized
INFO - 2015-12-28 09:34:44 --> URI Class Initialized
DEBUG - 2015-12-28 09:34:44 --> No URI present. Default controller set.
INFO - 2015-12-28 09:34:44 --> Router Class Initialized
INFO - 2015-12-28 09:34:44 --> Output Class Initialized
INFO - 2015-12-28 09:34:44 --> Security Class Initialized
DEBUG - 2015-12-28 09:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 09:34:44 --> Input Class Initialized
INFO - 2015-12-28 09:34:44 --> Language Class Initialized
INFO - 2015-12-28 09:34:44 --> Loader Class Initialized
INFO - 2015-12-28 09:34:44 --> Helper loaded: url_helper
INFO - 2015-12-28 09:34:44 --> Database Driver Class Initialized
INFO - 2015-12-28 09:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 09:34:44 --> Controller Class Initialized
INFO - 2015-12-28 09:34:44 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2015-12-28 09:34:44 --> Final output sent to browser
DEBUG - 2015-12-28 09:34:44 --> Total execution time: 0.4697
INFO - 2015-12-28 09:34:51 --> Config Class Initialized
INFO - 2015-12-28 09:34:51 --> Hooks Class Initialized
DEBUG - 2015-12-28 09:34:51 --> UTF-8 Support Enabled
INFO - 2015-12-28 09:34:51 --> Utf8 Class Initialized
INFO - 2015-12-28 09:34:51 --> URI Class Initialized
INFO - 2015-12-28 09:34:51 --> Router Class Initialized
INFO - 2015-12-28 09:34:51 --> Output Class Initialized
INFO - 2015-12-28 09:34:51 --> Security Class Initialized
DEBUG - 2015-12-28 09:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 09:34:51 --> Input Class Initialized
INFO - 2015-12-28 09:34:51 --> Language Class Initialized
INFO - 2015-12-28 09:34:51 --> Loader Class Initialized
INFO - 2015-12-28 09:34:51 --> Helper loaded: url_helper
INFO - 2015-12-28 09:34:51 --> Database Driver Class Initialized
INFO - 2015-12-28 09:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 09:34:51 --> Controller Class Initialized
INFO - 2015-12-28 09:34:51 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2015-12-28 09:34:51 --> Final output sent to browser
DEBUG - 2015-12-28 09:34:51 --> Total execution time: 0.0999
INFO - 2015-12-28 09:34:52 --> Config Class Initialized
INFO - 2015-12-28 09:34:52 --> Hooks Class Initialized
DEBUG - 2015-12-28 09:34:52 --> UTF-8 Support Enabled
INFO - 2015-12-28 09:34:52 --> Utf8 Class Initialized
INFO - 2015-12-28 09:34:52 --> URI Class Initialized
INFO - 2015-12-28 09:34:52 --> Router Class Initialized
INFO - 2015-12-28 09:34:52 --> Output Class Initialized
INFO - 2015-12-28 09:34:52 --> Security Class Initialized
DEBUG - 2015-12-28 09:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-12-28 09:34:52 --> Input Class Initialized
INFO - 2015-12-28 09:34:52 --> Language Class Initialized
INFO - 2015-12-28 09:34:52 --> Loader Class Initialized
INFO - 2015-12-28 09:34:52 --> Helper loaded: url_helper
INFO - 2015-12-28 09:34:52 --> Database Driver Class Initialized
INFO - 2015-12-28 09:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2015-12-28 09:34:52 --> Controller Class Initialized
DEBUG - 2015-12-28 09:34:52 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2015-12-28 09:34:52 --> Helper loaded: inflector_helper
INFO - 2015-12-28 09:34:52 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2015-12-28 09:34:52 --> Model Class Initialized
INFO - 2015-12-28 09:34:52 --> Model Class Initialized
INFO - 2015-12-28 09:34:52 --> Final output sent to browser
DEBUG - 2015-12-28 09:34:52 --> Total execution time: 0.1354
