<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-07 06:47:50 --> Config Class Initialized
INFO - 2016-01-07 06:47:50 --> Hooks Class Initialized
DEBUG - 2016-01-07 06:47:50 --> UTF-8 Support Enabled
INFO - 2016-01-07 06:47:50 --> Utf8 Class Initialized
INFO - 2016-01-07 06:47:50 --> URI Class Initialized
INFO - 2016-01-07 06:47:50 --> Router Class Initialized
INFO - 2016-01-07 06:47:50 --> Output Class Initialized
INFO - 2016-01-07 06:47:50 --> Security Class Initialized
DEBUG - 2016-01-07 06:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-07 06:47:50 --> Input Class Initialized
INFO - 2016-01-07 06:47:50 --> Language Class Initialized
INFO - 2016-01-07 06:47:50 --> Loader Class Initialized
INFO - 2016-01-07 06:47:50 --> Helper loaded: url_helper
INFO - 2016-01-07 06:47:50 --> Database Driver Class Initialized
INFO - 2016-01-07 06:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-07 06:47:50 --> Controller Class Initialized
INFO - 2016-01-07 06:47:50 --> Helper loaded: form_helper
INFO - 2016-01-07 06:47:50 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-07 06:47:50 --> Final output sent to browser
DEBUG - 2016-01-07 06:47:50 --> Total execution time: 0.5321
