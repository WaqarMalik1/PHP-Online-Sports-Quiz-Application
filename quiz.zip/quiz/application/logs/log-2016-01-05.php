<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-05 07:38:31 --> Config Class Initialized
INFO - 2016-01-05 07:38:31 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:38:31 --> UTF-8 Support Enabled
INFO - 2016-01-05 07:38:31 --> Utf8 Class Initialized
INFO - 2016-01-05 07:38:31 --> URI Class Initialized
INFO - 2016-01-05 07:38:31 --> Router Class Initialized
INFO - 2016-01-05 07:38:31 --> Output Class Initialized
INFO - 2016-01-05 07:38:31 --> Security Class Initialized
DEBUG - 2016-01-05 07:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 07:38:31 --> Input Class Initialized
INFO - 2016-01-05 07:38:31 --> Language Class Initialized
INFO - 2016-01-05 07:38:31 --> Loader Class Initialized
INFO - 2016-01-05 07:38:31 --> Helper loaded: url_helper
INFO - 2016-01-05 07:38:31 --> Database Driver Class Initialized
INFO - 2016-01-05 07:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 07:38:32 --> Controller Class Initialized
INFO - 2016-01-05 07:38:32 --> Helper loaded: form_helper
INFO - 2016-01-05 07:38:32 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-05 07:38:32 --> Final output sent to browser
DEBUG - 2016-01-05 07:38:32 --> Total execution time: 0.2260
INFO - 2016-01-05 07:38:39 --> Config Class Initialized
INFO - 2016-01-05 07:38:39 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:38:39 --> UTF-8 Support Enabled
INFO - 2016-01-05 07:38:39 --> Utf8 Class Initialized
INFO - 2016-01-05 07:38:39 --> URI Class Initialized
DEBUG - 2016-01-05 07:38:39 --> No URI present. Default controller set.
INFO - 2016-01-05 07:38:39 --> Router Class Initialized
INFO - 2016-01-05 07:38:39 --> Output Class Initialized
INFO - 2016-01-05 07:38:39 --> Security Class Initialized
DEBUG - 2016-01-05 07:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 07:38:39 --> Input Class Initialized
INFO - 2016-01-05 07:38:39 --> Language Class Initialized
INFO - 2016-01-05 07:38:39 --> Loader Class Initialized
INFO - 2016-01-05 07:38:39 --> Helper loaded: url_helper
INFO - 2016-01-05 07:38:39 --> Database Driver Class Initialized
INFO - 2016-01-05 07:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 07:38:39 --> Controller Class Initialized
INFO - 2016-01-05 07:38:39 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-05 07:38:39 --> Final output sent to browser
DEBUG - 2016-01-05 07:38:39 --> Total execution time: 0.1318
INFO - 2016-01-05 07:38:41 --> Config Class Initialized
INFO - 2016-01-05 07:38:41 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:38:41 --> UTF-8 Support Enabled
INFO - 2016-01-05 07:38:41 --> Utf8 Class Initialized
INFO - 2016-01-05 07:38:41 --> URI Class Initialized
INFO - 2016-01-05 07:38:41 --> Router Class Initialized
INFO - 2016-01-05 07:38:41 --> Output Class Initialized
INFO - 2016-01-05 07:38:41 --> Security Class Initialized
DEBUG - 2016-01-05 07:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 07:38:41 --> Input Class Initialized
INFO - 2016-01-05 07:38:41 --> Language Class Initialized
INFO - 2016-01-05 07:38:41 --> Loader Class Initialized
INFO - 2016-01-05 07:38:41 --> Helper loaded: url_helper
INFO - 2016-01-05 07:38:41 --> Database Driver Class Initialized
INFO - 2016-01-05 07:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 07:38:41 --> Controller Class Initialized
INFO - 2016-01-05 07:38:41 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-05 07:38:41 --> Final output sent to browser
DEBUG - 2016-01-05 07:38:41 --> Total execution time: 0.1003
INFO - 2016-01-05 07:38:42 --> Config Class Initialized
INFO - 2016-01-05 07:38:42 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:38:42 --> UTF-8 Support Enabled
INFO - 2016-01-05 07:38:42 --> Utf8 Class Initialized
INFO - 2016-01-05 07:38:42 --> URI Class Initialized
INFO - 2016-01-05 07:38:42 --> Router Class Initialized
INFO - 2016-01-05 07:38:42 --> Output Class Initialized
INFO - 2016-01-05 07:38:42 --> Security Class Initialized
DEBUG - 2016-01-05 07:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 07:38:42 --> Input Class Initialized
INFO - 2016-01-05 07:38:42 --> Language Class Initialized
INFO - 2016-01-05 07:38:42 --> Loader Class Initialized
INFO - 2016-01-05 07:38:42 --> Helper loaded: url_helper
INFO - 2016-01-05 07:38:42 --> Database Driver Class Initialized
INFO - 2016-01-05 07:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 07:38:42 --> Controller Class Initialized
DEBUG - 2016-01-05 07:38:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 07:38:42 --> Helper loaded: inflector_helper
INFO - 2016-01-05 07:38:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 07:38:42 --> Model Class Initialized
INFO - 2016-01-05 07:38:42 --> Model Class Initialized
INFO - 2016-01-05 07:38:42 --> Final output sent to browser
DEBUG - 2016-01-05 07:38:42 --> Total execution time: 0.1471
INFO - 2016-01-05 07:39:43 --> Config Class Initialized
INFO - 2016-01-05 07:39:43 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:39:43 --> UTF-8 Support Enabled
INFO - 2016-01-05 07:39:43 --> Utf8 Class Initialized
INFO - 2016-01-05 07:39:43 --> URI Class Initialized
INFO - 2016-01-05 07:39:43 --> Router Class Initialized
INFO - 2016-01-05 07:39:43 --> Output Class Initialized
INFO - 2016-01-05 07:39:43 --> Security Class Initialized
DEBUG - 2016-01-05 07:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 07:39:43 --> Input Class Initialized
INFO - 2016-01-05 07:39:43 --> Language Class Initialized
INFO - 2016-01-05 07:39:43 --> Loader Class Initialized
INFO - 2016-01-05 07:39:43 --> Helper loaded: url_helper
INFO - 2016-01-05 07:39:43 --> Database Driver Class Initialized
INFO - 2016-01-05 07:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 07:39:43 --> Controller Class Initialized
DEBUG - 2016-01-05 07:39:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 07:39:43 --> Helper loaded: inflector_helper
INFO - 2016-01-05 07:39:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 07:39:43 --> Model Class Initialized
INFO - 2016-01-05 07:39:43 --> Model Class Initialized
INFO - 2016-01-05 07:39:43 --> Final output sent to browser
DEBUG - 2016-01-05 07:39:43 --> Total execution time: 0.2195
INFO - 2016-01-05 07:41:41 --> Config Class Initialized
INFO - 2016-01-05 07:41:41 --> Hooks Class Initialized
DEBUG - 2016-01-05 07:41:41 --> UTF-8 Support Enabled
INFO - 2016-01-05 07:41:41 --> Utf8 Class Initialized
INFO - 2016-01-05 07:41:41 --> URI Class Initialized
INFO - 2016-01-05 07:41:41 --> Router Class Initialized
INFO - 2016-01-05 07:41:41 --> Output Class Initialized
INFO - 2016-01-05 07:41:41 --> Security Class Initialized
DEBUG - 2016-01-05 07:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 07:41:41 --> Input Class Initialized
INFO - 2016-01-05 07:41:41 --> Language Class Initialized
INFO - 2016-01-05 07:41:41 --> Loader Class Initialized
INFO - 2016-01-05 07:41:41 --> Helper loaded: url_helper
INFO - 2016-01-05 07:41:41 --> Database Driver Class Initialized
INFO - 2016-01-05 07:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 07:41:41 --> Controller Class Initialized
DEBUG - 2016-01-05 07:41:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 07:41:41 --> Helper loaded: inflector_helper
INFO - 2016-01-05 07:41:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 07:41:41 --> Model Class Initialized
INFO - 2016-01-05 07:41:41 --> Model Class Initialized
INFO - 2016-01-05 07:41:41 --> Final output sent to browser
DEBUG - 2016-01-05 07:41:41 --> Total execution time: 0.1454
INFO - 2016-01-05 18:16:04 --> Config Class Initialized
INFO - 2016-01-05 18:16:04 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:16:04 --> UTF-8 Support Enabled
INFO - 2016-01-05 18:16:04 --> Utf8 Class Initialized
INFO - 2016-01-05 18:16:04 --> URI Class Initialized
DEBUG - 2016-01-05 18:16:04 --> No URI present. Default controller set.
INFO - 2016-01-05 18:16:04 --> Router Class Initialized
INFO - 2016-01-05 18:16:04 --> Output Class Initialized
INFO - 2016-01-05 18:16:04 --> Security Class Initialized
DEBUG - 2016-01-05 18:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 18:16:04 --> Input Class Initialized
INFO - 2016-01-05 18:16:04 --> Language Class Initialized
INFO - 2016-01-05 18:16:04 --> Loader Class Initialized
INFO - 2016-01-05 18:16:04 --> Helper loaded: url_helper
INFO - 2016-01-05 18:16:05 --> Database Driver Class Initialized
INFO - 2016-01-05 18:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 18:16:05 --> Controller Class Initialized
INFO - 2016-01-05 18:16:05 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-05 18:16:05 --> Final output sent to browser
DEBUG - 2016-01-05 18:16:05 --> Total execution time: 0.1927
INFO - 2016-01-05 18:16:25 --> Config Class Initialized
INFO - 2016-01-05 18:16:25 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:16:25 --> UTF-8 Support Enabled
INFO - 2016-01-05 18:16:25 --> Utf8 Class Initialized
INFO - 2016-01-05 18:16:25 --> URI Class Initialized
DEBUG - 2016-01-05 18:16:25 --> No URI present. Default controller set.
INFO - 2016-01-05 18:16:25 --> Router Class Initialized
INFO - 2016-01-05 18:16:25 --> Output Class Initialized
INFO - 2016-01-05 18:16:25 --> Security Class Initialized
DEBUG - 2016-01-05 18:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 18:16:25 --> Input Class Initialized
INFO - 2016-01-05 18:16:25 --> Language Class Initialized
INFO - 2016-01-05 18:16:25 --> Loader Class Initialized
INFO - 2016-01-05 18:16:25 --> Helper loaded: url_helper
INFO - 2016-01-05 18:16:25 --> Database Driver Class Initialized
INFO - 2016-01-05 18:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 18:16:26 --> Controller Class Initialized
INFO - 2016-01-05 18:16:26 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-05 18:16:26 --> Final output sent to browser
DEBUG - 2016-01-05 18:16:26 --> Total execution time: 0.1213
INFO - 2016-01-05 18:16:29 --> Config Class Initialized
INFO - 2016-01-05 18:16:29 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:16:29 --> UTF-8 Support Enabled
INFO - 2016-01-05 18:16:29 --> Utf8 Class Initialized
INFO - 2016-01-05 18:16:29 --> URI Class Initialized
DEBUG - 2016-01-05 18:16:29 --> No URI present. Default controller set.
INFO - 2016-01-05 18:16:29 --> Router Class Initialized
INFO - 2016-01-05 18:16:29 --> Output Class Initialized
INFO - 2016-01-05 18:16:29 --> Security Class Initialized
DEBUG - 2016-01-05 18:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 18:16:29 --> Input Class Initialized
INFO - 2016-01-05 18:16:29 --> Language Class Initialized
INFO - 2016-01-05 18:16:29 --> Loader Class Initialized
INFO - 2016-01-05 18:16:29 --> Helper loaded: url_helper
INFO - 2016-01-05 18:16:29 --> Database Driver Class Initialized
INFO - 2016-01-05 18:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 18:16:29 --> Controller Class Initialized
INFO - 2016-01-05 18:16:29 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-05 18:16:29 --> Final output sent to browser
DEBUG - 2016-01-05 18:16:29 --> Total execution time: 0.1052
INFO - 2016-01-05 18:16:48 --> Config Class Initialized
INFO - 2016-01-05 18:16:48 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:16:48 --> UTF-8 Support Enabled
INFO - 2016-01-05 18:16:48 --> Utf8 Class Initialized
INFO - 2016-01-05 18:16:48 --> URI Class Initialized
DEBUG - 2016-01-05 18:16:48 --> No URI present. Default controller set.
INFO - 2016-01-05 18:16:48 --> Router Class Initialized
INFO - 2016-01-05 18:16:48 --> Output Class Initialized
INFO - 2016-01-05 18:16:48 --> Security Class Initialized
DEBUG - 2016-01-05 18:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 18:16:48 --> Input Class Initialized
INFO - 2016-01-05 18:16:48 --> Language Class Initialized
INFO - 2016-01-05 18:16:48 --> Loader Class Initialized
INFO - 2016-01-05 18:16:48 --> Helper loaded: url_helper
INFO - 2016-01-05 18:16:48 --> Database Driver Class Initialized
INFO - 2016-01-05 18:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 18:16:48 --> Controller Class Initialized
INFO - 2016-01-05 18:16:48 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-05 18:16:48 --> Final output sent to browser
DEBUG - 2016-01-05 18:16:48 --> Total execution time: 0.0823
INFO - 2016-01-05 18:17:11 --> Config Class Initialized
INFO - 2016-01-05 18:17:11 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:17:11 --> UTF-8 Support Enabled
INFO - 2016-01-05 18:17:11 --> Utf8 Class Initialized
INFO - 2016-01-05 18:17:11 --> URI Class Initialized
DEBUG - 2016-01-05 18:17:11 --> No URI present. Default controller set.
INFO - 2016-01-05 18:17:11 --> Router Class Initialized
INFO - 2016-01-05 18:17:11 --> Output Class Initialized
INFO - 2016-01-05 18:17:11 --> Security Class Initialized
DEBUG - 2016-01-05 18:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 18:17:11 --> Input Class Initialized
INFO - 2016-01-05 18:17:11 --> Language Class Initialized
INFO - 2016-01-05 18:17:11 --> Loader Class Initialized
INFO - 2016-01-05 18:17:11 --> Helper loaded: url_helper
INFO - 2016-01-05 18:17:11 --> Database Driver Class Initialized
INFO - 2016-01-05 18:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 18:17:11 --> Controller Class Initialized
INFO - 2016-01-05 18:17:11 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-05 18:17:11 --> Final output sent to browser
DEBUG - 2016-01-05 18:17:11 --> Total execution time: 0.0909
INFO - 2016-01-05 18:17:52 --> Config Class Initialized
INFO - 2016-01-05 18:17:52 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:17:52 --> UTF-8 Support Enabled
INFO - 2016-01-05 18:17:52 --> Utf8 Class Initialized
INFO - 2016-01-05 18:17:52 --> URI Class Initialized
INFO - 2016-01-05 18:17:52 --> Router Class Initialized
INFO - 2016-01-05 18:17:52 --> Output Class Initialized
INFO - 2016-01-05 18:17:52 --> Security Class Initialized
DEBUG - 2016-01-05 18:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 18:17:52 --> Input Class Initialized
INFO - 2016-01-05 18:17:52 --> Language Class Initialized
INFO - 2016-01-05 18:17:52 --> Loader Class Initialized
INFO - 2016-01-05 18:17:52 --> Helper loaded: url_helper
INFO - 2016-01-05 18:17:52 --> Database Driver Class Initialized
INFO - 2016-01-05 18:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 18:17:52 --> Controller Class Initialized
INFO - 2016-01-05 18:17:52 --> Helper loaded: form_helper
INFO - 2016-01-05 18:17:52 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-05 18:17:52 --> Final output sent to browser
DEBUG - 2016-01-05 18:17:52 --> Total execution time: 0.1097
INFO - 2016-01-05 18:20:45 --> Config Class Initialized
INFO - 2016-01-05 18:20:45 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:20:45 --> UTF-8 Support Enabled
INFO - 2016-01-05 18:20:45 --> Utf8 Class Initialized
INFO - 2016-01-05 18:20:45 --> URI Class Initialized
DEBUG - 2016-01-05 18:20:45 --> No URI present. Default controller set.
INFO - 2016-01-05 18:20:45 --> Router Class Initialized
INFO - 2016-01-05 18:20:45 --> Output Class Initialized
INFO - 2016-01-05 18:20:45 --> Security Class Initialized
DEBUG - 2016-01-05 18:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 18:20:45 --> Input Class Initialized
INFO - 2016-01-05 18:20:45 --> Language Class Initialized
INFO - 2016-01-05 18:20:45 --> Loader Class Initialized
INFO - 2016-01-05 18:20:45 --> Helper loaded: url_helper
INFO - 2016-01-05 18:20:45 --> Database Driver Class Initialized
INFO - 2016-01-05 18:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 18:20:45 --> Controller Class Initialized
INFO - 2016-01-05 18:20:45 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-05 18:20:45 --> Final output sent to browser
DEBUG - 2016-01-05 18:20:45 --> Total execution time: 0.1362
INFO - 2016-01-05 18:20:54 --> Config Class Initialized
INFO - 2016-01-05 18:20:54 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:20:54 --> UTF-8 Support Enabled
INFO - 2016-01-05 18:20:54 --> Utf8 Class Initialized
INFO - 2016-01-05 18:20:54 --> URI Class Initialized
INFO - 2016-01-05 18:20:54 --> Router Class Initialized
INFO - 2016-01-05 18:20:54 --> Output Class Initialized
INFO - 2016-01-05 18:20:54 --> Security Class Initialized
DEBUG - 2016-01-05 18:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 18:20:54 --> Input Class Initialized
INFO - 2016-01-05 18:20:54 --> Language Class Initialized
INFO - 2016-01-05 18:20:54 --> Loader Class Initialized
INFO - 2016-01-05 18:20:54 --> Helper loaded: url_helper
INFO - 2016-01-05 18:20:54 --> Database Driver Class Initialized
INFO - 2016-01-05 18:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 18:20:54 --> Controller Class Initialized
INFO - 2016-01-05 18:20:54 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-05 18:20:54 --> Final output sent to browser
DEBUG - 2016-01-05 18:20:54 --> Total execution time: 0.1093
INFO - 2016-01-05 18:20:54 --> Config Class Initialized
INFO - 2016-01-05 18:20:54 --> Hooks Class Initialized
DEBUG - 2016-01-05 18:20:54 --> UTF-8 Support Enabled
INFO - 2016-01-05 18:20:54 --> Utf8 Class Initialized
INFO - 2016-01-05 18:20:54 --> URI Class Initialized
INFO - 2016-01-05 18:20:54 --> Router Class Initialized
INFO - 2016-01-05 18:20:54 --> Output Class Initialized
INFO - 2016-01-05 18:20:54 --> Security Class Initialized
DEBUG - 2016-01-05 18:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 18:20:54 --> Input Class Initialized
INFO - 2016-01-05 18:20:54 --> Language Class Initialized
INFO - 2016-01-05 18:20:54 --> Loader Class Initialized
INFO - 2016-01-05 18:20:54 --> Helper loaded: url_helper
INFO - 2016-01-05 18:20:54 --> Database Driver Class Initialized
INFO - 2016-01-05 18:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 18:20:54 --> Controller Class Initialized
DEBUG - 2016-01-05 18:20:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 18:20:54 --> Helper loaded: inflector_helper
INFO - 2016-01-05 18:20:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 18:20:54 --> Model Class Initialized
INFO - 2016-01-05 18:20:54 --> Model Class Initialized
INFO - 2016-01-05 18:20:54 --> Final output sent to browser
DEBUG - 2016-01-05 18:20:54 --> Total execution time: 0.1418
INFO - 2016-01-05 19:22:48 --> Config Class Initialized
INFO - 2016-01-05 19:22:48 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:22:48 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:22:48 --> Utf8 Class Initialized
INFO - 2016-01-05 19:22:48 --> URI Class Initialized
INFO - 2016-01-05 19:22:48 --> Router Class Initialized
INFO - 2016-01-05 19:22:48 --> Output Class Initialized
INFO - 2016-01-05 19:22:48 --> Security Class Initialized
DEBUG - 2016-01-05 19:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:22:48 --> Input Class Initialized
INFO - 2016-01-05 19:22:48 --> Language Class Initialized
INFO - 2016-01-05 19:22:48 --> Loader Class Initialized
INFO - 2016-01-05 19:22:48 --> Helper loaded: url_helper
INFO - 2016-01-05 19:22:48 --> Database Driver Class Initialized
INFO - 2016-01-05 19:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:22:48 --> Controller Class Initialized
INFO - 2016-01-05 19:22:48 --> Helper loaded: form_helper
INFO - 2016-01-05 19:22:48 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-05 19:22:48 --> Final output sent to browser
DEBUG - 2016-01-05 19:22:48 --> Total execution time: 0.1584
INFO - 2016-01-05 19:22:52 --> Config Class Initialized
INFO - 2016-01-05 19:22:52 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:22:52 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:22:52 --> Utf8 Class Initialized
INFO - 2016-01-05 19:22:52 --> URI Class Initialized
INFO - 2016-01-05 19:22:52 --> Router Class Initialized
INFO - 2016-01-05 19:22:52 --> Output Class Initialized
INFO - 2016-01-05 19:22:52 --> Security Class Initialized
DEBUG - 2016-01-05 19:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:22:52 --> Input Class Initialized
INFO - 2016-01-05 19:22:52 --> Language Class Initialized
INFO - 2016-01-05 19:22:52 --> Loader Class Initialized
INFO - 2016-01-05 19:22:52 --> Helper loaded: url_helper
INFO - 2016-01-05 19:22:52 --> Database Driver Class Initialized
INFO - 2016-01-05 19:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:22:52 --> Controller Class Initialized
INFO - 2016-01-05 19:22:52 --> Model Class Initialized
INFO - 2016-01-05 19:22:52 --> Model Class Initialized
INFO - 2016-01-05 19:22:52 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-05 19:22:52 --> Final output sent to browser
DEBUG - 2016-01-05 19:22:52 --> Total execution time: 0.1039
INFO - 2016-01-05 19:22:52 --> Config Class Initialized
INFO - 2016-01-05 19:22:52 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:22:52 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:22:52 --> Utf8 Class Initialized
INFO - 2016-01-05 19:22:52 --> URI Class Initialized
INFO - 2016-01-05 19:22:52 --> Router Class Initialized
INFO - 2016-01-05 19:22:52 --> Output Class Initialized
INFO - 2016-01-05 19:22:52 --> Security Class Initialized
DEBUG - 2016-01-05 19:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:22:52 --> Input Class Initialized
INFO - 2016-01-05 19:22:52 --> Language Class Initialized
INFO - 2016-01-05 19:22:52 --> Loader Class Initialized
INFO - 2016-01-05 19:22:52 --> Helper loaded: url_helper
INFO - 2016-01-05 19:22:52 --> Database Driver Class Initialized
INFO - 2016-01-05 19:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:22:52 --> Controller Class Initialized
INFO - 2016-01-05 19:22:52 --> Model Class Initialized
INFO - 2016-01-05 19:22:52 --> Model Class Initialized
INFO - 2016-01-05 19:22:52 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-05 19:22:52 --> Final output sent to browser
DEBUG - 2016-01-05 19:22:52 --> Total execution time: 0.1222
INFO - 2016-01-05 19:22:52 --> Config Class Initialized
INFO - 2016-01-05 19:22:52 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:22:52 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:22:52 --> Utf8 Class Initialized
INFO - 2016-01-05 19:22:52 --> URI Class Initialized
INFO - 2016-01-05 19:22:52 --> Router Class Initialized
INFO - 2016-01-05 19:22:52 --> Output Class Initialized
INFO - 2016-01-05 19:22:52 --> Security Class Initialized
DEBUG - 2016-01-05 19:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:22:52 --> Input Class Initialized
INFO - 2016-01-05 19:22:52 --> Language Class Initialized
INFO - 2016-01-05 19:22:53 --> Loader Class Initialized
INFO - 2016-01-05 19:22:53 --> Helper loaded: url_helper
INFO - 2016-01-05 19:22:53 --> Database Driver Class Initialized
INFO - 2016-01-05 19:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:22:53 --> Controller Class Initialized
DEBUG - 2016-01-05 19:22:53 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 19:22:53 --> Helper loaded: inflector_helper
INFO - 2016-01-05 19:22:53 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 19:22:53 --> Model Class Initialized
INFO - 2016-01-05 19:22:53 --> Model Class Initialized
INFO - 2016-01-05 19:22:53 --> Final output sent to browser
DEBUG - 2016-01-05 19:22:53 --> Total execution time: 0.1125
INFO - 2016-01-05 19:23:31 --> Config Class Initialized
INFO - 2016-01-05 19:23:31 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:23:31 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:23:31 --> Utf8 Class Initialized
INFO - 2016-01-05 19:23:31 --> URI Class Initialized
INFO - 2016-01-05 19:23:31 --> Router Class Initialized
INFO - 2016-01-05 19:23:31 --> Output Class Initialized
INFO - 2016-01-05 19:23:31 --> Security Class Initialized
DEBUG - 2016-01-05 19:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:23:31 --> Input Class Initialized
INFO - 2016-01-05 19:23:31 --> Language Class Initialized
INFO - 2016-01-05 19:23:31 --> Loader Class Initialized
INFO - 2016-01-05 19:23:31 --> Helper loaded: url_helper
INFO - 2016-01-05 19:23:31 --> Database Driver Class Initialized
INFO - 2016-01-05 19:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:23:31 --> Controller Class Initialized
INFO - 2016-01-05 19:23:31 --> Model Class Initialized
INFO - 2016-01-05 19:23:31 --> Model Class Initialized
INFO - 2016-01-05 19:23:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-05 19:23:31 --> Final output sent to browser
DEBUG - 2016-01-05 19:23:31 --> Total execution time: 0.1175
INFO - 2016-01-05 19:23:31 --> Config Class Initialized
INFO - 2016-01-05 19:23:31 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:23:31 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:23:31 --> Utf8 Class Initialized
INFO - 2016-01-05 19:23:31 --> URI Class Initialized
INFO - 2016-01-05 19:23:31 --> Router Class Initialized
INFO - 2016-01-05 19:23:31 --> Output Class Initialized
INFO - 2016-01-05 19:23:31 --> Security Class Initialized
DEBUG - 2016-01-05 19:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:23:31 --> Input Class Initialized
INFO - 2016-01-05 19:23:31 --> Language Class Initialized
INFO - 2016-01-05 19:23:31 --> Loader Class Initialized
INFO - 2016-01-05 19:23:31 --> Helper loaded: url_helper
INFO - 2016-01-05 19:23:31 --> Database Driver Class Initialized
INFO - 2016-01-05 19:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:23:31 --> Controller Class Initialized
INFO - 2016-01-05 19:23:31 --> Model Class Initialized
INFO - 2016-01-05 19:23:31 --> Model Class Initialized
INFO - 2016-01-05 19:23:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-05 19:23:31 --> Final output sent to browser
DEBUG - 2016-01-05 19:23:31 --> Total execution time: 0.1052
INFO - 2016-01-05 19:23:31 --> Config Class Initialized
INFO - 2016-01-05 19:23:31 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:23:31 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:23:31 --> Utf8 Class Initialized
INFO - 2016-01-05 19:23:31 --> URI Class Initialized
INFO - 2016-01-05 19:23:31 --> Router Class Initialized
INFO - 2016-01-05 19:23:31 --> Output Class Initialized
INFO - 2016-01-05 19:23:31 --> Security Class Initialized
DEBUG - 2016-01-05 19:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:23:31 --> Input Class Initialized
INFO - 2016-01-05 19:23:31 --> Language Class Initialized
INFO - 2016-01-05 19:23:31 --> Loader Class Initialized
INFO - 2016-01-05 19:23:31 --> Helper loaded: url_helper
INFO - 2016-01-05 19:23:31 --> Database Driver Class Initialized
INFO - 2016-01-05 19:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:23:31 --> Controller Class Initialized
DEBUG - 2016-01-05 19:23:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 19:23:31 --> Helper loaded: inflector_helper
INFO - 2016-01-05 19:23:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 19:23:31 --> Model Class Initialized
INFO - 2016-01-05 19:23:31 --> Model Class Initialized
INFO - 2016-01-05 19:23:31 --> Final output sent to browser
DEBUG - 2016-01-05 19:23:31 --> Total execution time: 0.1267
INFO - 2016-01-05 19:23:46 --> Config Class Initialized
INFO - 2016-01-05 19:23:46 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:23:46 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:23:46 --> Utf8 Class Initialized
INFO - 2016-01-05 19:23:46 --> URI Class Initialized
INFO - 2016-01-05 19:23:46 --> Router Class Initialized
INFO - 2016-01-05 19:23:46 --> Output Class Initialized
INFO - 2016-01-05 19:23:46 --> Security Class Initialized
DEBUG - 2016-01-05 19:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:23:46 --> Input Class Initialized
INFO - 2016-01-05 19:23:46 --> Language Class Initialized
INFO - 2016-01-05 19:23:46 --> Loader Class Initialized
INFO - 2016-01-05 19:23:46 --> Helper loaded: url_helper
INFO - 2016-01-05 19:23:46 --> Database Driver Class Initialized
INFO - 2016-01-05 19:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:23:46 --> Controller Class Initialized
INFO - 2016-01-05 19:23:46 --> Model Class Initialized
INFO - 2016-01-05 19:23:46 --> Model Class Initialized
INFO - 2016-01-05 19:23:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-05 19:23:46 --> Final output sent to browser
DEBUG - 2016-01-05 19:23:46 --> Total execution time: 0.1264
INFO - 2016-01-05 19:23:46 --> Config Class Initialized
INFO - 2016-01-05 19:23:46 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:23:46 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:23:46 --> Utf8 Class Initialized
INFO - 2016-01-05 19:23:46 --> URI Class Initialized
INFO - 2016-01-05 19:23:46 --> Router Class Initialized
INFO - 2016-01-05 19:23:46 --> Output Class Initialized
INFO - 2016-01-05 19:23:46 --> Security Class Initialized
DEBUG - 2016-01-05 19:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:23:46 --> Input Class Initialized
INFO - 2016-01-05 19:23:46 --> Language Class Initialized
INFO - 2016-01-05 19:23:46 --> Loader Class Initialized
INFO - 2016-01-05 19:23:46 --> Helper loaded: url_helper
INFO - 2016-01-05 19:23:46 --> Database Driver Class Initialized
INFO - 2016-01-05 19:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:23:46 --> Controller Class Initialized
INFO - 2016-01-05 19:23:46 --> Model Class Initialized
INFO - 2016-01-05 19:23:46 --> Model Class Initialized
INFO - 2016-01-05 19:23:46 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-05 19:23:46 --> Final output sent to browser
DEBUG - 2016-01-05 19:23:46 --> Total execution time: 0.1268
INFO - 2016-01-05 19:23:46 --> Config Class Initialized
INFO - 2016-01-05 19:23:46 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:23:46 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:23:46 --> Utf8 Class Initialized
INFO - 2016-01-05 19:23:46 --> URI Class Initialized
INFO - 2016-01-05 19:23:46 --> Router Class Initialized
INFO - 2016-01-05 19:23:46 --> Output Class Initialized
INFO - 2016-01-05 19:23:46 --> Security Class Initialized
DEBUG - 2016-01-05 19:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:23:46 --> Input Class Initialized
INFO - 2016-01-05 19:23:46 --> Language Class Initialized
INFO - 2016-01-05 19:23:46 --> Loader Class Initialized
INFO - 2016-01-05 19:23:46 --> Helper loaded: url_helper
INFO - 2016-01-05 19:23:46 --> Database Driver Class Initialized
INFO - 2016-01-05 19:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:23:46 --> Controller Class Initialized
DEBUG - 2016-01-05 19:23:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 19:23:46 --> Helper loaded: inflector_helper
INFO - 2016-01-05 19:23:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 19:23:46 --> Model Class Initialized
INFO - 2016-01-05 19:23:46 --> Model Class Initialized
INFO - 2016-01-05 19:23:46 --> Final output sent to browser
DEBUG - 2016-01-05 19:23:46 --> Total execution time: 0.1100
INFO - 2016-01-05 19:23:48 --> Config Class Initialized
INFO - 2016-01-05 19:23:48 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:23:48 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:23:48 --> Utf8 Class Initialized
INFO - 2016-01-05 19:23:48 --> URI Class Initialized
INFO - 2016-01-05 19:23:48 --> Router Class Initialized
INFO - 2016-01-05 19:23:48 --> Output Class Initialized
INFO - 2016-01-05 19:23:48 --> Security Class Initialized
DEBUG - 2016-01-05 19:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:23:48 --> Input Class Initialized
INFO - 2016-01-05 19:23:48 --> Language Class Initialized
INFO - 2016-01-05 19:23:48 --> Loader Class Initialized
INFO - 2016-01-05 19:23:48 --> Helper loaded: url_helper
INFO - 2016-01-05 19:23:48 --> Database Driver Class Initialized
INFO - 2016-01-05 19:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:23:48 --> Controller Class Initialized
DEBUG - 2016-01-05 19:23:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 19:23:48 --> Helper loaded: inflector_helper
INFO - 2016-01-05 19:23:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 19:23:48 --> Model Class Initialized
INFO - 2016-01-05 19:23:48 --> Model Class Initialized
INFO - 2016-01-05 19:23:48 --> Final output sent to browser
DEBUG - 2016-01-05 19:23:48 --> Total execution time: 0.1869
INFO - 2016-01-05 19:29:56 --> Config Class Initialized
INFO - 2016-01-05 19:29:56 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:29:56 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:29:56 --> Utf8 Class Initialized
INFO - 2016-01-05 19:29:56 --> URI Class Initialized
INFO - 2016-01-05 19:29:56 --> Router Class Initialized
INFO - 2016-01-05 19:29:56 --> Output Class Initialized
INFO - 2016-01-05 19:29:56 --> Security Class Initialized
DEBUG - 2016-01-05 19:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:29:56 --> Input Class Initialized
INFO - 2016-01-05 19:29:56 --> Language Class Initialized
INFO - 2016-01-05 19:29:56 --> Loader Class Initialized
INFO - 2016-01-05 19:29:56 --> Helper loaded: url_helper
INFO - 2016-01-05 19:29:56 --> Database Driver Class Initialized
INFO - 2016-01-05 19:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:29:56 --> Controller Class Initialized
INFO - 2016-01-05 19:29:56 --> Model Class Initialized
INFO - 2016-01-05 19:29:56 --> Model Class Initialized
INFO - 2016-01-05 19:29:56 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-05 19:29:56 --> Final output sent to browser
DEBUG - 2016-01-05 19:29:56 --> Total execution time: 0.1661
INFO - 2016-01-05 19:29:56 --> Config Class Initialized
INFO - 2016-01-05 19:29:56 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:29:56 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:29:56 --> Utf8 Class Initialized
INFO - 2016-01-05 19:29:56 --> URI Class Initialized
INFO - 2016-01-05 19:29:56 --> Router Class Initialized
INFO - 2016-01-05 19:29:56 --> Output Class Initialized
INFO - 2016-01-05 19:29:56 --> Security Class Initialized
DEBUG - 2016-01-05 19:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:29:56 --> Input Class Initialized
INFO - 2016-01-05 19:29:56 --> Language Class Initialized
INFO - 2016-01-05 19:29:56 --> Loader Class Initialized
INFO - 2016-01-05 19:29:56 --> Helper loaded: url_helper
INFO - 2016-01-05 19:29:56 --> Database Driver Class Initialized
INFO - 2016-01-05 19:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:29:56 --> Controller Class Initialized
INFO - 2016-01-05 19:29:56 --> Model Class Initialized
INFO - 2016-01-05 19:29:56 --> Model Class Initialized
INFO - 2016-01-05 19:29:56 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-05 19:29:56 --> Final output sent to browser
DEBUG - 2016-01-05 19:29:56 --> Total execution time: 0.1070
INFO - 2016-01-05 19:29:56 --> Config Class Initialized
INFO - 2016-01-05 19:29:56 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:29:56 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:29:56 --> Utf8 Class Initialized
INFO - 2016-01-05 19:29:56 --> URI Class Initialized
INFO - 2016-01-05 19:29:56 --> Router Class Initialized
INFO - 2016-01-05 19:29:56 --> Output Class Initialized
INFO - 2016-01-05 19:29:56 --> Security Class Initialized
DEBUG - 2016-01-05 19:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:29:56 --> Input Class Initialized
INFO - 2016-01-05 19:29:56 --> Language Class Initialized
INFO - 2016-01-05 19:29:56 --> Loader Class Initialized
INFO - 2016-01-05 19:29:56 --> Helper loaded: url_helper
INFO - 2016-01-05 19:29:56 --> Database Driver Class Initialized
INFO - 2016-01-05 19:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:29:57 --> Controller Class Initialized
DEBUG - 2016-01-05 19:29:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 19:29:57 --> Helper loaded: inflector_helper
INFO - 2016-01-05 19:29:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 19:29:57 --> Model Class Initialized
INFO - 2016-01-05 19:29:57 --> Model Class Initialized
INFO - 2016-01-05 19:29:57 --> Final output sent to browser
DEBUG - 2016-01-05 19:29:57 --> Total execution time: 0.1356
INFO - 2016-01-05 19:39:12 --> Config Class Initialized
INFO - 2016-01-05 19:39:12 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:39:12 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:39:12 --> Utf8 Class Initialized
INFO - 2016-01-05 19:39:12 --> URI Class Initialized
INFO - 2016-01-05 19:39:12 --> Router Class Initialized
INFO - 2016-01-05 19:39:12 --> Output Class Initialized
INFO - 2016-01-05 19:39:12 --> Security Class Initialized
DEBUG - 2016-01-05 19:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:39:12 --> Input Class Initialized
INFO - 2016-01-05 19:39:12 --> Language Class Initialized
INFO - 2016-01-05 19:39:12 --> Loader Class Initialized
INFO - 2016-01-05 19:39:12 --> Helper loaded: url_helper
INFO - 2016-01-05 19:39:12 --> Database Driver Class Initialized
INFO - 2016-01-05 19:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:39:12 --> Controller Class Initialized
INFO - 2016-01-05 19:39:12 --> Model Class Initialized
INFO - 2016-01-05 19:39:12 --> Model Class Initialized
INFO - 2016-01-05 19:39:12 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-05 19:39:12 --> Final output sent to browser
DEBUG - 2016-01-05 19:39:12 --> Total execution time: 0.1722
INFO - 2016-01-05 19:39:12 --> Config Class Initialized
INFO - 2016-01-05 19:39:12 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:39:12 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:39:12 --> Utf8 Class Initialized
INFO - 2016-01-05 19:39:12 --> URI Class Initialized
INFO - 2016-01-05 19:39:12 --> Router Class Initialized
INFO - 2016-01-05 19:39:12 --> Output Class Initialized
INFO - 2016-01-05 19:39:12 --> Security Class Initialized
DEBUG - 2016-01-05 19:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:39:12 --> Input Class Initialized
INFO - 2016-01-05 19:39:12 --> Language Class Initialized
INFO - 2016-01-05 19:39:12 --> Loader Class Initialized
INFO - 2016-01-05 19:39:12 --> Helper loaded: url_helper
INFO - 2016-01-05 19:39:12 --> Database Driver Class Initialized
INFO - 2016-01-05 19:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:39:12 --> Controller Class Initialized
INFO - 2016-01-05 19:39:12 --> Model Class Initialized
INFO - 2016-01-05 19:39:12 --> Model Class Initialized
INFO - 2016-01-05 19:39:12 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-05 19:39:12 --> Final output sent to browser
DEBUG - 2016-01-05 19:39:12 --> Total execution time: 0.1113
INFO - 2016-01-05 19:39:12 --> Config Class Initialized
INFO - 2016-01-05 19:39:12 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:39:12 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:39:12 --> Utf8 Class Initialized
INFO - 2016-01-05 19:39:12 --> URI Class Initialized
INFO - 2016-01-05 19:39:12 --> Router Class Initialized
INFO - 2016-01-05 19:39:12 --> Output Class Initialized
INFO - 2016-01-05 19:39:12 --> Security Class Initialized
DEBUG - 2016-01-05 19:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:39:12 --> Input Class Initialized
INFO - 2016-01-05 19:39:12 --> Language Class Initialized
INFO - 2016-01-05 19:39:12 --> Loader Class Initialized
INFO - 2016-01-05 19:39:12 --> Helper loaded: url_helper
INFO - 2016-01-05 19:39:12 --> Database Driver Class Initialized
INFO - 2016-01-05 19:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:39:13 --> Controller Class Initialized
DEBUG - 2016-01-05 19:39:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 19:39:13 --> Helper loaded: inflector_helper
INFO - 2016-01-05 19:39:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 19:39:13 --> Model Class Initialized
INFO - 2016-01-05 19:39:13 --> Model Class Initialized
INFO - 2016-01-05 19:39:13 --> Final output sent to browser
DEBUG - 2016-01-05 19:39:13 --> Total execution time: 0.1483
INFO - 2016-01-05 19:39:31 --> Config Class Initialized
INFO - 2016-01-05 19:39:31 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:39:31 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:39:31 --> Utf8 Class Initialized
INFO - 2016-01-05 19:39:31 --> URI Class Initialized
INFO - 2016-01-05 19:39:31 --> Router Class Initialized
INFO - 2016-01-05 19:39:31 --> Output Class Initialized
INFO - 2016-01-05 19:39:31 --> Security Class Initialized
DEBUG - 2016-01-05 19:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:39:31 --> Input Class Initialized
INFO - 2016-01-05 19:39:31 --> Language Class Initialized
INFO - 2016-01-05 19:39:31 --> Loader Class Initialized
INFO - 2016-01-05 19:39:31 --> Helper loaded: url_helper
INFO - 2016-01-05 19:39:31 --> Database Driver Class Initialized
INFO - 2016-01-05 19:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:39:31 --> Controller Class Initialized
DEBUG - 2016-01-05 19:39:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 19:39:31 --> Helper loaded: inflector_helper
INFO - 2016-01-05 19:39:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 19:39:31 --> Model Class Initialized
INFO - 2016-01-05 19:39:31 --> Model Class Initialized
INFO - 2016-01-05 19:39:31 --> Final output sent to browser
DEBUG - 2016-01-05 19:39:31 --> Total execution time: 0.1494
INFO - 2016-01-05 19:39:31 --> Config Class Initialized
INFO - 2016-01-05 19:39:31 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:39:31 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:39:31 --> Utf8 Class Initialized
INFO - 2016-01-05 19:39:31 --> URI Class Initialized
INFO - 2016-01-05 19:39:31 --> Router Class Initialized
INFO - 2016-01-05 19:39:31 --> Output Class Initialized
INFO - 2016-01-05 19:39:31 --> Security Class Initialized
DEBUG - 2016-01-05 19:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:39:31 --> Input Class Initialized
INFO - 2016-01-05 19:39:31 --> Language Class Initialized
INFO - 2016-01-05 19:39:31 --> Loader Class Initialized
INFO - 2016-01-05 19:39:31 --> Helper loaded: url_helper
INFO - 2016-01-05 19:39:31 --> Database Driver Class Initialized
INFO - 2016-01-05 19:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:39:31 --> Controller Class Initialized
DEBUG - 2016-01-05 19:39:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 19:39:31 --> Helper loaded: inflector_helper
INFO - 2016-01-05 19:39:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 19:39:31 --> Model Class Initialized
INFO - 2016-01-05 19:39:31 --> Model Class Initialized
INFO - 2016-01-05 19:39:31 --> Final output sent to browser
DEBUG - 2016-01-05 19:39:31 --> Total execution time: 0.1419
INFO - 2016-01-05 19:39:34 --> Config Class Initialized
INFO - 2016-01-05 19:39:34 --> Hooks Class Initialized
DEBUG - 2016-01-05 19:39:34 --> UTF-8 Support Enabled
INFO - 2016-01-05 19:39:34 --> Utf8 Class Initialized
INFO - 2016-01-05 19:39:34 --> URI Class Initialized
INFO - 2016-01-05 19:39:34 --> Router Class Initialized
INFO - 2016-01-05 19:39:34 --> Output Class Initialized
INFO - 2016-01-05 19:39:34 --> Security Class Initialized
DEBUG - 2016-01-05 19:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 19:39:34 --> Input Class Initialized
INFO - 2016-01-05 19:39:34 --> Language Class Initialized
INFO - 2016-01-05 19:39:34 --> Loader Class Initialized
INFO - 2016-01-05 19:39:34 --> Helper loaded: url_helper
INFO - 2016-01-05 19:39:34 --> Database Driver Class Initialized
INFO - 2016-01-05 19:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 19:39:34 --> Controller Class Initialized
DEBUG - 2016-01-05 19:39:34 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 19:39:34 --> Helper loaded: inflector_helper
INFO - 2016-01-05 19:39:34 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 19:39:34 --> Model Class Initialized
INFO - 2016-01-05 19:39:34 --> Model Class Initialized
INFO - 2016-01-05 19:39:34 --> Final output sent to browser
DEBUG - 2016-01-05 19:39:34 --> Total execution time: 0.1141
INFO - 2016-01-05 20:09:33 --> Config Class Initialized
INFO - 2016-01-05 20:09:33 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:09:33 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:09:33 --> Utf8 Class Initialized
INFO - 2016-01-05 20:09:33 --> URI Class Initialized
INFO - 2016-01-05 20:09:33 --> Router Class Initialized
INFO - 2016-01-05 20:09:33 --> Output Class Initialized
INFO - 2016-01-05 20:09:33 --> Security Class Initialized
DEBUG - 2016-01-05 20:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:09:33 --> Input Class Initialized
INFO - 2016-01-05 20:09:33 --> Language Class Initialized
INFO - 2016-01-05 20:09:33 --> Loader Class Initialized
INFO - 2016-01-05 20:09:33 --> Helper loaded: url_helper
INFO - 2016-01-05 20:09:33 --> Database Driver Class Initialized
INFO - 2016-01-05 20:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:09:33 --> Controller Class Initialized
INFO - 2016-01-05 20:09:33 --> Model Class Initialized
INFO - 2016-01-05 20:09:33 --> Model Class Initialized
ERROR - 2016-01-05 20:09:33 --> Severity: Notice --> Undefined variable: username /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php 30
INFO - 2016-01-05 20:09:33 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-05 20:09:33 --> Final output sent to browser
DEBUG - 2016-01-05 20:09:33 --> Total execution time: 0.1671
INFO - 2016-01-05 20:09:33 --> Config Class Initialized
INFO - 2016-01-05 20:09:33 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:09:33 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:09:33 --> Utf8 Class Initialized
INFO - 2016-01-05 20:09:33 --> URI Class Initialized
INFO - 2016-01-05 20:09:33 --> Router Class Initialized
INFO - 2016-01-05 20:09:33 --> Output Class Initialized
INFO - 2016-01-05 20:09:33 --> Security Class Initialized
DEBUG - 2016-01-05 20:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:09:33 --> Input Class Initialized
INFO - 2016-01-05 20:09:33 --> Language Class Initialized
INFO - 2016-01-05 20:09:33 --> Loader Class Initialized
INFO - 2016-01-05 20:09:33 --> Helper loaded: url_helper
INFO - 2016-01-05 20:09:33 --> Database Driver Class Initialized
INFO - 2016-01-05 20:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:09:33 --> Controller Class Initialized
INFO - 2016-01-05 20:09:33 --> Helper loaded: form_helper
INFO - 2016-01-05 20:09:33 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-05 20:09:33 --> Final output sent to browser
DEBUG - 2016-01-05 20:09:33 --> Total execution time: 0.1085
INFO - 2016-01-05 20:09:37 --> Config Class Initialized
INFO - 2016-01-05 20:09:37 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:09:37 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:09:37 --> Utf8 Class Initialized
INFO - 2016-01-05 20:09:37 --> URI Class Initialized
INFO - 2016-01-05 20:09:37 --> Router Class Initialized
INFO - 2016-01-05 20:09:37 --> Output Class Initialized
INFO - 2016-01-05 20:09:37 --> Security Class Initialized
DEBUG - 2016-01-05 20:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:09:37 --> Input Class Initialized
INFO - 2016-01-05 20:09:37 --> Language Class Initialized
INFO - 2016-01-05 20:09:37 --> Loader Class Initialized
INFO - 2016-01-05 20:09:37 --> Helper loaded: url_helper
INFO - 2016-01-05 20:09:37 --> Database Driver Class Initialized
INFO - 2016-01-05 20:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:09:37 --> Controller Class Initialized
INFO - 2016-01-05 20:09:37 --> Model Class Initialized
INFO - 2016-01-05 20:09:37 --> Model Class Initialized
INFO - 2016-01-05 20:09:37 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_home.php
INFO - 2016-01-05 20:09:37 --> Final output sent to browser
DEBUG - 2016-01-05 20:09:37 --> Total execution time: 0.1071
INFO - 2016-01-05 20:09:37 --> Config Class Initialized
INFO - 2016-01-05 20:09:37 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:09:37 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:09:37 --> Utf8 Class Initialized
INFO - 2016-01-05 20:09:37 --> URI Class Initialized
INFO - 2016-01-05 20:09:37 --> Router Class Initialized
INFO - 2016-01-05 20:09:37 --> Output Class Initialized
INFO - 2016-01-05 20:09:37 --> Security Class Initialized
DEBUG - 2016-01-05 20:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:09:37 --> Input Class Initialized
INFO - 2016-01-05 20:09:37 --> Language Class Initialized
INFO - 2016-01-05 20:09:37 --> Loader Class Initialized
INFO - 2016-01-05 20:09:37 --> Helper loaded: url_helper
INFO - 2016-01-05 20:09:37 --> Database Driver Class Initialized
INFO - 2016-01-05 20:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:09:38 --> Controller Class Initialized
INFO - 2016-01-05 20:09:38 --> Model Class Initialized
INFO - 2016-01-05 20:09:38 --> Model Class Initialized
INFO - 2016-01-05 20:09:38 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-05 20:09:38 --> Final output sent to browser
DEBUG - 2016-01-05 20:09:38 --> Total execution time: 0.1333
INFO - 2016-01-05 20:09:38 --> Config Class Initialized
INFO - 2016-01-05 20:09:38 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:09:38 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:09:38 --> Utf8 Class Initialized
INFO - 2016-01-05 20:09:38 --> URI Class Initialized
INFO - 2016-01-05 20:09:38 --> Router Class Initialized
INFO - 2016-01-05 20:09:38 --> Output Class Initialized
INFO - 2016-01-05 20:09:38 --> Security Class Initialized
DEBUG - 2016-01-05 20:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:09:38 --> Input Class Initialized
INFO - 2016-01-05 20:09:38 --> Language Class Initialized
INFO - 2016-01-05 20:09:38 --> Loader Class Initialized
INFO - 2016-01-05 20:09:38 --> Helper loaded: url_helper
INFO - 2016-01-05 20:09:38 --> Database Driver Class Initialized
INFO - 2016-01-05 20:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:09:38 --> Controller Class Initialized
DEBUG - 2016-01-05 20:09:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 20:09:38 --> Helper loaded: inflector_helper
INFO - 2016-01-05 20:09:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 20:09:38 --> Model Class Initialized
INFO - 2016-01-05 20:09:38 --> Model Class Initialized
INFO - 2016-01-05 20:09:38 --> Final output sent to browser
DEBUG - 2016-01-05 20:09:38 --> Total execution time: 0.1341
INFO - 2016-01-05 20:09:43 --> Config Class Initialized
INFO - 2016-01-05 20:09:43 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:09:43 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:09:43 --> Utf8 Class Initialized
INFO - 2016-01-05 20:09:43 --> URI Class Initialized
INFO - 2016-01-05 20:09:43 --> Router Class Initialized
INFO - 2016-01-05 20:09:43 --> Output Class Initialized
INFO - 2016-01-05 20:09:43 --> Security Class Initialized
DEBUG - 2016-01-05 20:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:09:43 --> Input Class Initialized
INFO - 2016-01-05 20:09:43 --> Language Class Initialized
INFO - 2016-01-05 20:09:43 --> Loader Class Initialized
INFO - 2016-01-05 20:09:43 --> Helper loaded: url_helper
INFO - 2016-01-05 20:09:43 --> Database Driver Class Initialized
INFO - 2016-01-05 20:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:09:43 --> Controller Class Initialized
DEBUG - 2016-01-05 20:09:43 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 20:09:43 --> Helper loaded: inflector_helper
INFO - 2016-01-05 20:09:43 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 20:09:43 --> Model Class Initialized
INFO - 2016-01-05 20:09:43 --> Model Class Initialized
INFO - 2016-01-05 20:09:43 --> Final output sent to browser
DEBUG - 2016-01-05 20:09:43 --> Total execution time: 0.1314
INFO - 2016-01-05 20:09:46 --> Config Class Initialized
INFO - 2016-01-05 20:09:46 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:09:46 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:09:46 --> Utf8 Class Initialized
INFO - 2016-01-05 20:09:46 --> URI Class Initialized
INFO - 2016-01-05 20:09:46 --> Router Class Initialized
INFO - 2016-01-05 20:09:46 --> Output Class Initialized
INFO - 2016-01-05 20:09:46 --> Security Class Initialized
DEBUG - 2016-01-05 20:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:09:46 --> Input Class Initialized
INFO - 2016-01-05 20:09:46 --> Language Class Initialized
INFO - 2016-01-05 20:09:46 --> Loader Class Initialized
INFO - 2016-01-05 20:09:46 --> Helper loaded: url_helper
INFO - 2016-01-05 20:09:46 --> Database Driver Class Initialized
INFO - 2016-01-05 20:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:09:46 --> Controller Class Initialized
DEBUG - 2016-01-05 20:09:46 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 20:09:46 --> Helper loaded: inflector_helper
INFO - 2016-01-05 20:09:46 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 20:09:46 --> Model Class Initialized
INFO - 2016-01-05 20:09:46 --> Model Class Initialized
INFO - 2016-01-05 20:09:46 --> Final output sent to browser
DEBUG - 2016-01-05 20:09:46 --> Total execution time: 0.1210
INFO - 2016-01-05 20:10:10 --> Config Class Initialized
INFO - 2016-01-05 20:10:10 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:10:10 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:10:10 --> Utf8 Class Initialized
INFO - 2016-01-05 20:10:10 --> URI Class Initialized
INFO - 2016-01-05 20:10:10 --> Router Class Initialized
INFO - 2016-01-05 20:10:10 --> Output Class Initialized
INFO - 2016-01-05 20:10:10 --> Security Class Initialized
DEBUG - 2016-01-05 20:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:10:10 --> Input Class Initialized
INFO - 2016-01-05 20:10:10 --> Language Class Initialized
INFO - 2016-01-05 20:10:10 --> Loader Class Initialized
INFO - 2016-01-05 20:10:10 --> Helper loaded: url_helper
INFO - 2016-01-05 20:10:10 --> Database Driver Class Initialized
INFO - 2016-01-05 20:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:10:10 --> Controller Class Initialized
DEBUG - 2016-01-05 20:10:10 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 20:10:10 --> Helper loaded: inflector_helper
INFO - 2016-01-05 20:10:10 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 20:10:10 --> Model Class Initialized
INFO - 2016-01-05 20:10:10 --> Model Class Initialized
INFO - 2016-01-05 20:10:10 --> Final output sent to browser
DEBUG - 2016-01-05 20:10:10 --> Total execution time: 0.0999
INFO - 2016-01-05 20:10:14 --> Config Class Initialized
INFO - 2016-01-05 20:10:14 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:10:14 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:10:14 --> Utf8 Class Initialized
INFO - 2016-01-05 20:10:14 --> URI Class Initialized
INFO - 2016-01-05 20:10:14 --> Router Class Initialized
INFO - 2016-01-05 20:10:14 --> Output Class Initialized
INFO - 2016-01-05 20:10:14 --> Security Class Initialized
DEBUG - 2016-01-05 20:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:10:14 --> Input Class Initialized
INFO - 2016-01-05 20:10:14 --> Language Class Initialized
INFO - 2016-01-05 20:10:14 --> Loader Class Initialized
INFO - 2016-01-05 20:10:14 --> Helper loaded: url_helper
INFO - 2016-01-05 20:10:14 --> Database Driver Class Initialized
INFO - 2016-01-05 20:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:10:14 --> Controller Class Initialized
DEBUG - 2016-01-05 20:10:14 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 20:10:14 --> Helper loaded: inflector_helper
INFO - 2016-01-05 20:10:14 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 20:10:14 --> Model Class Initialized
INFO - 2016-01-05 20:10:14 --> Model Class Initialized
INFO - 2016-01-05 20:10:14 --> Final output sent to browser
DEBUG - 2016-01-05 20:10:14 --> Total execution time: 0.1376
INFO - 2016-01-05 20:10:17 --> Config Class Initialized
INFO - 2016-01-05 20:10:17 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:10:17 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:10:17 --> Utf8 Class Initialized
INFO - 2016-01-05 20:10:17 --> URI Class Initialized
INFO - 2016-01-05 20:10:17 --> Router Class Initialized
INFO - 2016-01-05 20:10:17 --> Output Class Initialized
INFO - 2016-01-05 20:10:17 --> Security Class Initialized
DEBUG - 2016-01-05 20:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:10:17 --> Input Class Initialized
INFO - 2016-01-05 20:10:17 --> Language Class Initialized
INFO - 2016-01-05 20:10:17 --> Loader Class Initialized
INFO - 2016-01-05 20:10:17 --> Helper loaded: url_helper
INFO - 2016-01-05 20:10:17 --> Database Driver Class Initialized
INFO - 2016-01-05 20:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:10:17 --> Controller Class Initialized
DEBUG - 2016-01-05 20:10:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 20:10:17 --> Helper loaded: inflector_helper
INFO - 2016-01-05 20:10:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 20:10:17 --> Model Class Initialized
INFO - 2016-01-05 20:10:17 --> Model Class Initialized
INFO - 2016-01-05 20:10:17 --> Final output sent to browser
DEBUG - 2016-01-05 20:10:17 --> Total execution time: 0.0915
INFO - 2016-01-05 20:10:21 --> Config Class Initialized
INFO - 2016-01-05 20:10:21 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:10:21 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:10:21 --> Utf8 Class Initialized
INFO - 2016-01-05 20:10:21 --> URI Class Initialized
INFO - 2016-01-05 20:10:21 --> Router Class Initialized
INFO - 2016-01-05 20:10:21 --> Output Class Initialized
INFO - 2016-01-05 20:10:21 --> Security Class Initialized
DEBUG - 2016-01-05 20:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:10:21 --> Input Class Initialized
INFO - 2016-01-05 20:10:21 --> Language Class Initialized
INFO - 2016-01-05 20:10:21 --> Loader Class Initialized
INFO - 2016-01-05 20:10:21 --> Helper loaded: url_helper
INFO - 2016-01-05 20:10:21 --> Database Driver Class Initialized
INFO - 2016-01-05 20:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:10:21 --> Controller Class Initialized
DEBUG - 2016-01-05 20:10:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-05 20:10:21 --> Helper loaded: inflector_helper
INFO - 2016-01-05 20:10:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-05 20:10:21 --> Model Class Initialized
INFO - 2016-01-05 20:10:21 --> Model Class Initialized
INFO - 2016-01-05 20:10:21 --> Final output sent to browser
DEBUG - 2016-01-05 20:10:21 --> Total execution time: 0.1274
INFO - 2016-01-05 20:10:49 --> Config Class Initialized
INFO - 2016-01-05 20:10:49 --> Hooks Class Initialized
DEBUG - 2016-01-05 20:10:49 --> UTF-8 Support Enabled
INFO - 2016-01-05 20:10:49 --> Utf8 Class Initialized
INFO - 2016-01-05 20:10:49 --> URI Class Initialized
INFO - 2016-01-05 20:10:49 --> Router Class Initialized
INFO - 2016-01-05 20:10:49 --> Output Class Initialized
INFO - 2016-01-05 20:10:49 --> Security Class Initialized
DEBUG - 2016-01-05 20:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-05 20:10:49 --> Input Class Initialized
INFO - 2016-01-05 20:10:49 --> Language Class Initialized
INFO - 2016-01-05 20:10:49 --> Loader Class Initialized
INFO - 2016-01-05 20:10:49 --> Helper loaded: url_helper
INFO - 2016-01-05 20:10:49 --> Database Driver Class Initialized
INFO - 2016-01-05 20:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-05 20:10:49 --> Controller Class Initialized
INFO - 2016-01-05 20:10:49 --> Helper loaded: form_helper
INFO - 2016-01-05 20:10:49 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/admin_index.php
INFO - 2016-01-05 20:10:49 --> Final output sent to browser
DEBUG - 2016-01-05 20:10:49 --> Total execution time: 0.1314
