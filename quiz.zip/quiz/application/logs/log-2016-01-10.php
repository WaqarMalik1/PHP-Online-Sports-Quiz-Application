<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-10 00:24:10 --> Config Class Initialized
INFO - 2016-01-10 00:24:10 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:24:10 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:24:10 --> Utf8 Class Initialized
INFO - 2016-01-10 00:24:10 --> URI Class Initialized
DEBUG - 2016-01-10 00:24:10 --> No URI present. Default controller set.
INFO - 2016-01-10 00:24:10 --> Router Class Initialized
INFO - 2016-01-10 00:24:10 --> Output Class Initialized
INFO - 2016-01-10 00:24:10 --> Security Class Initialized
DEBUG - 2016-01-10 00:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:24:10 --> Input Class Initialized
INFO - 2016-01-10 00:24:10 --> Language Class Initialized
INFO - 2016-01-10 00:24:10 --> Loader Class Initialized
INFO - 2016-01-10 00:24:10 --> Helper loaded: url_helper
INFO - 2016-01-10 00:24:10 --> Database Driver Class Initialized
INFO - 2016-01-10 00:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:24:10 --> Controller Class Initialized
INFO - 2016-01-10 00:24:10 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-10 00:24:10 --> Final output sent to browser
DEBUG - 2016-01-10 00:24:10 --> Total execution time: 0.5752
INFO - 2016-01-10 00:24:15 --> Config Class Initialized
INFO - 2016-01-10 00:24:15 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:24:15 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:24:15 --> Utf8 Class Initialized
INFO - 2016-01-10 00:24:15 --> URI Class Initialized
INFO - 2016-01-10 00:24:15 --> Router Class Initialized
INFO - 2016-01-10 00:24:15 --> Output Class Initialized
INFO - 2016-01-10 00:24:15 --> Security Class Initialized
DEBUG - 2016-01-10 00:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:24:15 --> Input Class Initialized
INFO - 2016-01-10 00:24:15 --> Language Class Initialized
INFO - 2016-01-10 00:24:15 --> Loader Class Initialized
INFO - 2016-01-10 00:24:15 --> Helper loaded: url_helper
INFO - 2016-01-10 00:24:15 --> Database Driver Class Initialized
INFO - 2016-01-10 00:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:24:15 --> Controller Class Initialized
INFO - 2016-01-10 00:24:15 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-10 00:24:15 --> Final output sent to browser
DEBUG - 2016-01-10 00:24:15 --> Total execution time: 0.1257
INFO - 2016-01-10 00:24:15 --> Config Class Initialized
INFO - 2016-01-10 00:24:15 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:24:15 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:24:15 --> Utf8 Class Initialized
INFO - 2016-01-10 00:24:15 --> URI Class Initialized
INFO - 2016-01-10 00:24:15 --> Router Class Initialized
INFO - 2016-01-10 00:24:15 --> Output Class Initialized
INFO - 2016-01-10 00:24:15 --> Security Class Initialized
DEBUG - 2016-01-10 00:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:24:15 --> Input Class Initialized
INFO - 2016-01-10 00:24:15 --> Language Class Initialized
INFO - 2016-01-10 00:24:15 --> Loader Class Initialized
INFO - 2016-01-10 00:24:15 --> Helper loaded: url_helper
INFO - 2016-01-10 00:24:15 --> Database Driver Class Initialized
INFO - 2016-01-10 00:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:24:15 --> Controller Class Initialized
DEBUG - 2016-01-10 00:24:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:24:15 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:24:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:24:15 --> Model Class Initialized
INFO - 2016-01-10 00:24:15 --> Model Class Initialized
INFO - 2016-01-10 00:24:15 --> Final output sent to browser
DEBUG - 2016-01-10 00:24:15 --> Total execution time: 0.2230
INFO - 2016-01-10 00:25:16 --> Config Class Initialized
INFO - 2016-01-10 00:25:17 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:25:17 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:25:17 --> Utf8 Class Initialized
INFO - 2016-01-10 00:25:17 --> URI Class Initialized
INFO - 2016-01-10 00:25:17 --> Router Class Initialized
INFO - 2016-01-10 00:25:17 --> Output Class Initialized
INFO - 2016-01-10 00:25:17 --> Security Class Initialized
DEBUG - 2016-01-10 00:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:25:17 --> Input Class Initialized
INFO - 2016-01-10 00:25:17 --> Language Class Initialized
INFO - 2016-01-10 00:25:17 --> Loader Class Initialized
INFO - 2016-01-10 00:25:17 --> Helper loaded: url_helper
INFO - 2016-01-10 00:25:17 --> Database Driver Class Initialized
INFO - 2016-01-10 00:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:25:17 --> Controller Class Initialized
DEBUG - 2016-01-10 00:25:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:25:17 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:25:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:25:17 --> Model Class Initialized
INFO - 2016-01-10 00:25:17 --> Model Class Initialized
INFO - 2016-01-10 00:25:17 --> Final output sent to browser
DEBUG - 2016-01-10 00:25:17 --> Total execution time: 0.4261
INFO - 2016-01-10 00:30:24 --> Config Class Initialized
INFO - 2016-01-10 00:30:24 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:30:24 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:30:24 --> Utf8 Class Initialized
INFO - 2016-01-10 00:30:24 --> URI Class Initialized
INFO - 2016-01-10 00:30:24 --> Router Class Initialized
INFO - 2016-01-10 00:30:24 --> Output Class Initialized
INFO - 2016-01-10 00:30:24 --> Security Class Initialized
DEBUG - 2016-01-10 00:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:30:24 --> Input Class Initialized
INFO - 2016-01-10 00:30:24 --> Language Class Initialized
INFO - 2016-01-10 00:30:24 --> Loader Class Initialized
INFO - 2016-01-10 00:30:24 --> Helper loaded: url_helper
INFO - 2016-01-10 00:30:24 --> Database Driver Class Initialized
INFO - 2016-01-10 00:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:30:24 --> Controller Class Initialized
DEBUG - 2016-01-10 00:30:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:30:24 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:30:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:30:24 --> Model Class Initialized
INFO - 2016-01-10 00:30:24 --> Model Class Initialized
INFO - 2016-01-10 00:30:24 --> Final output sent to browser
DEBUG - 2016-01-10 00:30:24 --> Total execution time: 0.2074
INFO - 2016-01-10 00:30:31 --> Config Class Initialized
INFO - 2016-01-10 00:30:31 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:30:31 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:30:31 --> Utf8 Class Initialized
INFO - 2016-01-10 00:30:31 --> URI Class Initialized
DEBUG - 2016-01-10 00:30:31 --> No URI present. Default controller set.
INFO - 2016-01-10 00:30:31 --> Router Class Initialized
INFO - 2016-01-10 00:30:31 --> Output Class Initialized
INFO - 2016-01-10 00:30:31 --> Security Class Initialized
DEBUG - 2016-01-10 00:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:30:31 --> Input Class Initialized
INFO - 2016-01-10 00:30:31 --> Language Class Initialized
INFO - 2016-01-10 00:30:31 --> Loader Class Initialized
INFO - 2016-01-10 00:30:31 --> Helper loaded: url_helper
INFO - 2016-01-10 00:30:31 --> Database Driver Class Initialized
INFO - 2016-01-10 00:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:30:31 --> Controller Class Initialized
INFO - 2016-01-10 00:30:31 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-10 00:30:31 --> Final output sent to browser
DEBUG - 2016-01-10 00:30:31 --> Total execution time: 0.0940
INFO - 2016-01-10 00:30:36 --> Config Class Initialized
INFO - 2016-01-10 00:30:36 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:30:36 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:30:36 --> Utf8 Class Initialized
INFO - 2016-01-10 00:30:36 --> URI Class Initialized
INFO - 2016-01-10 00:30:36 --> Router Class Initialized
INFO - 2016-01-10 00:30:36 --> Output Class Initialized
INFO - 2016-01-10 00:30:36 --> Security Class Initialized
DEBUG - 2016-01-10 00:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:30:36 --> Input Class Initialized
INFO - 2016-01-10 00:30:36 --> Language Class Initialized
INFO - 2016-01-10 00:30:36 --> Loader Class Initialized
INFO - 2016-01-10 00:30:36 --> Helper loaded: url_helper
INFO - 2016-01-10 00:30:36 --> Database Driver Class Initialized
INFO - 2016-01-10 00:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:30:36 --> Controller Class Initialized
INFO - 2016-01-10 00:30:36 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-10 00:30:36 --> Final output sent to browser
DEBUG - 2016-01-10 00:30:36 --> Total execution time: 0.1373
INFO - 2016-01-10 00:30:36 --> Config Class Initialized
INFO - 2016-01-10 00:30:36 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:30:36 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:30:36 --> Utf8 Class Initialized
INFO - 2016-01-10 00:30:36 --> URI Class Initialized
INFO - 2016-01-10 00:30:36 --> Router Class Initialized
INFO - 2016-01-10 00:30:36 --> Output Class Initialized
INFO - 2016-01-10 00:30:36 --> Security Class Initialized
DEBUG - 2016-01-10 00:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:30:36 --> Input Class Initialized
INFO - 2016-01-10 00:30:36 --> Language Class Initialized
INFO - 2016-01-10 00:30:36 --> Loader Class Initialized
INFO - 2016-01-10 00:30:36 --> Helper loaded: url_helper
INFO - 2016-01-10 00:30:36 --> Database Driver Class Initialized
INFO - 2016-01-10 00:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:30:36 --> Controller Class Initialized
DEBUG - 2016-01-10 00:30:36 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:30:36 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:30:36 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:30:36 --> Model Class Initialized
INFO - 2016-01-10 00:30:36 --> Model Class Initialized
INFO - 2016-01-10 00:30:36 --> Final output sent to browser
DEBUG - 2016-01-10 00:30:36 --> Total execution time: 0.1478
INFO - 2016-01-10 00:30:41 --> Config Class Initialized
INFO - 2016-01-10 00:30:41 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:30:41 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:30:41 --> Utf8 Class Initialized
INFO - 2016-01-10 00:30:41 --> URI Class Initialized
INFO - 2016-01-10 00:30:41 --> Router Class Initialized
INFO - 2016-01-10 00:30:41 --> Output Class Initialized
INFO - 2016-01-10 00:30:41 --> Security Class Initialized
DEBUG - 2016-01-10 00:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:30:41 --> Input Class Initialized
INFO - 2016-01-10 00:30:41 --> Language Class Initialized
INFO - 2016-01-10 00:30:41 --> Loader Class Initialized
INFO - 2016-01-10 00:30:41 --> Helper loaded: url_helper
INFO - 2016-01-10 00:30:41 --> Database Driver Class Initialized
INFO - 2016-01-10 00:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:30:41 --> Controller Class Initialized
DEBUG - 2016-01-10 00:30:41 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:30:41 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:30:41 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:30:41 --> Model Class Initialized
INFO - 2016-01-10 00:30:41 --> Model Class Initialized
INFO - 2016-01-10 00:30:41 --> Final output sent to browser
DEBUG - 2016-01-10 00:30:41 --> Total execution time: 0.1710
INFO - 2016-01-10 00:30:42 --> Config Class Initialized
INFO - 2016-01-10 00:30:42 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:30:42 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:30:42 --> Utf8 Class Initialized
INFO - 2016-01-10 00:30:42 --> URI Class Initialized
INFO - 2016-01-10 00:30:42 --> Router Class Initialized
INFO - 2016-01-10 00:30:42 --> Output Class Initialized
INFO - 2016-01-10 00:30:42 --> Security Class Initialized
DEBUG - 2016-01-10 00:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:30:42 --> Input Class Initialized
INFO - 2016-01-10 00:30:42 --> Language Class Initialized
INFO - 2016-01-10 00:30:42 --> Loader Class Initialized
INFO - 2016-01-10 00:30:42 --> Helper loaded: url_helper
INFO - 2016-01-10 00:30:42 --> Database Driver Class Initialized
INFO - 2016-01-10 00:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:30:42 --> Controller Class Initialized
DEBUG - 2016-01-10 00:30:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:30:42 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:30:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:30:42 --> Model Class Initialized
INFO - 2016-01-10 00:30:42 --> Model Class Initialized
INFO - 2016-01-10 00:30:42 --> Final output sent to browser
DEBUG - 2016-01-10 00:30:42 --> Total execution time: 0.1116
INFO - 2016-01-10 00:30:48 --> Config Class Initialized
INFO - 2016-01-10 00:30:48 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:30:48 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:30:48 --> Utf8 Class Initialized
INFO - 2016-01-10 00:30:48 --> URI Class Initialized
INFO - 2016-01-10 00:30:48 --> Router Class Initialized
INFO - 2016-01-10 00:30:48 --> Output Class Initialized
INFO - 2016-01-10 00:30:48 --> Security Class Initialized
DEBUG - 2016-01-10 00:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:30:48 --> Input Class Initialized
INFO - 2016-01-10 00:30:48 --> Language Class Initialized
INFO - 2016-01-10 00:30:48 --> Loader Class Initialized
INFO - 2016-01-10 00:30:48 --> Helper loaded: url_helper
INFO - 2016-01-10 00:30:48 --> Database Driver Class Initialized
INFO - 2016-01-10 00:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:30:48 --> Controller Class Initialized
DEBUG - 2016-01-10 00:30:48 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:30:48 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:30:48 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:30:48 --> Model Class Initialized
INFO - 2016-01-10 00:30:48 --> Model Class Initialized
INFO - 2016-01-10 00:30:48 --> Final output sent to browser
DEBUG - 2016-01-10 00:30:48 --> Total execution time: 0.1112
INFO - 2016-01-10 00:30:49 --> Config Class Initialized
INFO - 2016-01-10 00:30:49 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:30:49 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:30:49 --> Utf8 Class Initialized
INFO - 2016-01-10 00:30:49 --> URI Class Initialized
INFO - 2016-01-10 00:30:49 --> Router Class Initialized
INFO - 2016-01-10 00:30:49 --> Output Class Initialized
INFO - 2016-01-10 00:30:49 --> Security Class Initialized
DEBUG - 2016-01-10 00:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:30:49 --> Input Class Initialized
INFO - 2016-01-10 00:30:49 --> Language Class Initialized
INFO - 2016-01-10 00:30:49 --> Loader Class Initialized
INFO - 2016-01-10 00:30:49 --> Helper loaded: url_helper
INFO - 2016-01-10 00:30:49 --> Database Driver Class Initialized
INFO - 2016-01-10 00:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:30:49 --> Controller Class Initialized
DEBUG - 2016-01-10 00:30:49 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:30:49 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:30:49 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:30:49 --> Model Class Initialized
INFO - 2016-01-10 00:30:49 --> Model Class Initialized
INFO - 2016-01-10 00:30:49 --> Final output sent to browser
DEBUG - 2016-01-10 00:30:49 --> Total execution time: 0.1025
INFO - 2016-01-10 00:30:54 --> Config Class Initialized
INFO - 2016-01-10 00:30:54 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:30:54 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:30:54 --> Utf8 Class Initialized
INFO - 2016-01-10 00:30:54 --> URI Class Initialized
INFO - 2016-01-10 00:30:54 --> Router Class Initialized
INFO - 2016-01-10 00:30:54 --> Output Class Initialized
INFO - 2016-01-10 00:30:54 --> Security Class Initialized
DEBUG - 2016-01-10 00:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:30:54 --> Input Class Initialized
INFO - 2016-01-10 00:30:54 --> Language Class Initialized
INFO - 2016-01-10 00:30:54 --> Loader Class Initialized
INFO - 2016-01-10 00:30:54 --> Helper loaded: url_helper
INFO - 2016-01-10 00:30:54 --> Database Driver Class Initialized
INFO - 2016-01-10 00:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:30:54 --> Controller Class Initialized
DEBUG - 2016-01-10 00:30:54 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:30:54 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:30:54 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:30:54 --> Model Class Initialized
INFO - 2016-01-10 00:30:54 --> Model Class Initialized
INFO - 2016-01-10 00:30:54 --> Final output sent to browser
DEBUG - 2016-01-10 00:30:54 --> Total execution time: 0.1585
INFO - 2016-01-10 00:30:55 --> Config Class Initialized
INFO - 2016-01-10 00:30:55 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:30:55 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:30:55 --> Utf8 Class Initialized
INFO - 2016-01-10 00:30:55 --> URI Class Initialized
INFO - 2016-01-10 00:30:55 --> Router Class Initialized
INFO - 2016-01-10 00:30:55 --> Output Class Initialized
INFO - 2016-01-10 00:30:55 --> Security Class Initialized
DEBUG - 2016-01-10 00:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:30:55 --> Input Class Initialized
INFO - 2016-01-10 00:30:55 --> Language Class Initialized
INFO - 2016-01-10 00:30:55 --> Loader Class Initialized
INFO - 2016-01-10 00:30:55 --> Helper loaded: url_helper
INFO - 2016-01-10 00:30:55 --> Database Driver Class Initialized
INFO - 2016-01-10 00:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:30:55 --> Controller Class Initialized
DEBUG - 2016-01-10 00:30:55 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:30:55 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:30:55 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:30:55 --> Model Class Initialized
INFO - 2016-01-10 00:30:55 --> Model Class Initialized
INFO - 2016-01-10 00:30:55 --> Final output sent to browser
DEBUG - 2016-01-10 00:30:55 --> Total execution time: 0.1043
INFO - 2016-01-10 00:31:12 --> Config Class Initialized
INFO - 2016-01-10 00:31:12 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:31:12 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:31:12 --> Utf8 Class Initialized
INFO - 2016-01-10 00:31:12 --> URI Class Initialized
INFO - 2016-01-10 00:31:12 --> Router Class Initialized
INFO - 2016-01-10 00:31:12 --> Output Class Initialized
INFO - 2016-01-10 00:31:12 --> Security Class Initialized
DEBUG - 2016-01-10 00:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:31:12 --> Input Class Initialized
INFO - 2016-01-10 00:31:12 --> Language Class Initialized
INFO - 2016-01-10 00:31:12 --> Loader Class Initialized
INFO - 2016-01-10 00:31:12 --> Helper loaded: url_helper
INFO - 2016-01-10 00:31:12 --> Database Driver Class Initialized
INFO - 2016-01-10 00:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:31:12 --> Controller Class Initialized
DEBUG - 2016-01-10 00:31:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:31:12 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:31:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:31:12 --> Model Class Initialized
INFO - 2016-01-10 00:31:12 --> Model Class Initialized
INFO - 2016-01-10 00:31:12 --> Final output sent to browser
DEBUG - 2016-01-10 00:31:12 --> Total execution time: 0.1576
INFO - 2016-01-10 00:31:13 --> Config Class Initialized
INFO - 2016-01-10 00:31:13 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:31:13 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:31:13 --> Utf8 Class Initialized
INFO - 2016-01-10 00:31:13 --> URI Class Initialized
INFO - 2016-01-10 00:31:13 --> Router Class Initialized
INFO - 2016-01-10 00:31:13 --> Output Class Initialized
INFO - 2016-01-10 00:31:13 --> Security Class Initialized
DEBUG - 2016-01-10 00:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:31:13 --> Input Class Initialized
INFO - 2016-01-10 00:31:13 --> Language Class Initialized
INFO - 2016-01-10 00:31:13 --> Loader Class Initialized
INFO - 2016-01-10 00:31:13 --> Helper loaded: url_helper
INFO - 2016-01-10 00:31:13 --> Database Driver Class Initialized
INFO - 2016-01-10 00:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:31:13 --> Controller Class Initialized
DEBUG - 2016-01-10 00:31:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:31:13 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:31:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:31:13 --> Model Class Initialized
INFO - 2016-01-10 00:31:13 --> Model Class Initialized
INFO - 2016-01-10 00:31:13 --> Final output sent to browser
DEBUG - 2016-01-10 00:31:13 --> Total execution time: 0.1177
INFO - 2016-01-10 00:31:19 --> Config Class Initialized
INFO - 2016-01-10 00:31:19 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:31:19 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:31:19 --> Utf8 Class Initialized
INFO - 2016-01-10 00:31:19 --> URI Class Initialized
INFO - 2016-01-10 00:31:19 --> Router Class Initialized
INFO - 2016-01-10 00:31:19 --> Output Class Initialized
INFO - 2016-01-10 00:31:19 --> Security Class Initialized
DEBUG - 2016-01-10 00:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:31:19 --> Input Class Initialized
INFO - 2016-01-10 00:31:19 --> Language Class Initialized
INFO - 2016-01-10 00:31:19 --> Loader Class Initialized
INFO - 2016-01-10 00:31:19 --> Helper loaded: url_helper
INFO - 2016-01-10 00:31:19 --> Database Driver Class Initialized
INFO - 2016-01-10 00:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:31:20 --> Controller Class Initialized
DEBUG - 2016-01-10 00:31:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:31:20 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:31:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:31:20 --> Model Class Initialized
INFO - 2016-01-10 00:31:20 --> Model Class Initialized
INFO - 2016-01-10 00:31:20 --> Final output sent to browser
DEBUG - 2016-01-10 00:31:20 --> Total execution time: 0.1306
INFO - 2016-01-10 00:31:20 --> Config Class Initialized
INFO - 2016-01-10 00:31:20 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:31:20 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:31:20 --> Utf8 Class Initialized
INFO - 2016-01-10 00:31:20 --> URI Class Initialized
INFO - 2016-01-10 00:31:20 --> Router Class Initialized
INFO - 2016-01-10 00:31:20 --> Output Class Initialized
INFO - 2016-01-10 00:31:20 --> Security Class Initialized
DEBUG - 2016-01-10 00:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:31:20 --> Input Class Initialized
INFO - 2016-01-10 00:31:20 --> Language Class Initialized
INFO - 2016-01-10 00:31:20 --> Loader Class Initialized
INFO - 2016-01-10 00:31:20 --> Helper loaded: url_helper
INFO - 2016-01-10 00:31:20 --> Database Driver Class Initialized
INFO - 2016-01-10 00:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:31:20 --> Controller Class Initialized
DEBUG - 2016-01-10 00:31:20 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:31:20 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:31:20 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:31:20 --> Model Class Initialized
INFO - 2016-01-10 00:31:20 --> Model Class Initialized
INFO - 2016-01-10 00:31:20 --> Final output sent to browser
DEBUG - 2016-01-10 00:31:20 --> Total execution time: 0.1252
INFO - 2016-01-10 00:31:29 --> Config Class Initialized
INFO - 2016-01-10 00:31:29 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:31:29 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:31:29 --> Utf8 Class Initialized
INFO - 2016-01-10 00:31:29 --> URI Class Initialized
INFO - 2016-01-10 00:31:29 --> Router Class Initialized
INFO - 2016-01-10 00:31:29 --> Output Class Initialized
INFO - 2016-01-10 00:31:29 --> Security Class Initialized
DEBUG - 2016-01-10 00:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:31:29 --> Input Class Initialized
INFO - 2016-01-10 00:31:29 --> Language Class Initialized
INFO - 2016-01-10 00:31:29 --> Loader Class Initialized
INFO - 2016-01-10 00:31:29 --> Helper loaded: url_helper
INFO - 2016-01-10 00:31:29 --> Database Driver Class Initialized
INFO - 2016-01-10 00:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:31:29 --> Controller Class Initialized
DEBUG - 2016-01-10 00:31:29 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:31:29 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:31:29 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:31:29 --> Model Class Initialized
INFO - 2016-01-10 00:31:29 --> Model Class Initialized
INFO - 2016-01-10 00:31:29 --> Final output sent to browser
DEBUG - 2016-01-10 00:31:29 --> Total execution time: 0.1828
INFO - 2016-01-10 00:31:31 --> Config Class Initialized
INFO - 2016-01-10 00:31:31 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:31:31 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:31:31 --> Utf8 Class Initialized
INFO - 2016-01-10 00:31:31 --> URI Class Initialized
INFO - 2016-01-10 00:31:31 --> Router Class Initialized
INFO - 2016-01-10 00:31:31 --> Output Class Initialized
INFO - 2016-01-10 00:31:31 --> Security Class Initialized
DEBUG - 2016-01-10 00:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:31:31 --> Input Class Initialized
INFO - 2016-01-10 00:31:31 --> Language Class Initialized
INFO - 2016-01-10 00:31:31 --> Loader Class Initialized
INFO - 2016-01-10 00:31:31 --> Helper loaded: url_helper
INFO - 2016-01-10 00:31:31 --> Database Driver Class Initialized
INFO - 2016-01-10 00:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:31:31 --> Controller Class Initialized
DEBUG - 2016-01-10 00:31:31 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:31:31 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:31:31 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:31:31 --> Model Class Initialized
INFO - 2016-01-10 00:31:31 --> Model Class Initialized
INFO - 2016-01-10 00:31:31 --> Final output sent to browser
DEBUG - 2016-01-10 00:31:31 --> Total execution time: 0.1568
INFO - 2016-01-10 00:31:49 --> Config Class Initialized
INFO - 2016-01-10 00:31:49 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:31:49 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:31:49 --> Utf8 Class Initialized
INFO - 2016-01-10 00:31:49 --> URI Class Initialized
INFO - 2016-01-10 00:31:49 --> Router Class Initialized
INFO - 2016-01-10 00:31:49 --> Output Class Initialized
INFO - 2016-01-10 00:31:49 --> Security Class Initialized
DEBUG - 2016-01-10 00:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:31:50 --> Input Class Initialized
INFO - 2016-01-10 00:31:50 --> Language Class Initialized
INFO - 2016-01-10 00:31:50 --> Loader Class Initialized
INFO - 2016-01-10 00:31:50 --> Helper loaded: url_helper
INFO - 2016-01-10 00:31:50 --> Database Driver Class Initialized
INFO - 2016-01-10 00:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:31:50 --> Controller Class Initialized
DEBUG - 2016-01-10 00:31:50 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:31:50 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:31:50 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:31:50 --> Model Class Initialized
INFO - 2016-01-10 00:31:50 --> Model Class Initialized
INFO - 2016-01-10 00:31:50 --> Final output sent to browser
DEBUG - 2016-01-10 00:31:50 --> Total execution time: 0.1689
INFO - 2016-01-10 00:31:51 --> Config Class Initialized
INFO - 2016-01-10 00:31:51 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:31:51 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:31:51 --> Utf8 Class Initialized
INFO - 2016-01-10 00:31:51 --> URI Class Initialized
INFO - 2016-01-10 00:31:51 --> Router Class Initialized
INFO - 2016-01-10 00:31:51 --> Output Class Initialized
INFO - 2016-01-10 00:31:51 --> Security Class Initialized
DEBUG - 2016-01-10 00:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:31:51 --> Input Class Initialized
INFO - 2016-01-10 00:31:51 --> Language Class Initialized
INFO - 2016-01-10 00:31:51 --> Loader Class Initialized
INFO - 2016-01-10 00:31:51 --> Helper loaded: url_helper
INFO - 2016-01-10 00:31:51 --> Database Driver Class Initialized
INFO - 2016-01-10 00:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:31:51 --> Controller Class Initialized
DEBUG - 2016-01-10 00:31:51 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:31:51 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:31:51 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:31:51 --> Model Class Initialized
INFO - 2016-01-10 00:31:51 --> Model Class Initialized
INFO - 2016-01-10 00:31:51 --> Final output sent to browser
DEBUG - 2016-01-10 00:31:51 --> Total execution time: 0.1012
INFO - 2016-01-10 00:31:56 --> Config Class Initialized
INFO - 2016-01-10 00:31:56 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:31:57 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:31:57 --> Utf8 Class Initialized
INFO - 2016-01-10 00:31:57 --> URI Class Initialized
INFO - 2016-01-10 00:31:57 --> Router Class Initialized
INFO - 2016-01-10 00:31:57 --> Output Class Initialized
INFO - 2016-01-10 00:31:57 --> Security Class Initialized
DEBUG - 2016-01-10 00:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:31:57 --> Input Class Initialized
INFO - 2016-01-10 00:31:57 --> Language Class Initialized
INFO - 2016-01-10 00:31:57 --> Loader Class Initialized
INFO - 2016-01-10 00:31:57 --> Helper loaded: url_helper
INFO - 2016-01-10 00:31:57 --> Database Driver Class Initialized
INFO - 2016-01-10 00:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:31:57 --> Controller Class Initialized
DEBUG - 2016-01-10 00:31:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:31:57 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:31:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:31:57 --> Model Class Initialized
INFO - 2016-01-10 00:31:57 --> Model Class Initialized
INFO - 2016-01-10 00:31:57 --> Final output sent to browser
DEBUG - 2016-01-10 00:31:57 --> Total execution time: 0.1674
INFO - 2016-01-10 00:31:57 --> Config Class Initialized
INFO - 2016-01-10 00:31:57 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:31:57 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:31:57 --> Utf8 Class Initialized
INFO - 2016-01-10 00:31:57 --> URI Class Initialized
INFO - 2016-01-10 00:31:57 --> Router Class Initialized
INFO - 2016-01-10 00:31:57 --> Output Class Initialized
INFO - 2016-01-10 00:31:57 --> Security Class Initialized
DEBUG - 2016-01-10 00:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:31:57 --> Input Class Initialized
INFO - 2016-01-10 00:31:57 --> Language Class Initialized
INFO - 2016-01-10 00:31:57 --> Loader Class Initialized
INFO - 2016-01-10 00:31:57 --> Helper loaded: url_helper
INFO - 2016-01-10 00:31:57 --> Database Driver Class Initialized
INFO - 2016-01-10 00:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:31:57 --> Controller Class Initialized
DEBUG - 2016-01-10 00:31:57 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:31:57 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:31:57 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:31:57 --> Model Class Initialized
INFO - 2016-01-10 00:31:57 --> Model Class Initialized
INFO - 2016-01-10 00:31:57 --> Final output sent to browser
DEBUG - 2016-01-10 00:31:57 --> Total execution time: 0.1588
INFO - 2016-01-10 00:32:02 --> Config Class Initialized
INFO - 2016-01-10 00:32:02 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:02 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:02 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:02 --> URI Class Initialized
INFO - 2016-01-10 00:32:02 --> Router Class Initialized
INFO - 2016-01-10 00:32:02 --> Output Class Initialized
INFO - 2016-01-10 00:32:02 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:02 --> Input Class Initialized
INFO - 2016-01-10 00:32:02 --> Language Class Initialized
INFO - 2016-01-10 00:32:02 --> Loader Class Initialized
INFO - 2016-01-10 00:32:02 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:02 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:02 --> Controller Class Initialized
INFO - 2016-01-10 00:32:02 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/sportsquiz.php
INFO - 2016-01-10 00:32:02 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:02 --> Total execution time: 0.0937
INFO - 2016-01-10 00:32:02 --> Config Class Initialized
INFO - 2016-01-10 00:32:02 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:02 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:02 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:02 --> URI Class Initialized
INFO - 2016-01-10 00:32:02 --> Router Class Initialized
INFO - 2016-01-10 00:32:02 --> Output Class Initialized
INFO - 2016-01-10 00:32:02 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:02 --> Input Class Initialized
INFO - 2016-01-10 00:32:02 --> Language Class Initialized
INFO - 2016-01-10 00:32:02 --> Loader Class Initialized
INFO - 2016-01-10 00:32:02 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:02 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:02 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:02 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:02 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:02 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:02 --> Model Class Initialized
INFO - 2016-01-10 00:32:02 --> Model Class Initialized
INFO - 2016-01-10 00:32:02 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:02 --> Total execution time: 0.1347
INFO - 2016-01-10 00:32:04 --> Config Class Initialized
INFO - 2016-01-10 00:32:04 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:04 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:04 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:04 --> URI Class Initialized
INFO - 2016-01-10 00:32:04 --> Router Class Initialized
INFO - 2016-01-10 00:32:04 --> Output Class Initialized
INFO - 2016-01-10 00:32:04 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:04 --> Input Class Initialized
INFO - 2016-01-10 00:32:04 --> Language Class Initialized
INFO - 2016-01-10 00:32:04 --> Loader Class Initialized
INFO - 2016-01-10 00:32:04 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:04 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:04 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:04 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:04 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:04 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:04 --> Model Class Initialized
INFO - 2016-01-10 00:32:04 --> Model Class Initialized
INFO - 2016-01-10 00:32:04 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:04 --> Total execution time: 0.1428
INFO - 2016-01-10 00:32:05 --> Config Class Initialized
INFO - 2016-01-10 00:32:05 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:05 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:05 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:05 --> URI Class Initialized
INFO - 2016-01-10 00:32:05 --> Router Class Initialized
INFO - 2016-01-10 00:32:05 --> Output Class Initialized
INFO - 2016-01-10 00:32:05 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:05 --> Input Class Initialized
INFO - 2016-01-10 00:32:05 --> Language Class Initialized
INFO - 2016-01-10 00:32:05 --> Loader Class Initialized
INFO - 2016-01-10 00:32:05 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:05 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:05 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:05 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:05 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:05 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:05 --> Model Class Initialized
INFO - 2016-01-10 00:32:05 --> Model Class Initialized
INFO - 2016-01-10 00:32:05 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:05 --> Total execution time: 0.1478
INFO - 2016-01-10 00:32:12 --> Config Class Initialized
INFO - 2016-01-10 00:32:12 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:12 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:12 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:12 --> URI Class Initialized
INFO - 2016-01-10 00:32:12 --> Router Class Initialized
INFO - 2016-01-10 00:32:12 --> Output Class Initialized
INFO - 2016-01-10 00:32:12 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:12 --> Input Class Initialized
INFO - 2016-01-10 00:32:12 --> Language Class Initialized
INFO - 2016-01-10 00:32:12 --> Loader Class Initialized
INFO - 2016-01-10 00:32:12 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:12 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:12 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:12 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:12 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:12 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:12 --> Model Class Initialized
INFO - 2016-01-10 00:32:12 --> Model Class Initialized
INFO - 2016-01-10 00:32:12 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:12 --> Total execution time: 0.1158
INFO - 2016-01-10 00:32:13 --> Config Class Initialized
INFO - 2016-01-10 00:32:13 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:13 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:13 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:13 --> URI Class Initialized
INFO - 2016-01-10 00:32:13 --> Router Class Initialized
INFO - 2016-01-10 00:32:13 --> Output Class Initialized
INFO - 2016-01-10 00:32:13 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:13 --> Input Class Initialized
INFO - 2016-01-10 00:32:13 --> Language Class Initialized
INFO - 2016-01-10 00:32:13 --> Loader Class Initialized
INFO - 2016-01-10 00:32:13 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:13 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:13 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:13 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:13 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:13 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:13 --> Model Class Initialized
INFO - 2016-01-10 00:32:13 --> Model Class Initialized
INFO - 2016-01-10 00:32:13 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:13 --> Total execution time: 0.1030
INFO - 2016-01-10 00:32:14 --> Config Class Initialized
INFO - 2016-01-10 00:32:14 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:14 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:14 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:14 --> URI Class Initialized
INFO - 2016-01-10 00:32:14 --> Router Class Initialized
INFO - 2016-01-10 00:32:14 --> Output Class Initialized
INFO - 2016-01-10 00:32:14 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:14 --> Input Class Initialized
INFO - 2016-01-10 00:32:14 --> Language Class Initialized
INFO - 2016-01-10 00:32:14 --> Loader Class Initialized
INFO - 2016-01-10 00:32:14 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:14 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:15 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:15 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:15 --> Model Class Initialized
INFO - 2016-01-10 00:32:15 --> Model Class Initialized
INFO - 2016-01-10 00:32:15 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:15 --> Total execution time: 0.1847
INFO - 2016-01-10 00:32:15 --> Config Class Initialized
INFO - 2016-01-10 00:32:15 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:15 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:15 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:15 --> URI Class Initialized
INFO - 2016-01-10 00:32:15 --> Router Class Initialized
INFO - 2016-01-10 00:32:15 --> Output Class Initialized
INFO - 2016-01-10 00:32:15 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:15 --> Input Class Initialized
INFO - 2016-01-10 00:32:15 --> Language Class Initialized
INFO - 2016-01-10 00:32:15 --> Loader Class Initialized
INFO - 2016-01-10 00:32:15 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:15 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:15 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:15 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:15 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:15 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:15 --> Model Class Initialized
INFO - 2016-01-10 00:32:15 --> Model Class Initialized
INFO - 2016-01-10 00:32:15 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:15 --> Total execution time: 0.1323
INFO - 2016-01-10 00:32:17 --> Config Class Initialized
INFO - 2016-01-10 00:32:17 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:17 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:17 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:17 --> URI Class Initialized
INFO - 2016-01-10 00:32:17 --> Router Class Initialized
INFO - 2016-01-10 00:32:17 --> Output Class Initialized
INFO - 2016-01-10 00:32:17 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:17 --> Input Class Initialized
INFO - 2016-01-10 00:32:17 --> Language Class Initialized
INFO - 2016-01-10 00:32:17 --> Loader Class Initialized
INFO - 2016-01-10 00:32:17 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:17 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:17 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:17 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:17 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:17 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:17 --> Model Class Initialized
INFO - 2016-01-10 00:32:17 --> Model Class Initialized
INFO - 2016-01-10 00:32:17 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:17 --> Total execution time: 0.1918
INFO - 2016-01-10 00:32:18 --> Config Class Initialized
INFO - 2016-01-10 00:32:18 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:18 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:18 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:18 --> URI Class Initialized
INFO - 2016-01-10 00:32:18 --> Router Class Initialized
INFO - 2016-01-10 00:32:18 --> Output Class Initialized
INFO - 2016-01-10 00:32:18 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:18 --> Input Class Initialized
INFO - 2016-01-10 00:32:18 --> Language Class Initialized
INFO - 2016-01-10 00:32:18 --> Loader Class Initialized
INFO - 2016-01-10 00:32:18 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:18 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:18 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:18 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:18 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:18 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:18 --> Model Class Initialized
INFO - 2016-01-10 00:32:18 --> Model Class Initialized
INFO - 2016-01-10 00:32:18 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:18 --> Total execution time: 0.1081
INFO - 2016-01-10 00:32:21 --> Config Class Initialized
INFO - 2016-01-10 00:32:21 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:21 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:21 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:21 --> URI Class Initialized
INFO - 2016-01-10 00:32:21 --> Router Class Initialized
INFO - 2016-01-10 00:32:21 --> Output Class Initialized
INFO - 2016-01-10 00:32:21 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:21 --> Input Class Initialized
INFO - 2016-01-10 00:32:21 --> Language Class Initialized
INFO - 2016-01-10 00:32:21 --> Loader Class Initialized
INFO - 2016-01-10 00:32:21 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:21 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:21 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:21 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:21 --> Model Class Initialized
INFO - 2016-01-10 00:32:21 --> Model Class Initialized
INFO - 2016-01-10 00:32:21 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:21 --> Total execution time: 0.1109
INFO - 2016-01-10 00:32:21 --> Config Class Initialized
INFO - 2016-01-10 00:32:21 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:21 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:21 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:21 --> URI Class Initialized
INFO - 2016-01-10 00:32:21 --> Router Class Initialized
INFO - 2016-01-10 00:32:21 --> Output Class Initialized
INFO - 2016-01-10 00:32:21 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:21 --> Input Class Initialized
INFO - 2016-01-10 00:32:21 --> Language Class Initialized
INFO - 2016-01-10 00:32:21 --> Loader Class Initialized
INFO - 2016-01-10 00:32:21 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:21 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:21 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:21 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:21 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:21 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:21 --> Model Class Initialized
INFO - 2016-01-10 00:32:21 --> Model Class Initialized
INFO - 2016-01-10 00:32:21 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:21 --> Total execution time: 0.1251
INFO - 2016-01-10 00:32:23 --> Config Class Initialized
INFO - 2016-01-10 00:32:23 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:23 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:23 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:23 --> URI Class Initialized
INFO - 2016-01-10 00:32:23 --> Router Class Initialized
INFO - 2016-01-10 00:32:23 --> Output Class Initialized
INFO - 2016-01-10 00:32:23 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:23 --> Input Class Initialized
INFO - 2016-01-10 00:32:23 --> Language Class Initialized
INFO - 2016-01-10 00:32:23 --> Loader Class Initialized
INFO - 2016-01-10 00:32:23 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:23 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:23 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:23 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:23 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:23 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:23 --> Model Class Initialized
INFO - 2016-01-10 00:32:23 --> Model Class Initialized
INFO - 2016-01-10 00:32:23 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:23 --> Total execution time: 0.1510
INFO - 2016-01-10 00:32:24 --> Config Class Initialized
INFO - 2016-01-10 00:32:24 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:24 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:24 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:24 --> URI Class Initialized
INFO - 2016-01-10 00:32:24 --> Router Class Initialized
INFO - 2016-01-10 00:32:24 --> Output Class Initialized
INFO - 2016-01-10 00:32:24 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:24 --> Input Class Initialized
INFO - 2016-01-10 00:32:24 --> Language Class Initialized
INFO - 2016-01-10 00:32:24 --> Loader Class Initialized
INFO - 2016-01-10 00:32:24 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:24 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:24 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:24 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:24 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:24 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:24 --> Model Class Initialized
INFO - 2016-01-10 00:32:24 --> Model Class Initialized
INFO - 2016-01-10 00:32:24 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:24 --> Total execution time: 0.1096
INFO - 2016-01-10 00:32:38 --> Config Class Initialized
INFO - 2016-01-10 00:32:38 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:38 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:38 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:38 --> URI Class Initialized
INFO - 2016-01-10 00:32:38 --> Router Class Initialized
INFO - 2016-01-10 00:32:38 --> Output Class Initialized
INFO - 2016-01-10 00:32:38 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:38 --> Input Class Initialized
INFO - 2016-01-10 00:32:38 --> Language Class Initialized
INFO - 2016-01-10 00:32:38 --> Loader Class Initialized
INFO - 2016-01-10 00:32:38 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:38 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:38 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:38 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:38 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:38 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:38 --> Model Class Initialized
INFO - 2016-01-10 00:32:38 --> Model Class Initialized
INFO - 2016-01-10 00:32:38 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:38 --> Total execution time: 0.1807
INFO - 2016-01-10 00:32:39 --> Config Class Initialized
INFO - 2016-01-10 00:32:39 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:39 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:39 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:39 --> URI Class Initialized
INFO - 2016-01-10 00:32:39 --> Router Class Initialized
INFO - 2016-01-10 00:32:39 --> Output Class Initialized
INFO - 2016-01-10 00:32:39 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:39 --> Input Class Initialized
INFO - 2016-01-10 00:32:39 --> Language Class Initialized
INFO - 2016-01-10 00:32:39 --> Loader Class Initialized
INFO - 2016-01-10 00:32:39 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:39 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:39 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:39 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:39 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:39 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:39 --> Model Class Initialized
INFO - 2016-01-10 00:32:39 --> Model Class Initialized
INFO - 2016-01-10 00:32:39 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:39 --> Total execution time: 0.1480
INFO - 2016-01-10 00:32:42 --> Config Class Initialized
INFO - 2016-01-10 00:32:42 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:42 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:42 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:42 --> URI Class Initialized
INFO - 2016-01-10 00:32:42 --> Router Class Initialized
INFO - 2016-01-10 00:32:42 --> Output Class Initialized
INFO - 2016-01-10 00:32:42 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:42 --> Input Class Initialized
INFO - 2016-01-10 00:32:42 --> Language Class Initialized
INFO - 2016-01-10 00:32:42 --> Loader Class Initialized
INFO - 2016-01-10 00:32:42 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:42 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:42 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:42 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:42 --> Model Class Initialized
INFO - 2016-01-10 00:32:42 --> Model Class Initialized
INFO - 2016-01-10 00:32:42 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:42 --> Total execution time: 0.1171
INFO - 2016-01-10 00:32:42 --> Config Class Initialized
INFO - 2016-01-10 00:32:42 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:42 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:42 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:42 --> URI Class Initialized
INFO - 2016-01-10 00:32:42 --> Router Class Initialized
INFO - 2016-01-10 00:32:42 --> Output Class Initialized
INFO - 2016-01-10 00:32:42 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:42 --> Input Class Initialized
INFO - 2016-01-10 00:32:42 --> Language Class Initialized
INFO - 2016-01-10 00:32:42 --> Loader Class Initialized
INFO - 2016-01-10 00:32:42 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:42 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:42 --> Controller Class Initialized
DEBUG - 2016-01-10 00:32:42 --> Config file loaded: /home/student/571/w1373571/public_html/quiz/application/config/rest.php
INFO - 2016-01-10 00:32:42 --> Helper loaded: inflector_helper
INFO - 2016-01-10 00:32:42 --> Language file loaded: language/english/rest_controller_lang.php
INFO - 2016-01-10 00:32:42 --> Model Class Initialized
INFO - 2016-01-10 00:32:42 --> Model Class Initialized
INFO - 2016-01-10 00:32:42 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:42 --> Total execution time: 0.1085
INFO - 2016-01-10 00:32:48 --> Config Class Initialized
INFO - 2016-01-10 00:32:48 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:32:48 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:32:48 --> Utf8 Class Initialized
INFO - 2016-01-10 00:32:48 --> URI Class Initialized
DEBUG - 2016-01-10 00:32:48 --> No URI present. Default controller set.
INFO - 2016-01-10 00:32:48 --> Router Class Initialized
INFO - 2016-01-10 00:32:48 --> Output Class Initialized
INFO - 2016-01-10 00:32:48 --> Security Class Initialized
DEBUG - 2016-01-10 00:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:32:48 --> Input Class Initialized
INFO - 2016-01-10 00:32:48 --> Language Class Initialized
INFO - 2016-01-10 00:32:48 --> Loader Class Initialized
INFO - 2016-01-10 00:32:48 --> Helper loaded: url_helper
INFO - 2016-01-10 00:32:48 --> Database Driver Class Initialized
INFO - 2016-01-10 00:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:32:48 --> Controller Class Initialized
INFO - 2016-01-10 00:32:48 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-10 00:32:48 --> Final output sent to browser
DEBUG - 2016-01-10 00:32:48 --> Total execution time: 0.1331
INFO - 2016-01-10 00:34:25 --> Config Class Initialized
INFO - 2016-01-10 00:34:25 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:34:25 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:34:25 --> Utf8 Class Initialized
INFO - 2016-01-10 00:34:25 --> URI Class Initialized
DEBUG - 2016-01-10 00:34:25 --> No URI present. Default controller set.
INFO - 2016-01-10 00:34:25 --> Router Class Initialized
INFO - 2016-01-10 00:34:25 --> Output Class Initialized
INFO - 2016-01-10 00:34:25 --> Security Class Initialized
DEBUG - 2016-01-10 00:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:34:25 --> Input Class Initialized
INFO - 2016-01-10 00:34:25 --> Language Class Initialized
INFO - 2016-01-10 00:34:25 --> Loader Class Initialized
INFO - 2016-01-10 00:34:25 --> Helper loaded: url_helper
INFO - 2016-01-10 00:34:25 --> Database Driver Class Initialized
INFO - 2016-01-10 00:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:34:25 --> Controller Class Initialized
INFO - 2016-01-10 00:34:25 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-10 00:34:25 --> Final output sent to browser
DEBUG - 2016-01-10 00:34:25 --> Total execution time: 0.2056
INFO - 2016-01-10 00:34:30 --> Config Class Initialized
INFO - 2016-01-10 00:34:30 --> Hooks Class Initialized
DEBUG - 2016-01-10 00:34:30 --> UTF-8 Support Enabled
INFO - 2016-01-10 00:34:30 --> Utf8 Class Initialized
INFO - 2016-01-10 00:34:30 --> URI Class Initialized
DEBUG - 2016-01-10 00:34:30 --> No URI present. Default controller set.
INFO - 2016-01-10 00:34:30 --> Router Class Initialized
INFO - 2016-01-10 00:34:30 --> Output Class Initialized
INFO - 2016-01-10 00:34:30 --> Security Class Initialized
DEBUG - 2016-01-10 00:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-10 00:34:30 --> Input Class Initialized
INFO - 2016-01-10 00:34:30 --> Language Class Initialized
INFO - 2016-01-10 00:34:30 --> Loader Class Initialized
INFO - 2016-01-10 00:34:30 --> Helper loaded: url_helper
INFO - 2016-01-10 00:34:30 --> Database Driver Class Initialized
INFO - 2016-01-10 00:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-01-10 00:34:30 --> Controller Class Initialized
INFO - 2016-01-10 00:34:30 --> File loaded: /home/student/571/w1373571/public_html/quiz/application/views/index.php
INFO - 2016-01-10 00:34:30 --> Final output sent to browser
DEBUG - 2016-01-10 00:34:30 --> Total execution time: 0.1314
